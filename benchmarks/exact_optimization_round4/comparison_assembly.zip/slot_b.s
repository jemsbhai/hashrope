	.def	@feat.00;
	.scl	3;
	.type	0;
	.endef
	.globl	@feat.00
@feat.00 = 0
	.file	"hashrope_diagnostic_slot_b.3bab2092b2acebe1-cgu.0"
	.def	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash11hash_concat17hcf04dbfad0e6d646E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash11hash_concat17hcf04dbfad0e6d646E,unique,0
	.globl	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash11hash_concat17hcf04dbfad0e6d646E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash11hash_concat17hcf04dbfad0e6d646E:
.seh_proc _ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash11hash_concat17hcf04dbfad0e6d646E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%r9, %rsi
	movq	%rdx, %rdi
	movq	%rcx, %rbx
	movq	%r8, %rdx
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE
	mulq	%rdi
	addq	%rsi, %rax
	adcq	$0, %rdx
	movq	2048(%rbx), %r8
	movl	$127, %r9d
	bsrq	%r8, %r9
	xorl	$63, %r9d
	movb	$64, %cl
	subb	%r9b, %cl
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	xorl	%r10d, %r10d
	testb	$64, %cl
	cmovneq	%rdx, %r9
	cmovneq	%r10, %rdx
	andq	%r8, %rax
	addq	%r9, %rax
	adcq	$0, %rdx
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	testb	$64, %cl
	cmovneq	%rdx, %r9
	andq	%r8, %rax
	addq	%r9, %rax
	cmpq	%rax, %r8
	cmovaq	%r10, %r8
	subq	%r8, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash11hash_repeat17h8821b48d54ad80e7E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash11hash_repeat17h8821b48d54ad80e7E,unique,1
	.globl	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash11hash_repeat17h8821b48d54ad80e7E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash11hash_repeat17h8821b48d54ad80e7E:
.seh_proc _ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash11hash_repeat17h8821b48d54ad80e7E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%r9, %rdi
	movq	%rdx, %rbx
	movq	%rcx, %rsi
	movq	%r8, %rdx
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE
	movq	2048(%rsi), %rsi
	movq	%rdi, %rcx
	movq	%rax, %rdx
	movq	%rsi, %r8
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash3phi17hc786991a0fa0b177E
	mulq	%rbx
	movl	$127, %r8d
	bsrq	%rsi, %r8
	xorl	$63, %r8d
	movb	$64, %cl
	subb	%r8b, %cl
	movq	%rdx, %r8
	shrq	%cl, %r8
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	xorl	%edx, %edx
	testb	$64, %cl
	cmovneq	%r8, %r9
	cmovneq	%rdx, %r8
	andq	%rsi, %rax
	addq	%r9, %rax
	adcq	$0, %r8
	movq	%rax, %r9
	shrdq	%cl, %r8, %r9
	shrq	%cl, %r8
	testb	$64, %cl
	cmoveq	%r9, %r8
	andq	%rsi, %rax
	addq	%r8, %rax
	cmpq	%rax, %rsi
	cmovaq	%rdx, %rsi
	subq	%rsi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash12default_hash17h41534eee8f9701f7E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash12default_hash17h41534eee8f9701f7E,unique,2
	.globl	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash12default_hash17h41534eee8f9701f7E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash12default_hash17h41534eee8f9701f7E:
.seh_proc _ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash12default_hash17h41534eee8f9701f7E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$2088, %rsp
	.seh_stackalloc 2088
	.seh_endprologue
	movq	%rcx, %rsi
	movabsq	$2305843009213693951, %rdi
	leaq	48(%rsp), %rcx
	movl	$2040, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	$1, 40(%rsp)
	movl	$1, %eax
	movl	$131, %r8d
	movabsq	$-2305843009213693951, %r9
	movl	$1, %r10d
	.p2align	4
.LBB2_1:
	mulq	%r8
	movq	%rax, %rcx
	shrq	$61, %rax
	leaq	(%rax,%rdx,8), %rax
	andq	%rdi, %rcx
	addq	%rax, %rcx
	movq	%rcx, %rax
	shrq	$61, %rax
	andq	%rdi, %rcx
	addq	%rax, %rcx
	leaq	(%rcx,%r9), %rax
	cmpq	%rdi, %rcx
	cmovbq	%rcx, %rax
	movq	%rax, 40(%rsp,%r10,8)
	incq	%r10
	cmpq	$256, %r10
	jne	.LBB2_1
	movq	%rdi, 2048(%rsi)
	movq	$131, 2056(%rsi)
	leaq	40(%rsp), %rdx
	movl	$2048, %r8d
	movq	%rsi, %rcx
	callq	memcpy
	movq	$0, 2064(%rsi)
	movq	$0, 2080(%rsi)
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$2088, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash12hash_overlap17h4751b6434bcf0c91E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash12hash_overlap17h4751b6434bcf0c91E,unique,3
	.globl	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash12hash_overlap17h4751b6434bcf0c91E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash12hash_overlap17h4751b6434bcf0c91E:
.seh_proc _ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash12hash_overlap17h4751b6434bcf0c91E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%r8, %r8
	je	.LBB3_5
	movq	%rdx, %rbx
	movq	%rcx, %rsi
	movq	128(%rsp), %r12
	movq	%r9, %rax
	orq	%r8, %rax
	shrq	$32, %rax
	je	.LBB3_2
	movq	%r9, %rax
	xorl	%edx, %edx
	divq	%r8
	movq	%rdx, %rdi
	movq	%rax, %r14
	jmp	.LBB3_4
.LBB3_2:
	movl	%r9d, %eax
	xorl	%edx, %edx
	divl	%r8d
	movl	%edx, %edi
	movl	%eax, %r14d
.LBB3_4:
	movq	%rsi, %rcx
	movq	%r8, %rdx
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE
	movq	%rax, %r15
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE
	movq	%rax, %rdi
	movq	2048(%rsi), %rsi
	movq	%r14, %rcx
	movq	%r15, %rdx
	movq	%rsi, %r8
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash3phi17hc786991a0fa0b177E
	mulq	%rbx
	movl	$127, %r8d
	bsrq	%rsi, %r8
	xorl	$63, %r8d
	movb	$64, %cl
	subb	%r8b, %cl
	movq	%rdx, %r9
	shrq	%cl, %r9
	movq	%rax, %r10
	shrdq	%cl, %rdx, %r10
	xorl	%r8d, %r8d
	testb	$64, %cl
	cmovneq	%r9, %r10
	cmovneq	%r8, %r9
	andq	%rsi, %rax
	addq	%r10, %rax
	adcq	$0, %r9
	movq	%rax, %rdx
	shrdq	%cl, %r9, %rdx
	shrq	%cl, %r9
	testb	$64, %cl
	cmoveq	%rdx, %r9
	andq	%rsi, %rax
	addq	%r9, %rax
	cmpq	%rax, %rsi
	movq	%rsi, %rdx
	cmovaq	%r8, %rdx
	subq	%rdx, %rax
	mulq	%rdi
	addq	%r12, %rax
	adcq	$0, %rdx
	movq	%rdx, %r9
	shrq	%cl, %r9
	testb	$64, %cl
	movq	%r9, %r10
	cmovneq	%r8, %r10
	movq	%rax, %r11
	shrdq	%cl, %rdx, %r11
	testb	$64, %cl
	cmovneq	%r9, %r11
	andq	%rsi, %rax
	addq	%r11, %rax
	adcq	$0, %r10
	movq	%rax, %rdx
	shrdq	%cl, %r10, %rdx
	shrq	%cl, %r10
	testb	$64, %cl
	cmoveq	%rdx, %r10
	andq	%rsi, %rax
	addq	%r10, %rax
	cmpq	%rax, %rsi
	cmovaq	%r8, %rsi
	subq	%rsi, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB3_5:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.1(%rip), %rcx
	callq	_ZN4core9panicking11panic_const23panic_const_div_by_zero17hdceffd214664eedfE
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash3new17h510463fa9e8f4baaE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash3new17h510463fa9e8f4baaE,unique,4
	.globl	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash3new17h510463fa9e8f4baaE
	.p2align	4
_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash3new17h510463fa9e8f4baaE:
.seh_proc _ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash3new17h510463fa9e8f4baaE
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$2088, %rsp
	.seh_stackalloc 2088
	.seh_endprologue
	cmpq	$2, %r8
	jb	.LBB4_5
	movq	%r8, %rdi
	movq	%rdx, %rbx
	cmpq	%rdx, %r8
	jae	.LBB4_5
	movq	%rcx, %rsi
	leaq	48(%rsp), %rcx
	xorl	%r14d, %r14d
	movl	$2040, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	$1, 40(%rsp)
	bsrq	%rbx, %rcx
	incl	%ecx
	movl	$1, %eax
	movl	$1, %r8d
	.p2align	4
.LBB4_3:
	mulq	%rdi
	movq	%rdx, %r9
	shrq	%cl, %r9
	movq	%rax, %r10
	shrdq	%cl, %rdx, %r10
	testb	$64, %cl
	cmovneq	%r9, %r10
	cmovneq	%r14, %r9
	andq	%rbx, %rax
	addq	%r10, %rax
	adcq	$0, %r9
	movq	%rax, %rdx
	shrdq	%cl, %r9, %rdx
	shrq	%cl, %r9
	testb	$64, %cl
	cmoveq	%rdx, %r9
	andq	%rbx, %rax
	addq	%r9, %rax
	cmpq	%rax, %rbx
	movq	%rbx, %rdx
	cmovaq	%r14, %rdx
	subq	%rdx, %rax
	movq	%rax, 40(%rsp,%r8,8)
	incq	%r8
	cmpq	$256, %r8
	jne	.LBB4_3
	movq	%rbx, 2048(%rsi)
	movq	%rdi, 2056(%rsi)
	leaq	40(%rsp), %rdx
	movl	$2048, %r8d
	movq	%rsi, %rcx
	callq	memcpy
	movq	$0, 2064(%rsi)
	movq	$0, 2080(%rsi)
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$2088, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.LBB4_5:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.2(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.3(%rip), %r8
	movl	$49, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash4hash17hef62f54324bd5bc8E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash4hash17hef62f54324bd5bc8E,unique,5
	.globl	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash4hash17hef62f54324bd5bc8E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash4hash17hef62f54324bd5bc8E:
.seh_proc _ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash4hash17hef62f54324bd5bc8E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	.seh_endprologue
	testq	%r8, %r8
	je	.LBB5_1
	movq	%rdx, %r9
	movabsq	$2305843009213693950, %r10
	movq	2048(%rcx), %r11
	movq	2056(%rcx), %rsi
	leaq	1(%r10), %rax
	xorq	%r11, %rax
	movq	%rsi, %rcx
	xorq	$131, %rcx
	orq	%rax, %rcx
	jne	.LBB5_4
	movabsq	$-2305843009213693951, %r11
	movl	%r8d, %ebx
	andl	$7, %ebx
	movabsq	$9223372036854775800, %rdi
	movabsq	$2305843009213693951, %rsi
	andq	%r8, %rdi
	je	.LBB5_7
	xorl	%r8d, %r8d
	movabsq	$667155411300048, %r14
	movabsq	$86730203469006241, %r15
	xorl	%eax, %eax
	.p2align	4
.LBB5_17:
	movzbl	(%r9,%r8), %ecx
	movzbl	1(%r9,%r8), %edx
	imulq	$131, %rcx, %rcx
	addq	%rdx, %rcx
	imulq	$131, %rcx, %rcx
	movzbl	2(%r9,%r8), %edx
	addq	%rcx, %rdx
	imulq	$131, %rdx, %rcx
	movzbl	3(%r9,%r8), %edx
	addq	%rcx, %rdx
	imulq	$131, %rdx, %rcx
	movzbl	4(%r9,%r8), %edx
	addq	%rcx, %rdx
	imulq	$131, %rdx, %rcx
	movzbl	5(%r9,%r8), %edx
	addq	%rcx, %rdx
	imulq	$131, %rdx, %rcx
	movzbl	6(%r9,%r8), %edx
	addq	%rcx, %rdx
	imulq	$131, %rdx, %r12
	movzbl	7(%r9,%r8), %r13d
	addq	%r14, %r13
	mulq	%r15
	movq	%rax, %rcx
	addq	%r12, %r13
	addq	%r13, %rcx
	adcq	$0, %rdx
	shldq	$3, %rcx, %rdx
	andq	%rsi, %rcx
	addq	%rdx, %rcx
	movq	%rcx, %rax
	shrq	$61, %rax
	andq	%rsi, %rcx
	addq	%rax, %rcx
	leaq	(%rcx,%r11), %rax
	cmpq	%r10, %rcx
	cmovbeq	%rcx, %rax
	addq	$8, %r8
	cmpq	%r8, %rdi
	jne	.LBB5_17
	testq	%rbx, %rbx
	jne	.LBB5_9
	jmp	.LBB5_2
.LBB5_1:
	xorl	%eax, %eax
	jmp	.LBB5_2
.LBB5_4:
	movl	$127, %ecx
	bsrq	%r11, %rcx
	xorl	$-64, %ecx
	addl	$65, %ecx
	xorl	%r10d, %r10d
	xorl	%edi, %edi
	xorl	%eax, %eax
	.p2align	4
.LBB5_5:
	movzbl	(%r9,%rdi), %ebx
	mulq	%rsi
	addq	%rbx, %rax
	adcq	$0, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rbx
	shrdq	%cl, %rdx, %rbx
	shrq	%cl, %rdx
	testb	$64, %cl
	cmovneq	%rdx, %rbx
	cmovneq	%r10, %rdx
	andq	%r11, %rax
	addq	%rbx, %rax
	adcq	$0, %rdx
	movq	%rax, %rbx
	shrdq	%cl, %rdx, %rbx
	shrq	%cl, %rdx
	testb	$64, %cl
	cmoveq	%rbx, %rdx
	andq	%r11, %rax
	addq	%rdx, %rax
	cmpq	%rax, %r11
	movq	%r11, %rdx
	cmovaq	%r10, %rdx
	subq	%rdx, %rax
	incq	%rdi
	cmpq	%rdi, %r8
	jne	.LBB5_5
	jmp	.LBB5_2
.LBB5_7:
	xorl	%eax, %eax
	testq	%rbx, %rbx
	je	.LBB5_2
.LBB5_9:
	movzbl	(%r9,%rdi), %r14d
	movl	$131, %r8d
	mulq	%r8
	movq	%rax, %rcx
	addq	%r14, %rcx
	adcl	$0, %edx
	addq	$1, %rcx
	adcl	$0, %edx
	movq	%rcx, %rax
	shrq	$61, %rax
	leaq	(%rax,%rdx,8), %rax
	andq	%rsi, %rcx
	addq	%rax, %rcx
	movq	%rcx, %rax
	shrq	$61, %rax
	andq	%rsi, %rcx
	addq	%rax, %rcx
	leaq	(%rcx,%r11), %rax
	cmpq	%r10, %rcx
	cmovbeq	%rcx, %rax
	cmpl	$1, %ebx
	je	.LBB5_2
	movzbl	1(%r9,%rdi), %r14d
	mulq	%r8
	movq	%rax, %rcx
	addq	%r14, %rcx
	adcl	$0, %edx
	addq	$1, %rcx
	adcl	$0, %edx
	movq	%rcx, %rax
	shrq	$61, %rax
	leaq	(%rax,%rdx,8), %rax
	andq	%rsi, %rcx
	addq	%rax, %rcx
	movq	%rcx, %rax
	shrq	$61, %rax
	andq	%rsi, %rcx
	addq	%rax, %rcx
	leaq	(%rcx,%r11), %rax
	cmpq	%r10, %rcx
	cmovbeq	%rcx, %rax
	cmpl	$2, %ebx
	je	.LBB5_2
	movzbl	2(%r9,%rdi), %r14d
	mulq	%r8
	movq	%rax, %rcx
	addq	%r14, %rcx
	adcl	$0, %edx
	addq	$1, %rcx
	adcl	$0, %edx
	movq	%rcx, %rax
	shrq	$61, %rax
	leaq	(%rax,%rdx,8), %rax
	andq	%rsi, %rcx
	addq	%rax, %rcx
	movq	%rcx, %rax
	shrq	$61, %rax
	andq	%rsi, %rcx
	addq	%rax, %rcx
	leaq	(%rcx,%r11), %rax
	cmpq	%r10, %rcx
	cmovbeq	%rcx, %rax
	cmpl	$3, %ebx
	je	.LBB5_2
	movzbl	3(%r9,%rdi), %r14d
	mulq	%r8
	movq	%rax, %rcx
	addq	%r14, %rcx
	adcl	$0, %edx
	addq	$1, %rcx
	adcl	$0, %edx
	movq	%rcx, %rax
	shrq	$61, %rax
	leaq	(%rax,%rdx,8), %rax
	andq	%rsi, %rcx
	addq	%rax, %rcx
	movq	%rcx, %rax
	shrq	$61, %rax
	andq	%rsi, %rcx
	addq	%rax, %rcx
	leaq	(%rcx,%r11), %rax
	cmpq	%r10, %rcx
	cmovbeq	%rcx, %rax
	cmpl	$4, %ebx
	je	.LBB5_2
	movzbl	4(%r9,%rdi), %r14d
	mulq	%r8
	movq	%rax, %rcx
	addq	%r14, %rcx
	adcl	$0, %edx
	addq	$1, %rcx
	adcl	$0, %edx
	movq	%rcx, %rax
	shrq	$61, %rax
	leaq	(%rax,%rdx,8), %rax
	andq	%rsi, %rcx
	addq	%rax, %rcx
	movq	%rcx, %rax
	shrq	$61, %rax
	andq	%rsi, %rcx
	addq	%rax, %rcx
	leaq	(%rcx,%r11), %rax
	cmpq	%r10, %rcx
	cmovbeq	%rcx, %rax
	cmpl	$5, %ebx
	je	.LBB5_2
	movzbl	5(%r9,%rdi), %r14d
	mulq	%r8
	movq	%rax, %rcx
	addq	%r14, %rcx
	adcl	$0, %edx
	addq	$1, %rcx
	adcl	$0, %edx
	movq	%rcx, %rax
	shrq	$61, %rax
	leaq	(%rax,%rdx,8), %rax
	andq	%rsi, %rcx
	addq	%rax, %rcx
	movq	%rcx, %rax
	shrq	$61, %rax
	andq	%rsi, %rcx
	addq	%rax, %rcx
	leaq	(%rcx,%r11), %rax
	cmpq	%r10, %rcx
	cmovbeq	%rcx, %rax
	cmpl	$6, %ebx
	je	.LBB5_2
	movzbl	6(%r9,%rdi), %ecx
	movl	$131, %edx
	mulq	%rdx
	addq	%rcx, %rax
	adcl	$0, %edx
	addq	$1, %rax
	adcl	$0, %edx
	movq	%rax, %rcx
	shrq	$61, %rcx
	leaq	(%rcx,%rdx,8), %rcx
	andq	%rsi, %rax
	addq	%rcx, %rax
	movq	%rax, %rcx
	shrq	$61, %rcx
	andq	%rsi, %rax
	addq	%rcx, %rax
	addq	%rax, %r11
	cmpq	%r10, %rax
	cmovbeq	%rax, %r11
	movq	%r11, %rax
.LBB5_2:
	.seh_startepilogue
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE,unique,6
	.p2align	4
_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE:
.Lfunc_begin0:
.seh_proc _ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$152, %rsp
	.seh_stackalloc 152
	leaq	128(%rsp), %rbp
	.seh_setframe %rbp, 128
	.seh_endprologue
	movq	$-2, 16(%rbp)
	cmpq	$256, %rdx
	jae	.LBB6_2
	movq	(%rcx,%rdx,8), %rsi
	jmp	.LBB6_29
.LBB6_2:
	movq	2064(%rcx), %r12
	movq	2072(%rcx), %r14
	testq	%r12, %r12
	je	.LBB6_12
	movq	%r14, %r8
	movq	%r12, %rax
.LBB6_4:
	movzwl	186(%rax), %r10d
	movl	%r10d, %r11d
	shll	$3, %r11d
	movq	$-1, %r9
	.p2align	4
.LBB6_5:
	testq	%r11, %r11
	je	.LBB6_8
	cmpq	16(%rax,%r9,8), %rdx
	seta	%bl
	sbbb	$0, %bl
	incq	%r9
	addq	$-8, %r11
	cmpb	$1, %bl
	je	.LBB6_5
	movzbl	%bl, %r10d
	testl	%r10d, %r10d
	jne	.LBB6_9
	jmp	.LBB6_11
	.p2align	4
.LBB6_8:
	movq	%r10, %r9
.LBB6_9:
	subq	$1, %r8
	jb	.LBB6_12
	movq	192(%rax,%r9,8), %rax
	jmp	.LBB6_4
.LBB6_11:
	movq	96(%rax,%r9,8), %rsi
	jmp	.LBB6_29
.LBB6_12:
	movq	2048(%rcx), %r9
	movq	%rcx, -16(%rbp)
	movq	2056(%rcx), %r8
	movl	$127, %ecx
	bsrq	%r9, %rcx
	xorl	$-64, %ecx
	addl	$65, %ecx
	movl	$1, %esi
	xorl	%r10d, %r10d
	movq	%rdx, %rbx
	movq	%rdx, %r11
	jmp	.LBB6_14
	.p2align	4
.LBB6_13:
	xorl	%edi, %edi
	imulq	%r8, %rdi
	movq	%r8, %rax
	mulq	%r8
	addq	%rdi, %rdx
	addq	%rdi, %rdx
	movq	%rax, %r8
	shrdq	%cl, %rdx, %rax
	shrq	%cl, %rdx
	testb	$64, %cl
	cmovneq	%rdx, %rax
	cmovneq	%r10, %rdx
	andq	%r9, %r8
	addq	%rax, %r8
	adcq	$0, %rdx
	movq	%r8, %rax
	shrdq	%cl, %rdx, %rax
	shrq	%cl, %rdx
	testb	$64, %cl
	cmoveq	%rax, %rdx
	andq	%r9, %r8
	addq	%rdx, %r8
	cmpq	%r8, %r9
	movq	%r9, %rax
	cmovaq	%r10, %rax
	subq	%rax, %r8
	movq	%r11, %rax
	shrq	%rax
	cmpq	$2, %r11
	movq	%rax, %r11
	jb	.LBB6_16
.LBB6_14:
	testb	$1, %r11b
	je	.LBB6_13
	movq	%rsi, %rax
	mulq	%r8
	movq	%rdx, %rdi
	shrq	%cl, %rdi
	movq	%rax, %rsi
	shrdq	%cl, %rdx, %rax
	testb	$64, %cl
	cmovneq	%rdi, %rax
	cmovneq	%r10, %rdi
	andq	%r9, %rsi
	addq	%rax, %rsi
	adcq	$0, %rdi
	movq	%rsi, %rax
	shrdq	%cl, %rdi, %rax
	shrq	%cl, %rdi
	testb	$64, %cl
	cmoveq	%rax, %rdi
	andq	%r9, %rsi
	addq	%rdi, %rsi
	cmpq	%rsi, %r9
	movq	%r9, %rax
	cmovaq	%r10, %rax
	subq	%rax, %rsi
	jmp	.LBB6_13
.LBB6_16:
	testq	%r12, %r12
	je	.LBB6_26
	movq	%r14, -88(%rbp)
	movq	%r14, %rcx
	movq	%r12, %r13
	movq	%rbx, %rax
.LBB6_18:
	leaq	8(%r13), %r15
	movzwl	186(%r13), %edi
	leal	(,%rdi,8), %edx
	movq	$-1, %r14
	.p2align	4
.LBB6_19:
	testq	%rdx, %rdx
	je	.LBB6_22
	cmpq	16(%r13,%r14,8), %rax
	seta	%r8b
	sbbb	$0, %r8b
	incq	%r14
	addq	$-8, %rdx
	cmpb	$1, %r8b
	je	.LBB6_19
	movzbl	%r8b, %edx
	testl	%edx, %edx
	jne	.LBB6_23
	jmp	.LBB6_25
.LBB6_22:
	movq	%rdi, %r14
.LBB6_23:
	subq	$1, %rcx
	jb	.LBB6_30
	movq	192(%r13,%r14,8), %r13
	jmp	.LBB6_18
.LBB6_25:
	movq	%rsi, 96(%r13,%r14,8)
	jmp	.LBB6_29
.LBB6_26:
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$192, %ecx
	movl	$8, %edx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB6_88
	movq	$0, (%rax)
	movq	-16(%rbp), %rcx
	movq	%rax, 2064(%rcx)
	movq	$0, 2072(%rcx)
	movw	$1, 186(%rax)
	movq	%rbx, 8(%rax)
	movq	%rsi, 96(%rax)
.LBB6_28:
	incq	2080(%rcx)
.LBB6_29:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$152, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.LBB6_30:
	cmpw	$11, %di
	jae	.LBB6_34
	cmpq	%r14, %rdi
	jbe	.LBB6_33
	leaq	(%r15,%r14,8), %rdx
	leaq	(%r15,%r14,8), %rcx
	addq	$8, %rcx
	movl	%edi, %r15d
	subl	%r14d, %r15d
	shll	$3, %r15d
	movq	%r15, %r8
	callq	memmove
	leaq	96(,%r14,8), %rdx
	addq	%r13, %rdx
	leaq	104(,%r14,8), %rcx
	addq	%r13, %rcx
	movq	%r15, %r8
	callq	memmove
	movq	%rbx, %rax
.LBB6_33:
	movq	%rax, 8(%r13,%r14,8)
	incl	%edi
	movq	%rsi, 96(%r13,%r14,8)
	movw	%di, 186(%r13)
	movq	-16(%rbp), %rcx
	jmp	.LBB6_28
.LBB6_34:
	cmpq	$5, %r14
	jae	.LBB6_36
	movl	$4, %edi
	movl	$0, (%rbp)
	jmp	.LBB6_41
.LBB6_36:
	je	.LBB6_39
	cmpq	$6, %r14
	jne	.LBB6_40
	movl	$5, %edi
	movb	$1, %al
	movl	%eax, (%rbp)
	xorl	%r14d, %r14d
	jmp	.LBB6_41
.LBB6_39:
	movl	$0, (%rbp)
	movq	%r14, %rdi
	jmp	.LBB6_41
.LBB6_40:
	addq	$-7, %r14
	movl	$6, %edi
	movb	$1, %al
	movl	%eax, (%rbp)
.LBB6_41:
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$192, %ecx
	movl	$8, %edx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB6_88
	movq	%rax, %rcx
	movq	$0, (%rax)
	movzwl	186(%r13), %eax
	movq	%rdi, %rdx
	notq	%rdi
	addq	%rax, %rdi
	movw	%di, 186(%rcx)
	cmpq	$12, %rdi
	movq	%rcx, -24(%rbp)
	jae	.LBB6_93
	movq	8(%r13,%rdx,8), %rax
	movq	%rax, -72(%rbp)
	movq	96(%r13,%rdx,8), %rax
	movq	%rax, -64(%rbp)
	movq	%rdx, 8(%rbp)
	leaq	(%r15,%rdx,8), %rdx
	addq	$8, %rdx
	movq	%rcx, %r15
	addq	$8, %rcx
	shlq	$3, %rdi
	movq	%rdi, %r8
	callq	memcpy
	movq	8(%rbp), %rax
	leaq	104(,%rax,8), %rdx
	addq	%r13, %rdx
	leaq	96(%r15), %rcx
	movq	%rdi, %r8
	callq	memcpy
	cmpb	$0, (%rbp)
	cmoveq	%r13, %r15
	movq	8(%rbp), %rax
	movw	%ax, 186(%r13)
	movzwl	186(%r15), %eax
	movzwl	%ax, %edi
	cmpq	%r14, %rdi
	jbe	.LBB6_45
	movl	%eax, 8(%rbp)
	leaq	8(%r15), %rax
	leaq	(%rax,%r14,8), %rdx
	leaq	(%rax,%r14,8), %rcx
	addq	$8, %rcx
	subl	%r14d, %edi
	shll	$3, %edi
	movq	%rdi, %r8
	callq	memmove
	leaq	(%r15,%r14,8), %rdx
	addq	$96, %rdx
	leaq	(%r15,%r14,8), %rcx
	addq	$104, %rcx
	movq	%rdi, %r8
	callq	memmove
	movl	8(%rbp), %eax
.LBB6_45:
	movq	%rbx, 8(%r15,%r14,8)
	incl	%eax
	movq	%rsi, 96(%r15,%r14,8)
	movw	%ax, 186(%r15)
	movq	(%r13), %rax
	testq	%rax, %rax
	je	.LBB6_73
	movq	$0, -32(%rbp)
	movq	-24(%rbp), %rdi
	jmp	.LBB6_48
.LBB6_47:
	movq	(%r13), %rax
	testq	%rax, %rax
	movq	-24(%rbp), %rdi
	je	.LBB6_74
.LBB6_48:
	movq	-64(%rbp), %rdx
	movq	-72(%rbp), %r9
	movq	%rdi, %r15
	movzwl	184(%r13), %ecx
	movq	%rax, %r13
	movzwl	%cx, %r14d
	movzwl	186(%rax), %edi
	cmpq	$11, %rdi
	movq	%r15, -80(%rbp)
	movq	%rdx, -48(%rbp)
	movq	%r9, -40(%rbp)
	movq	%rdi, -56(%rbp)
	jb	.LBB6_78
	cmpw	$5, %cx
	jae	.LBB6_51
	movq	%r14, 8(%rbp)
	movl	$4, %eax
	movq	%rax, (%rbp)
	movl	$0, -4(%rbp)
	jmp	.LBB6_56
.LBB6_51:
	je	.LBB6_54
	cmpl	$6, %r14d
	jne	.LBB6_55
	movb	$1, %al
	movl	%eax, -4(%rbp)
	movl	$5, %eax
	movq	%rax, (%rbp)
	movq	$0, 8(%rbp)
	jmp	.LBB6_56
.LBB6_54:
	movl	$0, -4(%rbp)
	movq	%r14, 8(%rbp)
	movq	%r14, (%rbp)
	jmp	.LBB6_56
.LBB6_55:
	addq	$-7, %r14
	movq	%r14, 8(%rbp)
	movb	$1, %al
	movl	%eax, -4(%rbp)
	movl	$6, %eax
	movq	%rax, (%rbp)
.LBB6_56:
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$288, %ecx
	movl	$8, %edx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB6_91
	movq	%rax, %rdi
	movq	$0, (%rdi)
	movzwl	186(%r13), %eax
	movq	(%rbp), %rcx
	movq	%rcx, %rbx
	notq	%rbx
	addq	%rax, %rbx
	movw	%bx, 186(%rdi)
	cmpq	$12, %rbx
	movq	%rdi, -24(%rbp)
	jae	.LBB6_89
	movq	%rdi, %r14
	leal	(,%rcx,8), %r15d
	movq	8(%r13,%r15), %rax
	movq	%rax, -72(%rbp)
	movq	96(%r13,%r15), %rax
	movq	%rax, -64(%rbp)
	leaq	(%r15,%r13), %rdx
	addq	$16, %rdx
	leaq	8(%rdi), %rcx
	shlq	$3, %rbx
	movq	%rbx, %r8
	callq	memcpy
	leaq	(%r15,%r13), %rdx
	addq	$104, %rdx
	leaq	96(%rdi), %rcx
	movq	%rbx, %r8
	callq	memcpy
	movq	(%rbp), %rdx
	movw	%dx, 186(%r13)
	movzwl	186(%rdi), %ebx
	leaq	1(%rbx), %r8
	cmpq	$12, %rbx
	jae	.LBB6_90
	movzwl	-56(%rbp), %eax
	subl	%edx, %eax
	cmpl	%r8d, %eax
	jne	.LBB6_92
	incq	-32(%rbp)
	leaq	192(%rdi), %rcx
	leaq	200(,%rdx,8), %rdx
	addq	%r13, %rdx
	shll	$3, %r8d
	callq	memcpy
	xorl	%eax, %eax
	.p2align	4
.LBB6_61:
	movq	%rax, %rcx
	cmpq	%rbx, %rax
	adcq	$0, %rax
	movq	192(%r14,%rcx,8), %rdx
	movq	%r14, (%rdx)
	movw	%cx, 184(%rdx)
	cmpq	%rbx, %rcx
	jae	.LBB6_63
	cmpq	%rbx, %rax
	jbe	.LBB6_61
.LBB6_63:
	cmpb	$0, -4(%rbp)
	cmoveq	%r13, %rdi
	movzwl	186(%rdi), %r14d
	movq	8(%rbp), %r8
	leaq	1(%r8), %r15
	movq	%r14, %r10
	subq	%r8, %r10
	jbe	.LBB6_65
	leaq	8(%rdi), %rax
	leaq	(%rdi,%r8,8), %rdx
	addq	$8, %rdx
	leaq	(%rax,%r15,8), %rcx
	movl	%r14d, %ebx
	subl	%r8d, %ebx
	shll	$3, %ebx
	movq	%rbx, %r8
	movq	%r10, (%rbp)
	callq	memmove
	movq	8(%rbp), %rax
	leaq	(%rdi,%rax,8), %rdx
	addq	$96, %rdx
	leaq	(%rdi,%r15,8), %rcx
	addq	$96, %rcx
	movq	%rbx, %r8
	callq	memmove
	movq	8(%rbp), %rax
	movq	-40(%rbp), %rcx
	movq	%rcx, 8(%rdi,%rax,8)
	movq	8(%rbp), %rax
	movq	-48(%rbp), %rcx
	movq	%rcx, 96(%rdi,%rax,8)
	leaq	192(%rdi,%r15,8), %rdx
	movq	8(%rbp), %rax
	leaq	(%rdi,%rax,8), %rcx
	addq	$208, %rcx
	movq	%rbx, %r8
	callq	memmove
	movq	(%rbp), %r10
	movq	8(%rbp), %r8
	jmp	.LBB6_66
.LBB6_65:
	movq	-40(%rbp), %rax
	movq	%rax, 8(%rdi,%r8,8)
	movq	-48(%rbp), %rax
	movq	%rax, 96(%rdi,%r8,8)
.LBB6_66:
	leal	1(%r14), %ecx
	leaq	2(%r14), %rax
	movq	-80(%rbp), %rdx
	movq	%rdx, 200(%rdi,%r8,8)
	movw	%cx, 186(%rdi)
	cmpq	%rax, %r15
	jae	.LBB6_47
	subl	%r8d, %r14d
	incl	%r14d
	andl	$3, %r14d
	je	.LBB6_71
	leaq	(%rdi,%r8,8), %rdx
	addq	$200, %rdx
	xorl	%ecx, %ecx
	.p2align	4
.LBB6_69:
	movq	(%rdx,%rcx,8), %r8
	movq	%rdi, (%r8)
	leal	(%r15,%rcx), %r9d
	movw	%r9w, 184(%r8)
	incq	%rcx
	cmpq	%rcx, %r14
	jne	.LBB6_69
	addq	%rcx, %r15
.LBB6_71:
	cmpq	$3, %r10
	jb	.LBB6_47
	.p2align	4
.LBB6_72:
	movq	192(%rdi,%r15,8), %rcx
	movq	%rdi, (%rcx)
	movw	%r15w, 184(%rcx)
	movq	200(%rdi,%r15,8), %rcx
	movq	%rdi, (%rcx)
	leal	1(%r15), %edx
	movw	%dx, 184(%rcx)
	movq	208(%rdi,%r15,8), %rcx
	movq	%rdi, (%rcx)
	leal	2(%r15), %edx
	movw	%dx, 184(%rcx)
	movq	216(%rdi,%r15,8), %rcx
	movq	%rdi, (%rcx)
	leal	3(%r15), %edx
	movw	%dx, 184(%rcx)
	addq	$4, %r15
	cmpq	%rax, %r15
	jne	.LBB6_72
	jmp	.LBB6_47
.LBB6_73:
	movq	$0, -32(%rbp)
	movq	-24(%rbp), %rdi
.LBB6_74:
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$288, %ecx
	movl	$8, %edx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB6_94
	movq	%rax, %r8
	movq	$0, (%rax)
	movw	$0, 186(%rax)
	movq	%r12, 192(%rax)
	movq	-88(%rbp), %rdx
	movq	%rdx, %rax
	incq	%rax
	movq	-16(%rbp), %rcx
	je	.LBB6_95
	movq	%r8, (%r12)
	movw	$0, 184(%r12)
	movq	%r8, 2064(%rcx)
	movq	%rax, 2072(%rcx)
	cmpq	%rdx, -32(%rbp)
	jne	.LBB6_97
	movw	$1, 186(%r8)
	movq	-72(%rbp), %rax
	movq	%rax, 8(%r8)
	movq	-64(%rbp), %rax
	movq	%rax, 96(%r8)
	movq	%rdi, 200(%r8)
	movq	%r8, (%rdi)
	movw	$1, 184(%rdi)
	jmp	.LBB6_28
.LBB6_78:
	leal	1(%rdi), %r10d
	leaq	1(%r14), %rbx
	cmpw	%di, %cx
	jae	.LBB6_80
	leaq	8(%r13), %rcx
	leaq	8(,%r14,8), %rdx
	addq	%r13, %rdx
	leal	(,%rbx,8), %r15d
	addq	%r15, %rcx
	movq	-56(%rbp), %rdi
	subq	%r14, %rdi
	shlq	$3, %rdi
	movq	%rdi, %r8
	movl	%r10d, 8(%rbp)
	callq	memmove
	leal	(,%r14,8), %r12d
	leaq	(%r12,%r13), %rdx
	addq	$96, %rdx
	leaq	(%r15,%r13), %rcx
	addq	$96, %rcx
	movq	%rdi, %r8
	callq	memmove
	movq	-40(%rbp), %rax
	movq	%rax, 8(%r13,%r12)
	movq	-48(%rbp), %rax
	movq	%rax, 96(%r13,%r12)
	leaq	192(%r13,%r15), %rdx
	movq	-80(%rbp), %r15
	leaq	(%r12,%r13), %rcx
	addq	$208, %rcx
	movq	%rdi, %r8
	movq	-56(%rbp), %rdi
	callq	memmove
	movl	8(%rbp), %r10d
	jmp	.LBB6_81
.LBB6_80:
	movq	%r9, 8(%r13,%r14,8)
	movq	%rdx, 96(%r13,%r14,8)
.LBB6_81:
	movq	-16(%rbp), %rcx
	leaq	2(%rdi), %rax
	movq	%r15, 200(%r13,%r14,8)
	movw	%r10w, 186(%r13)
	cmpl	%eax, %ebx
	jae	.LBB6_28
	movl	%edi, %edx
	subl	%r14d, %edx
	incl	%edx
	subq	%r14, %rdi
	andl	$3, %edx
	je	.LBB6_86
	leaq	200(,%r14,8), %r9
	addq	%r13, %r9
	xorl	%r8d, %r8d
.LBB6_84:
	movq	(%r9,%r8,8), %r10
	movq	%r13, (%r10)
	leal	(%rbx,%r8), %r11d
	movw	%r11w, 184(%r10)
	incq	%r8
	cmpq	%r8, %rdx
	jne	.LBB6_84
	addq	%r8, %rbx
.LBB6_86:
	cmpq	$3, %rdi
	jb	.LBB6_28
.LBB6_87:
	movq	192(%r13,%rbx,8), %rdx
	movq	%r13, (%rdx)
	movw	%bx, 184(%rdx)
	movq	200(%r13,%rbx,8), %rdx
	movq	%r13, (%rdx)
	leal	1(%rbx), %r8d
	movw	%r8w, 184(%rdx)
	movq	208(%r13,%rbx,8), %rdx
	movq	%r13, (%rdx)
	leal	2(%rbx), %r8d
	movw	%r8w, 184(%rdx)
	movq	216(%r13,%rbx,8), %rdx
	movq	%r13, (%rdx)
	leal	3(%rbx), %r8d
	movw	%r8w, 184(%rdx)
	addq	$4, %rbx
	cmpq	%rax, %rbx
	jne	.LBB6_87
	jmp	.LBB6_28
.LBB6_88:
	movl	$8, %ecx
	movl	$192, %edx
	callq	_ZN5alloc5alloc18handle_alloc_error17h6942ce664312655aE
.LBB6_89:
.Ltmp2:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.102(%rip), %r9
	movl	$11, %r8d
	xorl	%ecx, %ecx
	movq	%rbx, %rdx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.Ltmp3:
	jmp	.LBB6_96
.LBB6_90:
.Ltmp4:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.103(%rip), %r9
	movq	%r8, %rdx
	movl	$12, %r8d
	xorl	%ecx, %ecx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.Ltmp5:
	jmp	.LBB6_96
.LBB6_91:
	movl	$8, %ecx
	movl	$288, %edx
	callq	_ZN5alloc5alloc18handle_alloc_error17h6942ce664312655aE
.LBB6_92:
.Ltmp6:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.100(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.101(%rip), %r8
	movl	$40, %edx
	callq	_ZN4core9panicking5panic17hc5fbe615138639caE
.Ltmp7:
	jmp	.LBB6_96
.LBB6_93:
.Ltmp0:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.102(%rip), %r9
	movl	$11, %r8d
	xorl	%ecx, %ecx
	movq	%rdi, %rdx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.Ltmp1:
	jmp	.LBB6_96
.LBB6_94:
.Ltmp10:
	movl	$8, %ecx
	movl	$288, %edx
	callq	_ZN5alloc5alloc18handle_alloc_error17h6942ce664312655aE
.Ltmp11:
	jmp	.LBB6_96
.LBB6_95:
.Ltmp8:
	movq	%r8, -16(%rbp)
	leaq	anon.831c2442e46e5e41962cfb504544efb1.99(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.Ltmp9:
.LBB6_96:
	ud2
.LBB6_97:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.97(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.98(%rip), %r8
	movl	$48, %edx
	callq	_ZN4core9panicking5panic17hc5fbe615138639caE
	int3
	.seh_handlerdata
	.long	$cppxdata$_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE@IMGREL
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE,unique,6
	.seh_endproc
	.def	"?dtor$98@?0?_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$98@?0?_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE@4HA":
.seh_proc "?dtor$98@?0?_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE@4HA"
.LBB6_98:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	128(%rdx), %rbp
	.seh_endprologue
	movl	$288, %edx
	movl	$8, %r8d
	movq	-16(%rbp), %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE,unique,6
	.seh_endproc
	.def	"?dtor$99@?0?_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$99@?0?_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE@4HA":
.seh_proc "?dtor$99@?0?_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE@4HA"
.LBB6_99:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	128(%rdx), %rbp
	.seh_endprologue
	ud2
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE,unique,6
	.seh_endproc
	.def	"?dtor$100@?0?_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$100@?0?_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE@4HA":
.seh_proc "?dtor$100@?0?_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE@4HA"
.LBB6_100:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	128(%rdx), %rbp
	.seh_endprologue
	movl	$192, %edx
	movl	$8, %r8d
	movq	-24(%rbp), %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE,unique,6
	.seh_endproc
	.def	"?dtor$101@?0?_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$101@?0?_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE@4HA":
.seh_proc "?dtor$101@?0?_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE@4HA"
.LBB6_101:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	128(%rdx), %rbp
	.seh_endprologue
	movl	$288, %edx
	movl	$8, %r8d
	movq	-24(%rbp), %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.Lfunc_end0:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE,unique,6
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE,unique,0
	.p2align	2, 0x0
$cppxdata$_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE:
	.long	429065506
	.long	4
	.long	$stateUnwindMap$_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE@IMGREL
	.long	0
	.long	0
	.long	8
	.long	$ip2state$_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE@IMGREL
	.long	144
	.long	0
	.long	1
$stateUnwindMap$_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE:
	.long	-1
	.long	"?dtor$100@?0?_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE@4HA"@IMGREL
	.long	-1
	.long	"?dtor$99@?0?_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE@4HA"@IMGREL
	.long	1
	.long	"?dtor$98@?0?_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE@4HA"@IMGREL
	.long	-1
	.long	"?dtor$101@?0?_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE@4HA"@IMGREL
$ip2state$_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE:
	.long	.Lfunc_begin0@IMGREL
	.long	-1
	.long	.Ltmp2@IMGREL+1
	.long	3
	.long	.Ltmp5@IMGREL+1
	.long	-1
	.long	.Ltmp6@IMGREL+1
	.long	3
	.long	.Ltmp0@IMGREL+1
	.long	0
	.long	.Ltmp10@IMGREL+1
	.long	1
	.long	.Ltmp8@IMGREL+1
	.long	2
	.long	.Ltmp9@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE,unique,6

	.def	_ZN26hashrope_diagnostic_slot_b15polynomial_hash3phi17hc786991a0fa0b177E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b15polynomial_hash3phi17hc786991a0fa0b177E,unique,7
	.globl	_ZN26hashrope_diagnostic_slot_b15polynomial_hash3phi17hc786991a0fa0b177E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b15polynomial_hash3phi17hc786991a0fa0b177E:
.seh_proc _ZN26hashrope_diagnostic_slot_b15polynomial_hash3phi17hc786991a0fa0b177E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	.seh_endprologue
	movq	%rcx, %r9
	cmpq	$1, %rcx
	ja	.LBB7_3
	movq	%r9, %r11
.LBB7_2:
	movq	%r11, %rax
	.seh_startepilogue
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB7_3:
	movq	%rdx, %r10
	bsrq	%r9, %r14
	movl	$127, %ecx
	bsrq	%r8, %rcx
	xorl	$-64, %ecx
	addl	$65, %ecx
	decl	%r14d
	movl	$1, %r11d
	xorl	%r15d, %r15d
	movq	%rdx, %rbx
	jmp	.LBB7_4
	.p2align	4
.LBB7_6:
	movq	%rax, %rbx
	addl	$-1, %r14d
	jae	.LBB7_2
.LBB7_4:
	movq	%rbx, %rax
	mulq	%rbx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	shrdq	%cl, %rdx, %rax
	shrq	%cl, %rsi
	testb	$64, %cl
	cmovneq	%rsi, %rax
	cmovneq	%r15, %rsi
	andq	%r8, %rdi
	addq	%rax, %rdi
	adcq	$0, %rsi
	movq	%rdi, %rax
	shrdq	%cl, %rsi, %rax
	shrq	%cl, %rsi
	testb	$64, %cl
	cmoveq	%rax, %rsi
	xorl	%eax, %eax
	incq	%rbx
	sete	%al
	movq	%rax, %rdx
	shrq	%cl, %rdx
	testb	$64, %cl
	movq	%rdx, %r12
	cmovneq	%r15, %r12
	movq	%rbx, %r13
	shrdq	%cl, %rax, %r13
	testb	$64, %cl
	cmovneq	%rdx, %r13
	andq	%r8, %rbx
	addq	%r13, %rbx
	adcq	$0, %r12
	movq	%rbx, %rax
	shrdq	%cl, %r12, %rax
	shrq	%cl, %r12
	testb	$64, %cl
	cmoveq	%rax, %r12
	andq	%r8, %rbx
	addq	%r12, %rbx
	cmpq	%rbx, %r8
	movq	%r8, %rax
	cmovaq	%r15, %rax
	subq	%rax, %rbx
	movq	%rbx, %rax
	mulq	%r11
	movq	%rdx, %rbx
	shrq	%cl, %rbx
	testb	$64, %cl
	movq	%rbx, %r12
	cmovneq	%r15, %r12
	movq	%rax, %r11
	movq	%rdi, %rax
	movq	%r11, %rdi
	shrdq	%cl, %rdx, %rdi
	testb	$64, %cl
	cmovneq	%rbx, %rdi
	andq	%r8, %r11
	addq	%rdi, %r11
	adcq	$0, %r12
	movq	%r11, %rdx
	shrdq	%cl, %r12, %rdx
	shrq	%cl, %r12
	testb	$64, %cl
	cmoveq	%rdx, %r12
	andq	%r8, %r11
	addq	%r12, %r11
	cmpq	%r11, %r8
	movq	%r8, %rdx
	cmovaq	%r15, %rdx
	subq	%rdx, %r11
	andq	%r8, %rax
	addq	%rsi, %rax
	cmpq	%rax, %r8
	movq	%r8, %rdx
	cmovaq	%r15, %rdx
	subq	%rdx, %rax
	btq	%r14, %r9
	jae	.LBB7_6
	mulq	%r10
	movq	%rdx, %rsi
	movq	%rax, %rdi
	shrdq	%cl, %rdx, %rax
	shrq	%cl, %rsi
	testb	$64, %cl
	cmovneq	%rsi, %rax
	cmovneq	%r15, %rsi
	andq	%r8, %rdi
	addq	%rax, %rdi
	adcq	$0, %rsi
	movq	%rdi, %rax
	shrdq	%cl, %rsi, %rax
	shrq	%cl, %rsi
	testb	$64, %cl
	cmoveq	%rax, %rsi
	movq	%r11, %rax
	mulq	%r10
	movq	%rdx, %rbx
	shrq	%cl, %rbx
	testb	$64, %cl
	movq	%rbx, %r12
	cmovneq	%r15, %r12
	movq	%rax, %r11
	movq	%rdi, %rax
	movq	%r11, %rdi
	shrdq	%cl, %rdx, %rdi
	testb	$64, %cl
	cmovneq	%rbx, %rdi
	andq	%r8, %r11
	addq	%rdi, %r11
	adcq	$0, %r12
	movq	%r11, %rdx
	shrdq	%cl, %r12, %rdx
	shrq	%cl, %r12
	testb	$64, %cl
	cmoveq	%rdx, %r12
	andq	%r8, %r11
	addq	%r12, %r11
	cmpq	%r11, %r8
	movq	%r8, %rdx
	cmovaq	%r15, %rdx
	subq	%rdx, %r11
	xorl	%edx, %edx
	incq	%r11
	sete	%dl
	movq	%rdx, %rdi
	shrq	%cl, %rdi
	testb	$64, %cl
	movq	%rdi, %rbx
	cmovneq	%r15, %rbx
	movq	%r11, %r12
	shrdq	%cl, %rdx, %r12
	testb	$64, %cl
	cmovneq	%rdi, %r12
	andq	%r8, %r11
	addq	%r12, %r11
	adcq	$0, %rbx
	movq	%r11, %rdx
	shrdq	%cl, %rbx, %rdx
	shrq	%cl, %rbx
	testb	$64, %cl
	cmoveq	%rdx, %rbx
	andq	%r8, %r11
	addq	%rbx, %r11
	cmpq	%r11, %r8
	movq	%r8, %rdx
	cmovaq	%r15, %rdx
	subq	%rdx, %r11
	andq	%r8, %rax
	addq	%rsi, %rax
	cmpq	%rax, %r8
	movq	%r8, %rdx
	cmovaq	%r15, %rdx
	subq	%rdx, %rax
	jmp	.LBB7_6
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope13ExactFrontier6expand17h8dcc5442a36d207eE;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope13ExactFrontier6expand17h8dcc5442a36d207eE,unique,8
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope13ExactFrontier6expand17h8dcc5442a36d207eE:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope13ExactFrontier6expand17h8dcc5442a36d207eE
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movl	776(%rcx), %eax
	cmpq	%rax, %r8
	jbe	.LBB8_14
	leaq	(%rax,%rax,2), %r9
	shlq	$4, %r9
	cmpl	$1, (%rdx,%r9)
	jne	.LBB8_13
	addq	%rdx, %r9
	movl	4(%r9), %eax
	cmpq	%rax, %r8
	jbe	.LBB8_15
	movl	8(%r9), %r8d
	leaq	(%rax,%rax,2), %r9
	shlq	$4, %r9
	leaq	(%rdx,%r9), %r10
	xorl	%r11d, %r11d
	cmpl	$0, (%rdx,%r9)
	setne	%r11b
	movq	16(%r10,%r11,8), %rdx
	movq	768(%rcx), %r9
	movq	%r9, %r10
	subq	%rdx, %r10
	jae	.LBB8_8
	subq	%r9, %rdx
	movq	784(%rcx), %r10
	subq	%rdx, %r10
	jbe	.LBB8_11
	movq	792(%rcx), %r9
	cmpq	$32, %r9
	jne	.LBB8_9
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB8_8:
	movl	%r8d, 776(%rcx)
	movq	%r10, 768(%rcx)
	movb	$1, %al
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB8_9:
	jae	.LBB8_16
	leaq	(%r9,%r9,2), %r9
	movq	$0, (%rcx,%r9,8)
	movl	%r8d, 8(%rcx,%r9,8)
	movq	%r10, 16(%rcx,%r9,8)
	incq	792(%rcx)
	movq	%rdx, 784(%rcx)
.LBB8_11:
	movl	%eax, 776(%rcx)
	movb	$1, %al
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB8_13:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.8(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.9(%rip), %r8
	movl	$40, %edx
	callq	_ZN4core9panicking5panic17hc5fbe615138639caE
.LBB8_14:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.5(%rip), %r9
	movq	%rax, %rcx
	movq	%r8, %rdx
	movq	%r9, %r8
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB8_15:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r9
	movq	%rax, %rcx
	movq	%r8, %rdx
	movq	%r9, %r8
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB8_16:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.7(%rip), %r8
	movl	$32, %edx
	movq	%r9, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope14FastComparison13lcp_recursive17h4081b43ed8af9caaE;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope14FastComparison13lcp_recursive17h4081b43ed8af9caaE,unique,9
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope14FastComparison13lcp_recursive17h4081b43ed8af9caaE:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope14FastComparison13lcp_recursive17h4081b43ed8af9caaE
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$152, %rsp
	.seh_stackalloc 152
	.seh_endprologue
	movq	%r9, 104(%rsp)
	movq	%rdx, 80(%rsp)
	movq	264(%rsp), %rdx
	testq	%rdx, %rdx
	je	.LBB9_55
	movl	256(%rsp), %esi
	xorl	%r11d, %r11d
.LBB9_2:
	movzbl	24(%rcx), %ebx
	cmpl	%esi, %r8d
	sete	%al
	movq	80(%rsp), %r9
	cmpq	104(%rsp), %r9
	sete	%r10b
	andb	%al, %r10b
	andb	%bl, %r10b
	cmpb	$1, %r10b
	je	.LBB9_56
	movq	16(%rcx), %r10
	movl	$1, %eax
	testq	%r10, %r10
	je	.LBB9_63
	movb	%bl, 67(%rsp)
	movl	%esi, 68(%rsp)
	movq	%r11, 72(%rsp)
	subq	%r11, %rdx
	movq	%rdx, 120(%rsp)
	movq	(%rcx), %rdx
	movq	8(%rdx), %rax
	movq	16(%rdx), %rdx
	movl	$1, %r15d
	subq	%r10, %r15
	movl	$2, %r11d
	subq	%r10, %r11
	jmp	.LBB9_7
	.p2align	4
.LBB9_5:
	movl	8(%r12), %ebx
	movq	%rsi, 80(%rsp)
	movq	%rbp, %rdx
.LBB9_6:
	incq	%r15
	incq	%r11
	movl	%ebx, %r8d
	cmpq	$1, %r15
	je	.LBB9_58
.LBB9_7:
	movl	%r8d, %edi
	cmpq	%rdi, %rdx
	jbe	.LBB9_93
	leaq	(%rdi,%rdi,2), %r13
	shlq	$4, %r13
	leaq	(%rax,%r13), %r12
	movl	(%rax,%r13), %r14d
	cmpl	$1, %r14d
	jne	.LBB9_12
	movl	4(%r12), %ebx
	movq	%rdx, %rbp
	cmpq	%rbx, %rdx
	jbe	.LBB9_94
	leaq	(%rbx,%rbx,2), %rdx
	shlq	$4, %rdx
	leaq	(%rax,%rdx), %r10
	xorl	%esi, %esi
	cmpl	$0, (%rax,%rdx)
	setne	%sil
	movq	16(%r10,%rsi,8), %r10
	movq	80(%rsp), %rdx
	movq	%rdx, %rsi
	subq	%r10, %rsi
	jae	.LBB9_5
	subq	%rdx, %r10
	cmpq	%r10, 120(%rsp)
	movq	%rbp, %rdx
	jbe	.LBB9_6
	jmp	.LBB9_13
	.p2align	4
.LBB9_12:
	testl	%r14d, %r14d
	jne	.LBB9_57
.LBB9_13:
	negq	%r15
	movq	%r15, 16(%rcx)
	jae	.LBB9_61
	movq	%rdx, 136(%rsp)
	movq	%rcx, 96(%rsp)
	movq	8(%rcx), %rdx
	movq	8(%rdx), %rcx
	movq	%rcx, 128(%rsp)
	movq	16(%rdx), %rbp
	movl	68(%rsp), %edx
	movl	%r8d, 60(%rsp)
	jmp	.LBB9_17
	.p2align	4
.LBB9_15:
	movq	112(%rsp), %rdx
	movl	8(%rdx), %r15d
	movq	%rbp, 104(%rsp)
	movq	%r9, %rbp
.LBB9_16:
	incq	%r11
	movl	%r15d, %edx
	cmpq	$1, %r11
	je	.LBB9_60
.LBB9_17:
	movl	%edx, %r10d
	cmpq	%r10, %rbp
	jbe	.LBB9_95
	movl	%edx, 68(%rsp)
	leaq	(%r10,%r10,2), %rsi
	shlq	$4, %rsi
	movq	128(%rsp), %r8
	leaq	(%r8,%rsi), %rdx
	movl	(%r8,%rsi), %ebx
	cmpl	$1, %ebx
	movq	%rdx, 112(%rsp)
	movl	%ebx, 92(%rsp)
	jne	.LBB9_22
	movq	80(%rsp), %rcx
	movl	4(%rdx), %r15d
	movq	%rbp, %r9
	cmpq	%r15, %rbp
	jbe	.LBB9_96
	leaq	(%r15,%r15,2), %rbx
	shlq	$4, %rbx
	movq	128(%rsp), %r8
	leaq	(%r8,%rbx), %rbp
	xorl	%edx, %edx
	cmpl	$0, (%r8,%rbx)
	setne	%dl
	movq	16(%rbp,%rdx,8), %rbx
	movq	104(%rsp), %rdx
	movq	%rdx, %rbp
	subq	%rbx, %rbp
	jae	.LBB9_15
	subq	%rdx, %rbx
	cmpq	%rbx, 120(%rsp)
	movq	%rcx, %rdx
	movq	%r9, %rbp
	jbe	.LBB9_16
	jmp	.LBB9_23
.LBB9_22:
	testl	%ebx, %ebx
	movq	80(%rsp), %rdx
	jne	.LBB9_59
.LBB9_23:
	negq	%r11
	movq	104(%rsp), %rbx
	movq	96(%rsp), %rcx
	movq	%r11, 16(%rcx)
	movl	60(%rsp), %ecx
	cmpl	68(%rsp), %ecx
	sete	%cl
	movq	%rdx, %r15
	cmpq	%rbx, %rdx
	sete	%dl
	andb	%cl, %dl
	testb	%dl, 67(%rsp)
	jne	.LBB9_64
	movq	%rbx, %r11
	movq	%rbp, %rbx
	cmpl	$2, %r14d
	movq	264(%rsp), %rcx
	movq	%r10, 144(%rsp)
	je	.LBB9_27
	cmpl	$1, %r14d
	movq	120(%rsp), %r9
	movq	136(%rsp), %rdx
	jne	.LBB9_30
	movl	4(%r12), %ecx
	cmpq	%rcx, %rdx
	ja	.LBB9_28
	jmp	.LBB9_104
.LBB9_27:
	movl	4(%r12), %ecx
	movq	136(%rsp), %rdx
	cmpq	%rcx, %rdx
	movq	120(%rsp), %r9
	jbe	.LBB9_104
.LBB9_28:
	leaq	(%rcx,%rcx,2), %rdx
	shlq	$4, %rdx
	leaq	(%rax,%rdx), %rcx
	movl	(%rax,%rdx), %eax
	testl	%eax, %eax
	movl	92(%rsp), %r10d
	je	.LBB9_32
	cmpl	$1, %eax
	movq	%r15, %rbp
	movl	60(%rsp), %r8d
	addq	$24, %rcx
	movq	(%rcx), %r15
	subq	%rbp, %r15
	testl	%r10d, %r10d
	jne	.LBB9_33
	jmp	.LBB9_36
.LBB9_30:
	movl	92(%rsp), %r10d
	testl	%r10d, %r10d
	movq	%r15, %rbp
	je	.LBB9_67
	movq	16(%r12), %r15
	subq	%rbp, %r15
	movl	60(%rsp), %r8d
	jmp	.LBB9_33
.LBB9_32:
	addq	$16, %rcx
	movq	%r15, %rbp
	movl	60(%rsp), %r8d
	movq	(%rcx), %r15
	subq	%rbp, %r15
	testl	%r10d, %r10d
	je	.LBB9_36
.LBB9_33:
	movq	112(%rsp), %rax
	movl	4(%rax), %ecx
	cmpq	%rcx, %rbx
	jbe	.LBB9_103
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	movq	128(%rsp), %rdx
	leaq	(%rdx,%rcx), %rax
	movl	(%rdx,%rcx), %ecx
	testl	%ecx, %ecx
	je	.LBB9_37
	cmpl	$1, %ecx
	addq	$24, %rax
	jmp	.LBB9_38
.LBB9_36:
	movq	112(%rsp), %rax
	addq	$16, %rax
	jmp	.LBB9_38
.LBB9_37:
	addq	$16, %rax
.LBB9_38:
	movq	(%rax), %rax
	subq	%r11, %rax
	cmpq	%r15, %rax
	movq	%r15, %rbx
	movq	%rax, 128(%rsp)
	cmovbq	%rax, %r15
	cmpq	%r15, %r9
	cmovbq	%r9, %r15
	movl	%r8d, %eax
	cmpl	$1, %r14d
	jne	.LBB9_40
	movl	4(%r12), %eax
.LBB9_40:
	movl	68(%rsp), %ecx
	cmpl	$1, %r10d
	jne	.LBB9_42
	movq	112(%rsp), %rcx
	movl	4(%rcx), %ecx
.LBB9_42:
	movq	%r15, 40(%rsp)
	movl	%ecx, 32(%rsp)
	movq	96(%rsp), %rcx
	movq	%rcx, %r12
	movq	%rbp, %rdx
	movl	%eax, %r8d
	movq	%r11, %r9
	callq	_ZN26hashrope_diagnostic_slot_b4rope14FastComparison13lcp_recursive17h4081b43ed8af9caaE
	testb	$1, %al
	jne	.LBB9_65
	cmpq	%r15, %rdx
	jne	.LBB9_66
	movq	(%r12), %rax
	movq	16(%rax), %rdx
	cmpq	%rdi, %rdx
	jbe	.LBB9_101
	movq	%r12, %r10
	cmpq	%rbx, %r15
	movq	264(%rsp), %rdx
	movq	%rbp, 80(%rsp)
	movl	60(%rsp), %r8d
	movq	144(%rsp), %rcx
	jne	.LBB9_48
	movq	8(%rax), %rax
	cmpl	$1, (%rax,%r13)
	jne	.LBB9_48
	addq	%r13, %rax
	movl	8(%rax), %r8d
	movq	$0, 80(%rsp)
	jmp	.LBB9_49
.LBB9_48:
	addq	%r15, 80(%rsp)
.LBB9_49:
	movq	72(%rsp), %r11
	movq	8(%r10), %r9
	movq	16(%r9), %rax
	cmpq	%rcx, %rax
	jbe	.LBB9_102
	cmpq	128(%rsp), %r15
	jne	.LBB9_53
	movq	8(%r9), %rax
	cmpl	$1, (%rax,%rsi)
	jne	.LBB9_53
	addq	%rsi, %rax
	movl	8(%rax), %eax
	movl	%eax, 68(%rsp)
	movq	$0, 104(%rsp)
	jmp	.LBB9_54
.LBB9_53:
	addq	%r15, 104(%rsp)
.LBB9_54:
	addq	%r15, %r11
	cmpq	%rdx, %r11
	movq	%r10, %rcx
	movl	68(%rsp), %esi
	jb	.LBB9_2
	jmp	.LBB9_56
.LBB9_55:
	xorl	%edx, %edx
.LBB9_56:
	xorl	%eax, %eax
	jmp	.LBB9_62
.LBB9_57:
	negq	%r15
	movq	%r15, 16(%rcx)
	jmp	.LBB9_61
.LBB9_58:
	movq	$0, 16(%rcx)
	jmp	.LBB9_61
.LBB9_59:
	negq	%r11
	movq	96(%rsp), %rax
	movq	%r11, 16(%rax)
	jmp	.LBB9_61
.LBB9_60:
	movq	96(%rsp), %rax
	movq	$0, 16(%rax)
.LBB9_61:
	movq	72(%rsp), %rdx
	movl	$1, %eax
.LBB9_62:
	.seh_startepilogue
	addq	$152, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB9_63:
	movq	%r11, %rdx
	jmp	.LBB9_62
.LBB9_64:
	xorl	%eax, %eax
	movq	264(%rsp), %rdx
	jmp	.LBB9_62
.LBB9_65:
	movl	$1, %eax
	addq	72(%rsp), %rdx
	jmp	.LBB9_62
.LBB9_66:
	xorl	%eax, %eax
	addq	72(%rsp), %rdx
	jmp	.LBB9_62
.LBB9_67:
	movq	40(%r12), %rax
	movq	%rax, %r8
	subq	%rbp, %r8
	jb	.LBB9_98
	cmpq	%r8, %r9
	movq	112(%rsp), %r10
	ja	.LBB9_97
	movq	40(%r10), %rax
	movq	%rax, %r8
	subq	%r11, %r8
	jb	.LBB9_99
	cmpq	%r8, %r9
	ja	.LBB9_100
	movq	%rcx, %rsi
	addq	32(%r12), %rbp
	addq	32(%r10), %r11
	movq	%rbp, %rdi
	movq	%rbp, %rcx
	movq	%r11, %rbx
	movq	%r11, %rdx
	movq	%r9, %r8
	movq	%r9, %r14
	callq	memcmp
	testl	%eax, %eax
	je	.LBB9_76
	movabsq	$9223372036854775800, %rax
	andq	%r14, %rax
	movq	$-8, %r8
	movq	%r14, %r9
	movq	%rbx, %rcx
	movq	72(%rsp), %rsi
.LBB9_73:
	cmpq	$7, %r9
	jbe	.LBB9_77
	movq	8(%rdi,%r8), %r10
	movq	8(%rcx,%r8), %r11
	addq	$8, %r8
	addq	$-8, %r9
	cmpq	%r11, %r10
	je	.LBB9_73
	xorq	%r10, %r11
	rep		bsfq	%r11, %rdx
	shrl	$3, %edx
	addq	%r8, %rdx
	addq	%rsi, %rdx
	jmp	.LBB9_56
.LBB9_76:
	xorl	%eax, %eax
	movq	%rsi, %rdx
	jmp	.LBB9_62
.LBB9_77:
	movq	120(%rsp), %r9
	andq	$7, %r9
	je	.LBB9_105
	movzbl	(%rdi,%rax), %r8d
	cmpb	(%rcx,%rax), %r8b
	jne	.LBB9_92
	cmpl	$1, %r9d
	je	.LBB9_105
	movzbl	1(%rdi,%rax), %r8d
	movl	$1, %edx
	cmpb	1(%rcx,%rax), %r8b
	jne	.LBB9_91
	cmpl	$2, %r9d
	je	.LBB9_105
	movzbl	2(%rdi,%rax), %r8d
	movl	$2, %edx
	cmpb	2(%rcx,%rax), %r8b
	jne	.LBB9_91
	cmpl	$3, %r9d
	je	.LBB9_105
	movzbl	3(%rdi,%rax), %r8d
	movl	$3, %edx
	cmpb	3(%rcx,%rax), %r8b
	jne	.LBB9_91
	cmpl	$4, %r9d
	je	.LBB9_105
	movzbl	4(%rdi,%rax), %r8d
	movl	$4, %edx
	cmpb	4(%rcx,%rax), %r8b
	jne	.LBB9_91
	cmpl	$5, %r9d
	je	.LBB9_105
	movzbl	5(%rdi,%rax), %r8d
	movl	$5, %edx
	cmpb	5(%rcx,%rax), %r8b
	jne	.LBB9_91
	cmpl	$6, %r9d
	je	.LBB9_105
	movzbl	6(%rdi,%rax), %r8d
	movl	$6, %edx
	cmpb	6(%rcx,%rax), %r8b
	je	.LBB9_105
.LBB9_91:
	orq	%rax, %rdx
	addq	%rsi, %rdx
	jmp	.LBB9_56
.LBB9_92:
	xorl	%edx, %edx
	orq	%rax, %rdx
	addq	%rsi, %rdx
	jmp	.LBB9_56
.LBB9_93:
	negq	%r15
	movq	%r15, 16(%rcx)
	leaq	anon.831c2442e46e5e41962cfb504544efb1.23(%rip), %r8
	movq	%rdi, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB9_94:
	negq	%r15
	movq	%r15, 16(%rcx)
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%rbx, %rcx
	movq	%rbp, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB9_95:
	negq	%r11
	movq	96(%rsp), %rax
	movq	%r11, 16(%rax)
	leaq	anon.831c2442e46e5e41962cfb504544efb1.23(%rip), %r8
	movq	%r10, %rcx
	movq	%rbp, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB9_96:
	negq	%r11
	movq	96(%rsp), %rax
	movq	%r11, 16(%rax)
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%r15, %rcx
	movq	%r9, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB9_97:
	movq	%r9, %rdx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.19(%rip), %r9
	xorl	%ecx, %ecx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB9_98:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.20(%rip), %r9
	movq	%rbp, %rcx
	movq	%rax, %rdx
	movq	%rax, %r8
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB9_99:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.18(%rip), %r9
	movq	%r11, %rcx
	movq	%rax, %rdx
	movq	%rax, %r8
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB9_100:
	movq	%r9, %rdx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.17(%rip), %r9
	xorl	%ecx, %ecx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB9_101:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.21(%rip), %r8
	movq	%rdi, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB9_102:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.22(%rip), %r8
	movq	%rax, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB9_103:
	movq	%rbx, %rdx
.LBB9_104:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB9_105:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.36(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope15ExactComparison3lcp17h975f105586598874E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope15ExactComparison3lcp17h975f105586598874E,unique,10
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope15ExactComparison3lcp17h975f105586598874E:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope15ExactComparison3lcp17h975f105586598874E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	%rdx, %r10
	movq	168(%rsp), %rsi
	testq	%rsi, %rsi
	je	.LBB10_4
	movq	(%rcx), %r11
	movq	16(%r11), %rax
	movl	%r8d, %edx
	cmpq	%rdx, %rax
	jbe	.LBB10_5
	movl	160(%rsp), %edi
	movq	8(%r11), %r14
	leaq	(%rdx,%rdx,2), %rdx
	shlq	$4, %rdx
	leaq	(%r14,%rdx), %r12
	movl	(%r14,%rdx), %r13d
	cmpl	$1, %r13d
	je	.LBB10_6
	cmpl	$2, %r13d
	je	.LBB10_7
	jmp	.LBB10_4
.LBB10_6:
	movl	4(%r12), %edx
	cmpl	8(%r12), %edx
	jne	.LBB10_4
.LBB10_7:
	movq	8(%rcx), %rbx
	movq	16(%rbx), %rdx
	movl	%edi, %r11d
	cmpq	%r11, %rdx
	jbe	.LBB10_10
	movq	8(%rbx), %rbx
	leaq	(%r11,%r11,2), %r11
	shlq	$4, %r11
	leaq	(%rbx,%r11), %r15
	movl	(%rbx,%r11), %ebp
	cmpl	$1, %ebp
	je	.LBB10_11
	cmpl	$2, %ebp
	je	.LBB10_12
	jmp	.LBB10_4
.LBB10_11:
	movl	4(%r15), %r11d
	cmpl	8(%r15), %r11d
	jne	.LBB10_4
.LBB10_12:
	movl	4(%r12), %r11d
	cmpl	$1, %r13d
	jne	.LBB10_14
	cmpl	8(%r12), %r11d
	je	.LBB10_14
	leaq	anon.831c2442e46e5e41962cfb504544efb1.25(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
	.p2align	4
.LBB10_20:
	movl	4(%r11), %r13d
	cmpl	8(%r11), %r13d
	jne	.LBB10_21
.LBB10_18:
	movl	%r13d, %r11d
.LBB10_14:
	cmpq	%r11, %rax
	jbe	.LBB10_19
	leaq	(%r11,%r11,2), %r12
	shlq	$4, %r12
	leaq	(%r14,%r12), %r11
	movl	(%r14,%r12), %r12d
	cmpl	$1, %r12d
	je	.LBB10_20
	cmpl	$2, %r12d
	jne	.LBB10_21
	movl	4(%r11), %r13d
	jmp	.LBB10_18
.LBB10_21:
	xorl	%eax, %eax
	testl	%r12d, %r12d
	setne	%al
	movq	16(%r11,%rax,8), %r11
	cmpl	$1, %ebp
	je	.LBB10_24
	cmpl	$2, %ebp
	jne	.LBB10_38
	movl	4(%r15), %eax
	jmp	.LBB10_25
.LBB10_24:
	movl	4(%r15), %eax
	cmpl	8(%r15), %eax
	jne	.LBB10_38
.LBB10_25:
	movl	%eax, %eax
	jmp	.LBB10_26
	.p2align	4
.LBB10_32:
	movl	4(%rax), %r14d
	cmpl	8(%rax), %r14d
	jne	.LBB10_33
.LBB10_30:
	movl	%r14d, %eax
.LBB10_26:
	cmpq	%rax, %rdx
	jbe	.LBB10_31
	leaq	(%rax,%rax,2), %r14
	shlq	$4, %r14
	leaq	(%rbx,%r14), %rax
	movl	(%rbx,%r14), %ebp
	cmpl	$1, %ebp
	je	.LBB10_32
	cmpl	$2, %ebp
	jne	.LBB10_33
	movl	4(%rax), %r14d
	jmp	.LBB10_30
.LBB10_33:
	xorl	%edx, %edx
	testl	%ebp, %ebp
	setne	%dl
	movq	16(%rax,%rdx,8), %rbx
	movq	%r11, %r14
	testq	%rbx, %rbx
	je	.LBB10_39
	movq	%rbx, %rdx
	movq	%r11, %rax
	jmp	.LBB10_35
	.p2align	4
.LBB10_41:
	xorl	%edx, %edx
	divq	%r14
	movq	%r14, %rax
	testq	%rdx, %rdx
	je	.LBB10_39
.LBB10_35:
	movq	%rdx, %r14
	movq	%rax, %rdx
	orq	%r14, %rdx
	shrq	$32, %rdx
	jne	.LBB10_41
	xorl	%edx, %edx
	divl	%r14d
	movq	%r14, %rax
	testq	%rdx, %rdx
	jne	.LBB10_35
.LBB10_39:
	subq	%r14, %rbx
	addq	%rbx, %r11
	movq	$-1, %rbx
	cmovaeq	%r11, %rbx
	cmpq	%rsi, %rbx
	jae	.LBB10_4
	movq	%rbx, 40(%rsp)
	movl	%edi, 32(%rsp)
	movq	%r10, %rdx
	callq	_ZN26hashrope_diagnostic_slot_b4rope15ExactComparison9lcp_inner17h1a8c569200e6a126E
	cmpq	%rbx, %rax
	cmoveq	%rsi, %rax
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB10_4:
	movq	%r10, %rdx
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	jmp	_ZN26hashrope_diagnostic_slot_b4rope15ExactComparison9lcp_inner17h1a8c569200e6a126E
.LBB10_19:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.24(%rip), %r8
	movq	%r11, %rcx
	movq	%rax, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB10_31:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.24(%rip), %r8
	movq	%rax, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB10_5:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.27(%rip), %r8
	movq	%rdx, %rcx
	movq	%rax, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB10_10:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.27(%rip), %r8
	movq	%r11, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB10_38:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.26(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope15ExactComparison9lcp_inner17h1a8c569200e6a126E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope15ExactComparison9lcp_inner17h1a8c569200e6a126E,unique,11
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope15ExactComparison9lcp_inner17h1a8c569200e6a126E:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope15ExactComparison9lcp_inner17h1a8c569200e6a126E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$168, %rsp
	.seh_stackalloc 168
	.seh_endprologue
	movq	280(%rsp), %rsi
	testq	%rsi, %rsi
	je	.LBB11_1
	movq	%r9, %rdi
	movl	%r8d, %r9d
	movq	%rdx, %r8
	movq	%rcx, %r13
	movl	272(%rsp), %ebx
	movq	(%rcx), %rax
	movq	8(%rax), %rcx
	movq	16(%rax), %rdx
	movq	%rsi, 32(%rsp)
	callq	_ZN26hashrope_diagnostic_slot_b4rope15ExactComparison9normalize17h2bacdf64a98fef49E
	movq	%rax, %r14
	movl	%edx, %ebp
	movq	8(%r13), %rax
	movq	8(%rax), %rcx
	movq	16(%rax), %rdx
	movq	%rsi, 32(%rsp)
	movq	%rdi, %r8
	movl	%ebx, %r9d
	callq	_ZN26hashrope_diagnostic_slot_b4rope15ExactComparison9normalize17h2bacdf64a98fef49E
	movq	%rax, %r15
	movl	%edx, %r12d
	movl	%ebp, 152(%rsp)
	movq	%r14, 136(%rsp)
	movl	%edx, 156(%rsp)
	movq	%rax, 144(%rsp)
	movq	%rsi, 160(%rsp)
	leaq	16(%r13), %rax
	movq	%rax, 72(%rsp)
	movq	$0, 56(%rsp)
.LBB11_4:
	movq	%rsi, %rdi
	subq	56(%rsp), %rdi
	movq	(%r13), %rax
	movq	8(%rax), %rcx
	movq	16(%rax), %rdx
	movq	%rdi, 32(%rsp)
	movq	%r14, %r8
	movl	%ebp, %r9d
	callq	_ZN26hashrope_diagnostic_slot_b4rope15ExactComparison9normalize17h2bacdf64a98fef49E
	movq	%rax, %r14
	movl	%edx, %ebp
	movq	8(%r13), %rax
	movq	8(%rax), %rcx
	movq	16(%rax), %rdx
	movq	%rdi, 32(%rsp)
	movq	%r15, %r8
	movl	%r12d, %r9d
	callq	_ZN26hashrope_diagnostic_slot_b4rope15ExactComparison9normalize17h2bacdf64a98fef49E
	movq	%rax, %r15
	movl	%edx, %r12d
	cmpb	$1, 40(%r13)
	jne	.LBB11_8
	cmpl	%r12d, %ebp
	jne	.LBB11_8
	cmpq	%r15, %r14
	je	.LBB11_7
.LBB11_8:
	movq	72(%rsp), %rax
	movq	(%rax), %rax
	testq	%rax, %rax
	je	.LBB11_22
	movq	24(%r13), %rcx
.LBB11_10:
	movzwl	362(%rax), %r8d
	movl	%r8d, %r9d
	shll	$5, %r9d
	movq	$-1, %rdx
	xorl	%r10d, %r10d
	jmp	.LBB11_11
	.p2align	4
.LBB11_18:
	incq	%rdx
	addq	$32, %r10
	cmpb	$1, %r11b
	jne	.LBB11_19
.LBB11_11:
	cmpq	%r10, %r9
	je	.LBB11_12
	movl	16(%rax,%r10), %ebx
	cmpl	%ebx, %ebp
	seta	%r11b
	sbbb	$0, %r11b
	cmpl	%ebx, %ebp
	jne	.LBB11_18
	movq	(%rax,%r10), %rbx
	cmpq	%rbx, %r14
	seta	%r11b
	sbbb	$0, %r11b
	cmpq	%rbx, %r14
	jne	.LBB11_18
	movl	20(%rax,%r10), %ebx
	cmpl	%ebx, %r12d
	seta	%r11b
	sbbb	$0, %r11b
	cmpl	%ebx, %r12d
	jne	.LBB11_18
	movq	8(%rax,%r10), %rbx
	cmpq	%rbx, %r15
	seta	%r11b
	sbbb	$0, %r11b
	cmpq	%rbx, %r15
	jne	.LBB11_18
	cmpq	24(%rax,%r10), %rdi
	seta	%r11b
	sbbb	$0, %r11b
	jmp	.LBB11_18
	.p2align	4
.LBB11_19:
	movzbl	%r11b, %r8d
	testl	%r8d, %r8d
	je	.LBB11_7
	jmp	.LBB11_20
	.p2align	4
.LBB11_12:
	movq	%r8, %rdx
.LBB11_20:
	subq	$1, %rcx
	jb	.LBB11_22
	movq	368(%rax,%rdx,8), %rax
	jmp	.LBB11_10
	.p2align	4
.LBB11_22:
	movq	(%r13), %rdx
	movl	%ebp, %ecx
	movq	16(%rdx), %r9
	cmpq	%rcx, %r9
	jbe	.LBB11_98
	movq	8(%r13), %r11
	movl	%r12d, %eax
	movq	16(%r11), %r10
	cmpq	%rax, %r10
	jbe	.LBB11_30
	movq	8(%rdx), %r8
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	addq	%r8, %rcx
	movq	8(%r11), %rbx
	leaq	(%rax,%rax,2), %r11
	shlq	$4, %r11
	addq	%rbx, %r11
	movl	(%rcx), %edx
	testl	%edx, %edx
	je	.LBB11_32
	cmpl	$1, %edx
	jne	.LBB11_26
	movl	4(%rcx), %ecx
	cmpq	%rcx, %r9
	jbe	.LBB11_37
	leaq	(%rcx,%rcx,2), %rax
	shlq	$4, %rax
	leaq	(%r8,%rax), %rcx
	movl	(%r8,%rax), %eax
	testl	%eax, %eax
	je	.LBB11_38
	cmpl	$1, %eax
	addq	$24, %rcx
	jmp	.LBB11_41
.LBB11_32:
	movl	(%r11), %eax
	testl	%eax, %eax
	je	.LBB11_52
	movl	%edx, %r8d
	addq	$16, %rcx
	movq	(%rcx), %rdx
	cmpl	$2, %eax
	jne	.LBB11_43
	jmp	.LBB11_44
.LBB11_26:
	movq	%rbx, 64(%rsp)
	cmpl	$2, (%r11)
	movl	4(%rcx), %ecx
	jne	.LBB11_27
	movl	%edx, 92(%rsp)
	cmpq	%rcx, %r9
	jbe	.LBB11_37
	movq	%rcx, 128(%rsp)
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	xorl	%edx, %edx
	cmpl	$0, (%r8,%rcx)
	setne	%bl
	movl	4(%r11), %eax
	cmpq	%rax, %r10
	jbe	.LBB11_85
	addq	%r8, %rcx
	movb	%bl, %dl
	movq	16(%rcx,%rdx,8), %rbx
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	movq	64(%rsp), %rcx
	leaq	(%rcx,%rax), %rdx
	movq	%rdx, 80(%rsp)
	xorl	%edx, %edx
	cmpl	$0, (%rcx,%rax)
	setne	%dl
	movq	80(%rsp), %rax
	movq	16(%rax,%rdx,8), %rdx
	movq	%rbx, %rax
	movq	%rdx, %rcx
	movq	%rdx, 80(%rsp)
	jmp	.LBB11_93
	.p2align	4
.LBB11_91:
	xorl	%edx, %edx
	divq	%rcx
.LBB11_92:
	movq	%rcx, %rax
	movq	%rdx, %rcx
.LBB11_93:
	testq	%rdx, %rdx
	je	.LBB11_86
	movq	%rax, %rdx
	orq	%rcx, %rdx
	shrq	$32, %rdx
	jne	.LBB11_91
	xorl	%edx, %edx
	divl	%ecx
	jmp	.LBB11_92
.LBB11_86:
	movq	80(%rsp), %rcx
	subq	%rax, %rcx
	addq	%rcx, %rbx
	movq	$-1, %rax
	cmovbq	%rax, %rbx
	cmpq	%rdi, %rbx
	movl	92(%rsp), %edx
	movq	128(%rsp), %rcx
	jb	.LBB11_87
.LBB11_27:
	cmpq	%rcx, %r9
	jbe	.LBB11_37
	leaq	(%rcx,%rcx,2), %rax
	shlq	$4, %rax
	leaq	(%r8,%rax), %rcx
	movl	(%r8,%rax), %eax
	testl	%eax, %eax
	je	.LBB11_39
	cmpl	$1, %eax
	addq	$24, %rcx
	jmp	.LBB11_40
.LBB11_38:
	addq	$16, %rcx
	jmp	.LBB11_41
.LBB11_39:
	addq	$16, %rcx
.LBB11_40:
	movq	64(%rsp), %rbx
.LBB11_41:
	movl	%edx, %r8d
	movl	(%r11), %eax
	movq	(%rcx), %rdx
	cmpl	$2, %eax
	je	.LBB11_44
.LBB11_43:
	cmpl	$1, %eax
	jne	.LBB11_47
.LBB11_44:
	movl	4(%r11), %ecx
	cmpq	%rcx, %r10
	jbe	.LBB11_51
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	leaq	(%rbx,%rcx), %r11
	movl	(%rbx,%rcx), %ecx
	testl	%ecx, %ecx
	je	.LBB11_47
	cmpl	$1, %ecx
	addq	$24, %r11
	jmp	.LBB11_48
	.p2align	4
.LBB11_47:
	addq	$16, %r11
.LBB11_48:
	subq	%r14, %rdx
	movq	(%r11), %rbx
	subq	%r15, %rbx
	cmpl	$1, %r8d
	jne	.LBB11_49
	cmpl	$1, %eax
	je	.LBB11_50
	movq	%rdx, %rbx
	jmp	.LBB11_96
.LBB11_49:
	cmpl	$1, %eax
	je	.LBB11_96
.LBB11_50:
	cmpq	%rdx, %rbx
	cmovaeq	%rdx, %rbx
.LBB11_96:
	cmpq	%rbx, %rdi
	cmovbq	%rdi, %rbx
	movl	%r12d, 32(%rsp)
	movq	%rbx, 40(%rsp)
	movq	%r13, %rcx
	movq	%r14, %rdx
	movl	%ebp, %r8d
	movq	%r15, %r9
	callq	_ZN26hashrope_diagnostic_slot_b4rope15ExactComparison9lcp_inner17h1a8c569200e6a126E
	cmpq	%rbx, %rax
	jb	.LBB11_88
	addq	%rbx, %r14
	addq	%rbx, %r15
	movq	56(%rsp), %rcx
	addq	%rbx, %rcx
	movq	%rcx, 56(%rsp)
	cmpq	%rsi, %rcx
	jb	.LBB11_4
.LBB11_7:
	leaq	136(%rsp), %rdx
	movq	72(%rsp), %rcx
	callq	_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE
	jmp	.LBB11_2
.LBB11_1:
	xorl	%esi, %esi
.LBB11_2:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$168, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB11_52:
	movq	40(%rcx), %rdx
	movq	%rdx, %r8
	subq	%r14, %r8
	jb	.LBB11_99
	cmpq	%r8, %rdi
	ja	.LBB11_54
	movq	40(%r11), %rdx
	movq	%rdx, %r8
	subq	%r15, %r8
	jb	.LBB11_100
	cmpq	%r8, %rdi
	ja	.LBB11_58
	movq	32(%rcx), %rbx
	addq	%r14, %rbx
	movq	32(%r11), %r13
	addq	%r15, %r13
	movq	%rbx, %rcx
	movq	%r13, %rdx
	movq	%rdi, %r8
	callq	memcmp
	testl	%eax, %eax
	je	.LBB11_60
	movabsq	$9223372036854775800, %rax
	andq	%rdi, %rax
	movq	$-8, %rsi
	movq	%rdi, %rcx
.LBB11_62:
	cmpq	$7, %rcx
	jbe	.LBB11_63
	movq	8(%rbx,%rsi), %rdx
	movq	8(%r13,%rsi), %r8
	addq	$8, %rsi
	addq	$-8, %rcx
	cmpq	%r8, %rdx
	je	.LBB11_62
	xorq	%rdx, %r8
	rep		bsfq	%r8, %rax
	shrl	$3, %eax
	addq	56(%rsp), %rsi
	addq	%rax, %rsi
	jmp	.LBB11_2
.LBB11_87:
	movq	%rbx, 40(%rsp)
	movl	%r12d, 32(%rsp)
	movq	%r13, %rcx
	movq	%r14, %rdx
	movl	%ebp, %r8d
	movq	%r15, %r9
	callq	_ZN26hashrope_diagnostic_slot_b4rope15ExactComparison9lcp_inner17h1a8c569200e6a126E
	cmpq	%rbx, %rax
	jae	.LBB11_60
.LBB11_88:
	addq	56(%rsp), %rax
	movq	%rax, %rsi
	jmp	.LBB11_2
.LBB11_60:
	movq	%r14, 96(%rsp)
	movq	%r15, 104(%rsp)
	movl	%ebp, 112(%rsp)
	movl	%r12d, 116(%rsp)
	movq	%rdi, 120(%rsp)
	leaq	96(%rsp), %rdx
	movq	72(%rsp), %rcx
	callq	_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE
	jmp	.LBB11_7
.LBB11_63:
	andq	$7, %rdi
	je	.LBB11_79
	movzbl	(%rbx,%rax), %ecx
	cmpb	(%r13,%rax), %cl
	jne	.LBB11_65
	cmpl	$1, %edi
	je	.LBB11_79
	movzbl	1(%rbx,%rax), %ecx
	movl	$1, %esi
	cmpb	1(%r13,%rax), %cl
	jne	.LBB11_78
	cmpl	$2, %edi
	je	.LBB11_79
	movzbl	2(%rbx,%rax), %ecx
	movl	$2, %esi
	cmpb	2(%r13,%rax), %cl
	jne	.LBB11_78
	cmpl	$3, %edi
	je	.LBB11_79
	movzbl	3(%rbx,%rax), %ecx
	movl	$3, %esi
	cmpb	3(%r13,%rax), %cl
	jne	.LBB11_78
	cmpl	$4, %edi
	je	.LBB11_79
	movzbl	4(%rbx,%rax), %ecx
	movl	$4, %esi
	cmpb	4(%r13,%rax), %cl
	jne	.LBB11_78
	cmpl	$5, %edi
	je	.LBB11_79
	movzbl	5(%rbx,%rax), %ecx
	movl	$5, %esi
	cmpb	5(%r13,%rax), %cl
	jne	.LBB11_78
	cmpl	$6, %edi
	je	.LBB11_79
	movzbl	6(%rbx,%rax), %ecx
	movl	$6, %esi
	cmpb	6(%r13,%rax), %cl
	jne	.LBB11_78
.LBB11_79:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.36(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.LBB11_65:
	xorl	%esi, %esi
.LBB11_78:
	orq	%rax, %rsi
	addq	56(%rsp), %rsi
	jmp	.LBB11_2
.LBB11_54:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.32(%rip), %r9
	xorl	%ecx, %ecx
	movq	%rdi, %rdx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB11_99:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.33(%rip), %r9
	movq	%r14, %rcx
	movq	%rdx, %r8
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB11_100:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.31(%rip), %r9
	movq	%r15, %rcx
	movq	%rdx, %r8
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB11_58:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.30(%rip), %r9
	xorl	%ecx, %ecx
	movq	%rdi, %rdx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB11_98:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.28(%rip), %r8
	movq	%r9, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB11_30:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.29(%rip), %r8
	movq	%rax, %rcx
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB11_37:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%r9, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB11_51:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB11_85:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%rax, %rcx
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope15ExactComparison9normalize17h2bacdf64a98fef49E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope15ExactComparison9normalize17h2bacdf64a98fef49E,unique,12
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope15ExactComparison9normalize17h2bacdf64a98fef49E:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope15ExactComparison9normalize17h2bacdf64a98fef49E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rdx, %r11
	movl	%r9d, %r10d
	cmpq	%r10, %rdx
	jbe	.LBB12_8
	movq	%r8, %rax
	movq	96(%rsp), %r8
	jmp	.LBB12_2
	.p2align	4
.LBB12_14:
	movl	8(%rdx), %r10d
	movq	%rsi, %rax
.LBB12_15:
	movl	%r10d, %r9d
	cmpq	%r10, %r11
	jbe	.LBB12_8
.LBB12_2:
	leaq	(%r10,%r10,2), %r10
	shlq	$4, %r10
	leaq	(%rcx,%r10), %rdx
	movl	(%rcx,%r10), %r10d
	cmpl	$1, %r10d
	je	.LBB12_10
	cmpl	$2, %r10d
	jne	.LBB12_18
	movl	4(%rdx), %r10d
	cmpq	%r10, %r11
	jbe	.LBB12_11
	leaq	(%r10,%r10,2), %rdx
	shlq	$4, %rdx
	xorl	%esi, %esi
	cmpl	$0, (%rcx,%rdx)
	leaq	(%rcx,%rdx), %rdx
	setne	%sil
	movq	16(%rdx,%rsi,8), %rsi
	testq	%rsi, %rsi
	je	.LBB12_19
	movq	%rax, %rdx
	orq	%rsi, %rdx
	shrq	$32, %rdx
	je	.LBB12_7
	xorl	%edx, %edx
	divq	%rsi
	movq	%rdx, %rax
	subq	%rax, %rsi
	cmpq	%rsi, %r8
	jbe	.LBB12_15
	jmp	.LBB12_18
	.p2align	4
.LBB12_10:
	movl	4(%rdx), %r10d
	cmpq	%r10, %r11
	jbe	.LBB12_11
	leaq	(%r10,%r10,2), %rsi
	shlq	$4, %rsi
	leaq	(%rcx,%rsi), %rdi
	xorl	%ebx, %ebx
	cmpl	$0, (%rcx,%rsi)
	setne	%bl
	movq	16(%rdi,%rbx,8), %rdi
	movq	%rax, %rsi
	subq	%rdi, %rsi
	jae	.LBB12_14
	subq	%rax, %rdi
	cmpq	%rdi, %r8
	jbe	.LBB12_15
	jmp	.LBB12_18
.LBB12_7:
	xorl	%edx, %edx
	divl	%esi
	movl	%edx, %eax
	subq	%rax, %rsi
	cmpq	%rsi, %r8
	jbe	.LBB12_15
.LBB12_18:
	movl	%r9d, %edx
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB12_8:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.34(%rip), %r8
	movq	%r10, %rcx
	movq	%r11, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB12_11:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%r10, %rcx
	movq	%r11, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB12_19:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.35(%rip), %rcx
	callq	_ZN4core9panicking11panic_const23panic_const_rem_by_zero17hb0cdf0d2b6b1aafaE
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E,unique,13
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E:
.Lfunc_begin1:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$120, %rsp
	.seh_stackalloc 120
	leaq	112(%rsp), %rbp
	.seh_setframe %rbp, 112
	.seh_endprologue
	movq	$-2, (%rbp)
	movq	2112(%rcx), %rax
	cmpq	2072(%rcx), %rax
	jne	.LBB13_40
	movq	%rcx, %rsi
	movq	2080(%rcx), %rax
	cmpq	%rax, 2120(%rcx)
	jne	.LBB13_40
	movq	%r8, %rdi
	testq	%r8, %r8
	je	.LBB13_6
	movq	%rdx, %rbx
	cmpq	$513, %rdi
	jae	.LBB13_7
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$1, %edx
	movq	%rdi, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB13_43
	movq	%rdi, -80(%rbp)
	movq	%rax, -72(%rbp)
	movq	%rax, %rcx
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	memcpy
	movq	%rdi, -64(%rbp)
	leaq	-80(%rbp), %rdx
	movq	%rsi, %rcx
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE
	movl	%eax, %edx
	jmp	.LBB13_37
.LBB13_6:
	xorl	%eax, %eax
	jmp	.LBB13_38
.LBB13_7:
	leaq	511(%rdi), %r12
	shrq	$9, %r12
	leaq	(,%r12,4), %r15
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$4, %edx
	movq	%r15, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB13_44
	movq	%rax, %r14
	movq	%r12, -32(%rbp)
	movq	%rax, -24(%rbp)
	xorl	%r15d, %r15d
	jmp	.LBB13_11
	.p2align	4
.LBB13_9:
	movq	-24(%rbp), %r14
.LBB13_10:
	addq	%r13, %rbx
	subq	%r13, %rdi
	movl	%r12d, (%r14,%r15,4)
	incq	%r15
.LBB13_11:
	movq	%r15, -16(%rbp)
	testq	%rdi, %rdi
	je	.LBB13_16
	cmpq	$512, %rdi
	movl	$512, %r13d
	cmovbq	%rdi, %r13
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$1, %edx
	movq	%r13, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB13_41
	movq	%r13, -80(%rbp)
	movq	%rax, -72(%rbp)
	movq	%rax, %rcx
	movq	%rbx, %rdx
	movq	%r13, %r8
	callq	memcpy
	movq	%r13, -64(%rbp)
.Ltmp12:
	movq	%rsi, %rcx
	leaq	-80(%rbp), %rdx
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE
.Ltmp13:
	movl	%eax, %r12d
	cmpq	-32(%rbp), %r15
	jne	.LBB13_10
.Ltmp14:
	leaq	-32(%rbp), %rcx
	callq	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hd82fe28a84893d11E
.Ltmp15:
	jmp	.LBB13_9
.LBB13_16:
	leaq	-56(%rbp), %rdi
	jmp	.LBB13_18
	.p2align	4
.LBB13_17:
	movq	-40(%rbp), %r15
	movq	%r15, -16(%rbp)
	movups	-56(%rbp), %xmm0
	movaps	%xmm0, -32(%rbp)
.LBB13_18:
	cmpq	$1, %r15
	jbe	.LBB13_34
	leaq	1(%r15), %r14
	shrq	%r14
	leaq	(,%r14,4), %rbx
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$4, %edx
	movq	%rbx, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB13_42
	movq	%r14, -56(%rbp)
	movq	%rax, -48(%rbp)
	movq	$0, -40(%rbp)
	movq	-24(%rbp), %rbx
	xorl	%r12d, %r12d
	xorl	%r13d, %r13d
	jmp	.LBB13_23
	.p2align	4
.LBB13_21:
	movq	-48(%rbp), %rax
.LBB13_22:
	movl	%r14d, (%rax,%r12,4)
	incq	%r12
	movq	%r12, -40(%rbp)
	addq	$2, %r13
.LBB13_23:
	cmpq	%r15, %r13
	jae	.LBB13_32
	movq	%r13, %rcx
	orq	$1, %rcx
	cmpq	%r15, %rcx
	jae	.LBB13_30
	movq	2112(%rsi), %rax
	cmpq	2072(%rsi), %rax
	jne	.LBB13_39
	movq	2080(%rsi), %rax
	cmpq	%rax, 2120(%rsi)
	jne	.LBB13_39
	movl	(%rbx,%rcx,4), %r8d
	movl	(%rbx,%r13,4), %edx
.Ltmp24:
	movq	%rsi, %rcx
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E
.Ltmp25:
	movl	%eax, %r14d
	cmpq	-56(%rbp), %r12
	jne	.LBB13_21
.Ltmp26:
	movq	%rdi, %rcx
	callq	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hd82fe28a84893d11E
.Ltmp27:
	jmp	.LBB13_21
	.p2align	4
.LBB13_30:
	movl	(%rbx,%r13,4), %r14d
	cmpq	-56(%rbp), %r12
	jne	.LBB13_22
.Ltmp20:
	movq	%rdi, %rcx
	callq	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hd82fe28a84893d11E
.Ltmp21:
	jmp	.LBB13_21
	.p2align	4
.LBB13_32:
	movq	-32(%rbp), %rdx
	testq	%rdx, %rdx
	je	.LBB13_17
	shlq	$2, %rdx
	movl	$4, %r8d
	movq	%rbx, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	jmp	.LBB13_17
.LBB13_34:
	jne	.LBB13_45
	movq	-32(%rbp), %rax
	movq	-24(%rbp), %rcx
	movl	(%rcx), %edx
	testq	%rax, %rax
	je	.LBB13_37
	shlq	$2, %rax
	movl	$4, %r8d
	movl	%edx, %esi
	movq	%rax, %rdx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	movl	%esi, %edx
.LBB13_37:
	movl	$1, %eax
.LBB13_38:
	.seh_startepilogue
	addq	$120, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.LBB13_39:
.Ltmp22:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.37(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.Ltmp23:
	jmp	.LBB13_46
.LBB13_40:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.37(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB13_41:
.Ltmp16:
	movl	$1, %ecx
	movq	%r13, %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
.Ltmp17:
	jmp	.LBB13_46
.LBB13_42:
.Ltmp28:
	movl	$4, %ecx
	movq	%rbx, %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
.Ltmp29:
	jmp	.LBB13_46
.LBB13_43:
	movl	$1, %ecx
	movq	%rdi, %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
.LBB13_44:
	movl	$4, %ecx
	movq	%r15, %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
.LBB13_45:
.Ltmp18:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.39(%rip), %r8
	xorl	%ecx, %ecx
	xorl	%edx, %edx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.Ltmp19:
.LBB13_46:
	ud2
	.seh_handlerdata
	.long	$cppxdata$_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E@IMGREL
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E,unique,13
	.seh_endproc
	.def	"?dtor$47@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$47@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E@4HA":
.seh_proc "?dtor$47@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E@4HA"
.LBB13_47:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	112(%rdx), %rbp
	.seh_endprologue
	movq	-56(%rbp), %rdx
	testq	%rdx, %rdx
	je	.LBB13_49
	movq	-48(%rbp), %rcx
	shlq	$2, %rdx
	movl	$4, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB13_49:
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E,unique,13
	.seh_endproc
	.def	"?dtor$50@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$50@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E@4HA":
.seh_proc "?dtor$50@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E@4HA"
.LBB13_50:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	112(%rdx), %rbp
	.seh_endprologue
	movq	-32(%rbp), %rdx
	testq	%rdx, %rdx
	je	.LBB13_52
	movq	-24(%rbp), %rcx
	shlq	$2, %rdx
	movl	$4, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB13_52:
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.Lfunc_end1:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E,unique,13
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E,unique,1
	.p2align	2, 0x0
$cppxdata$_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E:
	.long	429065506
	.long	2
	.long	$stateUnwindMap$_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E@IMGREL
	.long	0
	.long	0
	.long	8
	.long	$ip2state$_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E@IMGREL
	.long	112
	.long	0
	.long	1
$stateUnwindMap$_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E:
	.long	-1
	.long	"?dtor$50@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E@4HA"@IMGREL
	.long	0
	.long	"?dtor$47@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E@4HA"@IMGREL
$ip2state$_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E:
	.long	.Lfunc_begin1@IMGREL
	.long	-1
	.long	.Ltmp12@IMGREL+1
	.long	0
	.long	.Ltmp24@IMGREL+1
	.long	1
	.long	.Ltmp23@IMGREL+1
	.long	-1
	.long	.Ltmp16@IMGREL+1
	.long	0
	.long	.Ltmp29@IMGREL+1
	.long	-1
	.long	.Ltmp18@IMGREL+1
	.long	0
	.long	.Ltmp19@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E,unique,13

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena10hash_bytes17h5dc37073fb621a6cE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena10hash_bytes17h5dc37073fb621a6cE,unique,14
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena10hash_bytes17h5dc37073fb621a6cE
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena10hash_bytes17h5dc37073fb621a6cE:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena10hash_bytes17h5dc37073fb621a6cE
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	2112(%rcx), %rax
	cmpq	2072(%rcx), %rax
	jne	.LBB14_2
	movq	2080(%rcx), %rax
	cmpq	%rax, 2120(%rcx)
	jne	.LBB14_2
	addq	$24, %rcx
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	jmp	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash4hash17hef62f54324bd5bc8E
.LBB14_2:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.37(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena10hash_range17h5acf44e76cb0f924E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena10hash_range17h5acf44e76cb0f924E,unique,15
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena10hash_range17h5acf44e76cb0f924E:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena10hash_range17h5acf44e76cb0f924E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	movq	%r9, %rbx
	movl	%edx, %edi
	movq	%rcx, %rsi
	leaq	-1(%r9), %r13
	movq	8(%rcx), %rcx
	movq	16(%rsi), %r10
.LBB15_1:
	movq	%r8, %r15
	leaq	(%r15,%rbx), %rax
	testq	%r15, %r15
	je	.LBB15_3
	.p2align	4
.LBB15_26:
	movl	%edi, %r14d
	cmpq	%r14, %r10
	jbe	.LBB15_23
	leaq	(%r14,%r14,2), %rdx
	shlq	$4, %rdx
	leaq	(%rcx,%rdx), %r9
	movl	(%rcx,%rdx), %edx
	cmpl	$1, %edx
	jne	.LBB15_28
	movl	4(%r9), %edi
	cmpq	%rdi, %r10
	jbe	.LBB15_34
	leaq	(%rdi,%rdi,2), %rdx
	shlq	$4, %rdx
	xorl	%r8d, %r8d
	cmpl	$0, (%rcx,%rdx)
	leaq	(%rcx,%rdx), %rdx
	setne	%r8b
	movq	16(%rdx,%r8,8), %r9
	cmpq	%r9, %rax
	jbe	.LBB15_26
	jmp	.LBB15_13
	.p2align	4
.LBB15_3:
	movl	%edi, %r14d
	cmpq	%r14, %r10
	jbe	.LBB15_15
	leaq	(%r14,%r14,2), %rdi
	shlq	$4, %rdi
	leaq	(%rcx,%rdi), %r9
	movl	(%rcx,%rdi), %edx
	xorl	%r8d, %r8d
	testl	%edx, %edx
	setne	%r8b
	cmpq	16(%r9,%r8,8), %rbx
	je	.LBB15_19
	cmpl	$1, %edx
	jne	.LBB15_6
	movl	4(%r9), %edi
	cmpq	%rdi, %r10
	jbe	.LBB15_34
	leaq	(%rdi,%rdi,2), %rdx
	shlq	$4, %rdx
	xorl	%r8d, %r8d
	cmpl	$0, (%rcx,%rdx)
	leaq	(%rcx,%rdx), %rdx
	setne	%r8b
	movq	16(%rdx,%r8,8), %r9
	cmpq	%r9, %rax
	jbe	.LBB15_3
.LBB15_13:
	leaq	(%r14,%r14,2), %rax
	shlq	$4, %rax
	movl	8(%rcx,%rax), %ebp
	movq	%r15, %rax
	subq	%r9, %rax
	jb	.LBB15_14
	movl	%ebp, %edi
	movq	%rax, %r15
	leaq	(%r15,%rbx), %rax
	testq	%r15, %r15
	jne	.LBB15_26
	jmp	.LBB15_3
	.p2align	4
.LBB15_28:
	testl	%edx, %edx
	je	.LBB15_8
	jmp	.LBB15_29
	.p2align	4
.LBB15_6:
	testl	%edx, %edx
	je	.LBB15_7
.LBB15_29:
	leaq	(%r14,%r14,2), %rax
	shlq	$4, %rax
	movl	4(%rcx,%rax), %edi
	cmpq	%rdi, %r10
	jbe	.LBB15_34
	movq	2072(%rsi), %r14
	leaq	(%rdi,%rdi,2), %rbp
	shlq	$4, %rbp
	leaq	(%rcx,%rbp), %rax
	xorl	%edx, %edx
	cmpl	$0, (%rcx,%rbp)
	setne	%dl
	movq	16(%rax,%rdx,8), %r12
	movq	%rsi, %rcx
	movl	%edi, %edx
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena17ensure_hash_inner17h495c162be458b4acE
	movq	16(%rsi), %r10
	cmpq	%rdi, %r10
	jbe	.LBB15_37
	testq	%r12, %r12
	je	.LBB15_48
	movq	8(%rsi), %rcx
	leaq	(%rcx,%rbp), %rax
	xorl	%edx, %edx
	cmpl	$0, (%rcx,%rbp)
	setne	%dl
	movq	8(%rax,%rdx,8), %r9
	movq	%r15, %rax
	orq	%r12, %rax
	shrq	$32, %rax
	je	.LBB15_33
	movq	%r15, %rax
	xorl	%edx, %edx
	divq	%r12
	movq	%rdx, %r8
	movq	%rax, %rbp
	jmp	.LBB15_39
.LBB15_33:
	movl	%r15d, %eax
	xorl	%edx, %edx
	divl	%r12d
	movl	%edx, %r8d
	movl	%eax, %ebp
.LBB15_39:
	addq	%r13, %r15
	movq	%r15, %rax
	orq	%r12, %rax
	shrq	$32, %rax
	je	.LBB15_40
	movq	%r15, %rax
	xorl	%edx, %edx
	divq	%r12
	cmpq	%rax, %rbp
	je	.LBB15_1
	jmp	.LBB15_43
.LBB15_40:
	movl	%r15d, %eax
	xorl	%edx, %edx
	divl	%r12d
	cmpq	%rax, %rbp
	je	.LBB15_1
.LBB15_43:
	movq	%r9, %r15
	movq	%rdx, 64(%rsp)
	leaq	24(%rsi), %rbx
	movq	%r12, %r9
	subq	%r8, %r9
	movq	%rsi, %rcx
	movl	%edi, %edx
	movq	%rax, %r13
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena10hash_range17h5acf44e76cb0f924E
	notq	%rbp
	addq	%rbp, %r13
	movq	%rax, 56(%rsp)
	movq	%rbx, 48(%rsp)
	je	.LBB15_44
	movq	%rbx, %rcx
	movq	%r12, %rdx
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE
	movq	%r13, %rcx
	movq	%rax, %rdx
	movq	%r14, %r8
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash3phi17hc786991a0fa0b177E
	mulq	%r15
	movq	%rax, %rbp
	movl	$127, %ebx
	bsrq	%r14, %rbx
	xorl	$-64, %ebx
	addl	$65, %ebx
	movq	%rdx, %rax
	movl	%ebx, %ecx
	shrq	%cl, %rax
	movq	%rbp, %r8
	shrdq	%cl, %rdx, %r8
	xorl	%r9d, %r9d
	testb	$64, %bl
	cmovneq	%rax, %r8
	cmovneq	%r9, %rax
	andq	%r14, %rbp
	addq	%r8, %rbp
	adcq	$0, %rax
	movq	%rbp, %rdx
	shrdq	%cl, %rax, %rdx
	shrq	%cl, %rax
	testb	$64, %bl
	cmoveq	%rdx, %rax
	andq	%r14, %rbp
	addq	%rax, %rbp
	cmpq	%rbp, %r14
	movq	%r14, %rax
	movl	$0, %ecx
	movq	%rcx, 40(%rsp)
	cmovaq	%r9, %rax
	subq	%rax, %rbp
	imulq	%r12, %r13
	jmp	.LBB15_46
.LBB15_19:
	movq	%rsi, %rcx
	movl	%r14d, %edx
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena17ensure_hash_inner17h495c162be458b4acE
	movq	16(%rsi), %rdx
	cmpq	%r14, %rdx
	jbe	.LBB15_20
	movq	8(%rsi), %rcx
	leaq	(%rcx,%rdi), %rax
	movl	(%rcx,%rdi), %ecx
	testl	%ecx, %ecx
	je	.LBB15_21
	cmpl	$1, %ecx
	movq	16(%rax), %rax
	jmp	.LBB15_22
.LBB15_7:
	xorl	%r15d, %r15d
.LBB15_8:
	movq	%r15, %rdx
	movq	40(%r9), %r8
	addq	%rbx, %rdx
	jb	.LBB15_10
	cmpq	%r8, %rdx
	ja	.LBB15_10
	addq	32(%r9), %r15
	addq	$24, %rsi
	movq	%rsi, %rcx
	movq	%r15, %rdx
	movq	%rbx, %r8
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	jmp	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash4hash17hef62f54324bd5bc8E
.LBB15_21:
	movq	8(%rax), %rax
	jmp	.LBB15_22
.LBB15_14:
	leaq	24(%rsi), %r14
	subq	%r15, %r9
	subq	%r9, %rbx
	movq	%rsi, %rcx
	movl	%edi, %edx
	movq	%r15, %r8
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena10hash_range17h5acf44e76cb0f924E
	movq	%rax, %rdi
	xorl	%r12d, %r12d
	movq	%rsi, %rcx
	movl	%ebp, %edx
	xorl	%r8d, %r8d
	movq	%rbx, %r9
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena10hash_range17h5acf44e76cb0f924E
	movq	%rax, %r15
	movq	%r14, %rcx
	movq	%rbx, %rdx
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE
	mulq	%rdi
	addq	%r15, %rax
	adcq	$0, %rdx
	movq	2072(%rsi), %r8
	movl	$127, %r9d
	bsrq	%r8, %r9
	xorl	$63, %r9d
	movb	$64, %cl
	subb	%r9b, %cl
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	testb	$64, %cl
	cmovneq	%rdx, %r9
	cmovneq	%r12, %rdx
	andq	%r8, %rax
	addq	%r9, %rax
	adcq	$0, %rdx
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	testb	$64, %cl
	cmoveq	%r9, %rdx
	andq	%r8, %rax
	addq	%rdx, %rax
	cmpq	%rax, %r8
	cmovaq	%r12, %r8
	subq	%r8, %rax
	jmp	.LBB15_22
.LBB15_44:
	movl	$127, %ebx
	bsrq	%r14, %rbx
	xorl	$-64, %ebx
	addl	$65, %ebx
	movq	$0, 40(%rsp)
	xorl	%r13d, %r13d
	xorl	%ebp, %ebp
.LBB15_46:
	movq	64(%rsp), %r15
	leaq	1(%r15), %r12
	movq	%rsi, %rcx
	movl	%edi, %edx
	xorl	%r8d, %r8d
	movq	%r12, %r9
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena10hash_range17h5acf44e76cb0f924E
	movq	%rax, %rsi
	leaq	(%r15,%r13), %rdx
	incq	%rdx
	movq	48(%rsp), %r15
	movq	%r15, %rcx
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE
	movq	%rax, %rdi
	movq	%r15, %rcx
	movq	%r12, %rdx
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE
	movq	%rax, %rcx
	movq	%rdi, %rax
	mulq	56(%rsp)
	movq	%rdx, %r8
	movq	%rax, %r9
	movq	%rcx, %rax
	mulq	%rbp
	movq	%rax, %rcx
	movq	%r9, %rax
	addq	%rsi, %rax
	adcq	$0, %r8
	addq	%rcx, %rax
	adcq	%rdx, %r8
	movq	%rax, %rdx
	movl	%ebx, %ecx
	shrdq	%cl, %r8, %rdx
	movq	%r8, %r9
	shrq	%cl, %r9
	testb	$64, %bl
	cmovneq	%r9, %rdx
	movl	$0, %r10d
	cmovneq	%r10, %r9
	andq	40(%rsp), %r8
	andq	%r14, %rax
	addq	%rdx, %rax
	adcq	%r9, %r8
	movq	%rax, %rdx
	shrdq	%cl, %r8, %rdx
	shrq	%cl, %r8
	testb	$64, %bl
	cmoveq	%rdx, %r8
	andq	%r14, %rax
	addq	%r8, %rax
	cmpq	%rax, %r14
	cmovaq	%r10, %r14
	subq	%r14, %rax
.LBB15_22:
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB15_10:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.42(%rip), %r9
	movq	%r15, %rcx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB15_34:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%rdi, %rcx
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB15_23:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.41(%rip), %r8
	movq	%r14, %rcx
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB15_15:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%r14, %rcx
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB15_37:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.40(%rip), %r8
	movq	%rdi, %rcx
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB15_48:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.43(%rip), %rcx
	callq	_ZN4core9panicking11panic_const23panic_const_div_by_zero17hdceffd214664eedfE
.LBB15_20:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.40(%rip), %r8
	movq	%r14, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena10lcp_across17hca32030b4aef09e1E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena10lcp_across17hca32030b4aef09e1E,unique,16
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena10lcp_across17hca32030b4aef09e1E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena10lcp_across17hca32030b4aef09e1E:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena10lcp_across17hca32030b4aef09e1E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	testl	%edx, 112(%rsp)
	je	.LBB16_6
	movl	%r8d, %eax
	movq	16(%rcx), %rdx
	cmpq	%rax, %rdx
	jbe	.LBB16_7
	movl	120(%rsp), %r11d
	movl	%r11d, %r10d
	movq	16(%r9), %rdx
	cmpq	%r10, %rdx
	jbe	.LBB16_8
	movq	8(%rcx), %rdx
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	xorl	%esi, %esi
	cmpl	$0, (%rdx,%rax)
	leaq	(%rdx,%rax), %rax
	setne	%sil
	movq	16(%rax,%rsi,8), %rax
	movq	8(%r9), %rdx
	leaq	(%r10,%r10,2), %r10
	shlq	$4, %r10
	leaq	(%rdx,%r10), %rsi
	xorl	%edi, %edi
	cmpl	$0, (%rdx,%r10)
	setne	%dil
	movq	16(%rsi,%rdi,8), %rdx
	cmpq	%rax, %rdx
	cmovbq	%rdx, %rax
	cmpq	%r9, %rcx
	sete	%dl
	cmpl	%r11d, %r8d
	sete	%r10b
	testb	%r10b, %dl
	jne	.LBB16_5
	movq	%rax, 48(%rsp)
	movl	%r11d, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	%r9, %rdx
	movl	%r8d, %r9d
	xorl	%r8d, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE
.LBB16_5:
	nop
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB16_6:
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB16_7:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%rax, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB16_8:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%r10, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena11ensure_hash17h4d092161171f41d8E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena11ensure_hash17h4d092161171f41d8E,unique,17
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena11ensure_hash17h4d092161171f41d8E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena11ensure_hash17h4d092161171f41d8E:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena11ensure_hash17h4d092161171f41d8E
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	2112(%rcx), %rax
	cmpq	2072(%rcx), %rax
	jne	.LBB17_2
	movq	2080(%rcx), %rax
	cmpq	%rax, 2120(%rcx)
	jne	.LBB17_2
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	jmp	_ZN26hashrope_diagnostic_slot_b4rope5Arena17ensure_hash_inner17h495c162be458b4acE
.LBB17_2:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.37(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena11equal_range17h748c52900e79b401E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena11equal_range17h748c52900e79b401E,unique,18
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena11equal_range17h748c52900e79b401E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena11equal_range17h748c52900e79b401E:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena11equal_range17h748c52900e79b401E
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$80, %rsp
	.seh_stackalloc 80
	.seh_endprologue
	movl	128(%rsp), %eax
	movl	136(%rsp), %r10d
	movq	144(%rsp), %r11
	movq	152(%rsp), %rsi
	movq	%rsi, 64(%rsp)
	movq	%r11, 56(%rsp)
	movl	%r10d, 48(%rsp)
	movl	%eax, 40(%rsp)
	movq	%rcx, 32(%rsp)
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena16lcp_range_across17h2b5fd754af3fafdbE
	cmpq	%rsi, %rax
	sete	%al
	.seh_startepilogue
	addq	$80, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena11make_repeat17h9a70e50e745a5030E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena11make_repeat17h9a70e50e745a5030E,unique,19
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena11make_repeat17h9a70e50e745a5030E:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena11make_repeat17h9a70e50e745a5030E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	testq	%r8, %r8
	je	.LBB19_1
	movq	%r8, %rsi
	cmpq	$1, %r8
	jne	.LBB19_3
	movl	$1, %eax
	jmp	.LBB19_14
.LBB19_1:
	xorl	%eax, %eax
	jmp	.LBB19_14
.LBB19_3:
	movl	%edx, %eax
	movq	16(%rcx), %rbx
	cmpq	%rax, %rbx
	jbe	.LBB19_6
	movq	8(%rcx), %r9
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	leaq	(%r9,%rax), %r8
	movl	(%r9,%rax), %r9d
	testl	%r9d, %r9d
	je	.LBB19_7
	cmpl	$1, %r9d
	leaq	24(%r8), %rax
	movq	32(%r8), %r15
	movq	(%rax), %rdi
	movq	$-1, %rax
	cmpb	$0, 2128(%rcx)
	jne	.LBB19_10
.LBB19_9:
	xorl	%eax, %eax
	testl	%r9d, %r9d
	setne	%al
	movq	8(%r8,%rax,8), %r12
	leaq	24(%rcx), %rax
	movq	%rcx, %r14
	movq	%rax, %rcx
	movl	%edx, %ebp
	movq	%rdi, %rdx
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE
	movq	2072(%r14), %rbx
	movq	%rsi, %rcx
	movq	%rax, %rdx
	movq	%rbx, %r8
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash3phi17hc786991a0fa0b177E
	mulq	%r12
	movq	%rdx, %r9
	movl	%ebp, %edx
	movl	$127, %ecx
	bsrq	%rbx, %rcx
	xorl	$63, %ecx
	movb	$64, %r8b
	subb	%cl, %r8b
	movq	%r9, %r10
	movl	%r8d, %ecx
	shrq	%cl, %r10
	movq	%rax, %r11
	shrdq	%cl, %r9, %r11
	xorl	%r9d, %r9d
	testb	$64, %r8b
	cmovneq	%r10, %r11
	cmovneq	%r9, %r10
	andq	%rbx, %rax
	addq	%r11, %rax
	adcq	$0, %r10
	movq	%rax, %r11
	shrdq	%cl, %r10, %r11
	shrq	%cl, %r10
	movq	%r14, %rcx
	testb	$64, %r8b
	cmoveq	%r11, %r10
	andq	%rbx, %rax
	addq	%r10, %rax
	cmpq	%rax, %rbx
	cmovaq	%r9, %rbx
	subq	%rbx, %rax
	movq	16(%r14), %rbx
.LBB19_10:
	cmpq	(%rcx), %rbx
	je	.LBB19_11
.LBB19_12:
	imulq	%rsi, %rdi
	imulq	%rsi, %r15
	movq	8(%rcx), %r8
	leaq	(%rbx,%rbx,2), %r9
	shlq	$4, %r9
	movl	$2, (%r8,%r9)
	movl	%edx, 4(%r8,%r9)
	movq	%rsi, 8(%r8,%r9)
	movq	%rax, 16(%r8,%r9)
	movq	%rdi, 24(%r8,%r9)
	movq	%r15, 32(%r8,%r9)
	movq	%rbx, %rax
	incq	%rax
	movq	%rax, 16(%rcx)
	movl	$1, %eax
	movl	%ebx, %edx
.LBB19_14:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB19_7:
	leaq	16(%r8), %rax
	movl	$1, %r15d
	movq	(%rax), %rdi
	movq	$-1, %rax
	cmpb	$0, 2128(%rcx)
	je	.LBB19_9
	jmp	.LBB19_10
.LBB19_11:
	movq	%rcx, %r14
	movl	%edx, %ebp
	movq	%rax, %r12
	callq	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h3f28a2f1503df7efE
	movq	%r12, %rax
	movq	%r14, %rcx
	movl	%ebp, %edx
	jmp	.LBB19_12
.LBB19_6:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%rax, %rcx
	movq	%rbx, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena11node_height17hf83ff14f0e199e86E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena11node_height17hf83ff14f0e199e86E,unique,20
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena11node_height17hf83ff14f0e199e86E:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena11node_height17hf83ff14f0e199e86E
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movl	%edx, %eax
	movq	16(%rcx), %rdx
	movl	%eax, %eax
	cmpq	%rax, %rdx
	jbe	.LBB20_7
	movq	8(%rcx), %r8
	xorl	%esi, %esi
	.p2align	4
.LBB20_2:
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	leaq	(%r8,%rax), %r14
	movl	(%r8,%rax), %eax
	cmpl	$2, %eax
	jne	.LBB20_3
	movl	4(%r14), %eax
	incq	%rsi
	cmpq	%rax, %rdx
	ja	.LBB20_2
.LBB20_7:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.45(%rip), %r8
	movq	%rax, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB20_3:
	testl	%eax, %eax
	je	.LBB20_5
	movl	4(%r14), %edx
	movq	%rcx, %rdi
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11node_height17hf83ff14f0e199e86E
	movq	%rax, %rbx
	movl	8(%r14), %edx
	movq	%rdi, %rcx
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11node_height17hf83ff14f0e199e86E
	cmpq	%rbx, %rax
	cmovaq	%rax, %rbx
	addq	%rbx, %rsi
	incq	%rsi
.LBB20_5:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE,unique,21
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE:
.Lfunc_begin2:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$120, %rsp
	.seh_stackalloc 120
	leaq	112(%rsp), %rbp
	.seh_setframe %rbp, 112
	.seh_endprologue
	movq	$-2, (%rbp)
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	movl	%r8d, %ecx
	movq	16(%rdx), %rdx
	cmpq	%rcx, %rdx
	jbe	.LBB21_58
	movq	%r9, %r13
	movq	8(%rdi), %rax
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	leaq	(%rax,%rcx), %r15
	movl	(%rax,%rcx), %ecx
	testl	%ecx, %ecx
	je	.LBB21_6
	cmpl	$1, %ecx
	jne	.LBB21_10
	movl	4(%r15), %ebx
	cmpq	%rbx, %rdx
	jbe	.LBB21_59
	movl	8(%r15), %r14d
	leaq	(%rbx,%rbx,2), %rcx
	shlq	$4, %rcx
	leaq	(%rax,%rcx), %rdx
	xorl	%r8d, %r8d
	cmpl	$0, (%rax,%rcx)
	setne	%r8b
	movl	$1, %r12d
	movq	%r13, %r9
	subq	16(%rdx,%r8,8), %r9
	jne	.LBB21_19
.LBB21_52:
	movl	$1, %r15d
	jmp	.LBB21_53
.LBB21_6:
	movq	40(%r15), %r8
	cmpq	%r8, %r13
	ja	.LBB21_55
	testq	%r13, %r13
	jns	.LBB21_24
	xorl	%r14d, %r14d
.LBB21_9:
	movq	%r14, %rcx
	movq	%r13, %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
.LBB21_10:
	movl	4(%r15), %r14d
	cmpq	%r14, %rdx
	jbe	.LBB21_60
	leaq	(%r14,%r14,2), %rcx
	shlq	$4, %rcx
	xorl	%edx, %edx
	cmpl	$0, (%rax,%rcx)
	leaq	(%rax,%rcx), %rax
	setne	%dl
	movq	16(%rax,%rdx,8), %rcx
	testq	%rcx, %rcx
	je	.LBB21_61
	movq	8(%r15), %r12
	movq	%r13, %rax
	orq	%rcx, %rax
	shrq	$32, %rax
	je	.LBB21_27
	movq	%r13, %rax
	xorl	%edx, %edx
	divq	%rcx
	movq	%rdx, %r9
	movq	%rax, %r13
	testq	%r9, %r9
	je	.LBB21_28
.LBB21_14:
	leaq	-32(%rbp), %rcx
	movq	%rdi, %rdx
	movl	%r14d, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE
	movl	-32(%rbp), %eax
	movl	%eax, -48(%rbp)
	movl	-28(%rbp), %ebx
	movl	-24(%rbp), %eax
	movl	%eax, -56(%rbp)
	movl	-20(%rbp), %r15d
	movq	%rdi, %rcx
	movl	%r14d, %edx
	movq	%r13, %r8
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11make_repeat17h9a70e50e745a5030E
	movq	2112(%rdi), %rcx
	cmpq	2072(%rdi), %rcx
	jne	.LBB21_54
	movq	2080(%rdi), %rcx
	cmpq	%rcx, 2120(%rdi)
	jne	.LBB21_54
	movl	%r15d, -40(%rbp)
	testb	$1, %al
	je	.LBB21_29
	movl	$1, %r15d
	cmpl	$0, -48(%rbp)
	je	.LBB21_44
	movq	%rdi, %rcx
	movl	%ebx, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E
	movl	%eax, %ebx
	jmp	.LBB21_45
.LBB21_19:
	leaq	-32(%rbp), %rcx
	movq	%rdi, %rdx
	jae	.LBB21_30
	movl	%ebx, %r8d
	movq	%r13, %r9
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE
	movq	2112(%rdi), %rax
	cmpq	2072(%rdi), %rax
	jne	.LBB21_54
	movq	2080(%rdi), %rax
	cmpq	%rax, 2120(%rdi)
	jne	.LBB21_54
	movl	-32(%rbp), %r15d
	movl	-28(%rbp), %ebx
	cmpl	$0, -24(%rbp)
	je	.LBB21_53
	movl	-20(%rbp), %edx
	movq	%rdi, %rcx
	jmp	.LBB21_50
.LBB21_24:
	movq	32(%r15), %rbx
	je	.LBB21_34
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$1, %r14d
	movl	$1, %edx
	movq	%r13, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB21_9
	movq	%rax, %r12
	jmp	.LBB21_35
.LBB21_27:
	movl	%r13d, %eax
	xorl	%edx, %edx
	divl	%ecx
	movl	%edx, %r9d
	movl	%eax, %r13d
	testq	%r9, %r9
	jne	.LBB21_14
.LBB21_28:
	movq	%rdi, %rcx
	movl	%r14d, %edx
	movq	%r13, %r8
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11make_repeat17h9a70e50e745a5030E
	movl	%eax, %r15d
	movl	%edx, %ebx
	subq	%r13, %r12
	movq	%rdi, %rcx
	movl	%r14d, %edx
	movq	%r12, %r8
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11make_repeat17h9a70e50e745a5030E
	movl	%eax, %r12d
	movl	%edx, %r14d
	jmp	.LBB21_53
.LBB21_29:
	movl	-48(%rbp), %r15d
	jmp	.LBB21_45
.LBB21_30:
	movl	%r14d, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE
	movq	2112(%rdi), %rax
	cmpq	2072(%rdi), %rax
	jne	.LBB21_54
	movq	2080(%rdi), %rax
	cmpq	%rax, 2120(%rdi)
	jne	.LBB21_54
	movl	-24(%rbp), %r12d
	movl	-20(%rbp), %r14d
	cmpl	$0, -32(%rbp)
	je	.LBB21_52
	movl	-28(%rbp), %r8d
	movq	%rdi, %rcx
	movl	%ebx, %edx
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E
	movl	%eax, %ebx
	jmp	.LBB21_52
.LBB21_34:
	movl	$1, %r12d
.LBB21_35:
	movq	%r12, %rcx
	movq	%rbx, %rdx
	movq	%r13, %r8
	callq	memcpy
	movq	40(%r15), %rdx
	cmpq	%r13, %rdx
	movq	%r13, -48(%rbp)
	movq	%r12, -56(%rbp)
	jb	.LBB21_56
	movq	32(%r15), %rbx
	addq	%r13, %rbx
	movq	%rdx, %r15
	subq	%r13, %r15
	jns	.LBB21_39
	xorl	%r14d, %r14d
.LBB21_38:
	movb	$0, -1(%rbp)
.Ltmp34:
	movq	%r14, %rcx
	movq	%r15, %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
.Ltmp35:
	jmp	.LBB21_57
.LBB21_39:
	movq	%rdx, -72(%rbp)
	movl	$1, %eax
	je	.LBB21_41
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$1, %r14d
	movl	$1, %edx
	movq	%r15, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB21_38
.LBB21_41:
	movq	%rax, %rcx
	movq	%rax, -40(%rbp)
	movq	%rbx, %rdx
	movq	%r15, %r8
	callq	memcpy
	movq	%r13, -32(%rbp)
	movq	%r12, -24(%rbp)
	movq	%r13, -16(%rbp)
	movb	$1, -2(%rbp)
.Ltmp30:
	leaq	-32(%rbp), %rdx
	movq	%rdi, %rcx
	movq	%r15, -64(%rbp)
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE
.Ltmp31:
	movl	%eax, %ebx
	movq	-64(%rbp), %rcx
	movq	%rcx, -32(%rbp)
	movq	-40(%rbp), %rax
	movq	%rax, -24(%rbp)
	movq	%rcx, -16(%rbp)
	movb	$0, -2(%rbp)
.Ltmp32:
	leaq	-32(%rbp), %rdx
	movq	%rdi, %rcx
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE
.Ltmp33:
	movl	%eax, %r14d
	movl	$1, %r15d
	movl	$1, %r12d
	jmp	.LBB21_53
.LBB21_44:
	movl	%edx, %ebx
.LBB21_45:
	notq	%r13
	addq	%r13, %r12
	movq	%rdi, %rcx
	movl	%r14d, %edx
	movq	%r12, %r8
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11make_repeat17h9a70e50e745a5030E
	movl	%eax, %r12d
	movq	2112(%rdi), %rax
	cmpq	2072(%rdi), %rax
	jne	.LBB21_54
	movq	2080(%rdi), %rax
	cmpq	%rax, 2120(%rdi)
	jne	.LBB21_54
	movl	%edx, %r14d
	cmpl	$0, -56(%rbp)
	je	.LBB21_53
	testb	$1, %r12b
	movl	$1, %r12d
	je	.LBB21_51
	movq	%rdi, %rcx
	movl	-40(%rbp), %edx
.LBB21_50:
	movl	%r14d, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E
	movl	%eax, %r14d
	jmp	.LBB21_53
.LBB21_51:
	movl	-40(%rbp), %r14d
.LBB21_53:
	movl	%r15d, (%rsi)
	movl	%ebx, 4(%rsi)
	movl	%r12d, 8(%rsi)
	movl	%r14d, 12(%rsi)
	.seh_startepilogue
	addq	$120, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.LBB21_54:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.37(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB21_55:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.48(%rip), %r9
	xorl	%ecx, %ecx
	movq	%r13, %rdx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB21_56:
	movb	$0, -1(%rbp)
.Ltmp36:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.47(%rip), %r9
	movq	%r13, %rcx
	movq	%rdx, %r8
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.Ltmp37:
.LBB21_57:
	ud2
.LBB21_58:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.46(%rip), %r8
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB21_59:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%rbx, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB21_60:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%r14, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB21_61:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.49(%rip), %rcx
	callq	_ZN4core9panicking11panic_const23panic_const_div_by_zero17hdceffd214664eedfE
	int3
	.seh_handlerdata
	.long	$cppxdata$_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE@IMGREL
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE,unique,21
	.seh_endproc
	.def	"?dtor$62@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$62@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE@4HA":
.seh_proc "?dtor$62@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE@4HA"
.LBB21_62:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	112(%rdx), %rbp
	.seh_endprologue
	movq	-40(%rbp), %rcx
	movq	-64(%rbp), %rdx
	cmpb	$0, -2(%rbp)
	je	.LBB21_66
	movq	-72(%rbp), %rax
	cmpq	-48(%rbp), %rax
	je	.LBB21_65
	movl	$1, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB21_65:
	movb	$1, -1(%rbp)
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.LBB21_66:
	movb	$1, -1(%rbp)
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE,unique,21
	.seh_endproc
	.def	"?dtor$67@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$67@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE@4HA":
.seh_proc "?dtor$67@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE@4HA"
.LBB21_67:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	112(%rdx), %rbp
	.seh_endprologue
	movq	-48(%rbp), %rdx
	testq	%rdx, %rdx
	je	.LBB21_70
	testb	$1, -1(%rbp)
	jne	.LBB21_70
	movl	$1, %r8d
	movq	-56(%rbp), %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB21_70:
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.Lfunc_end2:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE,unique,21
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE,unique,2
	.p2align	2, 0x0
$cppxdata$_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE:
	.long	429065506
	.long	2
	.long	$stateUnwindMap$_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE@IMGREL
	.long	0
	.long	0
	.long	7
	.long	$ip2state$_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE@IMGREL
	.long	112
	.long	0
	.long	1
$stateUnwindMap$_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE:
	.long	-1
	.long	"?dtor$67@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE@4HA"@IMGREL
	.long	0
	.long	"?dtor$62@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE@4HA"@IMGREL
$ip2state$_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE:
	.long	.Lfunc_begin2@IMGREL
	.long	-1
	.long	.Ltmp34@IMGREL+1
	.long	0
	.long	.Ltmp35@IMGREL+1
	.long	-1
	.long	.Ltmp30@IMGREL+1
	.long	1
	.long	.Ltmp33@IMGREL+1
	.long	-1
	.long	.Ltmp36@IMGREL+1
	.long	0
	.long	.Ltmp37@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE,unique,21

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena11substr_hash17h6b6186b69c81f7fbE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena11substr_hash17h6b6186b69c81f7fbE,unique,22
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena11substr_hash17h6b6186b69c81f7fbE
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena11substr_hash17h6b6186b69c81f7fbE:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena11substr_hash17h6b6186b69c81f7fbE
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	2112(%rcx), %rax
	cmpq	2072(%rcx), %rax
	jne	.LBB22_4
	movq	2080(%rcx), %rax
	cmpq	%rax, 2120(%rcx)
	jne	.LBB22_4
	movq	80(%rsp), %rax
	testq	%rax, %rax
	setne	%r10b
	testb	%dl, %r10b
	je	.LBB22_5
	movl	%r8d, %edx
	movq	%r9, %r8
	movq	%rax, %r9
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	jmp	_ZN26hashrope_diagnostic_slot_b4rope5Arena10hash_range17h5acf44e76cb0f924E
.LBB22_5:
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB22_4:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.37(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena12equal_across17hfd97c5ebbeced2adE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena12equal_across17hfd97c5ebbeced2adE,unique,23
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena12equal_across17hfd97c5ebbeced2adE
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena12equal_across17hfd97c5ebbeced2adE:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena12equal_across17hfd97c5ebbeced2adE
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$64, %rsp
	.seh_stackalloc 64
	.seh_endprologue
	movl	%edx, %eax
	movq	8(%rcx), %rdi
	movq	16(%rcx), %rdx
	testb	$1, %al
	je	.LBB23_1
	movl	%r8d, %r10d
	cmpq	%r10, %rdx
	jbe	.LBB23_18
	leaq	(%r10,%r10,2), %r10
	shlq	$4, %r10
	leaq	(%rdi,%r10), %r11
	xorl	%esi, %esi
	cmpl	$0, (%rdi,%r10)
	setne	%sil
	movq	16(%r11,%rsi,8), %rsi
	jmp	.LBB23_4
.LBB23_1:
	xorl	%esi, %esi
.LBB23_4:
	movl	168(%rsp), %ebx
	movl	160(%rsp), %ebp
	movq	8(%r9), %r14
	movq	16(%r9), %r10
	testb	$1, %bpl
	je	.LBB23_5
	movl	%ebx, %r11d
	cmpq	%r11, %r10
	jbe	.LBB23_19
	leaq	(%r11,%r11,2), %r11
	shlq	$4, %r11
	leaq	(%r14,%r11), %r15
	xorl	%r12d, %r12d
	cmpl	$0, (%r14,%r11)
	setne	%r12b
	movq	16(%r15,%r12,8), %r11
	cmpq	%r11, %rsi
	je	.LBB23_10
.LBB23_9:
	xorl	%eax, %eax
	jmp	.LBB23_17
.LBB23_5:
	xorl	%r11d, %r11d
	cmpq	%r11, %rsi
	jne	.LBB23_9
.LBB23_10:
	testl	%eax, %ebp
	je	.LBB23_11
	movl	%r8d, %eax
	cmpq	%rax, %rdx
	jbe	.LBB23_20
	movl	%ebx, %edx
	cmpq	%rdx, %r10
	jbe	.LBB23_21
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	leaq	(%rdi,%rax), %r10
	xorl	%r11d, %r11d
	cmpl	$0, (%rdi,%rax)
	setne	%r11b
	movq	16(%r10,%r11,8), %rax
	leaq	(%rdx,%rdx,2), %rdx
	shlq	$4, %rdx
	leaq	(%r14,%rdx), %r10
	xorl	%r11d, %r11d
	cmpl	$0, (%r14,%rdx)
	setne	%r11b
	movq	16(%r10,%r11,8), %rdx
	cmpq	%rax, %rdx
	cmovbq	%rdx, %rax
	cmpq	%r9, %rcx
	sete	%dl
	cmpl	%ebx, %r8d
	sete	%r10b
	testb	%r10b, %dl
	jne	.LBB23_16
	movq	%rax, 48(%rsp)
	movl	%ebx, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	%r9, %rdx
	movl	%r8d, %r9d
	xorl	%r8d, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE
	jmp	.LBB23_16
.LBB23_11:
	xorl	%eax, %eax
.LBB23_16:
	cmpq	%rsi, %rax
	sete	%al
.LBB23_17:
	.seh_startepilogue
	addq	$64, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB23_18:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%r10, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB23_19:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%r11, %rcx
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB23_20:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%rax, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB23_21:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%rdx, %rcx
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena13collect_bytes17h2481e8508043f24cE;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena13collect_bytes17h2481e8508043f24cE,unique,24
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena13collect_bytes17h2481e8508043f24cE:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena13collect_bytes17h2481e8508043f24cE
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rcx, %rdi
	movq	16(%rcx), %rbx
	movl	%edx, %ecx
	cmpq	%rcx, %rbx
	jbe	.LBB24_8
	movq	%r8, %rsi
	movq	8(%rdi), %r15
	.p2align	4
.LBB24_2:
	leaq	(%rcx,%rcx,2), %rax
	shlq	$4, %rax
	leaq	(%r15,%rax), %r14
	movl	(%r15,%rax), %eax
	cmpl	$1, %eax
	jne	.LBB24_3
	movl	4(%r14), %edx
	movq	%rdi, %rcx
	movq	%rsi, %r8
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena13collect_bytes17h2481e8508043f24cE
	movl	8(%r14), %ecx
	cmpq	%rcx, %rbx
	ja	.LBB24_2
.LBB24_8:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.50(%rip), %r8
	movq	%rbx, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB24_3:
	testl	%eax, %eax
	jne	.LBB24_9
	movq	32(%r14), %rdx
	movq	40(%r14), %rdi
	movq	(%rsi), %rax
	movq	16(%rsi), %rcx
	subq	%rcx, %rax
	cmpq	%rax, %rdi
	ja	.LBB24_5
.LBB24_6:
	addq	8(%rsi), %rcx
	movq	%rdi, %r8
	callq	memcpy
	addq	%rdi, 16(%rsi)
	jmp	.LBB24_11
.LBB24_9:
	movq	8(%r14), %rbx
	testq	%rbx, %rbx
	je	.LBB24_11
	.p2align	4
.LBB24_10:
	movl	4(%r14), %edx
	movq	%rdi, %rcx
	movq	%rsi, %r8
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena13collect_bytes17h2481e8508043f24cE
	decq	%rbx
	jne	.LBB24_10
.LBB24_11:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB24_5:
	movq	%rcx, %rax
	movq	%rsi, %rcx
	movq	%rdx, %rbx
	movq	%rax, %rdx
	movq	%rdi, %r8
	callq	_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17hd373a462eb04ccaaE
	movq	%rbx, %rdx
	movq	16(%rsi), %rcx
	jmp	.LBB24_6
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena13make_internal17ha3e866f61b9e564cE;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena13make_internal17ha3e866f61b9e564cE,unique,25
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena13make_internal17ha3e866f61b9e564cE:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena13make_internal17ha3e866f61b9e564cE
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rcx, %rsi
	movl	%edx, %ecx
	movq	16(%rsi), %r14
	cmpq	%rcx, %r14
	jbe	.LBB25_11
	movl	%r8d, %edi
	movl	%edx, %ebx
	movq	8(%rsi), %rdx
	leaq	(%rcx,%rcx,2), %r8
	shlq	$4, %r8
	movl	(%rdx,%r8), %r9d
	xorl	%eax, %eax
	testl	%r9d, %r9d
	setne	%r10b
	movl	%edi, %ecx
	cmpq	%rcx, %r14
	jbe	.LBB25_11
	addq	%rdx, %r8
	movb	%r10b, %al
	leaq	(%rcx,%rcx,2), %r11
	shlq	$4, %r11
	movl	(%rdx,%r11), %r10d
	xorl	%ecx, %ecx
	testl	%r10d, %r10d
	setne	%cl
	movl	$1, %r15d
	movl	$1, %r12d
	testl	%r9d, %r9d
	je	.LBB25_4
	movq	32(%r8), %r12
.LBB25_4:
	addq	%r11, %rdx
	testl	%r10d, %r10d
	je	.LBB25_6
	movq	32(%rdx), %r15
.LBB25_6:
	movq	16(%r8,%rax,8), %rbp
	movq	16(%rdx,%rcx,8), %r13
	movq	$-1, %rax
	cmpb	$0, 2128(%rsi)
	jne	.LBB25_8
	leaq	24(%rsi), %rcx
	xorl	%eax, %eax
	testl	%r9d, %r9d
	setne	%al
	movq	8(%r8,%rax,8), %r14
	xorl	%eax, %eax
	testl	%r10d, %r10d
	setne	%al
	movq	%r12, 32(%rsp)
	movl	%ebx, %r12d
	movq	%rbp, %rbx
	movl	%edi, %ebp
	movq	8(%rdx,%rax,8), %rdi
	movq	16(%rdx,%rax,8), %rdx
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE
	mulq	%r14
	addq	%rdi, %rax
	movl	%ebp, %edi
	movq	%rbx, %rbp
	movl	%r12d, %ebx
	movq	32(%rsp), %r12
	adcq	$0, %rdx
	movq	2072(%rsi), %r8
	movl	$127, %r9d
	bsrq	%r8, %r9
	xorl	$63, %r9d
	movb	$64, %cl
	subb	%r9b, %cl
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	xorl	%r10d, %r10d
	testb	$64, %cl
	cmovneq	%rdx, %r9
	cmovneq	%r10, %rdx
	andq	%r8, %rax
	addq	%r9, %rax
	adcq	$0, %rdx
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	testb	$64, %cl
	cmoveq	%r9, %rdx
	andq	%r8, %rax
	addq	%rdx, %rax
	cmpq	%rax, %r8
	cmovaq	%r10, %r8
	subq	%r8, %rax
	movq	16(%rsi), %r14
.LBB25_8:
	cmpq	(%rsi), %r14
	je	.LBB25_9
.LBB25_10:
	addq	%rbp, %r13
	addq	%r12, %r15
	movq	8(%rsi), %rcx
	leaq	(%r14,%r14,2), %rdx
	shlq	$4, %rdx
	movl	$1, (%rcx,%rdx)
	movl	%ebx, 4(%rcx,%rdx)
	movl	%edi, 8(%rcx,%rdx)
	movq	%rax, 16(%rcx,%rdx)
	movq	%r13, 24(%rcx,%rdx)
	movq	%r15, 32(%rcx,%rdx)
	movq	%r14, %rax
	incq	%rax
	movq	%rax, 16(%rsi)
	movl	%r14d, %eax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB25_9:
	movq	%rsi, %rcx
	movq	%rax, 32(%rsp)
	callq	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h3f28a2f1503df7efE
	movq	32(%rsp), %rax
	jmp	.LBB25_10
.LBB25_11:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%r14, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena14validate_inner17ha8790b82eb44a503E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena14validate_inner17ha8790b82eb44a503E,unique,26
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena14validate_inner17ha8790b82eb44a503E:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena14validate_inner17ha8790b82eb44a503E
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$136, %rsp
	.seh_stackalloc 136
	.seh_endprologue
	movq	%rcx, %rbx
	movq	16(%rcx), %rdi
	movl	%edx, %ecx
	cmpq	%rcx, %rdi
	jbe	.LBB26_24
	movq	8(%rbx), %r14
	jmp	.LBB26_2
	.p2align	4
.LBB26_22:
	movq	%rbx, %rcx
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena14validate_inner17ha8790b82eb44a503E
	movl	8(%rsi), %ecx
.LBB26_23:
	cmpq	%rcx, %rdi
	jbe	.LBB26_24
.LBB26_2:
	leaq	(%rcx,%rcx,2), %rax
	shlq	$4, %rax
	leaq	(%r14,%rax), %rsi
	movl	(%r14,%rax), %eax
	cmpl	$1, %eax
	je	.LBB26_8
	cmpl	$2, %eax
	jne	.LBB26_4
	leaq	8(%rsi), %rax
	movq	%rax, 48(%rsp)
	movl	4(%rsi), %ecx
	cmpq	%rcx, %rdi
	jbe	.LBB26_38
	leaq	(%rcx,%rcx,2), %rax
	shlq	$4, %rax
	leaq	(%r14,%rax), %rdx
	movl	(%r14,%rax), %r8d
	xorl	%r9d, %r9d
	testl	%r8d, %r8d
	setne	%r9b
	movq	8(%rsi), %rax
	movq	16(%rdx,%r9,8), %r9
	imulq	%rax, %r9
	movq	%r9, 120(%rsp)
	cmpq	%r9, 24(%rsi)
	jne	.LBB26_30
	testl	%r8d, %r8d
	je	.LBB26_32
	movq	32(%rdx), %rdx
	imulq	%rax, %rdx
	movq	%rdx, 128(%rsp)
	cmpq	%rdx, 32(%rsi)
	je	.LBB26_36
	jmp	.LBB26_35
	.p2align	4
.LBB26_8:
	movl	4(%rsi), %edx
	cmpq	%rdx, %rdi
	jbe	.LBB26_40
	movl	8(%rsi), %ecx
	cmpq	%rcx, %rdi
	jbe	.LBB26_38
	leaq	(%rdx,%rdx,2), %r8
	shlq	$4, %r8
	leaq	(%r14,%r8), %rax
	movl	(%r14,%r8), %r8d
	xorl	%r11d, %r11d
	testl	%r8d, %r8d
	setne	%r11b
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	leaq	(%r14,%rcx), %r9
	movl	(%r14,%rcx), %r10d
	xorl	%ecx, %ecx
	testl	%r10d, %r10d
	setne	%cl
	movq	16(%r9,%rcx,8), %rcx
	addq	16(%rax,%r11,8), %rcx
	movq	%rcx, 104(%rsp)
	cmpq	%rcx, 24(%rsi)
	jne	.LBB26_11
	movl	$1, %ecx
	movl	$1, %r11d
	testl	%r8d, %r8d
	je	.LBB26_14
	movq	32(%rax), %r11
.LBB26_14:
	testl	%r10d, %r10d
	je	.LBB26_16
	movq	32(%r9), %rcx
.LBB26_16:
	addq	%r11, %rcx
	movq	%rcx, 112(%rsp)
	cmpq	%rcx, 32(%rsi)
	jne	.LBB26_17
	movq	%rcx, 88(%rsp)
	testl	%r8d, %r8d
	je	.LBB26_19
	movq	32(%rax), %rax
	movq	%rax, 48(%rsp)
	cmpq	$2, %rcx
	jbe	.LBB26_22
	jmp	.LBB26_25
.LBB26_32:
	movl	$1, %edx
	imulq	%rax, %rdx
	movq	%rdx, 128(%rsp)
	cmpq	%rdx, 32(%rsi)
	jne	.LBB26_35
.LBB26_36:
	cmpq	$1, %rax
	ja	.LBB26_23
	jmp	.LBB26_37
.LBB26_19:
	movl	$1, %eax
	movq	%rax, 48(%rsp)
	cmpq	$2, %rcx
	jbe	.LBB26_22
.LBB26_25:
	leaq	(%rcx,%rcx), %r9
	leaq	(,%rax,8), %r8
	subq	%rax, %r8
	cmpq	%r8, %r9
	ja	.LBB26_39
	leaq	(%rcx,%rcx,4), %rax
	cmpq	%rax, %r8
	jbe	.LBB26_22
	leaq	48(%rsp), %rax
	movq	%rax, 56(%rsp)
	leaq	_ZN4core3fmt3num3imp52_$LT$impl$u20$core..fmt..Display$u20$for$u20$u64$GT$3fmt17h9f4f228998531a48E(%rip), %rax
	movq	%rax, 64(%rsp)
	leaq	88(%rsp), %rcx
	movq	%rcx, 72(%rsp)
	movq	%rax, 80(%rsp)
	leaq	anon.831c2442e46e5e41962cfb504544efb1.60(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.61(%rip), %r8
	leaq	56(%rsp), %rdx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB26_4:
	movq	40(%rsi), %rax
	movq	%rax, 96(%rsp)
	cmpq	%rax, 16(%rsi)
	jne	.LBB26_5
	.seh_startepilogue
	addq	$136, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.LBB26_30:
	addq	$24, %rsi
	leaq	anon.831c2442e46e5e41962cfb504544efb1.63(%rip), %rax
	movq	%rax, 40(%rsp)
	movq	$47, 32(%rsp)
	leaq	anon.831c2442e46e5e41962cfb504544efb1.62(%rip), %r9
	leaq	120(%rsp), %r8
	xorl	%ecx, %ecx
	movq	%rsi, %rdx
	callq	_ZN4core9panicking13assert_failed17h05de43114f7e23d0E
.LBB26_11:
	addq	$24, %rsi
	leaq	anon.831c2442e46e5e41962cfb504544efb1.55(%rip), %rax
	movq	%rax, 40(%rsp)
	movq	$43, 32(%rsp)
	leaq	anon.831c2442e46e5e41962cfb504544efb1.54(%rip), %r9
	leaq	104(%rsp), %r8
	xorl	%ecx, %ecx
	movq	%rsi, %rdx
	callq	_ZN4core9panicking13assert_failed17h05de43114f7e23d0E
.LBB26_35:
	addq	$32, %rsi
	leaq	anon.831c2442e46e5e41962cfb504544efb1.65(%rip), %rax
	movq	%rax, 40(%rsp)
	movq	$53, 32(%rsp)
	leaq	anon.831c2442e46e5e41962cfb504544efb1.64(%rip), %r9
	leaq	128(%rsp), %r8
	xorl	%ecx, %ecx
	movq	%rsi, %rdx
	callq	_ZN4core9panicking13assert_failed17h05de43114f7e23d0E
.LBB26_17:
	addq	$32, %rsi
	leaq	anon.831c2442e46e5e41962cfb504544efb1.57(%rip), %rax
	movq	%rax, 40(%rsp)
	movq	$49, 32(%rsp)
	leaq	anon.831c2442e46e5e41962cfb504544efb1.56(%rip), %r9
	leaq	112(%rsp), %r8
	xorl	%ecx, %ecx
	movq	%rsi, %rdx
	callq	_ZN4core9panicking13assert_failed17h05de43114f7e23d0E
.LBB26_37:
	leaq	48(%rsp), %rax
	movq	%rax, 56(%rsp)
	leaq	_ZN44_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$3fmt17hf512590d10024b5fE(%rip), %rax
	movq	%rax, 64(%rsp)
	leaq	anon.831c2442e46e5e41962cfb504544efb1.66(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.67(%rip), %r8
	leaq	56(%rsp), %rdx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB26_39:
	leaq	48(%rsp), %rax
	movq	%rax, 56(%rsp)
	leaq	_ZN4core3fmt3num3imp52_$LT$impl$u20$core..fmt..Display$u20$for$u20$u64$GT$3fmt17h9f4f228998531a48E(%rip), %rax
	movq	%rax, 64(%rsp)
	leaq	88(%rsp), %rcx
	movq	%rcx, 72(%rsp)
	movq	%rax, 80(%rsp)
	leaq	anon.831c2442e46e5e41962cfb504544efb1.58(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.59(%rip), %r8
	leaq	56(%rsp), %rdx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB26_5:
	addq	$16, %rsi
	leaq	anon.831c2442e46e5e41962cfb504544efb1.53(%rip), %rax
	movq	%rax, 40(%rsp)
	movq	$35, 32(%rsp)
	leaq	anon.831c2442e46e5e41962cfb504544efb1.52(%rip), %r9
	leaq	96(%rsp), %r8
	xorl	%ecx, %ecx
	movq	%rsi, %rdx
	callq	_ZN4core9panicking13assert_failed17h05de43114f7e23d0E
.LBB26_24:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.51(%rip), %r8
	movq	%rdi, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB26_38:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%rdi, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB26_40:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena16lcp_range_across17h2b5fd754af3fafdbE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena16lcp_range_across17h2b5fd754af3fafdbE,unique,27
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena16lcp_range_across17h2b5fd754af3fafdbE
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena16lcp_range_across17h2b5fd754af3fafdbE:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena16lcp_range_across17h2b5fd754af3fafdbE
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movl	%r8d, %r10d
	testb	$1, %dl
	je	.LBB27_1
	movq	16(%rcx), %r11
	movl	%r10d, %eax
	cmpq	%rax, %r11
	jbe	.LBB27_24
	movq	8(%rcx), %r8
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	leaq	(%r8,%rax), %r11
	xorl	%esi, %esi
	cmpl	$0, (%r8,%rax)
	setne	%sil
	movq	16(%r11,%rsi,8), %rbx
	jmp	.LBB27_4
.LBB27_1:
	xorl	%ebx, %ebx
.LBB27_4:
	movl	160(%rsp), %esi
	movl	152(%rsp), %edi
	movq	144(%rsp), %r8
	testb	$1, %dil
	je	.LBB27_5
	movq	16(%r8), %r11
	movl	%esi, %eax
	cmpq	%rax, %r11
	jbe	.LBB27_24
	movq	8(%r8), %r11
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	leaq	(%r11,%rax), %r14
	xorl	%r15d, %r15d
	cmpl	$0, (%r11,%rax)
	setne	%r15b
	movq	16(%r14,%r15,8), %r14
	jmp	.LBB27_8
.LBB27_5:
	xorl	%r14d, %r14d
.LBB27_8:
	subq	%r9, %rbx
	jb	.LBB27_25
	movq	176(%rsp), %rax
	cmpq	%rbx, %rax
	ja	.LBB27_25
	movq	168(%rsp), %r11
	subq	%r11, %r14
	jb	.LBB27_26
	cmpq	%r14, %rax
	ja	.LBB27_26
	testq	%rax, %rax
	je	.LBB27_13
	cmpq	%r8, %rcx
	jne	.LBB27_20
	testb	$1, %dl
	je	.LBB27_18
	testb	$1, %dil
	je	.LBB27_27
	cmpl	%esi, %r10d
	sete	%bl
	cmpq	%r11, %r9
	sete	%bpl
	testb	%bl, %bpl
	je	.LBB27_20
	jmp	.LBB27_23
.LBB27_13:
	xorl	%eax, %eax
	jmp	.LBB27_23
.LBB27_18:
	movl	%edi, %ebx
	xorb	$1, %bl
	cmpq	%r11, %r9
	sete	%bpl
	testb	%bl, %bpl
	jne	.LBB27_23
.LBB27_20:
	testb	$1, %dl
	je	.LBB27_28
	testb	$1, %dil
	je	.LBB27_27
	movq	%rax, 48(%rsp)
	movl	%esi, 40(%rsp)
	movq	%r11, 32(%rsp)
	movq	%r8, %rdx
	movq	%r9, %r8
	movl	%r10d, %r9d
	callq	_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE
.LBB27_23:
	nop
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB27_25:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.68(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.69(%rip), %r8
	movl	$71, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB27_26:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.70(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.71(%rip), %r8
	movl	$73, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB27_28:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.72(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.LBB27_24:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%rax, %rcx
	movq	%r11, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB27_27:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.73(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena17ensure_hash_inner17h495c162be458b4acE;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena17ensure_hash_inner17h495c162be458b4acE,unique,28
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena17ensure_hash_inner17h495c162be458b4acE:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena17ensure_hash_inner17h495c162be458b4acE
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movl	%edx, %esi
	movq	16(%rcx), %rdx
	cmpq	%rsi, %rdx
	jbe	.LBB28_17
	movq	%rcx, %rdi
	movq	8(%rcx), %rax
	leaq	(%rsi,%rsi,2), %r15
	shlq	$4, %r15
	movl	(%rax,%r15), %ecx
	addq	%r15, %rax
	xorl	%edx, %edx
	testl	%ecx, %ecx
	setne	%dl
	cmpq	$-1, 8(%rax,%rdx,8)
	jne	.LBB28_10
	testl	%ecx, %ecx
	je	.LBB28_7
	cmpl	$2, %ecx
	jne	.LBB28_4
	movl	4(%rax), %ebx
	movq	8(%rax), %r14
	movq	%rdi, %rcx
	movl	%ebx, %edx
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena17ensure_hash_inner17h495c162be458b4acE
	movq	16(%rdi), %rdx
	cmpq	%rbx, %rdx
	jbe	.LBB28_15
	movq	8(%rdi), %rax
	leaq	(%rbx,%rbx,2), %rcx
	shlq	$4, %rcx
	leaq	(%rax,%rcx), %rdx
	xorl	%r8d, %r8d
	cmpl	$0, (%rax,%rcx)
	setne	%r8b
	movq	8(%rdx,%r8,8), %r12
	movq	16(%rdx,%r8,8), %rdx
	leaq	24(%rdi), %rcx
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE
	movq	2072(%rdi), %rbx
	movq	%r14, %rcx
	movq	%rax, %rdx
	movq	%rbx, %r8
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash3phi17hc786991a0fa0b177E
	mulq	%r12
	movl	$127, %r8d
	bsrq	%rbx, %r8
	xorl	$63, %r8d
	movb	$64, %cl
	subb	%r8b, %cl
	movq	%rdx, %r8
	shrq	%cl, %r8
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	xorl	%edx, %edx
	testb	$64, %cl
	cmovneq	%r8, %r9
	cmovneq	%rdx, %r8
	andq	%rbx, %rax
	addq	%r9, %rax
	adcq	$0, %r8
	movq	%rax, %r9
	shrdq	%cl, %r8, %r9
	shrq	%cl, %r8
	testb	$64, %cl
	cmoveq	%r9, %r8
	andq	%rbx, %rax
	addq	%r8, %rax
	cmpq	%rax, %rbx
	cmovaq	%rdx, %rbx
	subq	%rbx, %rax
	jmp	.LBB28_8
.LBB28_7:
	leaq	24(%rdi), %rcx
	movq	32(%rax), %rdx
	movq	40(%rax), %r8
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash4hash17hef62f54324bd5bc8E
	jmp	.LBB28_8
.LBB28_4:
	movl	4(%rax), %r14d
	movl	8(%rax), %ebx
	movq	%rdi, %rcx
	movl	%r14d, %edx
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena17ensure_hash_inner17h495c162be458b4acE
	movq	%rdi, %rcx
	movl	%ebx, %edx
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena17ensure_hash_inner17h495c162be458b4acE
	movq	16(%rdi), %rdx
	cmpq	%r14, %rdx
	jbe	.LBB28_11
	cmpq	%rbx, %rdx
	jbe	.LBB28_12
	leaq	24(%rdi), %rcx
	movq	8(%rdi), %rax
	leaq	(%r14,%r14,2), %rdx
	shlq	$4, %rdx
	xorl	%r8d, %r8d
	cmpl	$0, (%rax,%rdx)
	leaq	(%rax,%rdx), %rdx
	setne	%r8b
	movq	8(%rdx,%r8,8), %r14
	leaq	(%rbx,%rbx,2), %rdx
	shlq	$4, %rdx
	xorl	%r8d, %r8d
	cmpl	$0, (%rax,%rdx)
	leaq	(%rax,%rdx), %rax
	setne	%r8b
	movq	8(%rax,%r8,8), %rbx
	movq	16(%rax,%r8,8), %rdx
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE
	mulq	%r14
	addq	%rbx, %rax
	adcq	$0, %rdx
	movq	2072(%rdi), %r8
	movl	$127, %r9d
	bsrq	%r8, %r9
	xorl	$63, %r9d
	movb	$64, %cl
	subb	%r9b, %cl
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	xorl	%r10d, %r10d
	testb	$64, %cl
	cmovneq	%rdx, %r9
	cmovneq	%r10, %rdx
	andq	%r8, %rax
	addq	%r9, %rax
	adcq	$0, %rdx
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	testb	$64, %cl
	cmoveq	%r9, %rdx
	andq	%r8, %rax
	addq	%rdx, %rax
	cmpq	%rax, %r8
	cmovaq	%r10, %r8
	subq	%r8, %rax
.LBB28_8:
	movq	16(%rdi), %rdx
	cmpq	%rsi, %rdx
	jbe	.LBB28_16
	movq	8(%rdi), %rcx
	leaq	(%rcx,%r15), %rdx
	xorl	%r8d, %r8d
	cmpl	$0, (%rcx,%r15)
	setne	%r8b
	movq	%rax, 8(%rdx,%r8,8)
.LBB28_10:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB28_17:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.40(%rip), %r8
	movq	%rsi, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB28_16:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.74(%rip), %r8
	movq	%rsi, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB28_15:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.40(%rip), %r8
	movq	%rbx, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB28_11:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.40(%rip), %r8
	movq	%r14, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB28_12:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%rbx, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena18equal_range_across17h2685b41debabad9dE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena18equal_range_across17h2685b41debabad9dE,unique,29
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena18equal_range_across17h2685b41debabad9dE
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena18equal_range_across17h2685b41debabad9dE:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena18equal_range_across17h2685b41debabad9dE
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	movq	128(%rsp), %rax
	movl	136(%rsp), %r10d
	movl	144(%rsp), %r11d
	movq	152(%rsp), %rsi
	movq	160(%rsp), %rdi
	movq	%rdi, 64(%rsp)
	movq	%rsi, 56(%rsp)
	movl	%r11d, 48(%rsp)
	movl	%r10d, 40(%rsp)
	movq	%rax, 32(%rsp)
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena16lcp_range_across17h2b5fd754af3fafdbE
	cmpq	%rdi, %rax
	sete	%al
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena3lcp17hfc28df24ba3df6f8E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena3lcp17hfc28df24ba3df6f8E,unique,30
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena3lcp17hfc28df24ba3df6f8E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena3lcp17hfc28df24ba3df6f8E:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena3lcp17hfc28df24ba3df6f8E
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$64, %rsp
	.seh_stackalloc 64
	.seh_endprologue
	testl	%edx, %r9d
	je	.LBB30_6
	movl	%r8d, %r10d
	movl	%r8d, %eax
	movq	16(%rcx), %rdx
	cmpq	%rax, %rdx
	jbe	.LBB30_7
	movl	112(%rsp), %r8d
	movl	%r8d, %r9d
	cmpq	%r9, %rdx
	jbe	.LBB30_8
	movq	8(%rcx), %rdx
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	leaq	(%rdx,%rax), %r11
	xorl	%esi, %esi
	cmpl	$0, (%rdx,%rax)
	setne	%sil
	movq	16(%r11,%rsi,8), %rax
	leaq	(%r9,%r9,2), %r9
	shlq	$4, %r9
	leaq	(%rdx,%r9), %r11
	xorl	%esi, %esi
	cmpl	$0, (%rdx,%r9)
	setne	%sil
	movq	16(%r11,%rsi,8), %rdx
	cmpq	%rax, %rdx
	cmovbq	%rdx, %rax
	cmpl	%r8d, %r10d
	je	.LBB30_5
	movq	%rax, 48(%rsp)
	movl	%r8d, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	%rcx, %rdx
	xorl	%r8d, %r8d
	movl	%r10d, %r9d
	callq	_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE
.LBB30_5:
	nop
	.seh_startepilogue
	addq	$64, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB30_6:
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$64, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB30_7:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%rax, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB30_8:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%r9, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena3new17h3f1573a07bb75c9aE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena3new17h3f1573a07bb75c9aE,unique,31
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena3new17h3f1573a07bb75c9aE
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena3new17h3f1573a07bb75c9aE:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena3new17h3f1573a07bb75c9aE
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$2088, %rsp
	.seh_stackalloc 2088
	.seh_endprologue
	movq	%rcx, %rsi
	movabsq	$2305843009213693951, %rdi
	leaq	48(%rsp), %rcx
	movl	$2040, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	$1, 40(%rsp)
	movl	$1, %eax
	movl	$131, %r8d
	movabsq	$-2305843009213693951, %r9
	movl	$1, %r10d
	.p2align	4
.LBB31_1:
	mulq	%r8
	movq	%rax, %rcx
	shrq	$61, %rax
	leaq	(%rax,%rdx,8), %rax
	andq	%rdi, %rcx
	addq	%rax, %rcx
	movq	%rcx, %rax
	shrq	$61, %rax
	andq	%rdi, %rcx
	addq	%rax, %rcx
	leaq	(%rcx,%r9), %rax
	cmpq	%rdi, %rcx
	cmovbq	%rcx, %rax
	movq	%rax, 40(%rsp,%r10,8)
	incq	%r10
	cmpq	$256, %r10
	jne	.LBB31_1
	movq	$0, (%rsi)
	movq	$8, 8(%rsi)
	movq	$0, 16(%rsi)
	leaq	24(%rsi), %rcx
	leaq	40(%rsp), %rdx
	movl	$2048, %r8d
	callq	memcpy
	movq	%rdi, 2072(%rsi)
	movq	$131, 2080(%rsi)
	movq	$0, 2088(%rsi)
	movq	$0, 2104(%rsi)
	movq	%rdi, 2112(%rsi)
	movq	$131, 2120(%rsi)
	movb	$0, 2128(%rsi)
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$2088, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E,unique,32
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E:
.Lfunc_begin3:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$88, %rsp
	.seh_stackalloc 88
	leaq	80(%rsp), %rbp
	.seh_setframe %rbp, 80
	.seh_endprologue
	movq	$-2, (%rbp)
	movq	16(%rcx), %rax
	movl	%edx, %r9d
	cmpq	%r9, %rax
	jbe	.LBB32_7
	movq	8(%rcx), %rdi
	leaq	(%r9,%r9,2), %r9
	shlq	$4, %r9
	leaq	(%rdi,%r9), %r10
	movl	(%rdi,%r9), %r11d
	testl	%r11d, %r11d
	je	.LBB32_2
	movq	32(%r10), %rsi
	movl	%r8d, %r9d
	cmpq	%r9, %rax
	jbe	.LBB32_7
.LBB32_5:
	leaq	(%r9,%r9,2), %r9
	shlq	$4, %r9
	leaq	(%rdi,%r9), %rax
	movl	(%rdi,%r9), %r9d
	testl	%r9d, %r9d
	je	.LBB32_6
	movq	32(%rax), %rdi
	addq	%rsi, %rdi
	cmpq	$3, %rdi
	jae	.LBB32_10
	jmp	.LBB32_59
.LBB32_2:
	movl	$1, %esi
	movl	%r8d, %r9d
	cmpq	%r9, %rax
	ja	.LBB32_5
.LBB32_7:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.44(%rip), %r8
	movq	%r9, %rcx
	movq	%rax, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB32_6:
	movl	$1, %edi
	addq	%rsi, %rdi
	cmpq	$3, %rdi
	jb	.LBB32_59
.LBB32_10:
	leaq	(%rdi,%rdi), %r14
	leaq	(,%rsi,8), %rbx
	subq	%rsi, %rbx
	cmpq	%rbx, %r14
	ja	.LBB32_12
	leaq	(%rdi,%rdi,4), %rsi
	cmpq	%rsi, %rbx
	ja	.LBB32_12
.LBB32_59:
	.seh_startepilogue
	addq	$88, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	jmp	_ZN26hashrope_diagnostic_slot_b4rope5Arena13make_internal17ha3e866f61b9e564cE
.LBB32_12:
	movl	$1, %esi
	movl	$1, %edi
	testl	%r11d, %r11d
	je	.LBB32_14
	movq	32(%r10), %rdi
.LBB32_14:
	testl	%r9d, %r9d
	je	.LBB32_16
	movq	32(%rax), %rsi
.LBB32_16:
	cmpq	%rsi, %rdi
	jbe	.LBB32_17
	cmpl	$2, %r11d
	je	.LBB32_52
	cmpl	$1, %r11d
	jne	.LBB32_42
	movl	4(%r10), %esi
	movl	8(%r10), %edx
	movq	24(%r10), %rbx
	movq	32(%r10), %r14
	movb	$1, -2(%rbp)
	movq	%rbx, -32(%rbp)
	movq	%r14, -40(%rbp)
.Ltmp68:
	movq	%rcx, %rdi
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E
.Ltmp69:
	movb	$1, -2(%rbp)
	movq	%rbx, -32(%rbp)
	movq	%r14, -40(%rbp)
.Ltmp70:
	movq	%rdi, %rcx
	movl	%esi, %edx
	movl	%eax, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena7balance17hff2163d25d98077fE
.Ltmp71:
	jmp	.LBB32_58
.LBB32_17:
	cmpl	$2, %r9d
	je	.LBB32_31
	cmpl	$1, %r9d
	jne	.LBB32_19
	movl	4(%rax), %r8d
	movq	8(%rax), %rsi
	movq	24(%rax), %rbx
	movq	32(%rax), %r14
	movb	$1, -1(%rbp)
	movq	%rbx, -16(%rbp)
	movq	%r14, -24(%rbp)
.Ltmp50:
	movq	%rcx, %rdi
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E
.Ltmp51:
	movb	$1, -1(%rbp)
	movq	%rbx, -16(%rbp)
	movq	%r14, -24(%rbp)
.Ltmp52:
	movq	%rdi, %rcx
	movl	%eax, %edx
	movl	%esi, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena7balance17hff2163d25d98077fE
.Ltmp53:
	jmp	.LBB32_58
.LBB32_52:
	movl	%r8d, -44(%rbp)
	movl	4(%r10), %r14d
	movq	8(%r10), %r15
	movq	24(%r10), %rdi
	movq	32(%r10), %r13
	movq	%r15, %r12
	shrq	%r12
	movb	$1, -2(%rbp)
	movq	%rdi, -32(%rbp)
	movq	%r13, -40(%rbp)
.Ltmp56:
	movq	%rcx, %rsi
	movl	%r14d, %edx
	movq	%r12, %r8
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11make_repeat17h9a70e50e745a5030E
.Ltmp57:
	testb	$1, %al
	je	.LBB32_61
	movl	%edx, %ebx
	subq	%r12, %r15
	movb	$1, -2(%rbp)
	movq	%rdi, -32(%rbp)
	movq	%r13, -40(%rbp)
.Ltmp60:
	movq	%rsi, %rcx
	movl	%r14d, %edx
	movq	%r15, %r8
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11make_repeat17h9a70e50e745a5030E
.Ltmp61:
	testb	$1, %al
	je	.LBB32_62
	movb	$1, -2(%rbp)
	movq	%rdi, -32(%rbp)
	movq	%r13, -40(%rbp)
.Ltmp64:
	movq	%rsi, %rcx
	movl	-44(%rbp), %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E
.Ltmp65:
	movb	$1, -2(%rbp)
	movq	%rdi, -32(%rbp)
	movq	%r13, -40(%rbp)
.Ltmp66:
	movq	%rsi, %rcx
	movl	%ebx, %edx
	movl	%eax, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E
.Ltmp67:
	jmp	.LBB32_58
.LBB32_31:
	movl	%edx, -44(%rbp)
	movl	4(%rax), %r14d
	movq	8(%rax), %r15
	movq	24(%rax), %rdi
	movq	32(%rax), %r13
	movq	%r15, %r12
	shrq	%r12
	movb	$1, -1(%rbp)
	movq	%rdi, -16(%rbp)
	movq	%r13, -24(%rbp)
.Ltmp38:
	movq	%rcx, %rsi
	movl	%r14d, %edx
	movq	%r12, %r8
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11make_repeat17h9a70e50e745a5030E
.Ltmp39:
	testb	$1, %al
	je	.LBB32_37
	movl	%edx, %ebx
	subq	%r12, %r15
	movb	$1, -1(%rbp)
	movq	%rdi, -16(%rbp)
	movq	%r13, -24(%rbp)
.Ltmp42:
	movq	%rsi, %rcx
	movl	%r14d, %edx
	movq	%r15, %r8
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11make_repeat17h9a70e50e745a5030E
.Ltmp43:
	testb	$1, %al
	je	.LBB32_39
	movl	%edx, %r14d
	movb	$1, -1(%rbp)
	movq	%rdi, -16(%rbp)
	movq	%r13, -24(%rbp)
.Ltmp46:
	movq	%rsi, %rcx
	movl	-44(%rbp), %edx
	movl	%ebx, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E
.Ltmp47:
	movb	$1, -1(%rbp)
	movq	%rdi, -16(%rbp)
	movq	%r13, -24(%rbp)
.Ltmp48:
	movq	%rsi, %rcx
	movl	%eax, %edx
	movl	%r14d, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E
.Ltmp49:
	jmp	.LBB32_58
.LBB32_42:
	movl	%edx, %r14d
	movl	%r8d, %edi
	movq	%rcx, %r15
	movq	32(%r10), %r12
	movq	40(%r10), %rsi
	testq	%rsi, %rsi
	je	.LBB32_43
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$1, %edx
	movq	%rsi, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB32_60
	movq	%rax, %rbx
	jmp	.LBB32_46
.LBB32_19:
	movl	%edx, %r14d
	movl	%r8d, %edi
	movq	%rcx, %r15
	movq	32(%rax), %r12
	movq	40(%rax), %rsi
	testq	%rsi, %rsi
	je	.LBB32_20
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$1, %edx
	movq	%rsi, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB32_60
	movq	%rax, %rbx
	jmp	.LBB32_23
.LBB32_43:
	movl	$1, %ebx
.LBB32_46:
	movq	%rbx, %rcx
	movq	%r12, %rdx
	movq	%rsi, %r8
	callq	memcpy
	movb	$0, -2(%rbp)
	movq	%rsi, -32(%rbp)
	movq	%rbx, -40(%rbp)
.Ltmp72:
	movq	%r15, %rcx
	movl	%r14d, %edx
	movl	%edi, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena13make_internal17ha3e866f61b9e564cE
.Ltmp73:
	jmp	.LBB32_24
.LBB32_20:
	movl	$1, %ebx
.LBB32_23:
	movq	%rbx, %rcx
	movq	%r12, %rdx
	movq	%rsi, %r8
	callq	memcpy
	movb	$0, -1(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rbx, -24(%rbp)
.Ltmp54:
	movq	%r15, %rcx
	movl	%r14d, %edx
	movl	%edi, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena13make_internal17ha3e866f61b9e564cE
.Ltmp55:
.LBB32_24:
	testq	%rsi, %rsi
	je	.LBB32_58
	movl	$1, %r8d
	movq	%rbx, %rcx
	movq	%rsi, %rdx
	movl	%eax, %esi
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	movl	%esi, %eax
.LBB32_58:
	.seh_startepilogue
	addq	$88, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.LBB32_61:
	movb	$1, -2(%rbp)
	movq	%rdi, -32(%rbp)
	movq	%r13, -40(%rbp)
.Ltmp58:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.77(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.Ltmp59:
	jmp	.LBB32_38
.LBB32_37:
	movb	$1, -1(%rbp)
	movq	%rdi, -16(%rbp)
	movq	%r13, -24(%rbp)
.Ltmp40:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.75(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.Ltmp41:
	jmp	.LBB32_38
.LBB32_62:
	movb	$1, -2(%rbp)
	movq	%rdi, -32(%rbp)
	movq	%r13, -40(%rbp)
.Ltmp62:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.78(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.Ltmp63:
	jmp	.LBB32_38
.LBB32_39:
	movb	$1, -1(%rbp)
	movq	%rdi, -16(%rbp)
	movq	%r13, -24(%rbp)
.Ltmp44:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.76(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.Ltmp45:
.LBB32_38:
	ud2
.LBB32_60:
	movl	$1, %ecx
	movq	%rsi, %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
	int3
	.seh_handlerdata
	.long	$cppxdata$_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E@IMGREL
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E,unique,32
	.seh_endproc
	.def	"?dtor$26@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$26@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E@4HA":
.seh_proc "?dtor$26@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E@4HA"
.LBB32_26:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	80(%rdx), %rbp
	.seh_endprologue
	movq	-16(%rbp), %rdx
	testq	%rdx, %rdx
	sete	%al
	orb	-1(%rbp), %al
	testb	$1, %al
	jne	.LBB32_28
	movq	-24(%rbp), %rcx
	movl	$1, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB32_28:
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E,unique,32
	.seh_endproc
	.def	"?dtor$47@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$47@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E@4HA":
.seh_proc "?dtor$47@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E@4HA"
.LBB32_47:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	80(%rdx), %rbp
	.seh_endprologue
	movq	-32(%rbp), %rdx
	testq	%rdx, %rdx
	sete	%al
	orb	-2(%rbp), %al
	testb	$1, %al
	jne	.LBB32_49
	movq	-40(%rbp), %rcx
	movl	$1, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB32_49:
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.Lfunc_end3:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E,unique,32
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E,unique,3
	.p2align	2, 0x0
$cppxdata$_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E:
	.long	429065506
	.long	2
	.long	$stateUnwindMap$_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E@IMGREL
	.long	0
	.long	0
	.long	14
	.long	$ip2state$_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E@IMGREL
	.long	80
	.long	0
	.long	1
$stateUnwindMap$_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E:
	.long	-1
	.long	"?dtor$26@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E@4HA"@IMGREL
	.long	-1
	.long	"?dtor$47@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E@4HA"@IMGREL
$ip2state$_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E:
	.long	.Lfunc_begin3@IMGREL
	.long	-1
	.long	.Ltmp68@IMGREL+1
	.long	1
	.long	.Ltmp50@IMGREL+1
	.long	0
	.long	.Ltmp56@IMGREL+1
	.long	1
	.long	.Ltmp38@IMGREL+1
	.long	0
	.long	.Ltmp49@IMGREL+1
	.long	-1
	.long	.Ltmp72@IMGREL+1
	.long	1
	.long	.Ltmp73@IMGREL+1
	.long	-1
	.long	.Ltmp54@IMGREL+1
	.long	0
	.long	.Ltmp58@IMGREL+1
	.long	1
	.long	.Ltmp40@IMGREL+1
	.long	0
	.long	.Ltmp62@IMGREL+1
	.long	1
	.long	.Ltmp44@IMGREL+1
	.long	0
	.long	.Ltmp45@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E,unique,32

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena5equal17h0364632256ca6ef4E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena5equal17h0364632256ca6ef4E,unique,33
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena5equal17h0364632256ca6ef4E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena5equal17h0364632256ca6ef4E:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena5equal17h0364632256ca6ef4E
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movl	96(%rsp), %eax
	movl	%eax, 40(%rsp)
	movl	%r9d, 32(%rsp)
	movq	%rcx, %r9
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena12equal_across17hfd97c5ebbeced2adE
	nop
	.seh_startepilogue
	addq	$56, %rsp
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena5split17h098d345acda6e642E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena5split17h098d345acda6e642E,unique,34
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena5split17h098d345acda6e642E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena5split17h098d345acda6e642E:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena5split17h098d345acda6e642E
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	2112(%rdx), %rax
	cmpq	2072(%rdx), %rax
	jne	.LBB34_13
	movq	2080(%rdx), %rax
	cmpq	%rax, 2120(%rdx)
	jne	.LBB34_13
	testb	$1, %r8b
	je	.LBB34_7
	movq	80(%rsp), %rax
	testq	%rax, %rax
	je	.LBB34_8
	movl	%r9d, %r11d
	movq	16(%rdx), %r10
	cmpq	%r11, %r10
	jbe	.LBB34_14
	movq	8(%rdx), %r8
	leaq	(%r11,%r11,2), %r10
	shlq	$4, %r10
	xorl	%r11d, %r11d
	cmpl	$0, (%r8,%r10)
	leaq	(%r8,%r10), %r8
	setne	%r11b
	cmpq	16(%r8,%r11,8), %rax
	jae	.LBB34_9
	movq	%rcx, %rsi
	movl	%r9d, %r8d
	movq	%rax, %r9
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB34_7:
	movl	$0, (%rcx)
	jmp	.LBB34_10
.LBB34_8:
	movl	$0, (%rcx)
	movl	$1, 8(%rcx)
	movl	%r9d, 12(%rcx)
	movq	%rcx, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB34_9:
	movl	$1, (%rcx)
	movl	%r9d, 4(%rcx)
.LBB34_10:
	movl	$0, 8(%rcx)
	movq	%rcx, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB34_13:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.37(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB34_14:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%r11, %rcx
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena6concat17h664fe41d3fa8aabcE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena6concat17h664fe41d3fa8aabcE,unique,35
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena6concat17h664fe41d3fa8aabcE
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena6concat17h664fe41d3fa8aabcE:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena6concat17h664fe41d3fa8aabcE
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movl	%edx, %eax
	movq	2112(%rcx), %rdx
	cmpq	2072(%rcx), %rdx
	jne	.LBB35_7
	movq	2080(%rcx), %rdx
	cmpq	%rdx, 2120(%rcx)
	jne	.LBB35_7
	movl	80(%rsp), %edx
	testb	$1, %al
	je	.LBB35_5
	testb	$1, %r9b
	movl	$1, %r9d
	je	.LBB35_6
	movl	%edx, %eax
	movl	%r8d, %edx
	movl	%eax, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E
	movl	$1, %r9d
	movl	%eax, %edx
.LBB35_5:
	movl	%r9d, %eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB35_6:
	movl	%r8d, %edx
	movl	%r9d, %eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB35_7:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.37(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena6height17h7017bbb0bb74db99E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena6height17h7017bbb0bb74db99E,unique,36
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena6height17h7017bbb0bb74db99E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena6height17h7017bbb0bb74db99E:
	testb	$1, %dl
	je	.LBB36_1
	movl	%r8d, %edx
	jmp	_ZN26hashrope_diagnostic_slot_b4rope5Arena11node_height17hf83ff14f0e199e86E
.LBB36_1:
	xorl	%eax, %eax
	retq

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena6repeat17h4f679dc954411830E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena6repeat17h4f679dc954411830E,unique,37
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena6repeat17h4f679dc954411830E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena6repeat17h4f679dc954411830E:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena6repeat17h4f679dc954411830E
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	2112(%rcx), %rax
	cmpq	2072(%rcx), %rax
	jne	.LBB37_6
	movq	2080(%rcx), %rax
	cmpq	%rax, 2120(%rcx)
	jne	.LBB37_6
	testb	$1, %dl
	je	.LBB37_3
	movl	%r8d, %edx
	movq	%r9, %r8
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11make_repeat17h9a70e50e745a5030E
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB37_3:
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB37_6:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.37(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena7balance17hff2163d25d98077fE;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena7balance17hff2163d25d98077fE,unique,38
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena7balance17hff2163d25d98077fE:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena7balance17hff2163d25d98077fE
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movl	%edx, %ebx
	movq	%rcx, %rsi
	movl	%edx, %ecx
	movq	16(%rsi), %rdx
	cmpq	%rcx, %rdx
	jbe	.LBB38_30
	movl	%r8d, %edi
	jmp	.LBB38_2
	.p2align	4
.LBB38_29:
	movq	%rsi, %rcx
	movl	%eax, %edx
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E
	movl	%edx, %ebp
	movq	%rsi, %rcx
	movl	%ebx, %edx
	movl	%eax, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena7balance17hff2163d25d98077fE
	movl	%eax, %ebx
	movq	%rsi, %rcx
	movl	%ebp, %edx
	movl	%edi, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena7balance17hff2163d25d98077fE
	movl	%eax, %edi
	movl	%ebx, %ecx
	movq	16(%rsi), %rdx
	cmpq	%rcx, %rdx
	jbe	.LBB38_30
.LBB38_2:
	movq	8(%rsi), %rax
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	cmpl	$0, (%rax,%rcx)
	je	.LBB38_3
	addq	%rax, %rcx
	movq	32(%rcx), %r15
	movl	%edi, %ecx
	cmpq	%rcx, %rdx
	ja	.LBB38_6
	jmp	.LBB38_30
	.p2align	4
.LBB38_3:
	movl	$1, %r15d
	movl	%edi, %ecx
	cmpq	%rcx, %rdx
	jbe	.LBB38_30
.LBB38_6:
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	cmpl	$0, (%rax,%rcx)
	je	.LBB38_7
	addq	%rcx, %rax
	movq	32(%rax), %r14
	leaq	(%r14,%r15), %rax
	cmpq	$2, %rax
	ja	.LBB38_13
	jmp	.LBB38_10
	.p2align	4
.LBB38_7:
	movl	$1, %r14d
	leaq	(%r14,%r15), %rax
	cmpq	$2, %rax
	jbe	.LBB38_10
.LBB38_13:
	leaq	(%rax,%rax), %rcx
	leaq	(,%r15,8), %r12
	subq	%r15, %r12
	cmpq	%r12, %rcx
	ja	.LBB38_15
	leaq	(%rax,%rax,4), %rax
	cmpq	%rax, %r12
	jbe	.LBB38_10
.LBB38_15:
	cmpq	%r12, %rcx
	jbe	.LBB38_16
	movq	%rsi, %rcx
	movl	%edi, %edx
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E
	movl	%edx, %edi
	movl	%eax, %ecx
	movq	16(%rsi), %rdx
	cmpq	%rcx, %rdx
	jbe	.LBB38_30
	movq	8(%rsi), %r9
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	cmpl	$0, (%r9,%rcx)
	je	.LBB38_35
	addq	%r9, %rcx
	movq	32(%rcx), %r8
	movl	%edi, %ecx
	cmpq	%rcx, %rdx
	ja	.LBB38_38
	jmp	.LBB38_30
	.p2align	4
.LBB38_16:
	movq	%rsi, %rcx
	movl	%ebx, %edx
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E
	movl	%eax, %ebx
	movl	%edx, %eax
	movl	%ebx, %ecx
	movq	16(%rsi), %rdx
	cmpq	%rcx, %rdx
	jbe	.LBB38_30
	movq	8(%rsi), %r9
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	cmpl	$0, (%r9,%rcx)
	je	.LBB38_18
	addq	%r9, %rcx
	movq	32(%rcx), %r8
	movl	%eax, %ecx
	cmpq	%rcx, %rdx
	ja	.LBB38_21
	jmp	.LBB38_30
.LBB38_35:
	movl	$1, %r8d
	movl	%edi, %ecx
	cmpq	%rcx, %rdx
	jbe	.LBB38_30
.LBB38_38:
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	cmpl	$0, (%r9,%rcx)
	je	.LBB38_39
	addq	%rcx, %r9
	movq	32(%r9), %rcx
	addq	%r15, %r8
	cmpq	$3, %r8
	jae	.LBB38_42
	jmp	.LBB38_44
.LBB38_18:
	movl	$1, %r8d
	movl	%eax, %ecx
	cmpq	%rcx, %rdx
	jbe	.LBB38_30
.LBB38_21:
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	cmpl	$0, (%r9,%rcx)
	je	.LBB38_22
	addq	%rcx, %r9
	movq	32(%r9), %rcx
	addq	%rcx, %r14
	cmpq	$3, %r14
	jae	.LBB38_25
	jmp	.LBB38_27
.LBB38_39:
	movl	$1, %ecx
	addq	%r15, %r8
	cmpq	$3, %r8
	jb	.LBB38_44
.LBB38_42:
	leaq	(%r8,%r8), %rdx
	cmpq	%r12, %rdx
	ja	.LBB38_29
	leaq	(%r8,%r8,4), %rdx
	cmpq	%rdx, %r12
	ja	.LBB38_29
.LBB38_44:
	addq	%r8, %rcx
	cmpq	$3, %rcx
	jb	.LBB38_47
	leaq	(%rcx,%rcx), %r9
	leaq	(,%r8,8), %rdx
	subq	%r8, %rdx
	cmpq	%rdx, %r9
	ja	.LBB38_29
	leaq	(%rcx,%rcx,4), %rcx
	cmpq	%rcx, %rdx
	ja	.LBB38_29
	jmp	.LBB38_47
.LBB38_22:
	movl	$1, %ecx
	addq	%rcx, %r14
	cmpq	$3, %r14
	jb	.LBB38_27
.LBB38_25:
	leaq	(%r14,%r14), %r9
	leaq	(,%rcx,8), %rdx
	subq	%rcx, %rdx
	cmpq	%rdx, %r9
	ja	.LBB38_29
	leaq	(%r14,%r14,4), %rcx
	cmpq	%rcx, %rdx
	ja	.LBB38_29
.LBB38_27:
	addq	%r8, %r14
	cmpq	$3, %r14
	jb	.LBB38_32
	leaq	(%r14,%r14), %rdx
	leaq	(,%r8,8), %rcx
	subq	%r8, %rcx
	cmpq	%rcx, %rdx
	ja	.LBB38_29
	leaq	(%r14,%r14,4), %rdx
	cmpq	%rdx, %rcx
	ja	.LBB38_29
.LBB38_32:
	movq	%rsi, %rcx
	movl	%eax, %edx
	movl	%edi, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena13make_internal17ha3e866f61b9e564cE
	movq	%rsi, %rcx
	movl	%ebx, %edx
	movl	%eax, %r8d
	jmp	.LBB38_12
.LBB38_10:
	movq	%rsi, %rcx
	movl	%ebx, %edx
	jmp	.LBB38_11
.LBB38_47:
	movq	%rsi, %rcx
	movl	%ebx, %edx
	movl	%eax, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena13make_internal17ha3e866f61b9e564cE
	movq	%rsi, %rcx
	movl	%eax, %edx
.LBB38_11:
	movl	%edi, %r8d
.LBB38_12:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	jmp	_ZN26hashrope_diagnostic_slot_b4rope5Arena13make_internal17ha3e866f61b9e564cE
.LBB38_30:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.44(%rip), %r8
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena8new_lazy17hec5a357bf116732cE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena8new_lazy17hec5a357bf116732cE,unique,39
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena8new_lazy17hec5a357bf116732cE
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena8new_lazy17hec5a357bf116732cE:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena8new_lazy17hec5a357bf116732cE
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$2088, %rsp
	.seh_stackalloc 2088
	.seh_endprologue
	movq	%rcx, %rsi
	movabsq	$2305843009213693951, %rdi
	leaq	48(%rsp), %rcx
	movl	$2040, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	$1, 40(%rsp)
	movl	$1, %eax
	movl	$131, %r8d
	movabsq	$-2305843009213693951, %r9
	movl	$1, %r10d
	.p2align	4
.LBB39_1:
	mulq	%r8
	movq	%rax, %rcx
	shrq	$61, %rax
	leaq	(%rax,%rdx,8), %rax
	andq	%rdi, %rcx
	addq	%rax, %rcx
	movq	%rcx, %rax
	shrq	$61, %rax
	andq	%rdi, %rcx
	addq	%rax, %rcx
	leaq	(%rcx,%r9), %rax
	cmpq	%rdi, %rcx
	cmovbq	%rcx, %rax
	movq	%rax, 40(%rsp,%r10,8)
	incq	%r10
	cmpq	$256, %r10
	jne	.LBB39_1
	movq	$0, (%rsi)
	movq	$8, 8(%rsi)
	movq	$0, 16(%rsi)
	leaq	24(%rsi), %rcx
	leaq	40(%rsp), %rdx
	movl	$2048, %r8d
	callq	memcpy
	movq	%rdi, 2072(%rsi)
	movq	$131, 2080(%rsi)
	movq	$0, 2088(%rsi)
	movq	$0, 2104(%rsi)
	movq	%rdi, 2112(%rsi)
	movq	$131, 2120(%rsi)
	movb	$1, 2128(%rsi)
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$2088, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena8to_bytes17hf023425145e2eba9E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena8to_bytes17hf023425145e2eba9E,unique,40
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena8to_bytes17hf023425145e2eba9E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena8to_bytes17hf023425145e2eba9E:
.Lfunc_begin4:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena8to_bytes17hf023425145e2eba9E
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$72, %rsp
	.seh_stackalloc 72
	leaq	64(%rsp), %rbp
	.seh_setframe %rbp, 64
	.seh_endprologue
	movq	$-2, (%rbp)
	movq	%rcx, %rsi
	movq	$0, -24(%rbp)
	movq	$1, -16(%rbp)
	movq	$0, -8(%rbp)
	testb	$1, %r8b
	je	.LBB40_2
.Ltmp74:
	leaq	-24(%rbp), %r8
	movq	%rdx, %rcx
	movl	%r9d, %edx
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena13collect_bytes17h2481e8508043f24cE
.Ltmp75:
.LBB40_2:
	movq	-8(%rbp), %rax
	movq	%rax, 16(%rsi)
	movq	-24(%rbp), %rax
	movq	%rax, (%rsi)
	movq	-16(%rbp), %rax
	movq	%rax, 8(%rsi)
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rsi
	popq	%rbp
	.seh_endepilogue
	retq
	.seh_handlerdata
	.long	$cppxdata$_ZN26hashrope_diagnostic_slot_b4rope5Arena8to_bytes17hf023425145e2eba9E@IMGREL
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena8to_bytes17hf023425145e2eba9E,unique,40
	.seh_endproc
	.def	"?dtor$3@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena8to_bytes17hf023425145e2eba9E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$3@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena8to_bytes17hf023425145e2eba9E@4HA":
.seh_proc "?dtor$3@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena8to_bytes17hf023425145e2eba9E@4HA"
.LBB40_3:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	64(%rdx), %rbp
	.seh_endprologue
	movq	-24(%rbp), %rdx
	testq	%rdx, %rdx
	je	.LBB40_5
	movq	-16(%rbp), %rcx
	movl	$1, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB40_5:
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rsi
	popq	%rbp
	.seh_endepilogue
	retq
.Lfunc_end4:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena8to_bytes17hf023425145e2eba9E,unique,40
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN26hashrope_diagnostic_slot_b4rope5Arena8to_bytes17hf023425145e2eba9E,unique,4
	.p2align	2, 0x0
$cppxdata$_ZN26hashrope_diagnostic_slot_b4rope5Arena8to_bytes17hf023425145e2eba9E:
	.long	429065506
	.long	1
	.long	$stateUnwindMap$_ZN26hashrope_diagnostic_slot_b4rope5Arena8to_bytes17hf023425145e2eba9E@IMGREL
	.long	0
	.long	0
	.long	3
	.long	$ip2state$_ZN26hashrope_diagnostic_slot_b4rope5Arena8to_bytes17hf023425145e2eba9E@IMGREL
	.long	64
	.long	0
	.long	1
$stateUnwindMap$_ZN26hashrope_diagnostic_slot_b4rope5Arena8to_bytes17hf023425145e2eba9E:
	.long	-1
	.long	"?dtor$3@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena8to_bytes17hf023425145e2eba9E@4HA"@IMGREL
$ip2state$_ZN26hashrope_diagnostic_slot_b4rope5Arena8to_bytes17hf023425145e2eba9E:
	.long	.Lfunc_begin4@IMGREL
	.long	-1
	.long	.Ltmp74@IMGREL+1
	.long	0
	.long	.Ltmp75@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena8to_bytes17hf023425145e2eba9E,unique,40

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena8validate17h2768c9c52465d0f4E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena8validate17h2768c9c52465d0f4E,unique,41
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena8validate17h2768c9c52465d0f4E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena8validate17h2768c9c52465d0f4E:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena8validate17h2768c9c52465d0f4E
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	2112(%rcx), %rax
	cmpq	2072(%rcx), %rax
	jne	.LBB41_4
	movq	2080(%rcx), %rax
	cmpq	%rax, 2120(%rcx)
	jne	.LBB41_4
	testb	$1, %dl
	je	.LBB41_3
	movl	%r8d, %edx
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	jmp	_ZN26hashrope_diagnostic_slot_b4rope5Arena14validate_inner17ha8790b82eb44a503E
.LBB41_3:
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB41_4:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.37(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E,unique,42
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E:
.Lfunc_begin5:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$72, %rsp
	.seh_stackalloc 72
	leaq	64(%rsp), %rbp
	.seh_setframe %rbp, 64
	.seh_endprologue
	movq	$-2, (%rbp)
	movl	%edx, %eax
	movq	16(%rcx), %rdx
	cmpq	%rax, %rdx
	jbe	.LBB42_19
	movq	8(%rcx), %rdx
	leaq	(%rax,%rax,2), %r8
	shlq	$4, %r8
	leaq	(%rdx,%r8), %rax
	movl	(%rdx,%r8), %edx
	cmpl	$1, %edx
	je	.LBB42_10
	movl	%edx, -20(%rbp)
	cmpl	$2, %edx
	jne	.LBB42_3
	movl	4(%rax), %edi
	movq	8(%rax), %rbx
	movq	24(%rax), %r13
	movq	32(%rax), %r12
	movq	%rbx, %r14
	shrq	%r14
	movq	%r13, -8(%rbp)
	movq	%r12, -16(%rbp)
.Ltmp76:
	movq	%rcx, %r15
	movl	%edi, %edx
	movq	%r14, %r8
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11make_repeat17h9a70e50e745a5030E
.Ltmp77:
	testb	$1, %al
	je	.LBB42_17
	movl	%edx, %esi
	subq	%r14, %rbx
	movq	%r13, -8(%rbp)
	movq	%r12, -16(%rbp)
.Ltmp80:
	movq	%r15, %rcx
	movl	%edi, %edx
	movq	%rbx, %r8
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11make_repeat17h9a70e50e745a5030E
.Ltmp81:
	testb	$1, %al
	jne	.LBB42_11
	movq	%r13, -8(%rbp)
	movq	%r12, -16(%rbp)
.Ltmp82:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.83(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.Ltmp83:
	jmp	.LBB42_18
.LBB42_10:
	movl	4(%rax), %esi
	movl	8(%rax), %edx
.LBB42_11:
	movl	%esi, %eax
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.LBB42_17:
	movq	%r13, -8(%rbp)
	movq	%r12, -16(%rbp)
.Ltmp78:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.82(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.Ltmp79:
	jmp	.LBB42_18
.LBB42_19:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.79(%rip), %r8
	movq	%rax, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB42_3:
	movq	32(%rax), %rdi
	movq	40(%rax), %rsi
	movl	$1, %ebx
	testq	%rsi, %rsi
	je	.LBB42_6
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$1, %edx
	movq	%rsi, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	jne	.LBB42_5
	movl	$1, %ecx
	movq	%rsi, %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
.LBB42_5:
	movq	%rax, %rbx
.LBB42_6:
	movq	%rbx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %r8
	callq	memcpy
	movq	%rsi, -8(%rbp)
	movq	%rbx, -16(%rbp)
.Ltmp84:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.80(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.81(%rip), %r8
	movl	$149, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.Ltmp85:
.LBB42_18:
	ud2
	.seh_handlerdata
	.long	$cppxdata$_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E@IMGREL
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E,unique,42
	.seh_endproc
	.def	"?dtor$7@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$7@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E@4HA":
.seh_proc "?dtor$7@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E@4HA"
.LBB42_7:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	64(%rdx), %rbp
	.seh_endprologue
	movq	-8(%rbp), %rdx
	cmpl	$0, -20(%rbp)
	setne	%al
	testq	%rdx, %rdx
	sete	%cl
	orb	%al, %cl
	jne	.LBB42_9
	movq	-16(%rbp), %rcx
	movl	$1, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB42_9:
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.Lfunc_end5:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E,unique,42
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E,unique,5
	.p2align	2, 0x0
$cppxdata$_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E:
	.long	429065506
	.long	1
	.long	$stateUnwindMap$_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E@IMGREL
	.long	0
	.long	0
	.long	5
	.long	$ip2state$_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E@IMGREL
	.long	64
	.long	0
	.long	1
$stateUnwindMap$_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E:
	.long	-1
	.long	"?dtor$7@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E@4HA"@IMGREL
$ip2state$_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E:
	.long	.Lfunc_begin5@IMGREL
	.long	-1
	.long	.Ltmp76@IMGREL+1
	.long	0
	.long	.Ltmp79@IMGREL+1
	.long	-1
	.long	.Ltmp84@IMGREL+1
	.long	0
	.long	.Ltmp85@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena9decompose17h7aa77f250407f251E,unique,42

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena9lcp_range17h52b457db0543c805E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena9lcp_range17h52b457db0543c805E,unique,43
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena9lcp_range17h52b457db0543c805E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena9lcp_range17h52b457db0543c805E:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena9lcp_range17h52b457db0543c805E
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	movl	112(%rsp), %eax
	movl	120(%rsp), %r10d
	movaps	128(%rsp), %xmm0
	movups	%xmm0, 56(%rsp)
	movl	%r10d, 48(%rsp)
	movl	%eax, 40(%rsp)
	movq	%rcx, 32(%rsp)
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena16lcp_range_across17h2b5fd754af3fafdbE
	nop
	.seh_startepilogue
	addq	$72, %rsp
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE,unique,44
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE:
.Lfunc_begin6:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$72, %rsp
	.seh_stackalloc 72
	leaq	64(%rsp), %rbp
	.seh_setframe %rbp, 64
	.seh_endprologue
	movq	$-2, (%rbp)
	movq	16(%rdx), %r8
	testq	%r8, %r8
	movq	%rdx, -24(%rbp)
	movq	%r8, -32(%rbp)
	je	.LBB44_1
	movq	%rdx, %rbx
	movq	%rcx, %rsi
	cmpb	$1, 2128(%rcx)
	jne	.LBB44_5
	movq	8(%rbx), %rax
	movq	%rax, -8(%rbp)
	movq	$-1, %rdi
	jmp	.LBB44_6
.LBB44_5:
	leaq	24(%rsi), %rcx
	movq	8(%rbx), %rdx
	movq	%rdx, -8(%rbp)
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash4hash17hef62f54324bd5bc8E
	movq	%rax, %rdi
.LBB44_6:
	movq	(%rbx), %rax
	movq	%rax, -16(%rbp)
	movq	16(%rsi), %rbx
	cmpq	(%rsi), %rbx
	jne	.LBB44_8
.Ltmp86:
	movq	%rsi, %rcx
	callq	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h3f28a2f1503df7efE
.Ltmp87:
.LBB44_8:
	movq	8(%rsi), %rax
	leaq	(%rbx,%rbx,2), %rcx
	shlq	$4, %rcx
	movl	$0, (%rax,%rcx)
	movq	%rdi, 8(%rax,%rcx)
	movq	-32(%rbp), %rdx
	movq	%rdx, 16(%rax,%rcx)
	movq	-16(%rbp), %r8
	movq	%r8, 24(%rax,%rcx)
	movq	-8(%rbp), %r8
	movq	%r8, 32(%rax,%rcx)
	movq	%rdx, 40(%rax,%rcx)
	leaq	1(%rbx), %rax
	movq	%rax, 16(%rsi)
	movl	%ebx, %eax
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%rbp
	.seh_endepilogue
	retq
.LBB44_1:
.Ltmp88:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.84(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.85(%rip), %r8
	movl	$41, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.Ltmp89:
	ud2
	.seh_handlerdata
	.long	$cppxdata$_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE@IMGREL
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE,unique,44
	.seh_endproc
	.def	"?dtor$9@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$9@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE@4HA":
.seh_proc "?dtor$9@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE@4HA"
.LBB44_9:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	64(%rdx), %rbp
	.seh_endprologue
	cmpq	$0, -16(%rbp)
	je	.LBB44_11
	movl	$1, %r8d
	movq	-8(%rbp), %rcx
	movq	-16(%rbp), %rdx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB44_11:
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%rbp
	.seh_endepilogue
	retq
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE,unique,44
	.seh_endproc
	.def	"?dtor$12@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$12@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE@4HA":
.seh_proc "?dtor$12@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE@4HA"
.LBB44_12:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	64(%rdx), %rbp
	.seh_endprologue
	cmpq	$0, -32(%rbp)
	jne	.LBB44_15
	movq	-24(%rbp), %rax
	movq	(%rax), %rdx
	testq	%rdx, %rdx
	je	.LBB44_15
	movq	-24(%rbp), %rax
	movq	8(%rax), %rcx
	movl	$1, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB44_15:
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%rbp
	.seh_endepilogue
	retq
.Lfunc_end6:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE,unique,44
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE,unique,6
	.p2align	2, 0x0
$cppxdata$_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE:
	.long	429065506
	.long	2
	.long	$stateUnwindMap$_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE@IMGREL
	.long	0
	.long	0
	.long	4
	.long	$ip2state$_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE@IMGREL
	.long	64
	.long	0
	.long	1
$stateUnwindMap$_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE:
	.long	-1
	.long	"?dtor$12@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE@4HA"@IMGREL
	.long	0
	.long	"?dtor$9@?0?_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE@4HA"@IMGREL
$ip2state$_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE:
	.long	.Lfunc_begin6@IMGREL
	.long	-1
	.long	.Ltmp86@IMGREL+1
	.long	1
	.long	.Ltmp88@IMGREL+1
	.long	0
	.long	.Ltmp89@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena9make_leaf17he300cd141cea1f1aE,unique,44

	.def	_ZN26hashrope_diagnostic_slot_b4rope5Arena9with_hash17hd3b1e23adfbc01dcE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope5Arena9with_hash17hd3b1e23adfbc01dcE,unique,45
	.globl	_ZN26hashrope_diagnostic_slot_b4rope5Arena9with_hash17hd3b1e23adfbc01dcE
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope5Arena9with_hash17hd3b1e23adfbc01dcE:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope5Arena9with_hash17hd3b1e23adfbc01dcE
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$2088, %rsp
	.seh_stackalloc 2088
	.seh_endprologue
	cmpq	$2, %r8
	jb	.LBB45_5
	movq	%r8, %rdi
	movq	%rdx, %rbx
	cmpq	%rdx, %r8
	jae	.LBB45_5
	movq	%rcx, %rsi
	leaq	48(%rsp), %rcx
	xorl	%r14d, %r14d
	movl	$2040, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	$1, 40(%rsp)
	bsrq	%rbx, %rcx
	incl	%ecx
	movl	$1, %eax
	movl	$1, %r8d
	.p2align	4
.LBB45_3:
	mulq	%rdi
	movq	%rdx, %r9
	shrq	%cl, %r9
	movq	%rax, %r10
	shrdq	%cl, %rdx, %r10
	testb	$64, %cl
	cmovneq	%r9, %r10
	cmovneq	%r14, %r9
	andq	%rbx, %rax
	addq	%r10, %rax
	adcq	$0, %r9
	movq	%rax, %rdx
	shrdq	%cl, %r9, %rdx
	shrq	%cl, %r9
	testb	$64, %cl
	cmoveq	%rdx, %r9
	andq	%rbx, %rax
	addq	%r9, %rax
	cmpq	%rax, %rbx
	movq	%rbx, %rdx
	cmovaq	%r14, %rdx
	subq	%rdx, %rax
	movq	%rax, 40(%rsp,%r8,8)
	incq	%r8
	cmpq	$256, %r8
	jne	.LBB45_3
	movq	$0, (%rsi)
	movq	$8, 8(%rsi)
	movq	$0, 16(%rsi)
	leaq	24(%rsi), %rcx
	leaq	40(%rsp), %rdx
	movl	$2048, %r8d
	callq	memcpy
	movq	%rbx, 2072(%rsi)
	movq	%rdi, 2080(%rsi)
	movq	$0, 2088(%rsi)
	movq	$0, 2104(%rsi)
	movq	%rbx, 2112(%rsi)
	movq	%rdi, 2120(%rsi)
	movb	$0, 2128(%rsi)
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$2088, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.LBB45_5:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.2(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.3(%rip), %r8
	movl	$49, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE,unique,46
	.p2align	4
_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE:
.Lfunc_begin7:
.seh_proc _ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$1816, %rsp
	.seh_stackalloc 1816
	leaq	128(%rsp), %rbp
	.seh_setframe %rbp, 128
	.seh_endprologue
	movq	$-2, 1680(%rbp)
	movq	%rcx, %r15
	movq	16(%rcx), %r10
	movl	%r9d, %ecx
	cmpq	%rcx, %r10
	jbe	.LBB46_94
	movq	16(%rdx), %r11
	leaq	(%r11,%r10), %rdi
	movq	8(%r15), %rsi
	leaq	(%rcx,%rcx,2), %rax
	shlq	$4, %rax
	cmpl	$0, (%rsi,%rax)
	movq	%rsi, 1632(%rbp)
	je	.LBB46_3
	addq	%rsi, %rax
	movq	32(%rax), %rax
	jmp	.LBB46_4
.LBB46_3:
	movl	$1, %eax
.LBB46_4:
	movq	1808(%rbp), %r13
	movl	1800(%rbp), %r12d
	movq	1792(%rbp), %rbx
	cmpq	%rdi, %rax
	ja	.LBB46_8
	movl	%r12d, %ecx
	cmpq	%rcx, %r11
	jbe	.LBB46_95
	movq	8(%rdx), %rsi
	leaq	(%rcx,%rcx,2), %rax
	shlq	$4, %rax
	cmpl	$0, (%rsi,%rax)
	movq	%rsi, 1656(%rbp)
	je	.LBB46_15
	addq	%rsi, %rax
	movq	32(%rax), %rax
	cmpq	%rdi, %rax
	jbe	.LBB46_16
.LBB46_8:
	cmpq	%rdx, %r15
	movq	%r15, 728(%rbp)
	movq	%rdx, 736(%rbp)
	sete	768(%rbp)
	movq	$0, 744(%rbp)
	movq	$0, 760(%rbp)
.Ltmp92:
	movq	%r13, 40(%rsp)
	movl	%r12d, 32(%rsp)
	leaq	728(%rbp), %rcx
	movq	%r8, %rdx
	movl	%r9d, %r8d
	movq	%rbx, %r9
	callq	_ZN26hashrope_diagnostic_slot_b4rope15ExactComparison3lcp17h975f105586598874E
.Ltmp93:
	movq	%rax, %rbx
	movq	744(%rbp), %rcx
	testq	%rcx, %rcx
	je	.LBB46_11
	movq	752(%rbp), %rdx
	movq	760(%rbp), %rax
	movq	$0, -64(%rbp)
	movq	%rcx, -56(%rbp)
	movq	%rdx, -48(%rbp)
	movq	$0, -32(%rbp)
	movq	%rcx, -24(%rbp)
	movq	%rdx, -16(%rbp)
	movl	$1, %ecx
	jmp	.LBB46_12
.LBB46_11:
	xorl	%ecx, %ecx
	xorl	%eax, %eax
.LBB46_12:
	movq	%rcx, -72(%rbp)
	movq	%rcx, -40(%rbp)
	movq	%rax, -8(%rbp)
	leaq	1576(%rbp), %rcx
	leaq	-72(%rbp), %rdx
	callq	_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E
	cmpq	$0, 1576(%rbp)
	je	.LBB46_87
	leaq	1576(%rbp), %rsi
	leaq	-72(%rbp), %rdi
	.p2align	4
.LBB46_14:
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	callq	_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E
	cmpq	$0, 1576(%rbp)
	jne	.LBB46_14
	jmp	.LBB46_87
.LBB46_15:
	movl	$1, %eax
	cmpq	%rdi, %rax
	ja	.LBB46_8
.LBB46_16:
	shlq	$3, %rdi
	cmpq	%rdx, %r15
	sete	1679(%rbp)
	setne	%al
	movq	%r15, 1576(%rbp)
	movq	%rdx, 1584(%rbp)
	sete	1600(%rbp)
	movq	%rdi, 1592(%rbp)
	cmpq	$8192, %r13
	setae	%cl
	testb	%cl, %al
	jne	.LBB46_18
	movq	%r13, 40(%rsp)
	movl	%r12d, 32(%rsp)
	leaq	1576(%rbp), %rcx
	movq	%r8, %rdi
	movq	%rdx, %r14
	movq	%r8, %rdx
	movl	%r9d, %esi
	movl	%r9d, %r8d
	movq	%rbx, %r9
	callq	_ZN26hashrope_diagnostic_slot_b4rope14FastComparison13lcp_recursive17h4081b43ed8af9caaE
	movq	%rdx, 1664(%rbp)
	testb	$1, %al
	jne	.LBB46_78
	jmp	.LBB46_86
.LBB46_18:
	movq	%r15, 1568(%rbp)
	movq	%rdx, 1560(%rbp)
	movq	%r8, 1552(%rbp)
	movq	%r8, 1496(%rbp)
	movl	%r9d, 1628(%rbp)
	movl	%r9d, 1504(%rbp)
	movq	%r13, 1512(%rbp)
	movq	$0, 728(%rbp)
	movl	$0, 736(%rbp)
	movq	$0, 1488(%rbp)
	movq	$0, 1520(%rbp)
	xorps	%xmm0, %xmm0
	movups	%xmm0, 744(%rbp)
	movl	$0, 760(%rbp)
	movups	%xmm0, 768(%rbp)
	movl	$0, 784(%rbp)
	movups	%xmm0, 792(%rbp)
	movl	$0, 808(%rbp)
	movups	%xmm0, 816(%rbp)
	movl	$0, 832(%rbp)
	movups	%xmm0, 840(%rbp)
	movl	$0, 856(%rbp)
	movups	%xmm0, 864(%rbp)
	movl	$0, 880(%rbp)
	movups	%xmm0, 888(%rbp)
	movl	$0, 904(%rbp)
	movups	%xmm0, 912(%rbp)
	movl	$0, 928(%rbp)
	movups	%xmm0, 936(%rbp)
	movl	$0, 952(%rbp)
	movups	%xmm0, 960(%rbp)
	movl	$0, 976(%rbp)
	movups	%xmm0, 984(%rbp)
	movl	$0, 1000(%rbp)
	movups	%xmm0, 1008(%rbp)
	movl	$0, 1024(%rbp)
	movups	%xmm0, 1032(%rbp)
	movl	$0, 1048(%rbp)
	movups	%xmm0, 1056(%rbp)
	movl	$0, 1072(%rbp)
	movups	%xmm0, 1080(%rbp)
	movl	$0, 1096(%rbp)
	movups	%xmm0, 1104(%rbp)
	movl	$0, 1120(%rbp)
	movups	%xmm0, 1128(%rbp)
	movl	$0, 1144(%rbp)
	movups	%xmm0, 1152(%rbp)
	movl	$0, 1168(%rbp)
	movups	%xmm0, 1176(%rbp)
	movl	$0, 1192(%rbp)
	movups	%xmm0, 1200(%rbp)
	movl	$0, 1216(%rbp)
	movups	%xmm0, 1224(%rbp)
	movl	$0, 1240(%rbp)
	movups	%xmm0, 1248(%rbp)
	movl	$0, 1264(%rbp)
	movups	%xmm0, 1272(%rbp)
	movl	$0, 1288(%rbp)
	movups	%xmm0, 1296(%rbp)
	movl	$0, 1312(%rbp)
	movups	%xmm0, 1320(%rbp)
	movl	$0, 1336(%rbp)
	movups	%xmm0, 1344(%rbp)
	movl	$0, 1360(%rbp)
	movups	%xmm0, 1368(%rbp)
	movl	$0, 1384(%rbp)
	movups	%xmm0, 1392(%rbp)
	movl	$0, 1408(%rbp)
	movups	%xmm0, 1416(%rbp)
	movl	$0, 1432(%rbp)
	movups	%xmm0, 1440(%rbp)
	movl	$0, 1456(%rbp)
	movups	%xmm0, 1464(%rbp)
	movl	$0, 1480(%rbp)
	movq	%rbx, 696(%rbp)
	movl	%r12d, 704(%rbp)
	movq	%r13, 712(%rbp)
	movq	$0, -72(%rbp)
	movl	$0, -64(%rbp)
	movq	$0, 688(%rbp)
	movq	$0, 720(%rbp)
	movups	%xmm0, -56(%rbp)
	movl	$0, -40(%rbp)
	movups	%xmm0, -32(%rbp)
	movl	$0, -16(%rbp)
	movups	%xmm0, -8(%rbp)
	movl	$0, 8(%rbp)
	movups	%xmm0, 16(%rbp)
	movl	$0, 32(%rbp)
	movups	%xmm0, 40(%rbp)
	movl	$0, 56(%rbp)
	movups	%xmm0, 64(%rbp)
	movl	$0, 80(%rbp)
	movups	%xmm0, 88(%rbp)
	movl	$0, 104(%rbp)
	movups	%xmm0, 112(%rbp)
	movl	$0, 128(%rbp)
	movups	%xmm0, 136(%rbp)
	movl	$0, 152(%rbp)
	movups	%xmm0, 160(%rbp)
	movl	$0, 176(%rbp)
	movups	%xmm0, 184(%rbp)
	movl	$0, 200(%rbp)
	movups	%xmm0, 208(%rbp)
	movl	$0, 224(%rbp)
	movups	%xmm0, 232(%rbp)
	movl	$0, 248(%rbp)
	movups	%xmm0, 256(%rbp)
	movl	$0, 272(%rbp)
	movups	%xmm0, 280(%rbp)
	movl	$0, 296(%rbp)
	movups	%xmm0, 304(%rbp)
	movl	$0, 320(%rbp)
	movups	%xmm0, 328(%rbp)
	movl	$0, 344(%rbp)
	movups	%xmm0, 352(%rbp)
	movl	$0, 368(%rbp)
	movups	%xmm0, 376(%rbp)
	movl	$0, 392(%rbp)
	movups	%xmm0, 400(%rbp)
	movl	$0, 416(%rbp)
	movups	%xmm0, 424(%rbp)
	movl	$0, 440(%rbp)
	movups	%xmm0, 448(%rbp)
	movl	$0, 464(%rbp)
	movups	%xmm0, 472(%rbp)
	movl	$0, 488(%rbp)
	movups	%xmm0, 496(%rbp)
	movl	$0, 512(%rbp)
	movups	%xmm0, 520(%rbp)
	movl	$0, 536(%rbp)
	movups	%xmm0, 544(%rbp)
	movl	$0, 560(%rbp)
	movups	%xmm0, 568(%rbp)
	movl	$0, 584(%rbp)
	movups	%xmm0, 592(%rbp)
	movl	$0, 608(%rbp)
	movups	%xmm0, 616(%rbp)
	movl	$0, 632(%rbp)
	movups	%xmm0, 640(%rbp)
	movl	$0, 656(%rbp)
	movups	%xmm0, 664(%rbp)
	movl	$0, 680(%rbp)
	movq	%r13, %r15
	movq	1512(%rbp), %r13
	cmpq	%r13, %r15
	movq	%r13, %r14
	cmovbq	%r15, %r14
	movl	%r12d, %eax
	movq	1496(%rbp), %r12
	negq	%rdi
	movq	%rbx, %rsi
	movq	$0, 1664(%rbp)
	movq	%r10, %rbx
	movq	%r11, 1648(%rbp)
	movq	1656(%rbp), %r9
	movq	%r10, 1616(%rbp)
	jmp	.LBB46_22
	.p2align	4
.LBB46_19:
	leaq	-72(%rbp), %rcx
	movq	%r9, %rdx
	movq	%r11, %r8
.LBB46_20:
	callq	_ZN26hashrope_diagnostic_slot_b4rope13ExactFrontier6expand17h8dcc5442a36d207eE
	movq	1656(%rbp), %r9
	movq	1648(%rbp), %r11
	testb	%al, %al
	je	.LBB46_77
.LBB46_21:
	movq	1496(%rbp), %r12
	movq	1512(%rbp), %r13
	movl	704(%rbp), %eax
	movq	696(%rbp), %rsi
	movq	712(%rbp), %r15
	cmpq	%r13, %r15
	movq	%r13, %r14
	cmovbq	%r15, %r14
	addq	$2, %rdi
	je	.LBB46_77
.LBB46_22:
	movl	1504(%rbp), %ecx
	cmpq	%rcx, %rbx
	jbe	.LBB46_92
	movl	%eax, %eax
	cmpq	%rax, %r11
	jbe	.LBB46_93
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	addq	1632(%rbp), %rcx
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	addq	%r9, %rax
	movl	(%rcx), %edx
	testl	%edx, %edx
	je	.LBB46_27
	movl	$1, %ecx
	movq	%rcx, 1640(%rbp)
	cmpl	$1, %edx
	jne	.LBB46_77
	movl	(%rax), %r8d
	jmp	.LBB46_28
	.p2align	4
.LBB46_27:
	movl	$1, %r8d
	movq	%r8, 1640(%rbp)
	movl	(%rax), %r8d
	testl	%r8d, %r8d
	je	.LBB46_36
.LBB46_28:
	testl	%r8d, %r8d
	je	.LBB46_34
	cmpl	$1, %r8d
	jne	.LBB46_77
	cmpl	$1, %edx
	jne	.LBB46_19
	cmpq	%r15, %r13
	jb	.LBB46_33
	leaq	728(%rbp), %rcx
	movq	1632(%rbp), %rdx
	movq	%rbx, %r8
	callq	_ZN26hashrope_diagnostic_slot_b4rope13ExactFrontier6expand17h8dcc5442a36d207eE
	movq	1656(%rbp), %r9
	movq	1648(%rbp), %r11
	testb	%al, %al
	je	.LBB46_77
.LBB46_33:
	cmpq	%r13, %r15
	jae	.LBB46_19
	jmp	.LBB46_21
	.p2align	4
.LBB46_34:
	cmpl	$1, %edx
	jne	.LBB46_19
	leaq	728(%rbp), %rcx
	movq	1632(%rbp), %rdx
	movq	%rbx, %r8
	jmp	.LBB46_20
.LBB46_36:
	movq	40(%rcx), %rdx
	movq	%rdx, %r8
	subq	%r12, %r8
	jb	.LBB46_89
	cmpq	%r8, %r14
	ja	.LBB46_88
	movq	40(%rax), %rdx
	movq	%rdx, %r8
	subq	%rsi, %r8
	jb	.LBB46_90
	cmpq	%r8, %r14
	ja	.LBB46_91
	movq	%rdi, 1608(%rbp)
	movq	32(%rcx), %rbx
	addq	%r12, %rbx
	movq	32(%rax), %rdi
	addq	%rsi, %rdi
	movq	%rbx, %rcx
	movq	%rdi, %rdx
	movq	%r14, %r8
	callq	memcmp
	testl	%eax, %eax
	jne	.LBB46_54
	cmpq	%r15, %r13
	movq	1648(%rbp), %r11
	jbe	.LBB46_43
	addq	%r14, %r12
	movq	%r12, 1496(%rbp)
	movq	%r13, %rax
	subq	%r14, %rax
	movq	%rax, 1512(%rbp)
	movq	1616(%rbp), %rbx
	movq	1656(%rbp), %r9
	movq	1608(%rbp), %rdi
	cmpq	%r13, %r15
	jbe	.LBB46_48
.LBB46_46:
	addq	%r14, %rsi
	movq	%rsi, 696(%rbp)
	subq	%r14, %r15
	movq	%r15, 712(%rbp)
	movq	1808(%rbp), %rdx
	jmp	.LBB46_52
.LBB46_43:
	movq	1520(%rbp), %rax
	testq	%rax, %rax
	movq	1616(%rbp), %rbx
	movq	1656(%rbp), %r9
	movq	1608(%rbp), %rdi
	je	.LBB46_47
	leaq	-1(%rax), %rcx
	movq	%rcx, 1520(%rbp)
	cmpq	$32, %rax
	ja	.LBB46_96
	leaq	(%rcx,%rcx,2), %rax
	movups	728(%rbp,%rax,8), %xmm0
	movq	744(%rbp,%rax,8), %rax
	leaq	1496(%rbp), %rcx
	movq	%rax, 16(%rcx)
	movups	%xmm0, (%rcx)
	cmpq	%r13, %r15
	ja	.LBB46_46
.LBB46_48:
	movq	720(%rbp), %rax
	testq	%rax, %rax
	movq	1808(%rbp), %rdx
	je	.LBB46_51
	leaq	-1(%rax), %rcx
	movq	%rcx, 720(%rbp)
	cmpq	$32, %rax
	movq	1664(%rbp), %r8
	ja	.LBB46_96
	leaq	(%rcx,%rcx,2), %rax
	movups	-72(%rbp,%rax,8), %xmm0
	movq	-56(%rbp,%rax,8), %rax
	leaq	696(%rbp), %rcx
	movq	%rax, 16(%rcx)
	movups	%xmm0, (%rcx)
	addq	%r14, %r8
	movq	%r8, 1664(%rbp)
	cmpq	%rdx, %r8
	jb	.LBB46_21
	jmp	.LBB46_53
.LBB46_47:
	movq	$0, 1512(%rbp)
	cmpq	%r13, %r15
	ja	.LBB46_46
	jmp	.LBB46_48
.LBB46_51:
	movq	$0, 712(%rbp)
.LBB46_52:
	movq	1664(%rbp), %r8
	addq	%r14, %r8
	movq	%r8, 1664(%rbp)
	cmpq	%rdx, %r8
	jb	.LBB46_21
.LBB46_53:
	movq	1808(%rbp), %rax
	movq	%rax, 1664(%rbp)
	jmp	.LBB46_76
.LBB46_54:
	movabsq	$9223372036854775800, %rax
	andq	%r14, %rax
	movq	$-8, %rdx
	movq	%r14, %rcx
	movq	1664(%rbp), %r10
.LBB46_55:
	cmpq	$7, %rcx
	jbe	.LBB46_58
	movq	8(%rbx,%rdx), %r8
	movq	8(%rdi,%rdx), %r9
	addq	$8, %rdx
	addq	$-8, %rcx
	cmpq	%r9, %r8
	je	.LBB46_55
	xorq	%r8, %r9
	rep		bsfq	%r9, %rcx
	shrl	$3, %ecx
	addq	%rdx, %rcx
	jmp	.LBB46_75
.LBB46_58:
	andq	$7, %r14
	je	.LBB46_97
	movzbl	(%rbx,%rax), %ecx
	cmpb	(%rdi,%rax), %cl
	jne	.LBB46_73
	cmpl	$1, %r14d
	je	.LBB46_97
	movzbl	1(%rbx,%rax), %edx
	movl	$1, %ecx
	cmpb	1(%rdi,%rax), %dl
	jne	.LBB46_74
	cmpl	$2, %r14d
	je	.LBB46_97
	movzbl	2(%rbx,%rax), %edx
	movl	$2, %ecx
	cmpb	2(%rdi,%rax), %dl
	jne	.LBB46_74
	cmpl	$3, %r14d
	je	.LBB46_97
	movzbl	3(%rbx,%rax), %edx
	movl	$3, %ecx
	cmpb	3(%rdi,%rax), %dl
	jne	.LBB46_74
	cmpl	$4, %r14d
	je	.LBB46_97
	movzbl	4(%rbx,%rax), %edx
	movl	$4, %ecx
	cmpb	4(%rdi,%rax), %dl
	jne	.LBB46_74
	cmpl	$5, %r14d
	je	.LBB46_97
	movzbl	5(%rbx,%rax), %edx
	movl	$5, %ecx
	cmpb	5(%rdi,%rax), %dl
	jne	.LBB46_74
	cmpl	$6, %r14d
	je	.LBB46_97
	movzbl	6(%rbx,%rax), %edx
	movl	$6, %ecx
	cmpb	6(%rdi,%rax), %dl
	jne	.LBB46_74
.LBB46_97:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.36(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.LBB46_73:
	xorl	%ecx, %ecx
.LBB46_74:
	orq	%rax, %rcx
.LBB46_75:
	addq	%rcx, %r10
	movq	%r10, 1664(%rbp)
.LBB46_76:
	movq	$0, 1640(%rbp)
.LBB46_77:
	movl	1628(%rbp), %esi
	movq	1552(%rbp), %rdi
	movq	1792(%rbp), %rbx
	movq	1560(%rbp), %r14
	movq	1568(%rbp), %r15
	movl	1800(%rbp), %r12d
	movq	1808(%rbp), %r13
	movq	1640(%rbp), %rax
	testb	$1, %al
	je	.LBB46_86
.LBB46_78:
	movq	%r15, 728(%rbp)
	movq	%r14, 736(%rbp)
	movzbl	1679(%rbp), %eax
	movb	%al, 768(%rbp)
	movq	$0, 744(%rbp)
	movq	$0, 760(%rbp)
	movq	%rdi, %rdx
	movq	1664(%rbp), %r14
	addq	%r14, %rdx
	addq	%r14, %rbx
	subq	%r14, %r13
.Ltmp90:
	movq	%r13, 40(%rsp)
	movl	%r12d, 32(%rsp)
	leaq	728(%rbp), %rcx
	movl	%esi, %r8d
	movq	%rbx, %r9
	callq	_ZN26hashrope_diagnostic_slot_b4rope15ExactComparison3lcp17h975f105586598874E
.Ltmp91:
	movq	%rax, %rsi
	movq	744(%rbp), %rcx
	testq	%rcx, %rcx
	je	.LBB46_81
	movq	752(%rbp), %rdx
	movq	760(%rbp), %rax
	movq	$0, -64(%rbp)
	movq	%rcx, -56(%rbp)
	movq	%rdx, -48(%rbp)
	movq	$0, -32(%rbp)
	movq	%rcx, -24(%rbp)
	movq	%rdx, -16(%rbp)
	movl	$1, %ecx
	jmp	.LBB46_82
.LBB46_81:
	xorl	%ecx, %ecx
	xorl	%eax, %eax
.LBB46_82:
	movq	%rcx, -72(%rbp)
	movq	%rcx, -40(%rbp)
	movq	%rax, -8(%rbp)
	leaq	1528(%rbp), %rcx
	leaq	-72(%rbp), %rdx
	callq	_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E
	cmpq	$0, 1528(%rbp)
	je	.LBB46_85
	leaq	1528(%rbp), %rdi
	leaq	-72(%rbp), %rbx
	.p2align	4
.LBB46_84:
	movq	%rdi, %rcx
	movq	%rbx, %rdx
	callq	_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E
	cmpq	$0, 1528(%rbp)
	jne	.LBB46_84
.LBB46_85:
	addq	%rsi, %r14
	movq	%r14, 1664(%rbp)
.LBB46_86:
	movq	1664(%rbp), %rbx
.LBB46_87:
	movq	%rbx, %rax
	.seh_startepilogue
	addq	$1816, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.LBB46_88:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.15(%rip), %r9
	xorl	%ecx, %ecx
	movq	%r14, %rdx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB46_89:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.16(%rip), %r9
	movq	%r12, %rcx
	movq	%rdx, %r8
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB46_90:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.14(%rip), %r9
	movq	%rsi, %rcx
	movq	%rdx, %r8
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB46_91:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.12(%rip), %r9
	xorl	%ecx, %ecx
	movq	%r14, %rdx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB46_92:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.10(%rip), %r8
	movq	%rbx, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB46_93:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.11(%rip), %r8
	movq	%rax, %rcx
	movq	%r11, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB46_94:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.44(%rip), %r8
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB46_95:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.44(%rip), %r8
	movq	%r11, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB46_96:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.13(%rip), %r8
	movl	$32, %edx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_handlerdata
	.long	$cppxdata$_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE@IMGREL
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE,unique,46
	.seh_endproc
	.def	"?dtor$98@?0?_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$98@?0?_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE@4HA":
.seh_proc "?dtor$98@?0?_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE@4HA"
.LBB46_98:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	leaq	128(%rdx), %rbp
	.seh_endprologue
	leaq	728(%rbp), %rcx
	callq	_ZN4core3ptr70drop_in_place$LT$hashrope_diagnostic_slot_b..rope..ExactComparison$GT$17ha705e0c70d678b60E
	nop
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE,unique,46
	.seh_endproc
	.def	"?dtor$99@?0?_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$99@?0?_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE@4HA":
.seh_proc "?dtor$99@?0?_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE@4HA"
.LBB46_99:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	leaq	128(%rdx), %rbp
	.seh_endprologue
	leaq	728(%rbp), %rcx
	callq	_ZN4core3ptr70drop_in_place$LT$hashrope_diagnostic_slot_b..rope..ExactComparison$GT$17ha705e0c70d678b60E
	nop
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.Lfunc_end7:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE,unique,46
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE,unique,7
	.p2align	2, 0x0
$cppxdata$_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE:
	.long	429065506
	.long	2
	.long	$stateUnwindMap$_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE@IMGREL
	.long	0
	.long	0
	.long	5
	.long	$ip2state$_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE@IMGREL
	.long	1808
	.long	0
	.long	1
$stateUnwindMap$_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE:
	.long	-1
	.long	"?dtor$99@?0?_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE@4HA"@IMGREL
	.long	-1
	.long	"?dtor$98@?0?_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE@4HA"@IMGREL
$ip2state$_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE:
	.long	.Lfunc_begin7@IMGREL
	.long	-1
	.long	.Ltmp92@IMGREL+1
	.long	0
	.long	.Ltmp93@IMGREL+1
	.long	-1
	.long	.Ltmp90@IMGREL+1
	.long	1
	.long	.Ltmp91@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b4rope9exact_lcp17h418805a444da52deE,unique,46

	.def	_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow10final_hash17h71591f67d0cfd9e7E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow10final_hash17h71591f67d0cfd9e7E,unique,47
	.globl	_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow10final_hash17h71591f67d0cfd9e7E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow10final_hash17h71591f67d0cfd9e7E:
	jmp	_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow12current_hash17h6415cfdc4fe2c405E

	.def	_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow11append_copy17hf7545f8740fa2ec6E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow11append_copy17hf7545f8740fa2ec6E,unique,48
	.globl	_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow11append_copy17hf7545f8740fa2ec6E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow11append_copy17hf7545f8740fa2ec6E:
.seh_proc _ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow11append_copy17hf7545f8740fa2ec6E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$112, %rsp
	.seh_stackalloc 112
	.seh_endprologue
	movq	%r8, %rdi
	movq	%rdx, %r10
	movq	%rcx, %rsi
	movq	%rdx, 32(%rsp)
	movl	2136(%rcx), %r11d
	movl	2140(%rcx), %ebx
	movq	8(%rcx), %rcx
	movq	16(%rsi), %rdx
	cmpl	$1, %r11d
	jne	.LBB48_1
	cmpq	%rbx, %rdx
	jbe	.LBB48_84
	leaq	(%rbx,%rbx,2), %rax
	shlq	$4, %rax
	leaq	(%rcx,%rax), %r8
	xorl	%r9d, %r9d
	cmpl	$0, (%rcx,%rax)
	setne	%r9b
	movq	16(%r8,%r9,8), %r14
	jmp	.LBB48_4
.LBB48_1:
	xorl	%r14d, %r14d
.LBB48_4:
	movq	%r14, 104(%rsp)
	cmpq	2184(%rsi), %r10
	ja	.LBB48_85
	movq	%r14, %r9
	subq	%r10, %r9
	jb	.LBB48_86
	cmpq	%rdi, %r10
	jae	.LBB48_25
	movq	2072(%rsi), %rax
	cmpq	%rax, 2112(%rsi)
	jne	.LBB48_87
	movq	2080(%rsi), %r8
	cmpq	%r8, 2120(%rsi)
	jne	.LBB48_87
	testb	%r11b, %r11b
	je	.LBB48_10
	cmpq	%r10, %r14
	je	.LBB48_19
	cmpq	%rbx, %rdx
	jbe	.LBB48_84
	leaq	(%rbx,%rbx,2), %rdx
	shlq	$4, %rdx
	xorl	%r11d, %r11d
	cmpl	$0, (%rcx,%rdx)
	leaq	(%rcx,%rdx), %rcx
	setne	%r11b
	cmpq	16(%rcx,%r11,8), %r9
	jae	.LBB48_10
	leaq	40(%rsp), %rcx
	movq	%rsi, %rdx
	movl	%ebx, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE
	movzbl	48(%rsp), %ecx
	movl	52(%rsp), %ebx
	movq	32(%rsp), %r10
	movq	2072(%rsi), %r9
	movq	2080(%rsi), %rdx
	movq	2112(%rsi), %rax
	movq	2120(%rsi), %r8
	jmp	.LBB48_15
.LBB48_25:
	movq	2072(%rsi), %rax
	cmpq	%rax, 2112(%rsi)
	jne	.LBB48_87
	movq	2080(%rsi), %r8
	cmpq	%r8, 2120(%rsi)
	jne	.LBB48_87
	testb	%r11b, %r11b
	je	.LBB48_28
	cmpq	%r10, %r14
	je	.LBB48_37
	cmpq	%rbx, %rdx
	jbe	.LBB48_84
	leaq	(%rbx,%rbx,2), %rdx
	shlq	$4, %rdx
	xorl	%r10d, %r10d
	cmpl	$0, (%rcx,%rdx)
	leaq	(%rcx,%rdx), %rcx
	setne	%r10b
	cmpq	16(%rcx,%r10,8), %r9
	jae	.LBB48_28
	leaq	40(%rsp), %rcx
	movq	%rsi, %rdx
	movl	%ebx, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE
	movzbl	48(%rsp), %ecx
	movl	52(%rsp), %ebx
	movq	2072(%rsi), %r9
	movq	2080(%rsi), %rdx
	movq	2112(%rsi), %rax
	movq	2120(%rsi), %r8
	jmp	.LBB48_33
.LBB48_10:
	xorl	%ecx, %ecx
	movq	%r8, %rdx
	movq	%rax, %r9
.LBB48_15:
	cmpq	%r9, %rax
	jne	.LBB48_87
	cmpq	%rdx, %r8
	jne	.LBB48_87
	testb	%cl, %cl
	je	.LBB48_18
.LBB48_19:
	testq	%r10, %r10
	je	.LBB48_24
	movl	%ebx, %ecx
	movq	16(%rsi), %rdx
	cmpq	%rcx, %rdx
	jbe	.LBB48_75
	movq	8(%rsi), %rax
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	xorl	%edx, %edx
	cmpl	$0, (%rax,%rcx)
	leaq	(%rax,%rcx), %rax
	setne	%dl
	cmpq	16(%rax,%rdx,8), %r10
	jae	.LBB48_51
	leaq	40(%rsp), %rcx
	movq	%rsi, %rdx
	movl	%ebx, %r8d
	movq	%r10, %r9
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE
	movzbl	40(%rsp), %r12d
	movl	44(%rsp), %ebx
	movq	32(%rsp), %r10
	jmp	.LBB48_23
.LBB48_28:
	xorl	%ecx, %ecx
	movq	%r8, %rdx
	movq	%rax, %r9
.LBB48_33:
	cmpq	%r9, %rax
	jne	.LBB48_87
	cmpq	%rdx, %r8
	jne	.LBB48_87
	testb	%cl, %cl
	je	.LBB48_36
.LBB48_37:
	testq	%rdi, %rdi
	je	.LBB48_36
	movl	%ebx, %ecx
	movq	16(%rsi), %rdx
	cmpq	%rcx, %rdx
	jbe	.LBB48_75
	movq	8(%rsi), %rdx
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	leaq	(%rdx,%rcx), %r9
	xorl	%r10d, %r10d
	cmpl	$0, (%rdx,%rcx)
	setne	%r10b
	movl	$1, %ecx
	cmpq	16(%r9,%r10,8), %rdi
	jae	.LBB48_40
	leaq	40(%rsp), %rcx
	movq	%rsi, %rdx
	movl	%ebx, %r8d
	movq	%rdi, %r9
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE
	movl	40(%rsp), %ecx
	movl	44(%rsp), %ebx
	movq	2072(%rsi), %r9
	movq	2080(%rsi), %rdx
	movq	2112(%rsi), %rax
	movq	2120(%rsi), %r8
	cmpq	%r9, %rax
	je	.LBB48_43
	jmp	.LBB48_87
.LBB48_36:
	xorl	%ecx, %ecx
	movq	%r8, %rdx
	movq	%rax, %r9
	cmpq	%r9, %rax
	je	.LBB48_43
	jmp	.LBB48_87
.LBB48_18:
	xorl	%r12d, %r12d
.LBB48_23:
	testq	%r10, %r10
	je	.LBB48_24
	movq	%rdi, %rax
	orq	%r10, %rax
	shrq	$32, %rax
	je	.LBB48_53
.LBB48_54:
	movq	%rdi, %rax
	xorl	%edx, %edx
	divq	%r10
	movq	%rdx, %r15
	jmp	.LBB48_55
.LBB48_51:
	movb	$1, %r12b
	movq	%rdi, %rax
	orq	%r10, %rax
	shrq	$32, %rax
	jne	.LBB48_54
.LBB48_53:
	movl	%edi, %eax
	xorl	%edx, %edx
	divl	%r10d
	movl	%edx, %r15d
.LBB48_55:
	xorl	%ebp, %ebp
	movq	2072(%rsi), %rdx
	movq	2080(%rsi), %rcx
	movq	2112(%rsi), %r9
	movq	2120(%rsi), %r8
	cmpq	%rdi, %r10
	jbe	.LBB48_57
	jmp	.LBB48_61
.LBB48_57:
	cmpq	%rdx, %r9
	jne	.LBB48_87
	cmpq	%rcx, %r8
	jne	.LBB48_87
	movq	%rcx, %r8
	movq	%rdx, %r9
	testb	%r12b, %r12b
	je	.LBB48_61
	movq	%rsi, %rcx
	movl	%ebx, %edx
	movq	%rax, %r8
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11make_repeat17h9a70e50e745a5030E
	movl	%eax, %ebp
	movl	%edx, %r14d
	movq	2072(%rsi), %rdx
	movq	2080(%rsi), %rcx
	movq	2112(%rsi), %r9
	movq	2120(%rsi), %r8
.LBB48_61:
	testq	%r15, %r15
	je	.LBB48_62
	cmpq	%rdx, %r9
	jne	.LBB48_87
	cmpq	%rcx, %r8
	jne	.LBB48_87
	testb	%r12b, %r12b
	je	.LBB48_71
	movl	%ebx, %ecx
	movq	16(%rsi), %rdx
	cmpq	%rcx, %rdx
	jbe	.LBB48_75
	movq	8(%rsi), %rax
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	leaq	(%rax,%rcx), %rdx
	xorl	%r10d, %r10d
	cmpl	$0, (%rax,%rcx)
	setne	%r10b
	movl	$1, %eax
	cmpq	16(%rdx,%r10,8), %r15
	jae	.LBB48_74
	leaq	40(%rsp), %rcx
	movq	%rsi, %rdx
	movl	%ebx, %r8d
	movq	%r15, %r9
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE
	movl	40(%rsp), %eax
	movl	44(%rsp), %ebx
	movq	2072(%rsi), %rdx
	movq	2080(%rsi), %rcx
	movq	2112(%rsi), %r9
	movq	2120(%rsi), %r8
	cmpq	%rdx, %r9
	je	.LBB48_78
	jmp	.LBB48_87
.LBB48_71:
	xorl	%eax, %eax
	movq	%r8, %rcx
	movq	%r9, %rdx
	cmpq	%rdx, %r9
	je	.LBB48_78
	jmp	.LBB48_87
.LBB48_40:
	movq	%r8, %rdx
	movq	%rax, %r9
	cmpq	%r9, %rax
	jne	.LBB48_87
.LBB48_43:
	cmpq	%rdx, %r8
	jne	.LBB48_87
	cmpl	$0, 2136(%rsi)
	je	.LBB48_45
	movl	2140(%rsi), %edx
	movl	$1, %ebp
	testl	%ecx, %ecx
	je	.LBB48_48
	movq	%rsi, %rcx
	movl	%ebx, %r8d
	jmp	.LBB48_50
.LBB48_45:
	movl	%ecx, %ebp
	jmp	.LBB48_46
.LBB48_48:
	movl	%edx, %ebx
	jmp	.LBB48_46
.LBB48_74:
	movq	%r8, %rcx
	movq	%r9, %rdx
	cmpq	%rdx, %r9
	jne	.LBB48_87
.LBB48_78:
	cmpq	%rcx, %r8
	jne	.LBB48_87
	testb	$1, %bpl
	je	.LBB48_80
	movl	$1, %ebp
	testl	%eax, %eax
	je	.LBB48_82
	movq	%rsi, %rcx
	movl	%r14d, %edx
	movl	%ebx, %r8d
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E
	movl	%eax, %r14d
	movq	2072(%rsi), %rdx
	movq	2080(%rsi), %rcx
	movq	2112(%rsi), %r9
	movq	2120(%rsi), %r8
	cmpq	%rdx, %r9
	je	.LBB48_63
	jmp	.LBB48_87
.LBB48_80:
	movq	%r8, %rcx
	movq	%r9, %rdx
	movl	%ebx, %r14d
	movl	%eax, %ebp
.LBB48_62:
	cmpq	%rdx, %r9
	jne	.LBB48_87
.LBB48_63:
	cmpq	%rcx, %r8
	jne	.LBB48_87
	cmpl	$0, 2136(%rsi)
	je	.LBB48_65
	movl	2140(%rsi), %ebx
	testb	$1, %bpl
	movl	$1, %ebp
	je	.LBB48_46
	movq	%rsi, %rcx
	movl	%ebx, %edx
	movl	%r14d, %r8d
.LBB48_50:
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E
	movl	%eax, %ebx
	jmp	.LBB48_46
.LBB48_65:
	movl	%r14d, %ebx
.LBB48_46:
	movl	%ebp, 2136(%rsi)
	movl	%ebx, 2140(%rsi)
	addq	%rdi, 2184(%rsi)
	movq	%rsi, %rcx
	.seh_startepilogue
	addq	$112, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	jmp	_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow5evict17hcf92496244cd5ca6E
.LBB48_82:
	movq	%r8, %rcx
	movq	%r9, %rdx
	cmpq	%rdx, %r9
	je	.LBB48_63
.LBB48_87:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.37(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB48_85:
	addq	$2184, %rsi
	leaq	32(%rsp), %rax
	movq	%rax, 40(%rsp)
	leaq	_ZN4core3fmt3num3imp52_$LT$impl$u20$core..fmt..Display$u20$for$u20$u64$GT$3fmt17h9f4f228998531a48E(%rip), %rax
	movq	%rax, 48(%rsp)
	movq	%rsi, 56(%rsp)
	movq	%rax, 64(%rsp)
	leaq	anon.831c2442e46e5e41962cfb504544efb1.86(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.88(%rip), %r8
	leaq	40(%rsp), %rdx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB48_86:
	addq	$2144, %rsi
	leaq	32(%rsp), %rax
	movq	%rax, 40(%rsp)
	leaq	_ZN4core3fmt3num3imp52_$LT$impl$u20$core..fmt..Display$u20$for$u20$u64$GT$3fmt17h9f4f228998531a48E(%rip), %rcx
	movq	%rcx, 48(%rsp)
	leaq	104(%rsp), %rdx
	movq	%rdx, 56(%rsp)
	movq	%rcx, 64(%rsp)
	movq	%rsi, 72(%rsp)
	movq	%rcx, 80(%rsp)
	movq	%rax, 88(%rsp)
	movq	%rcx, 96(%rsp)
	leaq	anon.831c2442e46e5e41962cfb504544efb1.89(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.90(%rip), %r8
	leaq	40(%rsp), %rdx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB48_84:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%rbx, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB48_75:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB48_24:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.91(%rip), %rcx
	callq	_ZN4core9panicking11panic_const23panic_const_div_by_zero17hdceffd214664eedfE
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow12append_bytes17he757af2917964f5eE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow12append_bytes17he757af2917964f5eE,unique,49
	.globl	_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow12append_bytes17he757af2917964f5eE
	.p2align	4
_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow12append_bytes17he757af2917964f5eE:
.seh_proc _ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow12append_bytes17he757af2917964f5eE
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%r8, %r8
	je	.LBB49_8
	movq	%r8, %rsi
	movq	%rcx, %rdi
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena10from_bytes17hfc6e308e028271d5E
	movq	2112(%rdi), %rcx
	cmpq	2072(%rdi), %rcx
	jne	.LBB49_9
	movq	2080(%rdi), %rcx
	cmpq	%rcx, 2120(%rdi)
	jne	.LBB49_9
	movl	%edx, %r8d
	cmpl	$0, 2136(%rdi)
	je	.LBB49_7
	movl	2140(%rdi), %edx
	testb	$1, %al
	movl	$1, %eax
	je	.LBB49_5
	movq	%rdi, %rcx
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena4join17hdb273b87e18eb989E
	movl	%eax, %r8d
	movl	$1, %eax
	jmp	.LBB49_7
.LBB49_8:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB49_5:
	movl	%edx, %r8d
.LBB49_7:
	movl	%eax, 2136(%rdi)
	movl	%r8d, 2140(%rdi)
	addq	%rsi, 2184(%rdi)
	movq	%rdi, %rcx
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	jmp	_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow5evict17hcf92496244cd5ca6E
.LBB49_9:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.37(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow12current_hash17h6415cfdc4fe2c405E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow12current_hash17h6415cfdc4fe2c405E,unique,50
	.globl	_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow12current_hash17h6415cfdc4fe2c405E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow12current_hash17h6415cfdc4fe2c405E:
.seh_proc _ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow12current_hash17h6415cfdc4fe2c405E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rcx, %rsi
	movl	2136(%rcx), %r9d
	movl	2140(%rcx), %ecx
	movq	8(%rsi), %r8
	movq	16(%rsi), %rdx
	cmpl	$1, %r9d
	jne	.LBB50_1
	cmpq	%rcx, %rdx
	jbe	.LBB50_11
	leaq	(%rcx,%rcx,2), %rax
	shlq	$4, %rax
	leaq	(%r8,%rax), %r10
	xorl	%r11d, %r11d
	cmpl	$0, (%r8,%rax)
	setne	%r11b
	movq	16(%r10,%r11,8), %rax
	jmp	.LBB50_4
.LBB50_1:
	xorl	%eax, %eax
.LBB50_4:
	movq	2112(%rsi), %r10
	cmpq	2072(%rsi), %r10
	jne	.LBB50_12
	movq	2080(%rsi), %r10
	cmpq	%r10, 2120(%rsi)
	jne	.LBB50_12
	testb	%r9b, %r9b
	je	.LBB50_7
	movl	%ecx, %ecx
	cmpq	%rcx, %rdx
	jbe	.LBB50_13
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	leaq	(%r8,%rcx), %rdx
	xorl	%r9d, %r9d
	cmpl	$0, (%r8,%rcx)
	setne	%r9b
	movq	8(%rdx,%r9,8), %rdi
	jmp	.LBB50_10
.LBB50_7:
	xorl	%edi, %edi
.LBB50_10:
	leaq	24(%rsi), %rcx
	movq	2168(%rsi), %rbx
	movq	%rax, %rdx
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE
	mulq	%rbx
	addq	%rdi, %rax
	adcq	$0, %rdx
	movq	2072(%rsi), %r8
	movl	$127, %r9d
	bsrq	%r8, %r9
	xorl	$63, %r9d
	movb	$64, %cl
	subb	%r9b, %cl
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	xorl	%r10d, %r10d
	testb	$64, %cl
	cmovneq	%rdx, %r9
	cmovneq	%r10, %rdx
	andq	%r8, %rax
	addq	%r9, %rax
	adcq	$0, %rdx
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	testb	$64, %cl
	cmovneq	%rdx, %r9
	andq	%r8, %rax
	addq	%r9, %rax
	cmpq	%rax, %r8
	cmovaq	%r10, %r8
	subq	%r8, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB50_12:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.37(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB50_11:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB50_13:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.40(%rip), %r8
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow14default_window17h0f0ef2d554902331E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow14default_window17h0f0ef2d554902331E,unique,51
	.globl	_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow14default_window17h0f0ef2d554902331E
	.p2align	4
_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow14default_window17h0f0ef2d554902331E:
.seh_proc _ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow14default_window17h0f0ef2d554902331E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$2088, %rsp
	.seh_stackalloc 2088
	.seh_endprologue
	movq	%rcx, %rsi
	movabsq	$2305843009213693951, %rdi
	leaq	48(%rsp), %rcx
	movl	$2040, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	$1, 40(%rsp)
	movl	$1, %eax
	movl	$131, %r8d
	movabsq	$-2305843009213693951, %r9
	movl	$1, %r10d
	.p2align	4
.LBB51_1:
	mulq	%r8
	movq	%rax, %rcx
	shrq	$61, %rax
	leaq	(%rax,%rdx,8), %rax
	andq	%rdi, %rcx
	addq	%rax, %rcx
	movq	%rcx, %rax
	shrq	$61, %rax
	andq	%rdi, %rcx
	addq	%rax, %rcx
	leaq	(%rcx,%r9), %rax
	cmpq	%rdi, %rcx
	cmovbq	%rcx, %rax
	movq	%rax, 40(%rsp,%r10,8)
	incq	%r10
	cmpq	$256, %r10
	jne	.LBB51_1
	movq	$0, (%rsi)
	movq	$8, 8(%rsi)
	movq	$0, 16(%rsi)
	leaq	24(%rsi), %rcx
	leaq	40(%rsp), %rdx
	movl	$2048, %r8d
	callq	memcpy
	movq	%rdi, 2072(%rsi)
	movq	$131, 2080(%rsi)
	movq	$0, 2088(%rsi)
	movq	$0, 2104(%rsi)
	movq	%rdi, 2112(%rsi)
	movq	$131, 2120(%rsi)
	movb	$0, 2128(%rsi)
	movq	$32768, 2144(%rsi)
	movq	$258, 2152(%rsi)
	movq	$33026, 2160(%rsi)
	movl	$0, 2136(%rsi)
	xorps	%xmm0, %xmm0
	movups	%xmm0, 2168(%rsi)
	movq	$0, 2184(%rsi)
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$2088, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow3new17h008083860bd75b5dE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow3new17h008083860bd75b5dE,unique,52
	.globl	_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow3new17h008083860bd75b5dE
	.p2align	4
_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow3new17h008083860bd75b5dE:
.seh_proc _ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow3new17h008083860bd75b5dE
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$2120, %rsp
	.seh_stackalloc 2120
	.seh_endprologue
	movq	%rdx, 56(%rsp)
	movq	%r8, 64(%rsp)
	testq	%rdx, %rdx
	je	.LBB52_7
	movq	%r8, %rdi
	testq	%r8, %r8
	je	.LBB52_8
	movq	2208(%rsp), %r15
	cmpq	$2, %r15
	jb	.LBB52_9
	movq	%r9, %r14
	cmpq	%r9, %r15
	jae	.LBB52_9
	movq	%rdx, %rbx
	movq	%rcx, %rsi
	leaq	80(%rsp), %rcx
	xorl	%r12d, %r12d
	movl	$2040, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	$1, 72(%rsp)
	bsrq	%r14, %rcx
	incl	%ecx
	movl	$1, %eax
	movl	$1, %r8d
	.p2align	4
.LBB52_5:
	mulq	%r15
	movq	%rdx, %r9
	shrq	%cl, %r9
	movq	%rax, %r10
	shrdq	%cl, %rdx, %r10
	testb	$64, %cl
	cmovneq	%r9, %r10
	cmovneq	%r12, %r9
	andq	%r14, %rax
	addq	%r10, %rax
	adcq	$0, %r9
	movq	%rax, %rdx
	shrdq	%cl, %r9, %rdx
	shrq	%cl, %r9
	testb	$64, %cl
	cmoveq	%rdx, %r9
	andq	%r14, %rax
	addq	%r9, %rax
	cmpq	%rax, %r14
	movq	%r14, %rdx
	cmovaq	%r12, %rdx
	subq	%rdx, %rax
	movq	%rax, 72(%rsp,%r8,8)
	incq	%r8
	cmpq	$256, %r8
	jne	.LBB52_5
	leaq	(%rdi,%rbx), %r12
	movq	$0, (%rsi)
	movq	$8, 8(%rsi)
	movq	$0, 16(%rsi)
	leaq	24(%rsi), %rcx
	leaq	72(%rsp), %rdx
	movl	$2048, %r8d
	callq	memcpy
	movq	%r14, 2072(%rsi)
	movq	%r15, 2080(%rsi)
	movq	$0, 2088(%rsi)
	movq	$0, 2104(%rsi)
	movq	%r14, 2112(%rsi)
	movq	%r15, 2120(%rsi)
	movb	$0, 2128(%rsi)
	movq	%rbx, 2144(%rsi)
	movq	%rdi, 2152(%rsi)
	movq	%r12, 2160(%rsi)
	movl	$0, 2136(%rsi)
	xorps	%xmm0, %xmm0
	movups	%xmm0, 2168(%rsi)
	movq	$0, 2184(%rsi)
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$2120, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB52_9:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.2(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.3(%rip), %r8
	movl	$49, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB52_7:
	leaq	56(%rsp), %rax
	movq	%rax, 40(%rsp)
	leaq	_ZN4core3fmt3num3imp52_$LT$impl$u20$core..fmt..Display$u20$for$u20$u64$GT$3fmt17h9f4f228998531a48E(%rip), %rax
	movq	%rax, 48(%rsp)
	leaq	anon.831c2442e46e5e41962cfb504544efb1.92(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.93(%rip), %r8
	leaq	40(%rsp), %rdx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB52_8:
	leaq	64(%rsp), %rax
	movq	%rax, 40(%rsp)
	leaq	_ZN4core3fmt3num3imp52_$LT$impl$u20$core..fmt..Display$u20$for$u20$u64$GT$3fmt17h9f4f228998531a48E(%rip), %rax
	movq	%rax, 48(%rsp)
	leaq	anon.831c2442e46e5e41962cfb504544efb1.94(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.95(%rip), %r8
	leaq	40(%rsp), %rdx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow5evict17hcf92496244cd5ca6E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow5evict17hcf92496244cd5ca6E,unique,53
	.p2align	4
_ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow5evict17hcf92496244cd5ca6E:
.seh_proc _ZN26hashrope_diagnostic_slot_b7sliding13SlidingWindow5evict17hcf92496244cd5ca6E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	cmpl	$1, 2136(%rcx)
	jne	.LBB53_20
	movl	2140(%rcx), %esi
	movq	16(%rcx), %rdx
	cmpq	%rsi, %rdx
	jbe	.LBB53_21
	movq	8(%rcx), %r8
	leaq	(%rsi,%rsi,2), %rax
	shlq	$4, %rax
	leaq	(%r8,%rax), %r9
	xorl	%r10d, %r10d
	cmpl	$0, (%r8,%rax)
	setne	%r10b
	movq	16(%r9,%r10,8), %rax
	cmpq	2160(%rcx), %rax
	jbe	.LBB53_20
	movq	2112(%rcx), %r9
	cmpq	2072(%rcx), %r9
	jne	.LBB53_22
	movq	2080(%rcx), %r9
	cmpq	%r9, 2120(%rcx)
	jne	.LBB53_22
	movq	2144(%rcx), %r9
	movq	%rax, %rdi
	subq	%r9, %rdi
	jne	.LBB53_7
	movl	$1, %ebx
	xorl	%r11d, %r11d
	xorl	%eax, %eax
	movq	2112(%rcx), %r10
	cmpq	2072(%rcx), %r10
	je	.LBB53_14
	jmp	.LBB53_22
.LBB53_7:
	cmpq	%rax, %rdi
	jae	.LBB53_8
	leaq	40(%rsp), %rax
	movq	%rcx, %rbx
	movq	%rax, %rcx
	movq	%rbx, %rdx
	movl	%esi, %r8d
	movq	%rdi, %r9
	callq	_ZN26hashrope_diagnostic_slot_b4rope5Arena11split_inner17hb98d605116abb54bE
	movq	%rbx, %rcx
	movl	44(%rsp), %r9d
	movl	48(%rsp), %ebx
	movl	52(%rsp), %r10d
	movq	8(%rcx), %r8
	movq	16(%rcx), %rdx
	cmpl	$1, 40(%rsp)
	jne	.LBB53_23
	movl	%r9d, %esi
	jmp	.LBB53_11
.LBB53_8:
	xorl	%ebx, %ebx
.LBB53_11:
	movl	%esi, %eax
	cmpq	%rax, %rdx
	jbe	.LBB53_24
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	leaq	(%r8,%rax), %r9
	xorl	%r11d, %r11d
	cmpl	$0, (%r8,%rax)
	setne	%r11b
	movq	16(%r9,%r11,8), %rax
	movb	$1, %r11b
	movl	%esi, %r9d
	movl	%r10d, %esi
	movq	2112(%rcx), %r10
	cmpq	2072(%rcx), %r10
	je	.LBB53_14
	jmp	.LBB53_22
.LBB53_23:
	xorl	%r11d, %r11d
	movl	%r10d, %esi
	xorl	%eax, %eax
	movq	2112(%rcx), %r10
	cmpq	2072(%rcx), %r10
	jne	.LBB53_22
.LBB53_14:
	movq	2080(%rcx), %r10
	cmpq	%r10, 2120(%rcx)
	jne	.LBB53_22
	testb	%r11b, %r11b
	je	.LBB53_16
	movl	%r9d, %r9d
	cmpq	%r9, %rdx
	jbe	.LBB53_25
	leaq	(%r9,%r9,2), %rdx
	shlq	$4, %rdx
	leaq	(%r8,%rdx), %r9
	xorl	%r10d, %r10d
	cmpl	$0, (%r8,%rdx)
	setne	%r10b
	movq	8(%r9,%r10,8), %r15
	jmp	.LBB53_19
.LBB53_16:
	xorl	%r15d, %r15d
.LBB53_19:
	leaq	24(%rcx), %rdx
	movq	2168(%rcx), %r12
	movq	%rcx, %r14
	movq	%rdx, %rcx
	movq	%rax, %rdx
	callq	_ZN26hashrope_diagnostic_slot_b15polynomial_hash14PolynomialHash5power17h91fd0686201fa3daE
	mulq	%r12
	addq	%r15, %rax
	adcq	$0, %rdx
	movq	2072(%r14), %r8
	movl	$127, %r9d
	bsrq	%r8, %r9
	xorl	$63, %r9d
	movb	$64, %cl
	subb	%r9b, %cl
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	xorl	%r10d, %r10d
	testb	$64, %cl
	cmovneq	%rdx, %r9
	cmovneq	%r10, %rdx
	andq	%r8, %rax
	addq	%r9, %rax
	adcq	$0, %rdx
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	testb	$64, %cl
	cmoveq	%r9, %rdx
	andq	%r8, %rax
	addq	%rdx, %rax
	cmpq	%rax, %r8
	cmovaq	%r10, %r8
	subq	%r8, %rax
	movq	%rax, 2168(%r14)
	addq	%rdi, 2176(%r14)
	movl	%ebx, 2136(%r14)
	movl	%esi, 2140(%r14)
.LBB53_20:
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB53_22:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.37(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB53_21:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%rsi, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB53_25:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.40(%rip), %r8
	movq	%r9, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB53_24:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.6(%rip), %r8
	movq	%rax, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN44_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$3fmt17hf512590d10024b5fE;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN44_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$3fmt17hf512590d10024b5fE,unique,54
	.p2align	4
_ZN44_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$3fmt17hf512590d10024b5fE:
	movq	(%rcx), %rcx
	jmp	_ZN4core3fmt3num3imp52_$LT$impl$u20$core..fmt..Display$u20$for$u20$u64$GT$3fmt17h9f4f228998531a48E

	.def	_ZN4core3ptr70drop_in_place$LT$hashrope_diagnostic_slot_b..rope..ExactComparison$GT$17ha705e0c70d678b60E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN4core3ptr70drop_in_place$LT$hashrope_diagnostic_slot_b..rope..ExactComparison$GT$17ha705e0c70d678b60E,unique,55
	.p2align	4
_ZN4core3ptr70drop_in_place$LT$hashrope_diagnostic_slot_b..rope..ExactComparison$GT$17ha705e0c70d678b60E:
.seh_proc _ZN4core3ptr70drop_in_place$LT$hashrope_diagnostic_slot_b..rope..ExactComparison$GT$17ha705e0c70d678b60E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$136, %rsp
	.seh_stackalloc 136
	.seh_endprologue
	movq	16(%rcx), %rdx
	testq	%rdx, %rdx
	je	.LBB55_1
	movq	24(%rcx), %r8
	movq	32(%rcx), %rax
	movq	$0, 72(%rsp)
	movq	%rdx, 80(%rsp)
	movq	%r8, 88(%rsp)
	movq	$0, 104(%rsp)
	movq	%rdx, 112(%rsp)
	movq	%r8, 120(%rsp)
	movl	$1, %ecx
	jmp	.LBB55_3
.LBB55_1:
	xorl	%ecx, %ecx
	xorl	%eax, %eax
.LBB55_3:
	movq	%rcx, 64(%rsp)
	movq	%rcx, 96(%rsp)
	movq	%rax, 128(%rsp)
	leaq	40(%rsp), %rcx
	leaq	64(%rsp), %rdx
	callq	_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E
	cmpq	$0, 40(%rsp)
	je	.LBB55_6
	leaq	40(%rsp), %rsi
	leaq	64(%rsp), %rdi
	.p2align	4
.LBB55_5:
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	callq	_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E
	cmpq	$0, 40(%rsp)
	jne	.LBB55_5
.LBB55_6:
	.seh_startepilogue
	addq	$136, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE,unique,56
	.p2align	4
_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE:
.Lfunc_begin8:
.seh_proc _ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$232, %rsp
	.seh_stackalloc 232
	leaq	128(%rsp), %rbp
	.seh_setframe %rbp, 128
	movaps	%xmm6, 80(%rbp)
	.seh_savexmm %xmm6, 208
	.seh_endprologue
	movq	$-2, 72(%rbp)
	movq	(%rcx), %r15
	testq	%r15, %r15
	je	.LBB56_83
	movq	%rcx, 32(%rbp)
	movq	8(%rcx), %r8
	movl	16(%rdx), %eax
	movq	(%rdx), %r14
	movq	8(%rdx), %rbx
	movl	20(%rdx), %ecx
	movq	24(%rdx), %rdi
	movq	%r8, -48(%rbp)
	movq	%r15, -56(%rbp)
.LBB56_2:
	movzwl	362(%r15), %r12d
	movl	%r12d, %r9d
	shll	$5, %r9d
	movq	$-1, %r13
	xorl	%r10d, %r10d
	jmp	.LBB56_3
	.p2align	4
.LBB56_10:
	incq	%r13
	addq	$32, %r10
	cmpb	$1, %r11b
	jne	.LBB56_11
.LBB56_3:
	cmpq	%r10, %r9
	je	.LBB56_4
	movl	16(%r15,%r10), %esi
	cmpl	%esi, %eax
	seta	%r11b
	sbbb	$0, %r11b
	cmpl	%esi, %eax
	jne	.LBB56_10
	movq	(%r15,%r10), %rsi
	cmpq	%rsi, %r14
	seta	%r11b
	sbbb	$0, %r11b
	cmpq	%rsi, %r14
	jne	.LBB56_10
	movl	20(%r15,%r10), %esi
	cmpl	%esi, %ecx
	seta	%r11b
	sbbb	$0, %r11b
	cmpl	%esi, %ecx
	jne	.LBB56_10
	movq	8(%r15,%r10), %rsi
	cmpq	%rsi, %rbx
	seta	%r11b
	sbbb	$0, %r11b
	cmpq	%rsi, %rbx
	jne	.LBB56_10
	cmpq	24(%r15,%r10), %rdi
	seta	%r11b
	sbbb	$0, %r11b
	jmp	.LBB56_10
	.p2align	4
.LBB56_11:
	movzbl	%r11b, %r9d
	testl	%r9d, %r9d
	je	.LBB56_86
	jmp	.LBB56_12
	.p2align	4
.LBB56_4:
	movq	%r12, %r13
.LBB56_12:
	subq	$1, %r8
	jb	.LBB56_14
	movq	368(%r15,%r13,8), %r15
	jmp	.LBB56_2
.LBB56_83:
	movq	%rcx, %rbx
	movq	(%rdx), %rsi
	movups	8(%rdx), %xmm6
	movq	24(%rdx), %rdi
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$368, %ecx
	movl	$8, %edx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB56_87
	movq	$0, 352(%rax)
	movq	%rbx, %rcx
	movq	%rax, (%rbx)
	movq	$0, 8(%rbx)
	movw	$1, 362(%rax)
	movq	%rsi, (%rax)
	movups	%xmm6, 8(%rax)
	movq	%rdi, 24(%rax)
.LBB56_85:
	incq	16(%rcx)
.LBB56_86:
	movaps	80(%rbp), %xmm6
	.seh_startepilogue
	addq	$232, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.LBB56_14:
	movq	16(%rdx), %rsi
	cmpw	$11, %r12w
	jae	.LBB56_15
	cmpq	%r13, %r12
	jbe	.LBB56_19
	movq	%r13, %rax
	shlq	$5, %rax
	leaq	(%r15,%rax), %rdx
	leaq	(%r15,%rax), %rcx
	addq	$32, %rcx
	movl	%r12d, %r8d
	subl	%r13d, %r8d
	shll	$5, %r8d
	callq	memmove
.LBB56_19:
	incl	%r12d
	shlq	$5, %r13
	movq	%r14, (%r15,%r13)
	movq	%rbx, 8(%r15,%r13)
	movq	%rsi, 16(%r15,%r13)
	movq	%rdi, 24(%r15,%r13)
	movw	%r12w, 362(%r15)
	movq	32(%rbp), %rcx
	jmp	.LBB56_85
.LBB56_15:
	cmpq	$5, %r13
	movq	%rsi, 48(%rbp)
	jae	.LBB56_20
	movl	$4, %eax
	movq	%rax, 64(%rbp)
	xorl	%r12d, %r12d
	jmp	.LBB56_25
.LBB56_20:
	je	.LBB56_21
	cmpq	$6, %r13
	jne	.LBB56_23
	movl	$5, %eax
	movq	%rax, 64(%rbp)
	movb	$1, %r12b
	xorl	%r13d, %r13d
	jmp	.LBB56_25
.LBB56_21:
	xorl	%r12d, %r12d
	movq	%r13, 64(%rbp)
	jmp	.LBB56_25
.LBB56_23:
	addq	$-7, %r13
	movl	$6, %eax
	movq	%rax, 64(%rbp)
	movb	$1, %r12b
.LBB56_25:
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$368, %ecx
	movl	$8, %edx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB56_87
	movq	%rax, %rsi
	movl	%r12d, 40(%rbp)
	movq	$0, 352(%rax)
	movzwl	362(%r15), %eax
	movq	64(%rbp), %r12
	movq	%r12, %r8
	notq	%r8
	addq	%rax, %r8
	movw	%r8w, 362(%rsi)
	cmpq	$12, %r8
	movq	%rsi, 56(%rbp)
	jae	.LBB56_27
	movq	%r12, 64(%rbp)
	shlq	$5, %r12
	leaq	(%r15,%r12), %rdx
	addq	$32, %rdx
	shlq	$5, %r8
	movq	%rsi, %rcx
	callq	memcpy
	movq	64(%rbp), %rax
	movw	%ax, 362(%r15)
	movups	(%r15,%r12), %xmm0
	movups	16(%r15,%r12), %xmm1
	movaps	%xmm1, -16(%rbp)
	cmpb	$0, 40(%rbp)
	cmoveq	%r15, %rsi
	movaps	%xmm0, -32(%rbp)
	movzwl	362(%rsi), %r12d
	movzwl	%r12w, %r8d
	cmpq	%r13, %r8
	jbe	.LBB56_32
	movq	%r13, %rax
	shlq	$5, %rax
	leaq	(%rsi,%rax), %rdx
	leaq	(%rsi,%rax), %rcx
	addq	$32, %rcx
	subl	%r13d, %r8d
	shll	$5, %r8d
	callq	memmove
.LBB56_32:
	incl	%r12d
	shlq	$5, %r13
	movq	%r14, (%rsi,%r13)
	movq	%rbx, 8(%rsi,%r13)
	movq	48(%rbp), %rax
	movq	%rax, 16(%rsi,%r13)
	movq	%rdi, 24(%rsi,%r13)
	movw	%r12w, 362(%rsi)
	movaps	-32(%rbp), %xmm0
	movaps	-16(%rbp), %xmm1
	movaps	%xmm1, 16(%rbp)
	movaps	%xmm0, (%rbp)
	movq	352(%r15), %rax
	testq	%rax, %rax
	je	.LBB56_33
	movq	$0, 40(%rbp)
	movq	56(%rbp), %r14
	jmp	.LBB56_43
.LBB56_82:
	movaps	-96(%rbp), %xmm0
	movaps	-80(%rbp), %xmm1
	movaps	%xmm1, 16(%rbp)
	movaps	%xmm0, (%rbp)
	movq	352(%r15), %rax
	testq	%rax, %rax
	je	.LBB56_34
.LBB56_43:
	movq	%r14, %rdx
	movzwl	360(%r15), %ecx
	movq	%rax, %r15
	movzwl	%cx, %r13d
	movzwl	362(%rax), %r14d
	cmpq	$11, %r14
	movq	%rdx, 64(%rbp)
	jb	.LBB56_46
	cmpw	$5, %cx
	jae	.LBB56_57
	movq	%r13, 48(%rbp)
	movl	$4, %esi
	xorl	%r13d, %r13d
	jmp	.LBB56_62
.LBB56_57:
	je	.LBB56_58
	cmpl	$6, %r13d
	jne	.LBB56_60
	movb	$1, %r13b
	movl	$5, %esi
	movq	$0, 48(%rbp)
	jmp	.LBB56_62
.LBB56_58:
	movq	%r13, %rsi
	xorl	%r13d, %r13d
	movq	%rsi, 48(%rbp)
	jmp	.LBB56_62
.LBB56_60:
	addq	$-7, %r13
	movq	%r13, 48(%rbp)
	movb	$1, %r13b
	movl	$6, %esi
.LBB56_62:
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$464, %ecx
	movl	$8, %edx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB56_89
	movq	%rax, %rdi
	movq	$0, 352(%rdi)
	movzwl	362(%r15), %eax
	movq	%rsi, %r8
	notq	%r8
	addq	%rax, %r8
	movw	%r8w, 362(%rdi)
	cmpq	$12, %r8
	movq	%rdi, 56(%rbp)
	jae	.LBB56_64
	movl	%esi, %r12d
	shll	$5, %r12d
	leaq	(%r15,%r12), %rdx
	addq	$32, %rdx
	shlq	$5, %r8
	movq	%rdi, %rcx
	callq	memcpy
	movw	%si, 362(%r15)
	movups	(%r15,%r12), %xmm0
	movups	16(%r15,%r12), %xmm1
	movaps	%xmm1, -16(%rbp)
	movaps	%xmm0, -32(%rbp)
	movzwl	362(%rdi), %r12d
	leaq	1(%r12), %r8
	cmpq	$12, %r12
	jae	.LBB56_66
	movzwl	%r14w, %eax
	subl	%esi, %eax
	cmpl	%r8d, %eax
	jne	.LBB56_68
	incq	40(%rbp)
	leaq	368(%rdi), %rcx
	leaq	(%r15,%rsi,8), %rdx
	addq	$376, %rdx
	shll	$3, %r8d
	callq	memcpy
	xorl	%eax, %eax
	movq	56(%rbp), %r14
	.p2align	4
.LBB56_70:
	movq	%rax, %rcx
	cmpq	%r12, %rax
	adcq	$0, %rax
	movq	368(%r14,%rcx,8), %rdx
	movq	%r14, 352(%rdx)
	movw	%cx, 360(%rdx)
	cmpq	%r12, %rcx
	jae	.LBB56_72
	cmpq	%r12, %rax
	jbe	.LBB56_70
.LBB56_72:
	movaps	-32(%rbp), %xmm0
	movaps	-16(%rbp), %xmm1
	movaps	%xmm1, -80(%rbp)
	testb	%r13b, %r13b
	cmoveq	%r15, %rdi
	movaps	%xmm0, -96(%rbp)
	movzwl	362(%rdi), %esi
	movq	48(%rbp), %r13
	leaq	1(%r13), %r12
	movq	%r13, %rbx
	shlq	$5, %rbx
	addq	%rdi, %rbx
	movq	%rsi, %r10
	subq	%r13, %r10
	jbe	.LBB56_73
	movq	%r12, %rcx
	shlq	$5, %rcx
	addq	%rdi, %rcx
	movl	%esi, %r14d
	subl	%r13d, %r14d
	movl	%r14d, %r8d
	shll	$5, %r8d
	movq	%rbx, %rdx
	movq	%r10, -40(%rbp)
	callq	memmove
	movaps	(%rbp), %xmm0
	movaps	16(%rbp), %xmm1
	movups	%xmm0, (%rbx)
	movups	%xmm1, 16(%rbx)
	leaq	(%rdi,%r12,8), %rdx
	addq	$368, %rdx
	leaq	(%rdi,%r13,8), %rcx
	addq	$384, %rcx
	shll	$3, %r14d
	movq	%r14, %r8
	movq	56(%rbp), %r14
	callq	memmove
	movq	-40(%rbp), %r10
	jmp	.LBB56_75
.LBB56_73:
	movaps	(%rbp), %xmm0
	movaps	16(%rbp), %xmm1
	movups	%xmm1, 16(%rbx)
	movups	%xmm0, (%rbx)
.LBB56_75:
	movq	64(%rbp), %rdx
	leal	1(%rsi), %ecx
	leaq	2(%rsi), %rax
	movq	%rdx, 376(%rdi,%r13,8)
	movw	%cx, 362(%rdi)
	cmpq	%rax, %r12
	jae	.LBB56_82
	subl	%r13d, %esi
	incl	%esi
	andl	$3, %esi
	je	.LBB56_80
	leaq	(%rdi,%r13,8), %rdx
	addq	$376, %rdx
	xorl	%ecx, %ecx
	.p2align	4
.LBB56_78:
	movq	(%rdx,%rcx,8), %r8
	movq	%rdi, 352(%r8)
	leal	(%r12,%rcx), %r9d
	movw	%r9w, 360(%r8)
	incq	%rcx
	cmpq	%rcx, %rsi
	jne	.LBB56_78
	addq	%rcx, %r12
.LBB56_80:
	cmpq	$3, %r10
	jb	.LBB56_82
	.p2align	4
.LBB56_81:
	movq	368(%rdi,%r12,8), %rcx
	movq	%rdi, 352(%rcx)
	movw	%r12w, 360(%rcx)
	movq	376(%rdi,%r12,8), %rcx
	movq	%rdi, 352(%rcx)
	leal	1(%r12), %edx
	movw	%dx, 360(%rcx)
	movq	384(%rdi,%r12,8), %rcx
	movq	%rdi, 352(%rcx)
	leal	2(%r12), %edx
	movw	%dx, 360(%rcx)
	movq	392(%rdi,%r12,8), %rcx
	movq	%rdi, 352(%rcx)
	leal	3(%r12), %edx
	movw	%dx, 360(%rcx)
	addq	$4, %r12
	cmpq	%rax, %r12
	jne	.LBB56_81
	jmp	.LBB56_82
.LBB56_33:
	movq	$0, 40(%rbp)
	movq	56(%rbp), %r14
.LBB56_34:
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$464, %ecx
	movl	$8, %edx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB56_35
	movq	$0, 352(%rax)
	movw	$0, 362(%rax)
	movq	-56(%rbp), %rdx
	movq	%rdx, 368(%rax)
	movq	-48(%rbp), %r8
	movq	%r8, %r9
	incq	%r9
	movq	32(%rbp), %rcx
	je	.LBB56_37
	movq	%rax, 352(%rdx)
	movw	$0, 360(%rdx)
	movq	%rax, (%rcx)
	movq	%r9, 8(%rcx)
	cmpq	%r8, 40(%rbp)
	jne	.LBB56_88
	movw	$1, 362(%rax)
	movaps	(%rbp), %xmm0
	movaps	16(%rbp), %xmm1
	movups	%xmm0, (%rax)
	movups	%xmm1, 16(%rax)
	movq	%r14, 376(%rax)
	movq	%rax, 352(%r14)
	movw	$1, 360(%r14)
	jmp	.LBB56_85
.LBB56_46:
	leal	1(%r14), %esi
	leaq	1(%r13), %r12
	movl	%r13d, %edi
	shll	$5, %edi
	addq	%r15, %rdi
	cmpw	%r14w, %cx
	jae	.LBB56_47
	movl	%r12d, %ecx
	shll	$5, %ecx
	addq	%r15, %rcx
	movq	%r14, %rbx
	subq	%r13, %rbx
	movq	%rbx, %r8
	shlq	$5, %r8
	movq	%rdi, %rdx
	callq	memmove
	movaps	(%rbp), %xmm0
	movaps	16(%rbp), %xmm1
	movups	%xmm0, (%rdi)
	movups	%xmm1, 16(%rdi)
	leaq	(%r15,%r12,8), %rdx
	addq	$368, %rdx
	leaq	(%r15,%r13,8), %rcx
	addq	$384, %rcx
	shlq	$3, %rbx
	movq	%rbx, %r8
	callq	memmove
	movq	64(%rbp), %rdx
	jmp	.LBB56_49
.LBB56_47:
	movaps	(%rbp), %xmm0
	movaps	16(%rbp), %xmm1
	movups	%xmm1, 16(%rdi)
	movups	%xmm0, (%rdi)
.LBB56_49:
	leaq	2(%r14), %rax
	movq	%rdx, 376(%r15,%r13,8)
	movw	%si, 362(%r15)
	cmpl	%eax, %r12d
	jae	.LBB56_56
	movl	%r14d, %ecx
	subl	%r13d, %ecx
	incl	%ecx
	subq	%r13, %r14
	andl	$3, %ecx
	je	.LBB56_54
	leaq	(%r15,%r13,8), %r8
	addq	$376, %r8
	xorl	%edx, %edx
.LBB56_52:
	movq	(%r8,%rdx,8), %r9
	movq	%r15, 352(%r9)
	leal	(%r12,%rdx), %r10d
	movw	%r10w, 360(%r9)
	incq	%rdx
	cmpq	%rdx, %rcx
	jne	.LBB56_52
	addq	%rdx, %r12
.LBB56_54:
	cmpq	$3, %r14
	jb	.LBB56_56
.LBB56_55:
	movq	368(%r15,%r12,8), %rcx
	movq	%r15, 352(%rcx)
	movw	%r12w, 360(%rcx)
	movq	376(%r15,%r12,8), %rcx
	movq	%r15, 352(%rcx)
	leal	1(%r12), %edx
	movw	%dx, 360(%rcx)
	movq	384(%r15,%r12,8), %rcx
	movq	%r15, 352(%rcx)
	leal	2(%r12), %edx
	movw	%dx, 360(%rcx)
	movq	392(%r15,%r12,8), %rcx
	movq	%r15, 352(%rcx)
	leal	3(%r12), %edx
	movw	%dx, 360(%rcx)
	addq	$4, %r12
	cmpq	%rax, %r12
	jne	.LBB56_55
.LBB56_56:
	movq	32(%rbp), %rcx
	jmp	.LBB56_85
.LBB56_87:
	movl	$8, %ecx
	movl	$368, %edx
	callq	_ZN5alloc5alloc18handle_alloc_error17h6942ce664312655aE
.LBB56_64:
.Ltmp96:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.102(%rip), %r9
	movq	%r8, %rdx
	movl	$11, %r8d
	xorl	%ecx, %ecx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.Ltmp97:
	jmp	.LBB56_28
.LBB56_66:
.Ltmp98:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.103(%rip), %r9
	movq	%r8, %rdx
	movl	$12, %r8d
	xorl	%ecx, %ecx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.Ltmp99:
	jmp	.LBB56_28
.LBB56_89:
	movl	$8, %ecx
	movl	$464, %edx
	callq	_ZN5alloc5alloc18handle_alloc_error17h6942ce664312655aE
.LBB56_68:
.Ltmp100:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.100(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.101(%rip), %r8
	movl	$40, %edx
	callq	_ZN4core9panicking5panic17hc5fbe615138639caE
.Ltmp101:
	jmp	.LBB56_28
.LBB56_27:
.Ltmp94:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.102(%rip), %r9
	movq	%r8, %rdx
	movl	$11, %r8d
	xorl	%ecx, %ecx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.Ltmp95:
	jmp	.LBB56_28
.LBB56_35:
.Ltmp104:
	movl	$8, %ecx
	movl	$464, %edx
	callq	_ZN5alloc5alloc18handle_alloc_error17h6942ce664312655aE
.Ltmp105:
	jmp	.LBB56_28
.LBB56_37:
.Ltmp102:
	movq	%rax, 32(%rbp)
	leaq	anon.831c2442e46e5e41962cfb504544efb1.99(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.Ltmp103:
.LBB56_28:
	ud2
.LBB56_88:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.97(%rip), %rcx
	leaq	anon.831c2442e46e5e41962cfb504544efb1.98(%rip), %r8
	movl	$48, %edx
	callq	_ZN4core9panicking5panic17hc5fbe615138639caE
	int3
	.seh_handlerdata
	.long	$cppxdata$_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE@IMGREL
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE,unique,56
	.seh_endproc
	.def	"?dtor$29@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$29@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE@4HA":
.seh_proc "?dtor$29@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE@4HA"
.LBB56_29:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	leaq	128(%rdx), %rbp
	movaps	%xmm6, 32(%rsp)
	.seh_savexmm %xmm6, 32
	.seh_endprologue
	movl	$368, %edx
	movl	$8, %r8d
	movq	56(%rbp), %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	movaps	32(%rsp), %xmm6
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE,unique,56
	.seh_endproc
	.def	"?dtor$38@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$38@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE@4HA":
.seh_proc "?dtor$38@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE@4HA"
.LBB56_38:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	leaq	128(%rdx), %rbp
	movaps	%xmm6, 32(%rsp)
	.seh_savexmm %xmm6, 32
	.seh_endprologue
	movl	$464, %edx
	movl	$8, %r8d
	movq	32(%rbp), %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	movaps	32(%rsp), %xmm6
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE,unique,56
	.seh_endproc
	.def	"?dtor$39@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$39@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE@4HA":
.seh_proc "?dtor$39@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE@4HA"
.LBB56_39:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	leaq	128(%rdx), %rbp
	movaps	%xmm6, 32(%rsp)
	.seh_savexmm %xmm6, 32
	.seh_endprologue
	ud2
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE,unique,56
	.seh_endproc
	.def	"?dtor$90@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$90@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE@4HA":
.seh_proc "?dtor$90@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE@4HA"
.LBB56_90:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	leaq	128(%rdx), %rbp
	movaps	%xmm6, 32(%rsp)
	.seh_savexmm %xmm6, 32
	.seh_endprologue
	movl	$464, %edx
	movl	$8, %r8d
	movq	56(%rbp), %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	movaps	32(%rsp), %xmm6
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.Lfunc_end8:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE,unique,56
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE,unique,8
	.p2align	2, 0x0
$cppxdata$_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE:
	.long	429065506
	.long	4
	.long	$stateUnwindMap$_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE@IMGREL
	.long	0
	.long	0
	.long	8
	.long	$ip2state$_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE@IMGREL
	.long	200
	.long	0
	.long	1
$stateUnwindMap$_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE:
	.long	-1
	.long	"?dtor$29@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE@4HA"@IMGREL
	.long	-1
	.long	"?dtor$39@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE@4HA"@IMGREL
	.long	1
	.long	"?dtor$38@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE@4HA"@IMGREL
	.long	-1
	.long	"?dtor$90@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE@4HA"@IMGREL
$ip2state$_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE:
	.long	.Lfunc_begin8@IMGREL
	.long	-1
	.long	.Ltmp96@IMGREL+1
	.long	3
	.long	.Ltmp99@IMGREL+1
	.long	-1
	.long	.Ltmp100@IMGREL+1
	.long	3
	.long	.Ltmp94@IMGREL+1
	.long	0
	.long	.Ltmp104@IMGREL+1
	.long	1
	.long	.Ltmp102@IMGREL+1
	.long	2
	.long	.Ltmp103@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17h4b50f2e2fdf0df9aE,unique,56

	.def	_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E,unique,57
	.p2align	4
_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E:
.Lfunc_begin9:
.seh_proc _ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$48, %rsp
	.seh_stackalloc 48
	leaq	48(%rsp), %rbp
	.seh_setframe %rbp, 48
	.seh_endprologue
	movq	$-2, -8(%rbp)
	movq	%rcx, %rsi
	movq	64(%rdx), %rax
	testq	%rax, %rax
	je	.LBB57_1
	decq	%rax
	movq	%rax, 64(%rdx)
	cmpl	$1, (%rdx)
	jne	.LBB57_49
	movq	8(%rdx), %rcx
	testq	%rcx, %rcx
	je	.LBB57_21
	movq	16(%rdx), %rax
	movq	24(%rdx), %rdi
	movzwl	362(%rcx), %r8d
	cmpq	%r8, %rdi
	jae	.LBB57_31
.LBB57_30:
	movq	%rax, %r14
	movq	%rcx, %rbx
	testq	%r14, %r14
	je	.LBB57_36
.LBB57_39:
	leaq	(%rbx,%rdi,8), %rax
	addq	$376, %rax
	movq	%r14, %r8
	andq	$7, %r8
	je	.LBB57_40
	xorl	%r10d, %r10d
	.p2align	4
.LBB57_42:
	movq	(%rax), %rcx
	leaq	368(%rcx), %rax
	incq	%r10
	cmpq	%r10, %r8
	jne	.LBB57_42
	movq	%r14, %r9
	subq	%r10, %r9
	xorl	%r8d, %r8d
	cmpq	$8, %r14
	jae	.LBB57_45
	jmp	.LBB57_37
.LBB57_1:
	movq	8(%rdx), %rcx
	movq	16(%rdx), %rdi
	movq	24(%rdx), %rax
	testb	$1, (%rdx)
	movq	$0, (%rdx)
	je	.LBB57_17
	testq	%rcx, %rcx
	je	.LBB57_4
	movq	%rdi, %rbx
	movq	%rcx, %rdi
.LBB57_13:
	movq	352(%rdi), %rax
	testq	%rax, %rax
	je	.LBB57_16
	movl	$368, %r14d
	movq	%rdi, %rcx
	movq	%rbx, %rdx
	.p2align	4
.LBB57_15:
	movq	%rax, %rdi
	leaq	1(%rdx), %rbx
	testq	%rdx, %rdx
	movl	$464, %edx
	cmoveq	%r14, %rdx
	movl	$8, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	movq	352(%rdi), %rax
	movq	%rdi, %rcx
	movq	%rbx, %rdx
	testq	%rax, %rax
	jne	.LBB57_15
.LBB57_16:
	testq	%rbx, %rbx
	movl	$368, %eax
	movl	$464, %edx
	cmoveq	%rax, %rdx
	movl	$8, %r8d
	movq	%rdi, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB57_17:
	movq	$0, (%rsi)
	jmp	.LBB57_38
.LBB57_21:
	movq	16(%rdx), %rcx
	movq	24(%rdx), %rax
	testq	%rax, %rax
	je	.LBB57_28
	movq	%rax, %r8
	andq	$7, %r8
	je	.LBB57_23
	xorl	%r9d, %r9d
	.p2align	4
.LBB57_25:
	movq	368(%rcx), %rcx
	incq	%r9
	cmpq	%r9, %r8
	jne	.LBB57_25
	movq	%rax, %r8
	subq	%r9, %r8
	cmpq	$8, %rax
	jb	.LBB57_28
	.p2align	4
.LBB57_50:
	movq	368(%rcx), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rcx
	addq	$-8, %r8
	jne	.LBB57_50
.LBB57_28:
	movq	$1, (%rdx)
	xorl	%edi, %edi
	xorl	%eax, %eax
	movzwl	362(%rcx), %r8d
	cmpq	%r8, %rdi
	jb	.LBB57_30
.LBB57_31:
	movq	%rdx, %r15
	movl	$368, %r12d
	.p2align	4
.LBB57_32:
	movq	352(%rcx), %rbx
	testq	%rbx, %rbx
	je	.LBB57_46
	leaq	1(%rax), %r14
	movzwl	360(%rcx), %edi
	testq	%rax, %rax
	movl	$464, %edx
	cmoveq	%r12, %rdx
	movl	$8, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	movq	%rbx, %rcx
	movq	%r14, %rax
	cmpw	362(%rbx), %di
	jae	.LBB57_32
	movq	%r15, %rdx
	testq	%r14, %r14
	jne	.LBB57_39
.LBB57_36:
	leaq	1(%rdi), %r8
	movq	%rbx, %rcx
	jmp	.LBB57_37
.LBB57_40:
	movq	%r14, %r9
	xorl	%r8d, %r8d
	cmpq	$8, %r14
	jb	.LBB57_37
	.p2align	4
.LBB57_45:
	movq	(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rcx
	leaq	368(%rcx), %rax
	addq	$-8, %r9
	jne	.LBB57_45
.LBB57_37:
	movq	%rcx, 8(%rdx)
	movq	$0, 16(%rdx)
	movq	%r8, 24(%rdx)
	movq	%rbx, (%rsi)
	movq	%r14, 8(%rsi)
	movq	%rdi, 16(%rsi)
.LBB57_38:
	.seh_startepilogue
	addq	$48, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.LBB57_4:
	testq	%rax, %rax
	je	.LBB57_5
	movq	%rax, %rcx
	andq	$7, %rcx
	je	.LBB57_7
	xorl	%edx, %edx
	.p2align	4
.LBB57_9:
	movq	368(%rdi), %rdi
	incq	%rdx
	cmpq	%rdx, %rcx
	jne	.LBB57_9
	movq	%rax, %rcx
	subq	%rdx, %rcx
	jmp	.LBB57_11
.LBB57_23:
	movq	%rax, %r8
	cmpq	$8, %rax
	jae	.LBB57_50
	jmp	.LBB57_28
.LBB57_5:
	xorl	%ebx, %ebx
	jmp	.LBB57_13
.LBB57_7:
	movq	%rax, %rcx
.LBB57_11:
	xorl	%ebx, %ebx
	cmpq	$8, %rax
	jb	.LBB57_13
	.p2align	4
.LBB57_12:
	movq	368(%rdi), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rdi
	addq	$-8, %rcx
	jne	.LBB57_12
	jmp	.LBB57_13
.LBB57_46:
	testq	%rax, %rax
	movl	$368, %eax
	movl	$464, %edx
	cmoveq	%rax, %rdx
	movl	$8, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.Ltmp106:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.105(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.Ltmp107:
	ud2
.LBB57_49:
	leaq	anon.831c2442e46e5e41962cfb504544efb1.106(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
	int3
	.seh_handlerdata
	.long	$cppxdata$_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E@IMGREL
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E,unique,57
	.seh_endproc
	.def	"?dtor$48@?0?_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$48@?0?_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E@4HA":
.seh_proc "?dtor$48@?0?_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E@4HA"
.LBB57_48:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	leaq	48(%rdx), %rbp
	.seh_endprologue
	ud2
.Lfunc_end9:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E,unique,57
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E,unique,9
	.p2align	2, 0x0
$cppxdata$_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E:
	.long	429065506
	.long	1
	.long	$stateUnwindMap$_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E@IMGREL
	.long	0
	.long	0
	.long	3
	.long	$ip2state$_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E@IMGREL
	.long	40
	.long	0
	.long	1
$stateUnwindMap$_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E:
	.long	-1
	.long	"?dtor$48@?0?_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E@4HA"@IMGREL
$ip2state$_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E:
	.long	.Lfunc_begin9@IMGREL
	.long	-1
	.long	.Ltmp106@IMGREL+1
	.long	0
	.long	.Ltmp107@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h45c201a188d37526E,unique,57

	.def	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h3f28a2f1503df7efE;
	.scl	2;
	.type	32;
	.endef
	.section	.text$unlikely,"xr",one_only,_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h3f28a2f1503df7efE,unique,58
	.globl	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h3f28a2f1503df7efE
	.p2align	4
_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h3f28a2f1503df7efE:
.seh_proc _ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h3f28a2f1503df7efE
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	movq	%rcx, %rsi
	movq	(%rcx), %rdx
	leaq	(%rdx,%rdx), %rax
	cmpq	$5, %rax
	movl	$4, %edi
	cmovaeq	%rax, %rdi
	movq	8(%rcx), %r8
	movq	$48, 40(%rsp)
	movq	$8, 32(%rsp)
	leaq	48(%rsp), %rcx
	movq	%rdi, %r9
	callq	_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h7a768e67d63e8b2bE
	cmpl	$1, 48(%rsp)
	je	.LBB58_2
	movq	56(%rsp), %rax
	movq	%rax, 8(%rsi)
	movq	%rdi, (%rsi)
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB58_2:
	movq	56(%rsp), %rcx
	movq	64(%rsp), %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
	int3
	.seh_endproc

	.def	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hd82fe28a84893d11E;
	.scl	2;
	.type	32;
	.endef
	.section	.text$unlikely,"xr",one_only,_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hd82fe28a84893d11E,unique,59
	.globl	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hd82fe28a84893d11E
	.p2align	4
_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hd82fe28a84893d11E:
.seh_proc _ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hd82fe28a84893d11E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	movq	%rcx, %rsi
	movq	(%rcx), %rdx
	leaq	(%rdx,%rdx), %rax
	cmpq	$5, %rax
	movl	$4, %edi
	cmovaeq	%rax, %rdi
	movq	8(%rcx), %r8
	movq	$4, 40(%rsp)
	movq	$4, 32(%rsp)
	leaq	48(%rsp), %rcx
	movq	%rdi, %r9
	callq	_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h7a768e67d63e8b2bE
	cmpl	$1, 48(%rsp)
	je	.LBB59_2
	movq	56(%rsp), %rax
	movq	%rax, 8(%rsi)
	movq	%rdi, (%rsi)
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB59_2:
	movq	56(%rsp), %rcx
	movq	64(%rsp), %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
	int3
	.seh_endproc

	.def	_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h7a768e67d63e8b2bE;
	.scl	3;
	.type	32;
	.endef
	.section	.text$unlikely,"xr",one_only,_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h7a768e67d63e8b2bE,unique,60
	.p2align	4
_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h7a768e67d63e8b2bE:
.seh_proc _ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h7a768e67d63e8b2bE
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rdx, %r11
	movq	%rcx, %rsi
	movq	112(%rsp), %rbx
	movq	120(%rsp), %r10
	leaq	(%rbx,%r10), %rcx
	decq	%rcx
	movq	%rbx, %rax
	negq	%rax
	andq	%rcx, %rax
	mulq	%r9
	movq	%rax, %rdi
	seto	%al
	movabsq	$-9223372036854775808, %rcx
	subq	%rbx, %rcx
	cmpq	%rcx, %rdi
	seta	%cl
	orb	%al, %cl
	movl	$1, %r14d
	je	.LBB60_2
	movl	$8, %eax
	xorl	%edi, %edi
	jmp	.LBB60_10
.LBB60_2:
	testq	%r11, %r11
	je	.LBB60_4
	imulq	%r11, %r10
	movq	%r8, %rcx
	movq	%r10, %rdx
	movq	%rbx, %r8
	movq	%rdi, %r9
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_realloc
	testq	%rax, %rax
	jne	.LBB60_6
	jmp	.LBB60_9
.LBB60_4:
	testq	%rdi, %rdi
	je	.LBB60_5
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movq	%rdi, %rcx
	movq	%rbx, %rdx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	jne	.LBB60_6
.LBB60_9:
	movq	%rbx, 8(%rsi)
	movl	$16, %eax
	jmp	.LBB60_10
.LBB60_5:
	movq	%rbx, %rax
.LBB60_6:
	movq	%rax, 8(%rsi)
	movl	$16, %eax
	xorl	%r14d, %r14d
.LBB60_10:
	movq	%rdi, (%rsi,%rax)
	movq	%r14, (%rsi)
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17hd373a462eb04ccaaE;
	.scl	3;
	.type	32;
	.endef
	.section	.text$unlikely,"xr",one_only,_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17hd373a462eb04ccaaE,unique,61
	.p2align	4
_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17hd373a462eb04ccaaE:
.seh_proc _ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17hd373a462eb04ccaaE
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	addq	%r8, %rdx
	jb	.LBB61_1
	movq	%rcx, %rsi
	movq	(%rcx), %rax
	leaq	(%rax,%rax), %rcx
	cmpq	%rcx, %rdx
	cmovaq	%rdx, %rcx
	cmpq	$9, %rcx
	movl	$8, %edi
	cmovaeq	%rcx, %rdi
	movq	8(%rsi), %r8
	movq	$1, 40(%rsp)
	movq	$1, 32(%rsp)
	leaq	48(%rsp), %rcx
	movq	%rax, %rdx
	movq	%rdi, %r9
	callq	_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h7a768e67d63e8b2bE
	cmpl	$1, 48(%rsp)
	je	.LBB61_3
	movq	56(%rsp), %rax
	movq	%rax, 8(%rsi)
	movq	%rdi, (%rsi)
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB61_1:
	xorl	%ecx, %ecx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
.LBB61_3:
	movq	56(%rsp), %rcx
	movq	64(%rsp), %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
	int3
	.seh_endproc

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.0,unique,62
anon.831c2442e46e5e41962cfb504544efb1.0:
	.asciz	"slot_b\\src\\polynomial_hash.rs"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.1,unique,63
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.1:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.0
	.asciz	"\035\000\000\000\000\000\000\000\343\000\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.2,unique,64
anon.831c2442e46e5e41962cfb504544efb1.2:
	.ascii	"Base must be in [2, p-1]"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.3,unique,65
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.3:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.0
	.asciz	"\035\000\000\000\000\000\000\000\202\000\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.4,unique,66
anon.831c2442e46e5e41962cfb504544efb1.4:
	.asciz	"slot_b\\src\\rope.rs"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.5,unique,67
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.5:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000+\004\000\000.\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.6,unique,68
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.6:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\265\000\000\000\032\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.7,unique,69
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.7:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\0007\004\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.8,unique,70
anon.831c2442e46e5e41962cfb504544efb1.8:
	.ascii	"internal error: entered unreachable code"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.9,unique,71
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.9:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000-\004\000\000\022\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.10,unique,72
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.10:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000`\004\000\000$\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.11,unique,73
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.11:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000`\004\000\000H\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.12,unique,74
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.12:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000c\004\000\0004\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.13,unique,75
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.13:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000C\004\000\000\035\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.14,unique,76
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.14:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000c\004\000\000\037\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.15,unique,77
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.15:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000b\004\000\0004\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.16,unique,78
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.16:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000b\004\000\000\037\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.17,unique,79
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.17:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\356\003\000\0000\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.18,unique,80
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.18:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\356\003\000\000\033\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.19,unique,81
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.19:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\355\003\000\0000\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.20,unique,82
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.20:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\355\003\000\000\033\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.21,unique,83
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.21:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\f\004\000\000'\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.22,unique,84
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.22:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\020\004\000\000(\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.23,unique,85
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.23:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\276\003\000\000\037\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.24,unique,86
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.24:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\243\004\000\000\037\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.25,unique,87
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.25:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\343\004\000\000@\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.26,unique,88
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.26:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\344\004\000\000A\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.27,unique,89
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.27:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\334\004\000\000\031\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.28,unique,90
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.28:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\007\005\000\000!\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.29,unique,91
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.29:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\b\005\000\000\"\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.30,unique,92
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.30:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\r\005\000\0004\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.31,unique,93
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.31:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\r\005\000\000\037\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.32,unique,94
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.32:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\f\005\000\0004\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.33,unique,95
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.33:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\f\005\000\000\037\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.34,unique,96
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.34:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\261\004\000\000\037\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.35,unique,97
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.35:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\300\004\000\000\025\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.36,unique,98
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.36:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\207\004\000\000T\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.37,unique,99
anon.831c2442e46e5e41962cfb504544efb1.37:
	.ascii	"Arena hash parameters changed; create a new arena to use a different profile"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.38,unique,100
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.38:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\216\000\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.39,unique,101
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.39:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\0008\003\000\000\023\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.40,unique,102
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.40:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\254\000\000\000\032\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.41,unique,103
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.41:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\322\002\000\000\032\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.42,unique,104
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.42:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\326\002\000\000\"\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.43,unique,105
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.43:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\355\002\000\000\"\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.44,unique,106
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.44:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\276\000\000\000\032\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.45,unique,107
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.45:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\267\001\000\000\032\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.46,unique,108
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.46:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000u\002\000\000\032\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.47,unique,109
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.47:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000{\002\000\000&\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.48,unique,110
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.48:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000z\002\000\000%\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.49,unique,111
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.49:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\230\002\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.50,unique,112
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.50:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000E\003\000\000\032\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.51,unique,113
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.51:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000a\003\000\000\032\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.52,unique,114
anon.831c2442e46e5e41962cfb504544efb1.52:
	.ascii	"Leaf len mismatch"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.53,unique,115
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.53:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000c\003\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.54,unique,116
anon.831c2442e46e5e41962cfb504544efb1.54:
	.ascii	"Internal len mismatch"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.55,unique,117
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.55:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000f\003\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.56,unique,118
anon.831c2442e46e5e41962cfb504544efb1.56:
	.ascii	"Internal weight mismatch"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.57,unique,119
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.57:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000g\003\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.58,unique,120
anon.831c2442e46e5e41962cfb504544efb1.58:
	.asciz	"\026Left child too light: \300\001/\300"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.59,unique,121
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.59:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000k\003\000\000\025\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.60,unique,122
anon.831c2442e46e5e41962cfb504544efb1.60:
	.asciz	"\026Left child too heavy: \300\001/\300"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.61,unique,123
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.61:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000o\003\000\000\025\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.62,unique,124
anon.831c2442e46e5e41962cfb504544efb1.62:
	.ascii	"RepeatNode len mismatch"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.63,unique,125
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.63:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000x\003\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.64,unique,126
anon.831c2442e46e5e41962cfb504544efb1.64:
	.ascii	"RepeatNode weight mismatch"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.65,unique,127
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.65:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000y\003\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.66,unique,128
anon.831c2442e46e5e41962cfb504544efb1.66:
	.asciz	"\"RepeatNode reps must be >= 2, got \300"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.67,unique,129
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.67:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000z\003\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.68,unique,130
anon.831c2442e46e5e41962cfb504544efb1.68:
	.ascii	"Left comparison range out of bounds"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.69,unique,131
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.69:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\237\001\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.70,unique,132
anon.831c2442e46e5e41962cfb504544efb1.70:
	.ascii	"Right comparison range out of bounds"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.71,unique,133
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.71:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\240\001\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.72,unique,134
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.72:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\245\001\000\000\"\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.73,unique,135
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.73:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\246\001\000\000\"\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.74,unique,136
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.74:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\313\000\000\000\036\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.75,unique,137
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.75:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000E\002\000\000<\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.76,unique,138
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.76:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000F\002\000\000C\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.77,unique,139
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.77:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\0005\002\000\000<\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.78,unique,140
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.78:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\0006\002\000\000C\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.79,unique,141
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.79:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\326\001\000\000\031\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.80,unique,142
anon.831c2442e46e5e41962cfb504544efb1.80:
	.ascii	"internal error: entered unreachable code: Cannot decompose Leaf in balance"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.81,unique,143
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.81:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\336\001\000\000'\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.82,unique,144
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.82:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\332\001\000\000:\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.83,unique,145
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.83:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\333\001\000\000B\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.84,unique,146
anon.831c2442e46e5e41962cfb504544efb1.84:
	.ascii	"Leaf cannot be empty"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.85,unique,147
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.85:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.4
	.asciz	"\022\000\000\000\000\000\000\000\032\001\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.86,unique,148
anon.831c2442e46e5e41962cfb504544efb1.86:
	.asciz	"\025Invalid copy: offset \300\030 exceeds decoded length \300"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.87,unique,149
anon.831c2442e46e5e41962cfb504544efb1.87:
	.asciz	"slot_b\\src\\sliding.rs"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.88,unique,150
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.88:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.87
	.asciz	"\025\000\000\000\000\000\000\000g\000\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.89,unique,151
anon.831c2442e46e5e41962cfb504544efb1.89:
	.asciz	"\fCopy offset \300\025 exceeds window size \300\034. Increase d_max (currently \300\016) to at least \300\001."

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.90,unique,152
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.90:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.87
	.asciz	"\025\000\000\000\000\000\000\000l\000\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.91,unique,153
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.91:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.87
	.asciz	"\025\000\000\000\000\000\000\000~\000\000\000\025\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.92,unique,154
anon.831c2442e46e5e41962cfb504544efb1.92:
	.asciz	"\030d_max must be >= 1, got \300"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.93,unique,155
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.93:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.87
	.asciz	"\025\000\000\000\000\000\000\000\035\000\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.94,unique,156
anon.831c2442e46e5e41962cfb504544efb1.94:
	.asciz	"\030m_max must be >= 1, got \300"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.95,unique,157
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.95:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.87
	.asciz	"\025\000\000\000\000\000\000\000\036\000\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.96,unique,158
anon.831c2442e46e5e41962cfb504544efb1.96:
	.asciz	"/rustc/4a4ef493e3a1488c6e321570238084b38948f6db/library\\alloc\\src\\collections\\btree\\node.rs"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.97,unique,159
anon.831c2442e46e5e41962cfb504544efb1.97:
	.ascii	"assertion failed: edge.height == self.height - 1"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.98,unique,160
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.98:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.96
	.asciz	"[\000\000\000\000\000\000\000\266\002\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.99,unique,161
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.99:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.96
	.asciz	"[\000\000\000\000\000\000\000\360\000\000\000M\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.100,unique,162
anon.831c2442e46e5e41962cfb504544efb1.100:
	.ascii	"assertion failed: src.len() == dst.len()"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.101,unique,163
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.101:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.96
	.asciz	"[\000\000\000\000\000\000\000T\007\000\000\005\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.102,unique,164
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.102:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.96
	.asciz	"[\000\000\000\000\000\000\000\320\004\000\000#\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.103,unique,165
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.103:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.96
	.asciz	"[\000\000\000\000\000\000\000\023\005\000\000$\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.104,unique,166
anon.831c2442e46e5e41962cfb504544efb1.104:
	.asciz	"/rustc/4a4ef493e3a1488c6e321570238084b38948f6db/library\\alloc\\src\\collections\\btree\\navigate.rs"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.105,unique,167
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.105:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.104
	.asciz	"_\000\000\000\000\000\000\000X\002\000\0000\000\000"

	.section	.rdata,"dr",one_only,anon.831c2442e46e5e41962cfb504544efb1.106,unique,168
	.p2align	3, 0x0
anon.831c2442e46e5e41962cfb504544efb1.106:
	.quad	anon.831c2442e46e5e41962cfb504544efb1.104
	.asciz	"_\000\000\000\000\000\000\000\306\000\000\000'\000\000"

