	.def	@feat.00;
	.scl	3;
	.type	0;
	.endef
	.globl	@feat.00
@feat.00 = 0
	.file	"hashrope_diagnostic_slot_a.77e1872059598300-cgu.0"
	.def	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash11hash_concat17h4209b8aa1dd0f33cE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash11hash_concat17h4209b8aa1dd0f33cE,unique,0
	.globl	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash11hash_concat17h4209b8aa1dd0f33cE
	.p2align	4
_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash11hash_concat17h4209b8aa1dd0f33cE:
.seh_proc _ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash11hash_concat17h4209b8aa1dd0f33cE
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%r9, %rsi
	movq	%rdx, %rdi
	movq	%rcx, %rbx
	movq	%r8, %rdx
	callq	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE
	mulq	%rdi
	addq	%rsi, %rax
	adcq	$0, %rdx
	movq	2048(%rbx), %r8
	movl	$127, %r9d
	bsrq	%r8, %r9
	xorl	$63, %r9d
	movb	$64, %cl
	subb	%r9b, %cl
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	xorl	%r10d, %r10d
	testb	$64, %cl
	cmovneq	%rdx, %r9
	cmovneq	%r10, %rdx
	andq	%r8, %rax
	addq	%r9, %rax
	adcq	$0, %rdx
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	testb	$64, %cl
	cmovneq	%rdx, %r9
	andq	%r8, %rax
	addq	%r9, %rax
	cmpq	%rax, %r8
	cmovaq	%r10, %r8
	subq	%r8, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash11hash_repeat17ha23790c30e7dad82E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash11hash_repeat17ha23790c30e7dad82E,unique,1
	.globl	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash11hash_repeat17ha23790c30e7dad82E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash11hash_repeat17ha23790c30e7dad82E:
.seh_proc _ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash11hash_repeat17ha23790c30e7dad82E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%r9, %rdi
	movq	%rdx, %rbx
	movq	%rcx, %rsi
	movq	%r8, %rdx
	callq	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE
	movq	2048(%rsi), %rsi
	movq	%rdi, %rcx
	movq	%rax, %rdx
	movq	%rsi, %r8
	callq	_ZN26hashrope_diagnostic_slot_a15polynomial_hash3phi17h9e9794fc8b05b4a7E
	mulq	%rbx
	movl	$127, %r8d
	bsrq	%rsi, %r8
	xorl	$63, %r8d
	movb	$64, %cl
	subb	%r8b, %cl
	movq	%rdx, %r8
	shrq	%cl, %r8
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	xorl	%edx, %edx
	testb	$64, %cl
	cmovneq	%r8, %r9
	cmovneq	%rdx, %r8
	andq	%rsi, %rax
	addq	%r9, %rax
	adcq	$0, %r8
	movq	%rax, %r9
	shrdq	%cl, %r8, %r9
	shrq	%cl, %r8
	testb	$64, %cl
	cmoveq	%r9, %r8
	andq	%rsi, %rax
	addq	%r8, %rax
	cmpq	%rax, %rsi
	cmovaq	%rdx, %rsi
	subq	%rsi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash12default_hash17h21522c25ed6f06f1E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash12default_hash17h21522c25ed6f06f1E,unique,2
	.globl	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash12default_hash17h21522c25ed6f06f1E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash12default_hash17h21522c25ed6f06f1E:
.seh_proc _ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash12default_hash17h21522c25ed6f06f1E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$2088, %rsp
	.seh_stackalloc 2088
	.seh_endprologue
	movq	%rcx, %rsi
	movabsq	$2305843009213693951, %rdi
	leaq	48(%rsp), %rcx
	movl	$2040, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	$1, 40(%rsp)
	movl	$1, %eax
	movl	$131, %r8d
	movabsq	$-2305843009213693951, %r9
	movl	$1, %r10d
	.p2align	4
.LBB2_1:
	mulq	%r8
	movq	%rax, %rcx
	shrq	$61, %rax
	leaq	(%rax,%rdx,8), %rax
	andq	%rdi, %rcx
	addq	%rax, %rcx
	movq	%rcx, %rax
	shrq	$61, %rax
	andq	%rdi, %rcx
	addq	%rax, %rcx
	leaq	(%rcx,%r9), %rax
	cmpq	%rdi, %rcx
	cmovbq	%rcx, %rax
	movq	%rax, 40(%rsp,%r10,8)
	incq	%r10
	cmpq	$256, %r10
	jne	.LBB2_1
	movq	%rdi, 2048(%rsi)
	movq	$131, 2056(%rsi)
	leaq	40(%rsp), %rdx
	movl	$2048, %r8d
	movq	%rsi, %rcx
	callq	memcpy
	movq	$0, 2064(%rsi)
	movq	$0, 2080(%rsi)
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$2088, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash12hash_overlap17h448d9ac07ad88905E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash12hash_overlap17h448d9ac07ad88905E,unique,3
	.globl	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash12hash_overlap17h448d9ac07ad88905E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash12hash_overlap17h448d9ac07ad88905E:
.seh_proc _ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash12hash_overlap17h448d9ac07ad88905E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%r8, %r8
	je	.LBB3_5
	movq	%rdx, %rbx
	movq	%rcx, %rsi
	movq	128(%rsp), %r12
	movq	%r9, %rax
	orq	%r8, %rax
	shrq	$32, %rax
	je	.LBB3_2
	movq	%r9, %rax
	xorl	%edx, %edx
	divq	%r8
	movq	%rdx, %rdi
	movq	%rax, %r14
	jmp	.LBB3_4
.LBB3_2:
	movl	%r9d, %eax
	xorl	%edx, %edx
	divl	%r8d
	movl	%edx, %edi
	movl	%eax, %r14d
.LBB3_4:
	movq	%rsi, %rcx
	movq	%r8, %rdx
	callq	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE
	movq	%rax, %r15
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	callq	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE
	movq	%rax, %rdi
	movq	2048(%rsi), %rsi
	movq	%r14, %rcx
	movq	%r15, %rdx
	movq	%rsi, %r8
	callq	_ZN26hashrope_diagnostic_slot_a15polynomial_hash3phi17h9e9794fc8b05b4a7E
	mulq	%rbx
	movl	$127, %r8d
	bsrq	%rsi, %r8
	xorl	$63, %r8d
	movb	$64, %cl
	subb	%r8b, %cl
	movq	%rdx, %r9
	shrq	%cl, %r9
	movq	%rax, %r10
	shrdq	%cl, %rdx, %r10
	xorl	%r8d, %r8d
	testb	$64, %cl
	cmovneq	%r9, %r10
	cmovneq	%r8, %r9
	andq	%rsi, %rax
	addq	%r10, %rax
	adcq	$0, %r9
	movq	%rax, %rdx
	shrdq	%cl, %r9, %rdx
	shrq	%cl, %r9
	testb	$64, %cl
	cmoveq	%rdx, %r9
	andq	%rsi, %rax
	addq	%r9, %rax
	cmpq	%rax, %rsi
	movq	%rsi, %rdx
	cmovaq	%r8, %rdx
	subq	%rdx, %rax
	mulq	%rdi
	addq	%r12, %rax
	adcq	$0, %rdx
	movq	%rdx, %r9
	shrq	%cl, %r9
	testb	$64, %cl
	movq	%r9, %r10
	cmovneq	%r8, %r10
	movq	%rax, %r11
	shrdq	%cl, %rdx, %r11
	testb	$64, %cl
	cmovneq	%r9, %r11
	andq	%rsi, %rax
	addq	%r11, %rax
	adcq	$0, %r10
	movq	%rax, %rdx
	shrdq	%cl, %r10, %rdx
	shrq	%cl, %r10
	testb	$64, %cl
	cmoveq	%rdx, %r10
	andq	%rsi, %rax
	addq	%r10, %rax
	cmpq	%rax, %rsi
	cmovaq	%r8, %rsi
	subq	%rsi, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB3_5:
	leaq	anon.3126157283a31055444fc45c79212b1f.1(%rip), %rcx
	callq	_ZN4core9panicking11panic_const23panic_const_div_by_zero17hdceffd214664eedfE
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash3new17h5719cdf6a6a667e5E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash3new17h5719cdf6a6a667e5E,unique,4
	.globl	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash3new17h5719cdf6a6a667e5E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash3new17h5719cdf6a6a667e5E:
.seh_proc _ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash3new17h5719cdf6a6a667e5E
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$2088, %rsp
	.seh_stackalloc 2088
	.seh_endprologue
	cmpq	$2, %r8
	jb	.LBB4_5
	movq	%r8, %rdi
	movq	%rdx, %rbx
	cmpq	%rdx, %r8
	jae	.LBB4_5
	movq	%rcx, %rsi
	leaq	48(%rsp), %rcx
	xorl	%r14d, %r14d
	movl	$2040, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	$1, 40(%rsp)
	bsrq	%rbx, %rcx
	incl	%ecx
	movl	$1, %eax
	movl	$1, %r8d
	.p2align	4
.LBB4_3:
	mulq	%rdi
	movq	%rdx, %r9
	shrq	%cl, %r9
	movq	%rax, %r10
	shrdq	%cl, %rdx, %r10
	testb	$64, %cl
	cmovneq	%r9, %r10
	cmovneq	%r14, %r9
	andq	%rbx, %rax
	addq	%r10, %rax
	adcq	$0, %r9
	movq	%rax, %rdx
	shrdq	%cl, %r9, %rdx
	shrq	%cl, %r9
	testb	$64, %cl
	cmoveq	%rdx, %r9
	andq	%rbx, %rax
	addq	%r9, %rax
	cmpq	%rax, %rbx
	movq	%rbx, %rdx
	cmovaq	%r14, %rdx
	subq	%rdx, %rax
	movq	%rax, 40(%rsp,%r8,8)
	incq	%r8
	cmpq	$256, %r8
	jne	.LBB4_3
	movq	%rbx, 2048(%rsi)
	movq	%rdi, 2056(%rsi)
	leaq	40(%rsp), %rdx
	movl	$2048, %r8d
	movq	%rsi, %rcx
	callq	memcpy
	movq	$0, 2064(%rsi)
	movq	$0, 2080(%rsi)
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$2088, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.LBB4_5:
	leaq	anon.3126157283a31055444fc45c79212b1f.2(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.3(%rip), %r8
	movl	$49, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE,unique,5
	.p2align	4
_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE:
.Lfunc_begin0:
.seh_proc _ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$152, %rsp
	.seh_stackalloc 152
	leaq	128(%rsp), %rbp
	.seh_setframe %rbp, 128
	.seh_endprologue
	movq	$-2, 16(%rbp)
	cmpq	$256, %rdx
	jae	.LBB5_2
	movq	(%rcx,%rdx,8), %rsi
	jmp	.LBB5_29
.LBB5_2:
	movq	2064(%rcx), %r12
	movq	2072(%rcx), %r14
	testq	%r12, %r12
	je	.LBB5_12
	movq	%r14, %r8
	movq	%r12, %rax
.LBB5_4:
	movzwl	186(%rax), %r10d
	movl	%r10d, %r11d
	shll	$3, %r11d
	movq	$-1, %r9
	.p2align	4
.LBB5_5:
	testq	%r11, %r11
	je	.LBB5_8
	cmpq	16(%rax,%r9,8), %rdx
	seta	%bl
	sbbb	$0, %bl
	incq	%r9
	addq	$-8, %r11
	cmpb	$1, %bl
	je	.LBB5_5
	movzbl	%bl, %r10d
	testl	%r10d, %r10d
	jne	.LBB5_9
	jmp	.LBB5_11
	.p2align	4
.LBB5_8:
	movq	%r10, %r9
.LBB5_9:
	subq	$1, %r8
	jb	.LBB5_12
	movq	192(%rax,%r9,8), %rax
	jmp	.LBB5_4
.LBB5_11:
	movq	96(%rax,%r9,8), %rsi
	jmp	.LBB5_29
.LBB5_12:
	movq	2048(%rcx), %r9
	movq	%rcx, -16(%rbp)
	movq	2056(%rcx), %r8
	movl	$127, %ecx
	bsrq	%r9, %rcx
	xorl	$-64, %ecx
	addl	$65, %ecx
	movl	$1, %esi
	xorl	%r10d, %r10d
	movq	%rdx, %rbx
	movq	%rdx, %r11
	jmp	.LBB5_14
	.p2align	4
.LBB5_13:
	xorl	%edi, %edi
	imulq	%r8, %rdi
	movq	%r8, %rax
	mulq	%r8
	addq	%rdi, %rdx
	addq	%rdi, %rdx
	movq	%rax, %r8
	shrdq	%cl, %rdx, %rax
	shrq	%cl, %rdx
	testb	$64, %cl
	cmovneq	%rdx, %rax
	cmovneq	%r10, %rdx
	andq	%r9, %r8
	addq	%rax, %r8
	adcq	$0, %rdx
	movq	%r8, %rax
	shrdq	%cl, %rdx, %rax
	shrq	%cl, %rdx
	testb	$64, %cl
	cmoveq	%rax, %rdx
	andq	%r9, %r8
	addq	%rdx, %r8
	cmpq	%r8, %r9
	movq	%r9, %rax
	cmovaq	%r10, %rax
	subq	%rax, %r8
	movq	%r11, %rax
	shrq	%rax
	cmpq	$2, %r11
	movq	%rax, %r11
	jb	.LBB5_16
.LBB5_14:
	testb	$1, %r11b
	je	.LBB5_13
	movq	%rsi, %rax
	mulq	%r8
	movq	%rdx, %rdi
	shrq	%cl, %rdi
	movq	%rax, %rsi
	shrdq	%cl, %rdx, %rax
	testb	$64, %cl
	cmovneq	%rdi, %rax
	cmovneq	%r10, %rdi
	andq	%r9, %rsi
	addq	%rax, %rsi
	adcq	$0, %rdi
	movq	%rsi, %rax
	shrdq	%cl, %rdi, %rax
	shrq	%cl, %rdi
	testb	$64, %cl
	cmoveq	%rax, %rdi
	andq	%r9, %rsi
	addq	%rdi, %rsi
	cmpq	%rsi, %r9
	movq	%r9, %rax
	cmovaq	%r10, %rax
	subq	%rax, %rsi
	jmp	.LBB5_13
.LBB5_16:
	testq	%r12, %r12
	je	.LBB5_26
	movq	%r14, -88(%rbp)
	movq	%r14, %rcx
	movq	%r12, %r13
	movq	%rbx, %rax
.LBB5_18:
	leaq	8(%r13), %r15
	movzwl	186(%r13), %edi
	leal	(,%rdi,8), %edx
	movq	$-1, %r14
	.p2align	4
.LBB5_19:
	testq	%rdx, %rdx
	je	.LBB5_22
	cmpq	16(%r13,%r14,8), %rax
	seta	%r8b
	sbbb	$0, %r8b
	incq	%r14
	addq	$-8, %rdx
	cmpb	$1, %r8b
	je	.LBB5_19
	movzbl	%r8b, %edx
	testl	%edx, %edx
	jne	.LBB5_23
	jmp	.LBB5_25
.LBB5_22:
	movq	%rdi, %r14
.LBB5_23:
	subq	$1, %rcx
	jb	.LBB5_30
	movq	192(%r13,%r14,8), %r13
	jmp	.LBB5_18
.LBB5_25:
	movq	%rsi, 96(%r13,%r14,8)
	jmp	.LBB5_29
.LBB5_26:
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$192, %ecx
	movl	$8, %edx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB5_88
	movq	$0, (%rax)
	movq	-16(%rbp), %rcx
	movq	%rax, 2064(%rcx)
	movq	$0, 2072(%rcx)
	movw	$1, 186(%rax)
	movq	%rbx, 8(%rax)
	movq	%rsi, 96(%rax)
.LBB5_28:
	incq	2080(%rcx)
.LBB5_29:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$152, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.LBB5_30:
	cmpw	$11, %di
	jae	.LBB5_34
	cmpq	%r14, %rdi
	jbe	.LBB5_33
	leaq	(%r15,%r14,8), %rdx
	leaq	(%r15,%r14,8), %rcx
	addq	$8, %rcx
	movl	%edi, %r15d
	subl	%r14d, %r15d
	shll	$3, %r15d
	movq	%r15, %r8
	callq	memmove
	leaq	96(,%r14,8), %rdx
	addq	%r13, %rdx
	leaq	104(,%r14,8), %rcx
	addq	%r13, %rcx
	movq	%r15, %r8
	callq	memmove
	movq	%rbx, %rax
.LBB5_33:
	movq	%rax, 8(%r13,%r14,8)
	incl	%edi
	movq	%rsi, 96(%r13,%r14,8)
	movw	%di, 186(%r13)
	movq	-16(%rbp), %rcx
	jmp	.LBB5_28
.LBB5_34:
	cmpq	$5, %r14
	jae	.LBB5_36
	movl	$4, %edi
	movl	$0, (%rbp)
	jmp	.LBB5_41
.LBB5_36:
	je	.LBB5_39
	cmpq	$6, %r14
	jne	.LBB5_40
	movl	$5, %edi
	movb	$1, %al
	movl	%eax, (%rbp)
	xorl	%r14d, %r14d
	jmp	.LBB5_41
.LBB5_39:
	movl	$0, (%rbp)
	movq	%r14, %rdi
	jmp	.LBB5_41
.LBB5_40:
	addq	$-7, %r14
	movl	$6, %edi
	movb	$1, %al
	movl	%eax, (%rbp)
.LBB5_41:
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$192, %ecx
	movl	$8, %edx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB5_88
	movq	%rax, %rcx
	movq	$0, (%rax)
	movzwl	186(%r13), %eax
	movq	%rdi, %rdx
	notq	%rdi
	addq	%rax, %rdi
	movw	%di, 186(%rcx)
	cmpq	$12, %rdi
	movq	%rcx, -24(%rbp)
	jae	.LBB5_93
	movq	8(%r13,%rdx,8), %rax
	movq	%rax, -72(%rbp)
	movq	96(%r13,%rdx,8), %rax
	movq	%rax, -64(%rbp)
	movq	%rdx, 8(%rbp)
	leaq	(%r15,%rdx,8), %rdx
	addq	$8, %rdx
	movq	%rcx, %r15
	addq	$8, %rcx
	shlq	$3, %rdi
	movq	%rdi, %r8
	callq	memcpy
	movq	8(%rbp), %rax
	leaq	104(,%rax,8), %rdx
	addq	%r13, %rdx
	leaq	96(%r15), %rcx
	movq	%rdi, %r8
	callq	memcpy
	cmpb	$0, (%rbp)
	cmoveq	%r13, %r15
	movq	8(%rbp), %rax
	movw	%ax, 186(%r13)
	movzwl	186(%r15), %eax
	movzwl	%ax, %edi
	cmpq	%r14, %rdi
	jbe	.LBB5_45
	movl	%eax, 8(%rbp)
	leaq	8(%r15), %rax
	leaq	(%rax,%r14,8), %rdx
	leaq	(%rax,%r14,8), %rcx
	addq	$8, %rcx
	subl	%r14d, %edi
	shll	$3, %edi
	movq	%rdi, %r8
	callq	memmove
	leaq	(%r15,%r14,8), %rdx
	addq	$96, %rdx
	leaq	(%r15,%r14,8), %rcx
	addq	$104, %rcx
	movq	%rdi, %r8
	callq	memmove
	movl	8(%rbp), %eax
.LBB5_45:
	movq	%rbx, 8(%r15,%r14,8)
	incl	%eax
	movq	%rsi, 96(%r15,%r14,8)
	movw	%ax, 186(%r15)
	movq	(%r13), %rax
	testq	%rax, %rax
	je	.LBB5_73
	movq	$0, -32(%rbp)
	movq	-24(%rbp), %rdi
	jmp	.LBB5_48
.LBB5_47:
	movq	(%r13), %rax
	testq	%rax, %rax
	movq	-24(%rbp), %rdi
	je	.LBB5_74
.LBB5_48:
	movq	-64(%rbp), %rdx
	movq	-72(%rbp), %r9
	movq	%rdi, %r15
	movzwl	184(%r13), %ecx
	movq	%rax, %r13
	movzwl	%cx, %r14d
	movzwl	186(%rax), %edi
	cmpq	$11, %rdi
	movq	%r15, -80(%rbp)
	movq	%rdx, -48(%rbp)
	movq	%r9, -40(%rbp)
	movq	%rdi, -56(%rbp)
	jb	.LBB5_78
	cmpw	$5, %cx
	jae	.LBB5_51
	movq	%r14, 8(%rbp)
	movl	$4, %eax
	movq	%rax, (%rbp)
	movl	$0, -4(%rbp)
	jmp	.LBB5_56
.LBB5_51:
	je	.LBB5_54
	cmpl	$6, %r14d
	jne	.LBB5_55
	movb	$1, %al
	movl	%eax, -4(%rbp)
	movl	$5, %eax
	movq	%rax, (%rbp)
	movq	$0, 8(%rbp)
	jmp	.LBB5_56
.LBB5_54:
	movl	$0, -4(%rbp)
	movq	%r14, 8(%rbp)
	movq	%r14, (%rbp)
	jmp	.LBB5_56
.LBB5_55:
	addq	$-7, %r14
	movq	%r14, 8(%rbp)
	movb	$1, %al
	movl	%eax, -4(%rbp)
	movl	$6, %eax
	movq	%rax, (%rbp)
.LBB5_56:
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$288, %ecx
	movl	$8, %edx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB5_91
	movq	%rax, %rdi
	movq	$0, (%rdi)
	movzwl	186(%r13), %eax
	movq	(%rbp), %rcx
	movq	%rcx, %rbx
	notq	%rbx
	addq	%rax, %rbx
	movw	%bx, 186(%rdi)
	cmpq	$12, %rbx
	movq	%rdi, -24(%rbp)
	jae	.LBB5_89
	movq	%rdi, %r14
	leal	(,%rcx,8), %r15d
	movq	8(%r13,%r15), %rax
	movq	%rax, -72(%rbp)
	movq	96(%r13,%r15), %rax
	movq	%rax, -64(%rbp)
	leaq	(%r15,%r13), %rdx
	addq	$16, %rdx
	leaq	8(%rdi), %rcx
	shlq	$3, %rbx
	movq	%rbx, %r8
	callq	memcpy
	leaq	(%r15,%r13), %rdx
	addq	$104, %rdx
	leaq	96(%rdi), %rcx
	movq	%rbx, %r8
	callq	memcpy
	movq	(%rbp), %rdx
	movw	%dx, 186(%r13)
	movzwl	186(%rdi), %ebx
	leaq	1(%rbx), %r8
	cmpq	$12, %rbx
	jae	.LBB5_90
	movzwl	-56(%rbp), %eax
	subl	%edx, %eax
	cmpl	%r8d, %eax
	jne	.LBB5_92
	incq	-32(%rbp)
	leaq	192(%rdi), %rcx
	leaq	200(,%rdx,8), %rdx
	addq	%r13, %rdx
	shll	$3, %r8d
	callq	memcpy
	xorl	%eax, %eax
	.p2align	4
.LBB5_61:
	movq	%rax, %rcx
	cmpq	%rbx, %rax
	adcq	$0, %rax
	movq	192(%r14,%rcx,8), %rdx
	movq	%r14, (%rdx)
	movw	%cx, 184(%rdx)
	cmpq	%rbx, %rcx
	jae	.LBB5_63
	cmpq	%rbx, %rax
	jbe	.LBB5_61
.LBB5_63:
	cmpb	$0, -4(%rbp)
	cmoveq	%r13, %rdi
	movzwl	186(%rdi), %r14d
	movq	8(%rbp), %r8
	leaq	1(%r8), %r15
	movq	%r14, %r10
	subq	%r8, %r10
	jbe	.LBB5_65
	leaq	8(%rdi), %rax
	leaq	(%rdi,%r8,8), %rdx
	addq	$8, %rdx
	leaq	(%rax,%r15,8), %rcx
	movl	%r14d, %ebx
	subl	%r8d, %ebx
	shll	$3, %ebx
	movq	%rbx, %r8
	movq	%r10, (%rbp)
	callq	memmove
	movq	8(%rbp), %rax
	leaq	(%rdi,%rax,8), %rdx
	addq	$96, %rdx
	leaq	(%rdi,%r15,8), %rcx
	addq	$96, %rcx
	movq	%rbx, %r8
	callq	memmove
	movq	8(%rbp), %rax
	movq	-40(%rbp), %rcx
	movq	%rcx, 8(%rdi,%rax,8)
	movq	8(%rbp), %rax
	movq	-48(%rbp), %rcx
	movq	%rcx, 96(%rdi,%rax,8)
	leaq	192(%rdi,%r15,8), %rdx
	movq	8(%rbp), %rax
	leaq	(%rdi,%rax,8), %rcx
	addq	$208, %rcx
	movq	%rbx, %r8
	callq	memmove
	movq	(%rbp), %r10
	movq	8(%rbp), %r8
	jmp	.LBB5_66
.LBB5_65:
	movq	-40(%rbp), %rax
	movq	%rax, 8(%rdi,%r8,8)
	movq	-48(%rbp), %rax
	movq	%rax, 96(%rdi,%r8,8)
.LBB5_66:
	leal	1(%r14), %ecx
	leaq	2(%r14), %rax
	movq	-80(%rbp), %rdx
	movq	%rdx, 200(%rdi,%r8,8)
	movw	%cx, 186(%rdi)
	cmpq	%rax, %r15
	jae	.LBB5_47
	subl	%r8d, %r14d
	incl	%r14d
	andl	$3, %r14d
	je	.LBB5_71
	leaq	(%rdi,%r8,8), %rdx
	addq	$200, %rdx
	xorl	%ecx, %ecx
	.p2align	4
.LBB5_69:
	movq	(%rdx,%rcx,8), %r8
	movq	%rdi, (%r8)
	leal	(%r15,%rcx), %r9d
	movw	%r9w, 184(%r8)
	incq	%rcx
	cmpq	%rcx, %r14
	jne	.LBB5_69
	addq	%rcx, %r15
.LBB5_71:
	cmpq	$3, %r10
	jb	.LBB5_47
	.p2align	4
.LBB5_72:
	movq	192(%rdi,%r15,8), %rcx
	movq	%rdi, (%rcx)
	movw	%r15w, 184(%rcx)
	movq	200(%rdi,%r15,8), %rcx
	movq	%rdi, (%rcx)
	leal	1(%r15), %edx
	movw	%dx, 184(%rcx)
	movq	208(%rdi,%r15,8), %rcx
	movq	%rdi, (%rcx)
	leal	2(%r15), %edx
	movw	%dx, 184(%rcx)
	movq	216(%rdi,%r15,8), %rcx
	movq	%rdi, (%rcx)
	leal	3(%r15), %edx
	movw	%dx, 184(%rcx)
	addq	$4, %r15
	cmpq	%rax, %r15
	jne	.LBB5_72
	jmp	.LBB5_47
.LBB5_73:
	movq	$0, -32(%rbp)
	movq	-24(%rbp), %rdi
.LBB5_74:
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$288, %ecx
	movl	$8, %edx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB5_94
	movq	%rax, %r8
	movq	$0, (%rax)
	movw	$0, 186(%rax)
	movq	%r12, 192(%rax)
	movq	-88(%rbp), %rdx
	movq	%rdx, %rax
	incq	%rax
	movq	-16(%rbp), %rcx
	je	.LBB5_95
	movq	%r8, (%r12)
	movw	$0, 184(%r12)
	movq	%r8, 2064(%rcx)
	movq	%rax, 2072(%rcx)
	cmpq	%rdx, -32(%rbp)
	jne	.LBB5_97
	movw	$1, 186(%r8)
	movq	-72(%rbp), %rax
	movq	%rax, 8(%r8)
	movq	-64(%rbp), %rax
	movq	%rax, 96(%r8)
	movq	%rdi, 200(%r8)
	movq	%r8, (%rdi)
	movw	$1, 184(%rdi)
	jmp	.LBB5_28
.LBB5_78:
	leal	1(%rdi), %r10d
	leaq	1(%r14), %rbx
	cmpw	%di, %cx
	jae	.LBB5_80
	leaq	8(%r13), %rcx
	leaq	8(,%r14,8), %rdx
	addq	%r13, %rdx
	leal	(,%rbx,8), %r15d
	addq	%r15, %rcx
	movq	-56(%rbp), %rdi
	subq	%r14, %rdi
	shlq	$3, %rdi
	movq	%rdi, %r8
	movl	%r10d, 8(%rbp)
	callq	memmove
	leal	(,%r14,8), %r12d
	leaq	(%r12,%r13), %rdx
	addq	$96, %rdx
	leaq	(%r15,%r13), %rcx
	addq	$96, %rcx
	movq	%rdi, %r8
	callq	memmove
	movq	-40(%rbp), %rax
	movq	%rax, 8(%r13,%r12)
	movq	-48(%rbp), %rax
	movq	%rax, 96(%r13,%r12)
	leaq	192(%r13,%r15), %rdx
	movq	-80(%rbp), %r15
	leaq	(%r12,%r13), %rcx
	addq	$208, %rcx
	movq	%rdi, %r8
	movq	-56(%rbp), %rdi
	callq	memmove
	movl	8(%rbp), %r10d
	jmp	.LBB5_81
.LBB5_80:
	movq	%r9, 8(%r13,%r14,8)
	movq	%rdx, 96(%r13,%r14,8)
.LBB5_81:
	movq	-16(%rbp), %rcx
	leaq	2(%rdi), %rax
	movq	%r15, 200(%r13,%r14,8)
	movw	%r10w, 186(%r13)
	cmpl	%eax, %ebx
	jae	.LBB5_28
	movl	%edi, %edx
	subl	%r14d, %edx
	incl	%edx
	subq	%r14, %rdi
	andl	$3, %edx
	je	.LBB5_86
	leaq	200(,%r14,8), %r9
	addq	%r13, %r9
	xorl	%r8d, %r8d
.LBB5_84:
	movq	(%r9,%r8,8), %r10
	movq	%r13, (%r10)
	leal	(%rbx,%r8), %r11d
	movw	%r11w, 184(%r10)
	incq	%r8
	cmpq	%r8, %rdx
	jne	.LBB5_84
	addq	%r8, %rbx
.LBB5_86:
	cmpq	$3, %rdi
	jb	.LBB5_28
.LBB5_87:
	movq	192(%r13,%rbx,8), %rdx
	movq	%r13, (%rdx)
	movw	%bx, 184(%rdx)
	movq	200(%r13,%rbx,8), %rdx
	movq	%r13, (%rdx)
	leal	1(%rbx), %r8d
	movw	%r8w, 184(%rdx)
	movq	208(%r13,%rbx,8), %rdx
	movq	%r13, (%rdx)
	leal	2(%rbx), %r8d
	movw	%r8w, 184(%rdx)
	movq	216(%r13,%rbx,8), %rdx
	movq	%r13, (%rdx)
	leal	3(%rbx), %r8d
	movw	%r8w, 184(%rdx)
	addq	$4, %rbx
	cmpq	%rax, %rbx
	jne	.LBB5_87
	jmp	.LBB5_28
.LBB5_88:
	movl	$8, %ecx
	movl	$192, %edx
	callq	_ZN5alloc5alloc18handle_alloc_error17h6942ce664312655aE
.LBB5_89:
.Ltmp2:
	leaq	anon.3126157283a31055444fc45c79212b1f.101(%rip), %r9
	movl	$11, %r8d
	xorl	%ecx, %ecx
	movq	%rbx, %rdx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.Ltmp3:
	jmp	.LBB5_96
.LBB5_90:
.Ltmp4:
	leaq	anon.3126157283a31055444fc45c79212b1f.102(%rip), %r9
	movq	%r8, %rdx
	movl	$12, %r8d
	xorl	%ecx, %ecx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.Ltmp5:
	jmp	.LBB5_96
.LBB5_91:
	movl	$8, %ecx
	movl	$288, %edx
	callq	_ZN5alloc5alloc18handle_alloc_error17h6942ce664312655aE
.LBB5_92:
.Ltmp6:
	leaq	anon.3126157283a31055444fc45c79212b1f.99(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.100(%rip), %r8
	movl	$40, %edx
	callq	_ZN4core9panicking5panic17hc5fbe615138639caE
.Ltmp7:
	jmp	.LBB5_96
.LBB5_93:
.Ltmp0:
	leaq	anon.3126157283a31055444fc45c79212b1f.101(%rip), %r9
	movl	$11, %r8d
	xorl	%ecx, %ecx
	movq	%rdi, %rdx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.Ltmp1:
	jmp	.LBB5_96
.LBB5_94:
.Ltmp10:
	movl	$8, %ecx
	movl	$288, %edx
	callq	_ZN5alloc5alloc18handle_alloc_error17h6942ce664312655aE
.Ltmp11:
	jmp	.LBB5_96
.LBB5_95:
.Ltmp8:
	movq	%r8, -16(%rbp)
	leaq	anon.3126157283a31055444fc45c79212b1f.98(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.Ltmp9:
.LBB5_96:
	ud2
.LBB5_97:
	leaq	anon.3126157283a31055444fc45c79212b1f.96(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.97(%rip), %r8
	movl	$48, %edx
	callq	_ZN4core9panicking5panic17hc5fbe615138639caE
	int3
	.seh_handlerdata
	.long	$cppxdata$_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE@IMGREL
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE,unique,5
	.seh_endproc
	.def	"?dtor$98@?0?_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$98@?0?_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE@4HA":
.seh_proc "?dtor$98@?0?_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE@4HA"
.LBB5_98:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	128(%rdx), %rbp
	.seh_endprologue
	movl	$288, %edx
	movl	$8, %r8d
	movq	-16(%rbp), %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE,unique,5
	.seh_endproc
	.def	"?dtor$99@?0?_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$99@?0?_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE@4HA":
.seh_proc "?dtor$99@?0?_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE@4HA"
.LBB5_99:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	128(%rdx), %rbp
	.seh_endprologue
	ud2
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE,unique,5
	.seh_endproc
	.def	"?dtor$100@?0?_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$100@?0?_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE@4HA":
.seh_proc "?dtor$100@?0?_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE@4HA"
.LBB5_100:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	128(%rdx), %rbp
	.seh_endprologue
	movl	$192, %edx
	movl	$8, %r8d
	movq	-24(%rbp), %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE,unique,5
	.seh_endproc
	.def	"?dtor$101@?0?_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$101@?0?_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE@4HA":
.seh_proc "?dtor$101@?0?_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE@4HA"
.LBB5_101:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	128(%rdx), %rbp
	.seh_endprologue
	movl	$288, %edx
	movl	$8, %r8d
	movq	-24(%rbp), %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.Lfunc_end0:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE,unique,5
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE,unique,0
	.p2align	2, 0x0
$cppxdata$_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE:
	.long	429065506
	.long	4
	.long	$stateUnwindMap$_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE@IMGREL
	.long	0
	.long	0
	.long	8
	.long	$ip2state$_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE@IMGREL
	.long	144
	.long	0
	.long	1
$stateUnwindMap$_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE:
	.long	-1
	.long	"?dtor$100@?0?_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE@4HA"@IMGREL
	.long	-1
	.long	"?dtor$99@?0?_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE@4HA"@IMGREL
	.long	1
	.long	"?dtor$98@?0?_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE@4HA"@IMGREL
	.long	-1
	.long	"?dtor$101@?0?_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE@4HA"@IMGREL
$ip2state$_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE:
	.long	.Lfunc_begin0@IMGREL
	.long	-1
	.long	.Ltmp2@IMGREL+1
	.long	3
	.long	.Ltmp5@IMGREL+1
	.long	-1
	.long	.Ltmp6@IMGREL+1
	.long	3
	.long	.Ltmp0@IMGREL+1
	.long	0
	.long	.Ltmp10@IMGREL+1
	.long	1
	.long	.Ltmp8@IMGREL+1
	.long	2
	.long	.Ltmp9@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE,unique,5

	.def	_ZN26hashrope_diagnostic_slot_a15polynomial_hash3phi17h9e9794fc8b05b4a7E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a15polynomial_hash3phi17h9e9794fc8b05b4a7E,unique,6
	.globl	_ZN26hashrope_diagnostic_slot_a15polynomial_hash3phi17h9e9794fc8b05b4a7E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a15polynomial_hash3phi17h9e9794fc8b05b4a7E:
.seh_proc _ZN26hashrope_diagnostic_slot_a15polynomial_hash3phi17h9e9794fc8b05b4a7E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	.seh_endprologue
	movq	%rcx, %r9
	cmpq	$1, %rcx
	ja	.LBB6_3
	movq	%r9, %r11
.LBB6_2:
	movq	%r11, %rax
	.seh_startepilogue
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB6_3:
	movq	%rdx, %r10
	bsrq	%r9, %r14
	movl	$127, %ecx
	bsrq	%r8, %rcx
	xorl	$-64, %ecx
	addl	$65, %ecx
	decl	%r14d
	movl	$1, %r11d
	xorl	%r15d, %r15d
	movq	%rdx, %rbx
	jmp	.LBB6_4
	.p2align	4
.LBB6_6:
	movq	%rax, %rbx
	addl	$-1, %r14d
	jae	.LBB6_2
.LBB6_4:
	movq	%rbx, %rax
	mulq	%rbx
	movq	%rdx, %rsi
	movq	%rax, %rdi
	shrdq	%cl, %rdx, %rax
	shrq	%cl, %rsi
	testb	$64, %cl
	cmovneq	%rsi, %rax
	cmovneq	%r15, %rsi
	andq	%r8, %rdi
	addq	%rax, %rdi
	adcq	$0, %rsi
	movq	%rdi, %rax
	shrdq	%cl, %rsi, %rax
	shrq	%cl, %rsi
	testb	$64, %cl
	cmoveq	%rax, %rsi
	xorl	%eax, %eax
	incq	%rbx
	sete	%al
	movq	%rax, %rdx
	shrq	%cl, %rdx
	testb	$64, %cl
	movq	%rdx, %r12
	cmovneq	%r15, %r12
	movq	%rbx, %r13
	shrdq	%cl, %rax, %r13
	testb	$64, %cl
	cmovneq	%rdx, %r13
	andq	%r8, %rbx
	addq	%r13, %rbx
	adcq	$0, %r12
	movq	%rbx, %rax
	shrdq	%cl, %r12, %rax
	shrq	%cl, %r12
	testb	$64, %cl
	cmoveq	%rax, %r12
	andq	%r8, %rbx
	addq	%r12, %rbx
	cmpq	%rbx, %r8
	movq	%r8, %rax
	cmovaq	%r15, %rax
	subq	%rax, %rbx
	movq	%rbx, %rax
	mulq	%r11
	movq	%rdx, %rbx
	shrq	%cl, %rbx
	testb	$64, %cl
	movq	%rbx, %r12
	cmovneq	%r15, %r12
	movq	%rax, %r11
	movq	%rdi, %rax
	movq	%r11, %rdi
	shrdq	%cl, %rdx, %rdi
	testb	$64, %cl
	cmovneq	%rbx, %rdi
	andq	%r8, %r11
	addq	%rdi, %r11
	adcq	$0, %r12
	movq	%r11, %rdx
	shrdq	%cl, %r12, %rdx
	shrq	%cl, %r12
	testb	$64, %cl
	cmoveq	%rdx, %r12
	andq	%r8, %r11
	addq	%r12, %r11
	cmpq	%r11, %r8
	movq	%r8, %rdx
	cmovaq	%r15, %rdx
	subq	%rdx, %r11
	andq	%r8, %rax
	addq	%rsi, %rax
	cmpq	%rax, %r8
	movq	%r8, %rdx
	cmovaq	%r15, %rdx
	subq	%rdx, %rax
	btq	%r14, %r9
	jae	.LBB6_6
	mulq	%r10
	movq	%rdx, %rsi
	movq	%rax, %rdi
	shrdq	%cl, %rdx, %rax
	shrq	%cl, %rsi
	testb	$64, %cl
	cmovneq	%rsi, %rax
	cmovneq	%r15, %rsi
	andq	%r8, %rdi
	addq	%rax, %rdi
	adcq	$0, %rsi
	movq	%rdi, %rax
	shrdq	%cl, %rsi, %rax
	shrq	%cl, %rsi
	testb	$64, %cl
	cmoveq	%rax, %rsi
	movq	%r11, %rax
	mulq	%r10
	movq	%rdx, %rbx
	shrq	%cl, %rbx
	testb	$64, %cl
	movq	%rbx, %r12
	cmovneq	%r15, %r12
	movq	%rax, %r11
	movq	%rdi, %rax
	movq	%r11, %rdi
	shrdq	%cl, %rdx, %rdi
	testb	$64, %cl
	cmovneq	%rbx, %rdi
	andq	%r8, %r11
	addq	%rdi, %r11
	adcq	$0, %r12
	movq	%r11, %rdx
	shrdq	%cl, %r12, %rdx
	shrq	%cl, %r12
	testb	$64, %cl
	cmoveq	%rdx, %r12
	andq	%r8, %r11
	addq	%r12, %r11
	cmpq	%r11, %r8
	movq	%r8, %rdx
	cmovaq	%r15, %rdx
	subq	%rdx, %r11
	xorl	%edx, %edx
	incq	%r11
	sete	%dl
	movq	%rdx, %rdi
	shrq	%cl, %rdi
	testb	$64, %cl
	movq	%rdi, %rbx
	cmovneq	%r15, %rbx
	movq	%r11, %r12
	shrdq	%cl, %rdx, %r12
	testb	$64, %cl
	cmovneq	%rdi, %r12
	andq	%r8, %r11
	addq	%r12, %r11
	adcq	$0, %rbx
	movq	%r11, %rdx
	shrdq	%cl, %rbx, %rdx
	shrq	%cl, %rbx
	testb	$64, %cl
	cmoveq	%rdx, %rbx
	andq	%r8, %r11
	addq	%rbx, %r11
	cmpq	%r11, %r8
	movq	%r8, %rdx
	cmovaq	%r15, %rdx
	subq	%rdx, %r11
	andq	%r8, %rax
	addq	%rsi, %rax
	cmpq	%rax, %r8
	movq	%r8, %rdx
	cmovaq	%r15, %rdx
	subq	%rdx, %rax
	jmp	.LBB6_6
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope13ExactFrontier6expand17h83c92e36a51ff2ebE;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope13ExactFrontier6expand17h83c92e36a51ff2ebE,unique,7
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope13ExactFrontier6expand17h83c92e36a51ff2ebE:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope13ExactFrontier6expand17h83c92e36a51ff2ebE
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movl	776(%rcx), %eax
	cmpq	%rax, %r8
	jbe	.LBB7_14
	leaq	(%rax,%rax,2), %r9
	shlq	$4, %r9
	cmpl	$1, (%rdx,%r9)
	jne	.LBB7_13
	addq	%rdx, %r9
	movl	4(%r9), %eax
	cmpq	%rax, %r8
	jbe	.LBB7_15
	movl	8(%r9), %r8d
	leaq	(%rax,%rax,2), %r9
	shlq	$4, %r9
	leaq	(%rdx,%r9), %r10
	xorl	%r11d, %r11d
	cmpl	$0, (%rdx,%r9)
	setne	%r11b
	movq	16(%r10,%r11,8), %rdx
	movq	768(%rcx), %r9
	movq	%r9, %r10
	subq	%rdx, %r10
	jae	.LBB7_8
	subq	%r9, %rdx
	movq	784(%rcx), %r10
	subq	%rdx, %r10
	jbe	.LBB7_11
	movq	792(%rcx), %r9
	cmpq	$32, %r9
	jne	.LBB7_9
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB7_8:
	movl	%r8d, 776(%rcx)
	movq	%r10, 768(%rcx)
	movb	$1, %al
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB7_9:
	jae	.LBB7_16
	leaq	(%r9,%r9,2), %r9
	movq	$0, (%rcx,%r9,8)
	movl	%r8d, 8(%rcx,%r9,8)
	movq	%r10, 16(%rcx,%r9,8)
	incq	792(%rcx)
	movq	%rdx, 784(%rcx)
.LBB7_11:
	movl	%eax, 776(%rcx)
	movb	$1, %al
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB7_13:
	leaq	anon.3126157283a31055444fc45c79212b1f.8(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.9(%rip), %r8
	movl	$40, %edx
	callq	_ZN4core9panicking5panic17hc5fbe615138639caE
.LBB7_14:
	leaq	anon.3126157283a31055444fc45c79212b1f.5(%rip), %r9
	movq	%rax, %rcx
	movq	%r8, %rdx
	movq	%r9, %r8
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB7_15:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r9
	movq	%rax, %rcx
	movq	%r8, %rdx
	movq	%r9, %r8
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB7_16:
	leaq	anon.3126157283a31055444fc45c79212b1f.7(%rip), %r8
	movl	$32, %edx
	movq	%r9, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope14FastComparison13lcp_recursive17h6af0d9319335c753E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope14FastComparison13lcp_recursive17h6af0d9319335c753E,unique,8
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope14FastComparison13lcp_recursive17h6af0d9319335c753E:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope14FastComparison13lcp_recursive17h6af0d9319335c753E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$152, %rsp
	.seh_stackalloc 152
	.seh_endprologue
	movq	%r9, 104(%rsp)
	movq	%rdx, 80(%rsp)
	movq	264(%rsp), %rdx
	testq	%rdx, %rdx
	je	.LBB8_55
	movl	256(%rsp), %esi
	xorl	%r11d, %r11d
.LBB8_2:
	movzbl	24(%rcx), %ebx
	cmpl	%esi, %r8d
	sete	%al
	movq	80(%rsp), %r9
	cmpq	104(%rsp), %r9
	sete	%r10b
	andb	%al, %r10b
	andb	%bl, %r10b
	cmpb	$1, %r10b
	je	.LBB8_56
	movq	16(%rcx), %r10
	movl	$1, %eax
	testq	%r10, %r10
	je	.LBB8_63
	movb	%bl, 67(%rsp)
	movl	%esi, 68(%rsp)
	movq	%r11, 72(%rsp)
	subq	%r11, %rdx
	movq	%rdx, 120(%rsp)
	movq	(%rcx), %rdx
	movq	8(%rdx), %rax
	movq	16(%rdx), %rdx
	movl	$1, %r15d
	subq	%r10, %r15
	movl	$2, %r11d
	subq	%r10, %r11
	jmp	.LBB8_7
	.p2align	4
.LBB8_5:
	movl	8(%r12), %ebx
	movq	%rsi, 80(%rsp)
	movq	%rbp, %rdx
.LBB8_6:
	incq	%r15
	incq	%r11
	movl	%ebx, %r8d
	cmpq	$1, %r15
	je	.LBB8_58
.LBB8_7:
	movl	%r8d, %edi
	cmpq	%rdi, %rdx
	jbe	.LBB8_93
	leaq	(%rdi,%rdi,2), %r13
	shlq	$4, %r13
	leaq	(%rax,%r13), %r12
	movl	(%rax,%r13), %r14d
	cmpl	$1, %r14d
	jne	.LBB8_12
	movl	4(%r12), %ebx
	movq	%rdx, %rbp
	cmpq	%rbx, %rdx
	jbe	.LBB8_94
	leaq	(%rbx,%rbx,2), %rdx
	shlq	$4, %rdx
	leaq	(%rax,%rdx), %r10
	xorl	%esi, %esi
	cmpl	$0, (%rax,%rdx)
	setne	%sil
	movq	16(%r10,%rsi,8), %r10
	movq	80(%rsp), %rdx
	movq	%rdx, %rsi
	subq	%r10, %rsi
	jae	.LBB8_5
	subq	%rdx, %r10
	cmpq	%r10, 120(%rsp)
	movq	%rbp, %rdx
	jbe	.LBB8_6
	jmp	.LBB8_13
	.p2align	4
.LBB8_12:
	testl	%r14d, %r14d
	jne	.LBB8_57
.LBB8_13:
	negq	%r15
	movq	%r15, 16(%rcx)
	jae	.LBB8_61
	movq	%rdx, 136(%rsp)
	movq	%rcx, 96(%rsp)
	movq	8(%rcx), %rdx
	movq	8(%rdx), %rcx
	movq	%rcx, 128(%rsp)
	movq	16(%rdx), %rbp
	movl	68(%rsp), %edx
	movl	%r8d, 60(%rsp)
	jmp	.LBB8_17
	.p2align	4
.LBB8_15:
	movq	112(%rsp), %rdx
	movl	8(%rdx), %r15d
	movq	%rbp, 104(%rsp)
	movq	%r9, %rbp
.LBB8_16:
	incq	%r11
	movl	%r15d, %edx
	cmpq	$1, %r11
	je	.LBB8_60
.LBB8_17:
	movl	%edx, %r10d
	cmpq	%r10, %rbp
	jbe	.LBB8_95
	movl	%edx, 68(%rsp)
	leaq	(%r10,%r10,2), %rsi
	shlq	$4, %rsi
	movq	128(%rsp), %r8
	leaq	(%r8,%rsi), %rdx
	movl	(%r8,%rsi), %ebx
	cmpl	$1, %ebx
	movq	%rdx, 112(%rsp)
	movl	%ebx, 92(%rsp)
	jne	.LBB8_22
	movq	80(%rsp), %rcx
	movl	4(%rdx), %r15d
	movq	%rbp, %r9
	cmpq	%r15, %rbp
	jbe	.LBB8_96
	leaq	(%r15,%r15,2), %rbx
	shlq	$4, %rbx
	movq	128(%rsp), %r8
	leaq	(%r8,%rbx), %rbp
	xorl	%edx, %edx
	cmpl	$0, (%r8,%rbx)
	setne	%dl
	movq	16(%rbp,%rdx,8), %rbx
	movq	104(%rsp), %rdx
	movq	%rdx, %rbp
	subq	%rbx, %rbp
	jae	.LBB8_15
	subq	%rdx, %rbx
	cmpq	%rbx, 120(%rsp)
	movq	%rcx, %rdx
	movq	%r9, %rbp
	jbe	.LBB8_16
	jmp	.LBB8_23
.LBB8_22:
	testl	%ebx, %ebx
	movq	80(%rsp), %rdx
	jne	.LBB8_59
.LBB8_23:
	negq	%r11
	movq	104(%rsp), %rbx
	movq	96(%rsp), %rcx
	movq	%r11, 16(%rcx)
	movl	60(%rsp), %ecx
	cmpl	68(%rsp), %ecx
	sete	%cl
	movq	%rdx, %r15
	cmpq	%rbx, %rdx
	sete	%dl
	andb	%cl, %dl
	testb	%dl, 67(%rsp)
	jne	.LBB8_64
	movq	%rbx, %r11
	movq	%rbp, %rbx
	cmpl	$2, %r14d
	movq	264(%rsp), %rcx
	movq	%r10, 144(%rsp)
	je	.LBB8_27
	cmpl	$1, %r14d
	movq	120(%rsp), %r9
	movq	136(%rsp), %rdx
	jne	.LBB8_30
	movl	4(%r12), %ecx
	cmpq	%rcx, %rdx
	ja	.LBB8_28
	jmp	.LBB8_104
.LBB8_27:
	movl	4(%r12), %ecx
	movq	136(%rsp), %rdx
	cmpq	%rcx, %rdx
	movq	120(%rsp), %r9
	jbe	.LBB8_104
.LBB8_28:
	leaq	(%rcx,%rcx,2), %rdx
	shlq	$4, %rdx
	leaq	(%rax,%rdx), %rcx
	movl	(%rax,%rdx), %eax
	testl	%eax, %eax
	movl	92(%rsp), %r10d
	je	.LBB8_32
	cmpl	$1, %eax
	movq	%r15, %rbp
	movl	60(%rsp), %r8d
	addq	$24, %rcx
	movq	(%rcx), %r15
	subq	%rbp, %r15
	testl	%r10d, %r10d
	jne	.LBB8_33
	jmp	.LBB8_36
.LBB8_30:
	movl	92(%rsp), %r10d
	testl	%r10d, %r10d
	movq	%r15, %rbp
	je	.LBB8_67
	movq	16(%r12), %r15
	subq	%rbp, %r15
	movl	60(%rsp), %r8d
	jmp	.LBB8_33
.LBB8_32:
	addq	$16, %rcx
	movq	%r15, %rbp
	movl	60(%rsp), %r8d
	movq	(%rcx), %r15
	subq	%rbp, %r15
	testl	%r10d, %r10d
	je	.LBB8_36
.LBB8_33:
	movq	112(%rsp), %rax
	movl	4(%rax), %ecx
	cmpq	%rcx, %rbx
	jbe	.LBB8_103
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	movq	128(%rsp), %rdx
	leaq	(%rdx,%rcx), %rax
	movl	(%rdx,%rcx), %ecx
	testl	%ecx, %ecx
	je	.LBB8_37
	cmpl	$1, %ecx
	addq	$24, %rax
	jmp	.LBB8_38
.LBB8_36:
	movq	112(%rsp), %rax
	addq	$16, %rax
	jmp	.LBB8_38
.LBB8_37:
	addq	$16, %rax
.LBB8_38:
	movq	(%rax), %rax
	subq	%r11, %rax
	cmpq	%r15, %rax
	movq	%r15, %rbx
	movq	%rax, 128(%rsp)
	cmovbq	%rax, %r15
	cmpq	%r15, %r9
	cmovbq	%r9, %r15
	movl	%r8d, %eax
	cmpl	$1, %r14d
	jne	.LBB8_40
	movl	4(%r12), %eax
.LBB8_40:
	movl	68(%rsp), %ecx
	cmpl	$1, %r10d
	jne	.LBB8_42
	movq	112(%rsp), %rcx
	movl	4(%rcx), %ecx
.LBB8_42:
	movq	%r15, 40(%rsp)
	movl	%ecx, 32(%rsp)
	movq	96(%rsp), %rcx
	movq	%rcx, %r12
	movq	%rbp, %rdx
	movl	%eax, %r8d
	movq	%r11, %r9
	callq	_ZN26hashrope_diagnostic_slot_a4rope14FastComparison13lcp_recursive17h6af0d9319335c753E
	testb	$1, %al
	jne	.LBB8_65
	cmpq	%r15, %rdx
	jne	.LBB8_66
	movq	(%r12), %rax
	movq	16(%rax), %rdx
	cmpq	%rdi, %rdx
	jbe	.LBB8_101
	movq	%r12, %r10
	cmpq	%rbx, %r15
	movq	264(%rsp), %rdx
	movq	%rbp, 80(%rsp)
	movl	60(%rsp), %r8d
	movq	144(%rsp), %rcx
	jne	.LBB8_48
	movq	8(%rax), %rax
	cmpl	$1, (%rax,%r13)
	jne	.LBB8_48
	addq	%r13, %rax
	movl	8(%rax), %r8d
	movq	$0, 80(%rsp)
	jmp	.LBB8_49
.LBB8_48:
	addq	%r15, 80(%rsp)
.LBB8_49:
	movq	72(%rsp), %r11
	movq	8(%r10), %r9
	movq	16(%r9), %rax
	cmpq	%rcx, %rax
	jbe	.LBB8_102
	cmpq	128(%rsp), %r15
	jne	.LBB8_53
	movq	8(%r9), %rax
	cmpl	$1, (%rax,%rsi)
	jne	.LBB8_53
	addq	%rsi, %rax
	movl	8(%rax), %eax
	movl	%eax, 68(%rsp)
	movq	$0, 104(%rsp)
	jmp	.LBB8_54
.LBB8_53:
	addq	%r15, 104(%rsp)
.LBB8_54:
	addq	%r15, %r11
	cmpq	%rdx, %r11
	movq	%r10, %rcx
	movl	68(%rsp), %esi
	jb	.LBB8_2
	jmp	.LBB8_56
.LBB8_55:
	xorl	%edx, %edx
.LBB8_56:
	xorl	%eax, %eax
	jmp	.LBB8_62
.LBB8_57:
	negq	%r15
	movq	%r15, 16(%rcx)
	jmp	.LBB8_61
.LBB8_58:
	movq	$0, 16(%rcx)
	jmp	.LBB8_61
.LBB8_59:
	negq	%r11
	movq	96(%rsp), %rax
	movq	%r11, 16(%rax)
	jmp	.LBB8_61
.LBB8_60:
	movq	96(%rsp), %rax
	movq	$0, 16(%rax)
.LBB8_61:
	movq	72(%rsp), %rdx
	movl	$1, %eax
.LBB8_62:
	.seh_startepilogue
	addq	$152, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB8_63:
	movq	%r11, %rdx
	jmp	.LBB8_62
.LBB8_64:
	xorl	%eax, %eax
	movq	264(%rsp), %rdx
	jmp	.LBB8_62
.LBB8_65:
	movl	$1, %eax
	addq	72(%rsp), %rdx
	jmp	.LBB8_62
.LBB8_66:
	xorl	%eax, %eax
	addq	72(%rsp), %rdx
	jmp	.LBB8_62
.LBB8_67:
	movq	40(%r12), %rax
	movq	%rax, %r8
	subq	%rbp, %r8
	jb	.LBB8_98
	cmpq	%r8, %r9
	movq	112(%rsp), %r10
	ja	.LBB8_97
	movq	40(%r10), %rax
	movq	%rax, %r8
	subq	%r11, %r8
	jb	.LBB8_99
	cmpq	%r8, %r9
	ja	.LBB8_100
	movq	%rcx, %rsi
	addq	32(%r12), %rbp
	addq	32(%r10), %r11
	movq	%rbp, %rdi
	movq	%rbp, %rcx
	movq	%r11, %rbx
	movq	%r11, %rdx
	movq	%r9, %r8
	movq	%r9, %r14
	callq	memcmp
	testl	%eax, %eax
	je	.LBB8_76
	movabsq	$9223372036854775800, %rax
	andq	%r14, %rax
	movq	$-8, %r8
	movq	%r14, %r9
	movq	%rbx, %rcx
	movq	72(%rsp), %rsi
.LBB8_73:
	cmpq	$7, %r9
	jbe	.LBB8_77
	movq	8(%rdi,%r8), %r10
	movq	8(%rcx,%r8), %r11
	addq	$8, %r8
	addq	$-8, %r9
	cmpq	%r11, %r10
	je	.LBB8_73
	xorq	%r10, %r11
	rep		bsfq	%r11, %rdx
	shrl	$3, %edx
	addq	%r8, %rdx
	addq	%rsi, %rdx
	jmp	.LBB8_56
.LBB8_76:
	xorl	%eax, %eax
	movq	%rsi, %rdx
	jmp	.LBB8_62
.LBB8_77:
	movq	120(%rsp), %r9
	andq	$7, %r9
	je	.LBB8_105
	movzbl	(%rdi,%rax), %r8d
	cmpb	(%rcx,%rax), %r8b
	jne	.LBB8_92
	cmpl	$1, %r9d
	je	.LBB8_105
	movzbl	1(%rdi,%rax), %r8d
	movl	$1, %edx
	cmpb	1(%rcx,%rax), %r8b
	jne	.LBB8_91
	cmpl	$2, %r9d
	je	.LBB8_105
	movzbl	2(%rdi,%rax), %r8d
	movl	$2, %edx
	cmpb	2(%rcx,%rax), %r8b
	jne	.LBB8_91
	cmpl	$3, %r9d
	je	.LBB8_105
	movzbl	3(%rdi,%rax), %r8d
	movl	$3, %edx
	cmpb	3(%rcx,%rax), %r8b
	jne	.LBB8_91
	cmpl	$4, %r9d
	je	.LBB8_105
	movzbl	4(%rdi,%rax), %r8d
	movl	$4, %edx
	cmpb	4(%rcx,%rax), %r8b
	jne	.LBB8_91
	cmpl	$5, %r9d
	je	.LBB8_105
	movzbl	5(%rdi,%rax), %r8d
	movl	$5, %edx
	cmpb	5(%rcx,%rax), %r8b
	jne	.LBB8_91
	cmpl	$6, %r9d
	je	.LBB8_105
	movzbl	6(%rdi,%rax), %r8d
	movl	$6, %edx
	cmpb	6(%rcx,%rax), %r8b
	je	.LBB8_105
.LBB8_91:
	orq	%rax, %rdx
	addq	%rsi, %rdx
	jmp	.LBB8_56
.LBB8_92:
	xorl	%edx, %edx
	orq	%rax, %rdx
	addq	%rsi, %rdx
	jmp	.LBB8_56
.LBB8_93:
	negq	%r15
	movq	%r15, 16(%rcx)
	leaq	anon.3126157283a31055444fc45c79212b1f.23(%rip), %r8
	movq	%rdi, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB8_94:
	negq	%r15
	movq	%r15, 16(%rcx)
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%rbx, %rcx
	movq	%rbp, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB8_95:
	negq	%r11
	movq	96(%rsp), %rax
	movq	%r11, 16(%rax)
	leaq	anon.3126157283a31055444fc45c79212b1f.23(%rip), %r8
	movq	%r10, %rcx
	movq	%rbp, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB8_96:
	negq	%r11
	movq	96(%rsp), %rax
	movq	%r11, 16(%rax)
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%r15, %rcx
	movq	%r9, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB8_97:
	movq	%r9, %rdx
	leaq	anon.3126157283a31055444fc45c79212b1f.19(%rip), %r9
	xorl	%ecx, %ecx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB8_98:
	leaq	anon.3126157283a31055444fc45c79212b1f.20(%rip), %r9
	movq	%rbp, %rcx
	movq	%rax, %rdx
	movq	%rax, %r8
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB8_99:
	leaq	anon.3126157283a31055444fc45c79212b1f.18(%rip), %r9
	movq	%r11, %rcx
	movq	%rax, %rdx
	movq	%rax, %r8
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB8_100:
	movq	%r9, %rdx
	leaq	anon.3126157283a31055444fc45c79212b1f.17(%rip), %r9
	xorl	%ecx, %ecx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB8_101:
	leaq	anon.3126157283a31055444fc45c79212b1f.21(%rip), %r8
	movq	%rdi, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB8_102:
	leaq	anon.3126157283a31055444fc45c79212b1f.22(%rip), %r8
	movq	%rax, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB8_103:
	movq	%rbx, %rdx
.LBB8_104:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB8_105:
	leaq	anon.3126157283a31055444fc45c79212b1f.36(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope15ExactComparison3lcp17h189789a5c51c350fE;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope15ExactComparison3lcp17h189789a5c51c350fE,unique,9
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope15ExactComparison3lcp17h189789a5c51c350fE:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope15ExactComparison3lcp17h189789a5c51c350fE
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movq	%rdx, %r10
	movq	168(%rsp), %rsi
	testq	%rsi, %rsi
	je	.LBB9_4
	movq	(%rcx), %r11
	movq	16(%r11), %rax
	movl	%r8d, %edx
	cmpq	%rdx, %rax
	jbe	.LBB9_5
	movl	160(%rsp), %edi
	movq	8(%r11), %r14
	leaq	(%rdx,%rdx,2), %rdx
	shlq	$4, %rdx
	leaq	(%r14,%rdx), %r12
	movl	(%r14,%rdx), %r13d
	cmpl	$1, %r13d
	je	.LBB9_6
	cmpl	$2, %r13d
	je	.LBB9_7
	jmp	.LBB9_4
.LBB9_6:
	movl	4(%r12), %edx
	cmpl	8(%r12), %edx
	jne	.LBB9_4
.LBB9_7:
	movq	8(%rcx), %rbx
	movq	16(%rbx), %rdx
	movl	%edi, %r11d
	cmpq	%r11, %rdx
	jbe	.LBB9_10
	movq	8(%rbx), %rbx
	leaq	(%r11,%r11,2), %r11
	shlq	$4, %r11
	leaq	(%rbx,%r11), %r15
	movl	(%rbx,%r11), %ebp
	cmpl	$1, %ebp
	je	.LBB9_11
	cmpl	$2, %ebp
	je	.LBB9_12
	jmp	.LBB9_4
.LBB9_11:
	movl	4(%r15), %r11d
	cmpl	8(%r15), %r11d
	jne	.LBB9_4
.LBB9_12:
	movl	4(%r12), %r11d
	cmpl	$1, %r13d
	jne	.LBB9_14
	cmpl	8(%r12), %r11d
	je	.LBB9_14
	leaq	anon.3126157283a31055444fc45c79212b1f.25(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
	.p2align	4
.LBB9_20:
	movl	4(%r11), %r13d
	cmpl	8(%r11), %r13d
	jne	.LBB9_21
.LBB9_18:
	movl	%r13d, %r11d
.LBB9_14:
	cmpq	%r11, %rax
	jbe	.LBB9_19
	leaq	(%r11,%r11,2), %r12
	shlq	$4, %r12
	leaq	(%r14,%r12), %r11
	movl	(%r14,%r12), %r12d
	cmpl	$1, %r12d
	je	.LBB9_20
	cmpl	$2, %r12d
	jne	.LBB9_21
	movl	4(%r11), %r13d
	jmp	.LBB9_18
.LBB9_21:
	xorl	%eax, %eax
	testl	%r12d, %r12d
	setne	%al
	movq	16(%r11,%rax,8), %r11
	cmpl	$1, %ebp
	je	.LBB9_24
	cmpl	$2, %ebp
	jne	.LBB9_38
	movl	4(%r15), %eax
	jmp	.LBB9_25
.LBB9_24:
	movl	4(%r15), %eax
	cmpl	8(%r15), %eax
	jne	.LBB9_38
.LBB9_25:
	movl	%eax, %eax
	jmp	.LBB9_26
	.p2align	4
.LBB9_32:
	movl	4(%rax), %r14d
	cmpl	8(%rax), %r14d
	jne	.LBB9_33
.LBB9_30:
	movl	%r14d, %eax
.LBB9_26:
	cmpq	%rax, %rdx
	jbe	.LBB9_31
	leaq	(%rax,%rax,2), %r14
	shlq	$4, %r14
	leaq	(%rbx,%r14), %rax
	movl	(%rbx,%r14), %ebp
	cmpl	$1, %ebp
	je	.LBB9_32
	cmpl	$2, %ebp
	jne	.LBB9_33
	movl	4(%rax), %r14d
	jmp	.LBB9_30
.LBB9_33:
	xorl	%edx, %edx
	testl	%ebp, %ebp
	setne	%dl
	movq	16(%rax,%rdx,8), %rbx
	movq	%r11, %r14
	testq	%rbx, %rbx
	je	.LBB9_39
	movq	%rbx, %rdx
	movq	%r11, %rax
	jmp	.LBB9_35
	.p2align	4
.LBB9_41:
	xorl	%edx, %edx
	divq	%r14
	movq	%r14, %rax
	testq	%rdx, %rdx
	je	.LBB9_39
.LBB9_35:
	movq	%rdx, %r14
	movq	%rax, %rdx
	orq	%r14, %rdx
	shrq	$32, %rdx
	jne	.LBB9_41
	xorl	%edx, %edx
	divl	%r14d
	movq	%r14, %rax
	testq	%rdx, %rdx
	jne	.LBB9_35
.LBB9_39:
	subq	%r14, %rbx
	addq	%rbx, %r11
	movq	$-1, %rbx
	cmovaeq	%r11, %rbx
	cmpq	%rsi, %rbx
	jae	.LBB9_4
	movq	%rbx, 40(%rsp)
	movl	%edi, 32(%rsp)
	movq	%r10, %rdx
	callq	_ZN26hashrope_diagnostic_slot_a4rope15ExactComparison9lcp_inner17h3ebe2d691194d80bE
	cmpq	%rbx, %rax
	cmoveq	%rsi, %rax
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB9_4:
	movq	%r10, %rdx
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	jmp	_ZN26hashrope_diagnostic_slot_a4rope15ExactComparison9lcp_inner17h3ebe2d691194d80bE
.LBB9_19:
	leaq	anon.3126157283a31055444fc45c79212b1f.24(%rip), %r8
	movq	%r11, %rcx
	movq	%rax, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB9_31:
	leaq	anon.3126157283a31055444fc45c79212b1f.24(%rip), %r8
	movq	%rax, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB9_5:
	leaq	anon.3126157283a31055444fc45c79212b1f.27(%rip), %r8
	movq	%rdx, %rcx
	movq	%rax, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB9_10:
	leaq	anon.3126157283a31055444fc45c79212b1f.27(%rip), %r8
	movq	%r11, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB9_38:
	leaq	anon.3126157283a31055444fc45c79212b1f.26(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope15ExactComparison9lcp_inner17h3ebe2d691194d80bE;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope15ExactComparison9lcp_inner17h3ebe2d691194d80bE,unique,10
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope15ExactComparison9lcp_inner17h3ebe2d691194d80bE:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope15ExactComparison9lcp_inner17h3ebe2d691194d80bE
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$168, %rsp
	.seh_stackalloc 168
	.seh_endprologue
	movq	280(%rsp), %rsi
	testq	%rsi, %rsi
	je	.LBB10_1
	movq	%r9, %rdi
	movl	%r8d, %r9d
	movq	%rdx, %r8
	movq	%rcx, %r13
	movl	272(%rsp), %ebx
	movq	(%rcx), %rax
	movq	8(%rax), %rcx
	movq	16(%rax), %rdx
	movq	%rsi, 32(%rsp)
	callq	_ZN26hashrope_diagnostic_slot_a4rope15ExactComparison9normalize17h0a8bbb027ce6bc91E
	movq	%rax, %r14
	movl	%edx, %ebp
	movq	8(%r13), %rax
	movq	8(%rax), %rcx
	movq	16(%rax), %rdx
	movq	%rsi, 32(%rsp)
	movq	%rdi, %r8
	movl	%ebx, %r9d
	callq	_ZN26hashrope_diagnostic_slot_a4rope15ExactComparison9normalize17h0a8bbb027ce6bc91E
	movq	%rax, %r15
	movl	%edx, %r12d
	movl	%ebp, 152(%rsp)
	movq	%r14, 136(%rsp)
	movl	%edx, 156(%rsp)
	movq	%rax, 144(%rsp)
	movq	%rsi, 160(%rsp)
	leaq	16(%r13), %rax
	movq	%rax, 72(%rsp)
	movq	$0, 56(%rsp)
.LBB10_4:
	movq	%rsi, %rdi
	subq	56(%rsp), %rdi
	movq	(%r13), %rax
	movq	8(%rax), %rcx
	movq	16(%rax), %rdx
	movq	%rdi, 32(%rsp)
	movq	%r14, %r8
	movl	%ebp, %r9d
	callq	_ZN26hashrope_diagnostic_slot_a4rope15ExactComparison9normalize17h0a8bbb027ce6bc91E
	movq	%rax, %r14
	movl	%edx, %ebp
	movq	8(%r13), %rax
	movq	8(%rax), %rcx
	movq	16(%rax), %rdx
	movq	%rdi, 32(%rsp)
	movq	%r15, %r8
	movl	%r12d, %r9d
	callq	_ZN26hashrope_diagnostic_slot_a4rope15ExactComparison9normalize17h0a8bbb027ce6bc91E
	movq	%rax, %r15
	movl	%edx, %r12d
	cmpb	$1, 40(%r13)
	jne	.LBB10_8
	cmpl	%r12d, %ebp
	jne	.LBB10_8
	cmpq	%r15, %r14
	je	.LBB10_7
.LBB10_8:
	movq	72(%rsp), %rax
	movq	(%rax), %rax
	testq	%rax, %rax
	je	.LBB10_22
	movq	24(%r13), %rcx
.LBB10_10:
	movzwl	362(%rax), %r8d
	movl	%r8d, %r9d
	shll	$5, %r9d
	movq	$-1, %rdx
	xorl	%r10d, %r10d
	jmp	.LBB10_11
	.p2align	4
.LBB10_18:
	incq	%rdx
	addq	$32, %r10
	cmpb	$1, %r11b
	jne	.LBB10_19
.LBB10_11:
	cmpq	%r10, %r9
	je	.LBB10_12
	movl	16(%rax,%r10), %ebx
	cmpl	%ebx, %ebp
	seta	%r11b
	sbbb	$0, %r11b
	cmpl	%ebx, %ebp
	jne	.LBB10_18
	movq	(%rax,%r10), %rbx
	cmpq	%rbx, %r14
	seta	%r11b
	sbbb	$0, %r11b
	cmpq	%rbx, %r14
	jne	.LBB10_18
	movl	20(%rax,%r10), %ebx
	cmpl	%ebx, %r12d
	seta	%r11b
	sbbb	$0, %r11b
	cmpl	%ebx, %r12d
	jne	.LBB10_18
	movq	8(%rax,%r10), %rbx
	cmpq	%rbx, %r15
	seta	%r11b
	sbbb	$0, %r11b
	cmpq	%rbx, %r15
	jne	.LBB10_18
	cmpq	24(%rax,%r10), %rdi
	seta	%r11b
	sbbb	$0, %r11b
	jmp	.LBB10_18
	.p2align	4
.LBB10_19:
	movzbl	%r11b, %r8d
	testl	%r8d, %r8d
	je	.LBB10_7
	jmp	.LBB10_20
	.p2align	4
.LBB10_12:
	movq	%r8, %rdx
.LBB10_20:
	subq	$1, %rcx
	jb	.LBB10_22
	movq	368(%rax,%rdx,8), %rax
	jmp	.LBB10_10
	.p2align	4
.LBB10_22:
	movq	(%r13), %rdx
	movl	%ebp, %ecx
	movq	16(%rdx), %r9
	cmpq	%rcx, %r9
	jbe	.LBB10_98
	movq	8(%r13), %r11
	movl	%r12d, %eax
	movq	16(%r11), %r10
	cmpq	%rax, %r10
	jbe	.LBB10_30
	movq	8(%rdx), %r8
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	addq	%r8, %rcx
	movq	8(%r11), %rbx
	leaq	(%rax,%rax,2), %r11
	shlq	$4, %r11
	addq	%rbx, %r11
	movl	(%rcx), %edx
	testl	%edx, %edx
	je	.LBB10_32
	cmpl	$1, %edx
	jne	.LBB10_26
	movl	4(%rcx), %ecx
	cmpq	%rcx, %r9
	jbe	.LBB10_37
	leaq	(%rcx,%rcx,2), %rax
	shlq	$4, %rax
	leaq	(%r8,%rax), %rcx
	movl	(%r8,%rax), %eax
	testl	%eax, %eax
	je	.LBB10_38
	cmpl	$1, %eax
	addq	$24, %rcx
	jmp	.LBB10_41
.LBB10_32:
	movl	(%r11), %eax
	testl	%eax, %eax
	je	.LBB10_52
	movl	%edx, %r8d
	addq	$16, %rcx
	movq	(%rcx), %rdx
	cmpl	$2, %eax
	jne	.LBB10_43
	jmp	.LBB10_44
.LBB10_26:
	movq	%rbx, 64(%rsp)
	cmpl	$2, (%r11)
	movl	4(%rcx), %ecx
	jne	.LBB10_27
	movl	%edx, 92(%rsp)
	cmpq	%rcx, %r9
	jbe	.LBB10_37
	movq	%rcx, 128(%rsp)
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	xorl	%edx, %edx
	cmpl	$0, (%r8,%rcx)
	setne	%bl
	movl	4(%r11), %eax
	cmpq	%rax, %r10
	jbe	.LBB10_85
	addq	%r8, %rcx
	movb	%bl, %dl
	movq	16(%rcx,%rdx,8), %rbx
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	movq	64(%rsp), %rcx
	leaq	(%rcx,%rax), %rdx
	movq	%rdx, 80(%rsp)
	xorl	%edx, %edx
	cmpl	$0, (%rcx,%rax)
	setne	%dl
	movq	80(%rsp), %rax
	movq	16(%rax,%rdx,8), %rdx
	movq	%rbx, %rax
	movq	%rdx, %rcx
	movq	%rdx, 80(%rsp)
	jmp	.LBB10_93
	.p2align	4
.LBB10_91:
	xorl	%edx, %edx
	divq	%rcx
.LBB10_92:
	movq	%rcx, %rax
	movq	%rdx, %rcx
.LBB10_93:
	testq	%rdx, %rdx
	je	.LBB10_86
	movq	%rax, %rdx
	orq	%rcx, %rdx
	shrq	$32, %rdx
	jne	.LBB10_91
	xorl	%edx, %edx
	divl	%ecx
	jmp	.LBB10_92
.LBB10_86:
	movq	80(%rsp), %rcx
	subq	%rax, %rcx
	addq	%rcx, %rbx
	movq	$-1, %rax
	cmovbq	%rax, %rbx
	cmpq	%rdi, %rbx
	movl	92(%rsp), %edx
	movq	128(%rsp), %rcx
	jb	.LBB10_87
.LBB10_27:
	cmpq	%rcx, %r9
	jbe	.LBB10_37
	leaq	(%rcx,%rcx,2), %rax
	shlq	$4, %rax
	leaq	(%r8,%rax), %rcx
	movl	(%r8,%rax), %eax
	testl	%eax, %eax
	je	.LBB10_39
	cmpl	$1, %eax
	addq	$24, %rcx
	jmp	.LBB10_40
.LBB10_38:
	addq	$16, %rcx
	jmp	.LBB10_41
.LBB10_39:
	addq	$16, %rcx
.LBB10_40:
	movq	64(%rsp), %rbx
.LBB10_41:
	movl	%edx, %r8d
	movl	(%r11), %eax
	movq	(%rcx), %rdx
	cmpl	$2, %eax
	je	.LBB10_44
.LBB10_43:
	cmpl	$1, %eax
	jne	.LBB10_47
.LBB10_44:
	movl	4(%r11), %ecx
	cmpq	%rcx, %r10
	jbe	.LBB10_51
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	leaq	(%rbx,%rcx), %r11
	movl	(%rbx,%rcx), %ecx
	testl	%ecx, %ecx
	je	.LBB10_47
	cmpl	$1, %ecx
	addq	$24, %r11
	jmp	.LBB10_48
	.p2align	4
.LBB10_47:
	addq	$16, %r11
.LBB10_48:
	subq	%r14, %rdx
	movq	(%r11), %rbx
	subq	%r15, %rbx
	cmpl	$1, %r8d
	jne	.LBB10_49
	cmpl	$1, %eax
	je	.LBB10_50
	movq	%rdx, %rbx
	jmp	.LBB10_96
.LBB10_49:
	cmpl	$1, %eax
	je	.LBB10_96
.LBB10_50:
	cmpq	%rdx, %rbx
	cmovaeq	%rdx, %rbx
.LBB10_96:
	cmpq	%rbx, %rdi
	cmovbq	%rdi, %rbx
	movl	%r12d, 32(%rsp)
	movq	%rbx, 40(%rsp)
	movq	%r13, %rcx
	movq	%r14, %rdx
	movl	%ebp, %r8d
	movq	%r15, %r9
	callq	_ZN26hashrope_diagnostic_slot_a4rope15ExactComparison9lcp_inner17h3ebe2d691194d80bE
	cmpq	%rbx, %rax
	jb	.LBB10_88
	addq	%rbx, %r14
	addq	%rbx, %r15
	movq	56(%rsp), %rcx
	addq	%rbx, %rcx
	movq	%rcx, 56(%rsp)
	cmpq	%rsi, %rcx
	jb	.LBB10_4
.LBB10_7:
	leaq	136(%rsp), %rdx
	movq	72(%rsp), %rcx
	callq	_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E
	jmp	.LBB10_2
.LBB10_1:
	xorl	%esi, %esi
.LBB10_2:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$168, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB10_52:
	movq	40(%rcx), %rdx
	movq	%rdx, %r8
	subq	%r14, %r8
	jb	.LBB10_99
	cmpq	%r8, %rdi
	ja	.LBB10_54
	movq	40(%r11), %rdx
	movq	%rdx, %r8
	subq	%r15, %r8
	jb	.LBB10_100
	cmpq	%r8, %rdi
	ja	.LBB10_58
	movq	32(%rcx), %rbx
	addq	%r14, %rbx
	movq	32(%r11), %r13
	addq	%r15, %r13
	movq	%rbx, %rcx
	movq	%r13, %rdx
	movq	%rdi, %r8
	callq	memcmp
	testl	%eax, %eax
	je	.LBB10_60
	movabsq	$9223372036854775800, %rax
	andq	%rdi, %rax
	movq	$-8, %rsi
	movq	%rdi, %rcx
.LBB10_62:
	cmpq	$7, %rcx
	jbe	.LBB10_63
	movq	8(%rbx,%rsi), %rdx
	movq	8(%r13,%rsi), %r8
	addq	$8, %rsi
	addq	$-8, %rcx
	cmpq	%r8, %rdx
	je	.LBB10_62
	xorq	%rdx, %r8
	rep		bsfq	%r8, %rax
	shrl	$3, %eax
	addq	56(%rsp), %rsi
	addq	%rax, %rsi
	jmp	.LBB10_2
.LBB10_87:
	movq	%rbx, 40(%rsp)
	movl	%r12d, 32(%rsp)
	movq	%r13, %rcx
	movq	%r14, %rdx
	movl	%ebp, %r8d
	movq	%r15, %r9
	callq	_ZN26hashrope_diagnostic_slot_a4rope15ExactComparison9lcp_inner17h3ebe2d691194d80bE
	cmpq	%rbx, %rax
	jae	.LBB10_60
.LBB10_88:
	addq	56(%rsp), %rax
	movq	%rax, %rsi
	jmp	.LBB10_2
.LBB10_60:
	movq	%r14, 96(%rsp)
	movq	%r15, 104(%rsp)
	movl	%ebp, 112(%rsp)
	movl	%r12d, 116(%rsp)
	movq	%rdi, 120(%rsp)
	leaq	96(%rsp), %rdx
	movq	72(%rsp), %rcx
	callq	_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E
	jmp	.LBB10_7
.LBB10_63:
	andq	$7, %rdi
	je	.LBB10_79
	movzbl	(%rbx,%rax), %ecx
	cmpb	(%r13,%rax), %cl
	jne	.LBB10_65
	cmpl	$1, %edi
	je	.LBB10_79
	movzbl	1(%rbx,%rax), %ecx
	movl	$1, %esi
	cmpb	1(%r13,%rax), %cl
	jne	.LBB10_78
	cmpl	$2, %edi
	je	.LBB10_79
	movzbl	2(%rbx,%rax), %ecx
	movl	$2, %esi
	cmpb	2(%r13,%rax), %cl
	jne	.LBB10_78
	cmpl	$3, %edi
	je	.LBB10_79
	movzbl	3(%rbx,%rax), %ecx
	movl	$3, %esi
	cmpb	3(%r13,%rax), %cl
	jne	.LBB10_78
	cmpl	$4, %edi
	je	.LBB10_79
	movzbl	4(%rbx,%rax), %ecx
	movl	$4, %esi
	cmpb	4(%r13,%rax), %cl
	jne	.LBB10_78
	cmpl	$5, %edi
	je	.LBB10_79
	movzbl	5(%rbx,%rax), %ecx
	movl	$5, %esi
	cmpb	5(%r13,%rax), %cl
	jne	.LBB10_78
	cmpl	$6, %edi
	je	.LBB10_79
	movzbl	6(%rbx,%rax), %ecx
	movl	$6, %esi
	cmpb	6(%r13,%rax), %cl
	jne	.LBB10_78
.LBB10_79:
	leaq	anon.3126157283a31055444fc45c79212b1f.36(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.LBB10_65:
	xorl	%esi, %esi
.LBB10_78:
	orq	%rax, %rsi
	addq	56(%rsp), %rsi
	jmp	.LBB10_2
.LBB10_54:
	leaq	anon.3126157283a31055444fc45c79212b1f.32(%rip), %r9
	xorl	%ecx, %ecx
	movq	%rdi, %rdx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB10_99:
	leaq	anon.3126157283a31055444fc45c79212b1f.33(%rip), %r9
	movq	%r14, %rcx
	movq	%rdx, %r8
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB10_100:
	leaq	anon.3126157283a31055444fc45c79212b1f.31(%rip), %r9
	movq	%r15, %rcx
	movq	%rdx, %r8
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB10_58:
	leaq	anon.3126157283a31055444fc45c79212b1f.30(%rip), %r9
	xorl	%ecx, %ecx
	movq	%rdi, %rdx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB10_98:
	leaq	anon.3126157283a31055444fc45c79212b1f.28(%rip), %r8
	movq	%r9, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB10_30:
	leaq	anon.3126157283a31055444fc45c79212b1f.29(%rip), %r8
	movq	%rax, %rcx
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB10_37:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%r9, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB10_51:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB10_85:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%rax, %rcx
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope15ExactComparison9normalize17h0a8bbb027ce6bc91E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope15ExactComparison9normalize17h0a8bbb027ce6bc91E,unique,11
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope15ExactComparison9normalize17h0a8bbb027ce6bc91E:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope15ExactComparison9normalize17h0a8bbb027ce6bc91E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rdx, %r11
	movl	%r9d, %r10d
	cmpq	%r10, %rdx
	jbe	.LBB11_8
	movq	%r8, %rax
	movq	96(%rsp), %r8
	jmp	.LBB11_2
	.p2align	4
.LBB11_14:
	movl	8(%rdx), %r10d
	movq	%rsi, %rax
.LBB11_15:
	movl	%r10d, %r9d
	cmpq	%r10, %r11
	jbe	.LBB11_8
.LBB11_2:
	leaq	(%r10,%r10,2), %r10
	shlq	$4, %r10
	leaq	(%rcx,%r10), %rdx
	movl	(%rcx,%r10), %r10d
	cmpl	$1, %r10d
	je	.LBB11_10
	cmpl	$2, %r10d
	jne	.LBB11_18
	movl	4(%rdx), %r10d
	cmpq	%r10, %r11
	jbe	.LBB11_11
	leaq	(%r10,%r10,2), %rdx
	shlq	$4, %rdx
	xorl	%esi, %esi
	cmpl	$0, (%rcx,%rdx)
	leaq	(%rcx,%rdx), %rdx
	setne	%sil
	movq	16(%rdx,%rsi,8), %rsi
	testq	%rsi, %rsi
	je	.LBB11_19
	movq	%rax, %rdx
	orq	%rsi, %rdx
	shrq	$32, %rdx
	je	.LBB11_7
	xorl	%edx, %edx
	divq	%rsi
	movq	%rdx, %rax
	subq	%rax, %rsi
	cmpq	%rsi, %r8
	jbe	.LBB11_15
	jmp	.LBB11_18
	.p2align	4
.LBB11_10:
	movl	4(%rdx), %r10d
	cmpq	%r10, %r11
	jbe	.LBB11_11
	leaq	(%r10,%r10,2), %rsi
	shlq	$4, %rsi
	leaq	(%rcx,%rsi), %rdi
	xorl	%ebx, %ebx
	cmpl	$0, (%rcx,%rsi)
	setne	%bl
	movq	16(%rdi,%rbx,8), %rdi
	movq	%rax, %rsi
	subq	%rdi, %rsi
	jae	.LBB11_14
	subq	%rax, %rdi
	cmpq	%rdi, %r8
	jbe	.LBB11_15
	jmp	.LBB11_18
.LBB11_7:
	xorl	%edx, %edx
	divl	%esi
	movl	%edx, %eax
	subq	%rax, %rsi
	cmpq	%rsi, %r8
	jbe	.LBB11_15
.LBB11_18:
	movl	%r9d, %edx
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB11_8:
	leaq	anon.3126157283a31055444fc45c79212b1f.34(%rip), %r8
	movq	%r10, %rcx
	movq	%r11, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB11_11:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%r10, %rcx
	movq	%r11, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB11_19:
	leaq	anon.3126157283a31055444fc45c79212b1f.35(%rip), %rcx
	callq	_ZN4core9panicking11panic_const23panic_const_rem_by_zero17hb0cdf0d2b6b1aafaE
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E,unique,12
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E:
.Lfunc_begin1:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$120, %rsp
	.seh_stackalloc 120
	leaq	112(%rsp), %rbp
	.seh_setframe %rbp, 112
	.seh_endprologue
	movq	$-2, (%rbp)
	movq	2112(%rcx), %rax
	cmpq	2072(%rcx), %rax
	jne	.LBB12_40
	movq	%rcx, %rsi
	movq	2080(%rcx), %rax
	cmpq	%rax, 2120(%rcx)
	jne	.LBB12_40
	movq	%r8, %rdi
	testq	%r8, %r8
	je	.LBB12_6
	movq	%rdx, %rbx
	cmpq	$513, %rdi
	jae	.LBB12_7
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$1, %edx
	movq	%rdi, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB12_43
	movq	%rdi, -80(%rbp)
	movq	%rax, -72(%rbp)
	movq	%rax, %rcx
	movq	%rbx, %rdx
	movq	%rdi, %r8
	callq	memcpy
	movq	%rdi, -64(%rbp)
	leaq	-80(%rbp), %rdx
	movq	%rsi, %rcx
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E
	movl	%eax, %edx
	jmp	.LBB12_37
.LBB12_6:
	xorl	%eax, %eax
	jmp	.LBB12_38
.LBB12_7:
	leaq	511(%rdi), %r12
	shrq	$9, %r12
	leaq	(,%r12,4), %r15
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$4, %edx
	movq	%r15, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB12_44
	movq	%rax, %r14
	movq	%r12, -32(%rbp)
	movq	%rax, -24(%rbp)
	xorl	%r15d, %r15d
	jmp	.LBB12_11
	.p2align	4
.LBB12_9:
	movq	-24(%rbp), %r14
.LBB12_10:
	addq	%r13, %rbx
	subq	%r13, %rdi
	movl	%r12d, (%r14,%r15,4)
	incq	%r15
.LBB12_11:
	movq	%r15, -16(%rbp)
	testq	%rdi, %rdi
	je	.LBB12_16
	cmpq	$512, %rdi
	movl	$512, %r13d
	cmovbq	%rdi, %r13
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$1, %edx
	movq	%r13, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB12_41
	movq	%r13, -80(%rbp)
	movq	%rax, -72(%rbp)
	movq	%rax, %rcx
	movq	%rbx, %rdx
	movq	%r13, %r8
	callq	memcpy
	movq	%r13, -64(%rbp)
.Ltmp12:
	movq	%rsi, %rcx
	leaq	-80(%rbp), %rdx
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E
.Ltmp13:
	movl	%eax, %r12d
	cmpq	-32(%rbp), %r15
	jne	.LBB12_10
.Ltmp14:
	leaq	-32(%rbp), %rcx
	callq	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h4f12d29f835ee7cfE
.Ltmp15:
	jmp	.LBB12_9
.LBB12_16:
	leaq	-56(%rbp), %rdi
	jmp	.LBB12_18
	.p2align	4
.LBB12_17:
	movq	-40(%rbp), %r15
	movq	%r15, -16(%rbp)
	movups	-56(%rbp), %xmm0
	movaps	%xmm0, -32(%rbp)
.LBB12_18:
	cmpq	$1, %r15
	jbe	.LBB12_34
	leaq	1(%r15), %r14
	shrq	%r14
	leaq	(,%r14,4), %rbx
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$4, %edx
	movq	%rbx, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB12_42
	movq	%r14, -56(%rbp)
	movq	%rax, -48(%rbp)
	movq	$0, -40(%rbp)
	movq	-24(%rbp), %rbx
	xorl	%r12d, %r12d
	xorl	%r13d, %r13d
	jmp	.LBB12_23
	.p2align	4
.LBB12_21:
	movq	-48(%rbp), %rax
.LBB12_22:
	movl	%r14d, (%rax,%r12,4)
	incq	%r12
	movq	%r12, -40(%rbp)
	addq	$2, %r13
.LBB12_23:
	cmpq	%r15, %r13
	jae	.LBB12_32
	movq	%r13, %rcx
	orq	$1, %rcx
	cmpq	%r15, %rcx
	jae	.LBB12_30
	movq	2112(%rsi), %rax
	cmpq	2072(%rsi), %rax
	jne	.LBB12_39
	movq	2080(%rsi), %rax
	cmpq	%rax, 2120(%rsi)
	jne	.LBB12_39
	movl	(%rbx,%rcx,4), %r8d
	movl	(%rbx,%r13,4), %edx
.Ltmp24:
	movq	%rsi, %rcx
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE
.Ltmp25:
	movl	%eax, %r14d
	cmpq	-56(%rbp), %r12
	jne	.LBB12_21
.Ltmp26:
	movq	%rdi, %rcx
	callq	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h4f12d29f835ee7cfE
.Ltmp27:
	jmp	.LBB12_21
	.p2align	4
.LBB12_30:
	movl	(%rbx,%r13,4), %r14d
	cmpq	-56(%rbp), %r12
	jne	.LBB12_22
.Ltmp20:
	movq	%rdi, %rcx
	callq	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h4f12d29f835ee7cfE
.Ltmp21:
	jmp	.LBB12_21
	.p2align	4
.LBB12_32:
	movq	-32(%rbp), %rdx
	testq	%rdx, %rdx
	je	.LBB12_17
	shlq	$2, %rdx
	movl	$4, %r8d
	movq	%rbx, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	jmp	.LBB12_17
.LBB12_34:
	jne	.LBB12_45
	movq	-32(%rbp), %rax
	movq	-24(%rbp), %rcx
	movl	(%rcx), %edx
	testq	%rax, %rax
	je	.LBB12_37
	shlq	$2, %rax
	movl	$4, %r8d
	movl	%edx, %esi
	movq	%rax, %rdx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	movl	%esi, %edx
.LBB12_37:
	movl	$1, %eax
.LBB12_38:
	.seh_startepilogue
	addq	$120, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.LBB12_39:
.Ltmp22:
	leaq	anon.3126157283a31055444fc45c79212b1f.37(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.Ltmp23:
	jmp	.LBB12_46
.LBB12_40:
	leaq	anon.3126157283a31055444fc45c79212b1f.37(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB12_41:
.Ltmp16:
	movl	$1, %ecx
	movq	%r13, %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
.Ltmp17:
	jmp	.LBB12_46
.LBB12_42:
.Ltmp28:
	movl	$4, %ecx
	movq	%rbx, %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
.Ltmp29:
	jmp	.LBB12_46
.LBB12_43:
	movl	$1, %ecx
	movq	%rdi, %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
.LBB12_44:
	movl	$4, %ecx
	movq	%r15, %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
.LBB12_45:
.Ltmp18:
	leaq	anon.3126157283a31055444fc45c79212b1f.39(%rip), %r8
	xorl	%ecx, %ecx
	xorl	%edx, %edx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.Ltmp19:
.LBB12_46:
	ud2
	.seh_handlerdata
	.long	$cppxdata$_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E@IMGREL
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E,unique,12
	.seh_endproc
	.def	"?dtor$47@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$47@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E@4HA":
.seh_proc "?dtor$47@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E@4HA"
.LBB12_47:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	112(%rdx), %rbp
	.seh_endprologue
	movq	-56(%rbp), %rdx
	testq	%rdx, %rdx
	je	.LBB12_49
	movq	-48(%rbp), %rcx
	shlq	$2, %rdx
	movl	$4, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB12_49:
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E,unique,12
	.seh_endproc
	.def	"?dtor$50@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$50@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E@4HA":
.seh_proc "?dtor$50@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E@4HA"
.LBB12_50:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	112(%rdx), %rbp
	.seh_endprologue
	movq	-32(%rbp), %rdx
	testq	%rdx, %rdx
	je	.LBB12_52
	movq	-24(%rbp), %rcx
	shlq	$2, %rdx
	movl	$4, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB12_52:
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.Lfunc_end1:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E,unique,12
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E,unique,1
	.p2align	2, 0x0
$cppxdata$_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E:
	.long	429065506
	.long	2
	.long	$stateUnwindMap$_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E@IMGREL
	.long	0
	.long	0
	.long	8
	.long	$ip2state$_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E@IMGREL
	.long	112
	.long	0
	.long	1
$stateUnwindMap$_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E:
	.long	-1
	.long	"?dtor$50@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E@4HA"@IMGREL
	.long	0
	.long	"?dtor$47@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E@4HA"@IMGREL
$ip2state$_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E:
	.long	.Lfunc_begin1@IMGREL
	.long	-1
	.long	.Ltmp12@IMGREL+1
	.long	0
	.long	.Ltmp24@IMGREL+1
	.long	1
	.long	.Ltmp23@IMGREL+1
	.long	-1
	.long	.Ltmp16@IMGREL+1
	.long	0
	.long	.Ltmp29@IMGREL+1
	.long	-1
	.long	.Ltmp18@IMGREL+1
	.long	0
	.long	.Ltmp19@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E,unique,12

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_bytes17hf79bc3636cb8b503E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_bytes17hf79bc3636cb8b503E,unique,13
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_bytes17hf79bc3636cb8b503E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_bytes17hf79bc3636cb8b503E:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_bytes17hf79bc3636cb8b503E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	2072(%rcx), %r10
	cmpq	%r10, 2112(%rcx)
	jne	.LBB13_7
	movq	2080(%rcx), %r11
	cmpq	%r11, 2120(%rcx)
	jne	.LBB13_7
	testq	%r8, %r8
	je	.LBB13_3
	movq	%rdx, %r9
	movl	$127, %ecx
	bsrq	%r10, %rcx
	xorl	$-64, %ecx
	addl	$65, %ecx
	xorl	%esi, %esi
	xorl	%edi, %edi
	xorl	%eax, %eax
	.p2align	4
.LBB13_5:
	movzbl	(%r9,%rdi), %ebx
	mulq	%r11
	addq	%rbx, %rax
	adcq	$0, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rbx
	shrdq	%cl, %rdx, %rbx
	shrq	%cl, %rdx
	testb	$64, %cl
	cmovneq	%rdx, %rbx
	cmovneq	%rsi, %rdx
	andq	%r10, %rax
	addq	%rbx, %rax
	adcq	$0, %rdx
	movq	%rax, %rbx
	shrdq	%cl, %rdx, %rbx
	shrq	%cl, %rdx
	testb	$64, %cl
	cmoveq	%rbx, %rdx
	andq	%r10, %rax
	addq	%rdx, %rax
	cmpq	%rax, %r10
	movq	%r10, %rdx
	cmovaq	%rsi, %rdx
	subq	%rdx, %rax
	incq	%rdi
	cmpq	%rdi, %r8
	jne	.LBB13_5
	jmp	.LBB13_6
.LBB13_3:
	xorl	%eax, %eax
.LBB13_6:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB13_7:
	leaq	anon.3126157283a31055444fc45c79212b1f.37(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E,unique,14
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E:
.Lfunc_begin2:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$88, %rsp
	.seh_stackalloc 88
	leaq	80(%rsp), %rbp
	.seh_setframe %rbp, 80
	.seh_endprologue
	movq	$-2, (%rbp)
	movq	%r9, %rdi
	movl	%edx, %ebx
	movq	%rcx, %rsi
	leaq	-1(%r9), %r11
	movq	8(%rcx), %rcx
	movq	16(%rsi), %r10
.LBB14_1:
	movq	%r8, %r14
	leaq	(%r14,%rdi), %rax
	testq	%r14, %r14
	je	.LBB14_3
	.p2align	4
.LBB14_40:
	movl	%ebx, %r15d
	cmpq	%r15, %r10
	jbe	.LBB14_20
	leaq	(%r15,%r15,2), %r8
	shlq	$4, %r8
	leaq	(%rcx,%r8), %rdx
	movl	(%rcx,%r8), %r8d
	cmpl	$1, %r8d
	jne	.LBB14_42
	movl	4(%rdx), %ebx
	cmpq	%rbx, %r10
	jbe	.LBB14_48
	leaq	(%rbx,%rbx,2), %rdx
	shlq	$4, %rdx
	xorl	%r8d, %r8d
	cmpl	$0, (%rcx,%rdx)
	leaq	(%rcx,%rdx), %rdx
	setne	%r8b
	movq	16(%rdx,%r8,8), %r9
	cmpq	%r9, %rax
	jbe	.LBB14_40
	jmp	.LBB14_29
	.p2align	4
.LBB14_3:
	movl	%ebx, %r15d
	cmpq	%r15, %r10
	jbe	.LBB14_12
	leaq	(%r15,%r15,2), %r12
	shlq	$4, %r12
	leaq	(%rcx,%r12), %rdx
	movl	(%rcx,%r12), %r8d
	xorl	%r9d, %r9d
	testl	%r8d, %r8d
	setne	%r9b
	cmpq	16(%rdx,%r9,8), %rdi
	je	.LBB14_16
	cmpl	$1, %r8d
	jne	.LBB14_6
	movl	4(%rdx), %ebx
	cmpq	%rbx, %r10
	jbe	.LBB14_48
	leaq	(%rbx,%rbx,2), %rdx
	shlq	$4, %rdx
	xorl	%r8d, %r8d
	cmpl	$0, (%rcx,%rdx)
	leaq	(%rcx,%rdx), %rdx
	setne	%r8b
	movq	16(%rdx,%r8,8), %r9
	cmpq	%r9, %rax
	jbe	.LBB14_3
.LBB14_29:
	leaq	(%r15,%r15,2), %rax
	shlq	$4, %rax
	movl	8(%rcx,%rax), %r15d
	movq	%r14, %rax
	subq	%r9, %rax
	jb	.LBB14_30
	movl	%r15d, %ebx
	movq	%rax, %r14
	leaq	(%r14,%rdi), %rax
	testq	%r14, %r14
	jne	.LBB14_40
	jmp	.LBB14_3
	.p2align	4
.LBB14_42:
	testl	%r8d, %r8d
	je	.LBB14_8
	jmp	.LBB14_43
	.p2align	4
.LBB14_6:
	testl	%r8d, %r8d
	je	.LBB14_7
.LBB14_43:
	movq	%r11, -8(%rbp)
	leaq	(%r15,%r15,2), %rax
	shlq	$4, %rax
	movl	4(%rcx,%rax), %ebx
	cmpq	%rbx, %r10
	jbe	.LBB14_48
	movq	2072(%rsi), %rax
	movq	%rax, -24(%rbp)
	leaq	(%rbx,%rbx,2), %r13
	shlq	$4, %r13
	leaq	(%rcx,%r13), %rax
	xorl	%edx, %edx
	cmpl	$0, (%rcx,%r13)
	setne	%dl
	movq	16(%rax,%rdx,8), %r12
	movq	%rsi, %rcx
	movl	%ebx, %edx
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena17ensure_hash_inner17h09315aac70f25a18E
	movq	16(%rsi), %r10
	cmpq	%rbx, %r10
	jbe	.LBB14_51
	testq	%r12, %r12
	movq	-8(%rbp), %r11
	je	.LBB14_62
	movq	8(%rsi), %rcx
	leaq	(%rcx,%r13), %rax
	xorl	%edx, %edx
	cmpl	$0, (%rcx,%r13)
	setne	%dl
	movq	8(%rax,%rdx,8), %r9
	movq	%r14, %rax
	orq	%r12, %rax
	shrq	$32, %rax
	movq	-24(%rbp), %r15
	je	.LBB14_47
	movq	%r14, %rax
	xorl	%edx, %edx
	divq	%r12
	movq	%rdx, %r8
	movq	%rax, %r13
	jmp	.LBB14_53
.LBB14_47:
	movl	%r14d, %eax
	xorl	%edx, %edx
	divl	%r12d
	movl	%edx, %r8d
	movl	%eax, %r13d
.LBB14_53:
	addq	%r11, %r14
	movq	%r14, %rax
	orq	%r12, %rax
	shrq	$32, %rax
	je	.LBB14_54
	movq	%r14, %rax
	xorl	%edx, %edx
	divq	%r12
	cmpq	%rax, %r13
	je	.LBB14_1
	jmp	.LBB14_57
.LBB14_54:
	movl	%r14d, %eax
	xorl	%edx, %edx
	divl	%r12d
	cmpq	%rax, %r13
	je	.LBB14_1
.LBB14_57:
	movq	%r9, -16(%rbp)
	movq	%rdx, -8(%rbp)
	leaq	24(%rsi), %rdi
	movq	%r12, %r9
	subq	%r8, %r9
	movq	%rsi, %rcx
	movl	%ebx, %edx
	movq	%rax, %r14
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E
	movq	%rax, -48(%rbp)
	notq	%r13
	addq	%r13, %r14
	movq	%rdi, -40(%rbp)
	je	.LBB14_58
	movq	%rdi, %rcx
	movq	%r12, %rdx
	callq	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE
	movq	%r14, %rcx
	movq	%rax, %rdx
	movq	%r15, %r8
	callq	_ZN26hashrope_diagnostic_slot_a15polynomial_hash3phi17h9e9794fc8b05b4a7E
	mulq	-16(%rbp)
	movq	%rax, %r13
	movl	$127, %edi
	bsrq	%r15, %rdi
	xorl	$-64, %edi
	addl	$65, %edi
	movq	%rdx, %rax
	movl	%edi, %ecx
	shrq	%cl, %rax
	movq	%r13, %r8
	shrdq	%cl, %rdx, %r8
	xorl	%r9d, %r9d
	testb	$64, %dil
	cmovneq	%rax, %r8
	cmovneq	%r9, %rax
	andq	%r15, %r13
	addq	%r8, %r13
	adcq	$0, %rax
	movq	%r13, %rdx
	shrdq	%cl, %rax, %rdx
	shrq	%cl, %rax
	testb	$64, %dil
	cmoveq	%rdx, %rax
	andq	%r15, %r13
	addq	%rax, %r13
	cmpq	%r13, %r15
	movq	%r15, %rax
	movl	$0, %ecx
	movq	%rcx, -32(%rbp)
	cmovaq	%r9, %rax
	subq	%rax, %r13
	imulq	%r12, %r14
	movq	%r14, -16(%rbp)
	jmp	.LBB14_60
.LBB14_16:
	movq	%rsi, %rcx
	movl	%ebx, %edx
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena17ensure_hash_inner17h09315aac70f25a18E
	movq	16(%rsi), %rdx
	cmpq	%r15, %rdx
	jbe	.LBB14_17
	movq	8(%rsi), %rcx
	leaq	(%rcx,%r12), %rax
	movl	(%rcx,%r12), %ecx
	testl	%ecx, %ecx
	je	.LBB14_18
	cmpl	$1, %ecx
	movq	16(%rax), %rax
	jmp	.LBB14_19
.LBB14_7:
	xorl	%r14d, %r14d
.LBB14_8:
	movq	32(%rdx), %rbx
	movq	40(%rdx), %r15
	testq	%r15, %r15
	je	.LBB14_9
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$1, %edx
	movq	%r15, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB14_61
	movq	%rax, %r12
	jmp	.LBB14_23
.LBB14_9:
	movl	$1, %r12d
.LBB14_23:
	movq	%r12, %rcx
	movq	%rbx, %rdx
	movq	%r15, %r8
	callq	memcpy
	movq	%r14, %rdx
	addq	%rdi, %rdx
	jb	.LBB14_25
	cmpq	%r15, %rdx
	ja	.LBB14_25
	testq	%rdi, %rdi
	je	.LBB14_32
	movq	2072(%rsi), %r8
	movq	2080(%rsi), %r9
	addq	%r12, %r14
	movl	$127, %ecx
	bsrq	%r8, %rcx
	xorl	$-64, %ecx
	addl	$65, %ecx
	xorl	%r10d, %r10d
	xorl	%r11d, %r11d
	xorl	%eax, %eax
	.p2align	4
.LBB14_34:
	movzbl	(%r14,%r11), %esi
	mulq	%r9
	addq	%rsi, %rax
	adcq	$0, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %rsi
	shrdq	%cl, %rdx, %rsi
	shrq	%cl, %rdx
	testb	$64, %cl
	cmovneq	%rdx, %rsi
	cmovneq	%r10, %rdx
	andq	%r8, %rax
	addq	%rsi, %rax
	adcq	$0, %rdx
	movq	%rax, %rsi
	shrdq	%cl, %rdx, %rsi
	shrq	%cl, %rdx
	testb	$64, %cl
	cmoveq	%rsi, %rdx
	andq	%r8, %rax
	addq	%rdx, %rax
	cmpq	%rax, %r8
	movq	%r8, %rdx
	cmovaq	%r10, %rdx
	subq	%rdx, %rax
	incq	%r11
	cmpq	%r11, %rdi
	jne	.LBB14_34
	testq	%r15, %r15
	jne	.LBB14_36
	jmp	.LBB14_19
.LBB14_32:
	xorl	%eax, %eax
	testq	%r15, %r15
	je	.LBB14_19
.LBB14_36:
	movl	$1, %r8d
	movq	%r12, %rcx
	movq	%r15, %rdx
	movq	%rax, %rsi
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	movq	%rsi, %rax
.LBB14_19:
	.seh_startepilogue
	addq	$88, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.LBB14_18:
	movq	8(%rax), %rax
	jmp	.LBB14_19
.LBB14_30:
	leaq	24(%rsi), %r12
	subq	%r14, %r9
	subq	%r9, %rdi
	movq	%rsi, %rcx
	movl	%ebx, %edx
	movq	%r14, %r8
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E
	movq	%rax, %rbx
	xorl	%r13d, %r13d
	movq	%rsi, %rcx
	movl	%r15d, %edx
	xorl	%r8d, %r8d
	movq	%rdi, %r9
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E
	movq	%rax, %r14
	movq	%r12, %rcx
	movq	%rdi, %rdx
	callq	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE
	mulq	%rbx
	addq	%r14, %rax
	adcq	$0, %rdx
	movq	2072(%rsi), %r8
	movl	$127, %r9d
	bsrq	%r8, %r9
	xorl	$63, %r9d
	movb	$64, %cl
	subb	%r9b, %cl
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	testb	$64, %cl
	cmovneq	%rdx, %r9
	cmovneq	%r13, %rdx
	andq	%r8, %rax
	addq	%r9, %rax
	adcq	$0, %rdx
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	testb	$64, %cl
	cmoveq	%r9, %rdx
	andq	%r8, %rax
	addq	%rdx, %rax
	cmpq	%rax, %r8
	cmovaq	%r13, %r8
	subq	%r8, %rax
	jmp	.LBB14_19
.LBB14_58:
	movl	$127, %edi
	bsrq	%r15, %rdi
	xorl	$-64, %edi
	addl	$65, %edi
	movq	$0, -32(%rbp)
	movq	$0, -16(%rbp)
	xorl	%r13d, %r13d
.LBB14_60:
	movq	-8(%rbp), %r12
	leaq	1(%r12), %r14
	movq	%rsi, %rcx
	movl	%ebx, %edx
	xorl	%r8d, %r8d
	movq	%r14, %r9
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E
	movq	%rax, %rsi
	movq	-16(%rbp), %rax
	leaq	(%rax,%r12), %rdx
	incq	%rdx
	movq	-40(%rbp), %r12
	movq	%r12, %rcx
	callq	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE
	movq	%rax, %rbx
	movq	%r12, %rcx
	movq	%r14, %rdx
	callq	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE
	movq	%rax, %rcx
	movq	%rbx, %rax
	mulq	-48(%rbp)
	movq	%rdx, %r8
	movq	%rax, %r9
	movq	%rcx, %rax
	mulq	%r13
	movq	%rax, %rcx
	movq	%r9, %rax
	addq	%rsi, %rax
	adcq	$0, %r8
	addq	%rcx, %rax
	adcq	%rdx, %r8
	movq	%rax, %rdx
	movl	%edi, %ecx
	shrdq	%cl, %r8, %rdx
	movq	%r8, %r9
	shrq	%cl, %r9
	testb	$64, %dil
	cmovneq	%r9, %rdx
	movl	$0, %r10d
	cmovneq	%r10, %r9
	andq	-32(%rbp), %r8
	andq	%r15, %rax
	addq	%rdx, %rax
	adcq	%r9, %r8
	movq	%rax, %rdx
	shrdq	%cl, %r8, %rdx
	shrq	%cl, %r8
	testb	$64, %dil
	cmoveq	%rdx, %r8
	andq	%r15, %rax
	addq	%r8, %rax
	cmpq	%rax, %r15
	cmovaq	%r10, %r15
	subq	%r15, %rax
	jmp	.LBB14_19
.LBB14_25:
.Ltmp30:
	movq	%r12, -24(%rbp)
	leaq	anon.3126157283a31055444fc45c79212b1f.42(%rip), %r9
	movq	%r14, %rcx
	movq	%r15, %r8
	movq	%r15, -8(%rbp)
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.Ltmp31:
	ud2
.LBB14_48:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%rbx, %rcx
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB14_20:
	leaq	anon.3126157283a31055444fc45c79212b1f.41(%rip), %r8
	movq	%r15, %rcx
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB14_12:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%r15, %rcx
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB14_51:
	leaq	anon.3126157283a31055444fc45c79212b1f.40(%rip), %r8
	movq	%rbx, %rcx
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB14_62:
	leaq	anon.3126157283a31055444fc45c79212b1f.43(%rip), %rcx
	callq	_ZN4core9panicking11panic_const23panic_const_div_by_zero17hdceffd214664eedfE
.LBB14_61:
	movl	$1, %ecx
	movq	%r15, %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
.LBB14_17:
	leaq	anon.3126157283a31055444fc45c79212b1f.40(%rip), %r8
	movq	%r15, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_handlerdata
	.long	$cppxdata$_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E@IMGREL
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E,unique,14
	.seh_endproc
	.def	"?dtor$37@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$37@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E@4HA":
.seh_proc "?dtor$37@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E@4HA"
.LBB14_37:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	80(%rdx), %rbp
	.seh_endprologue
	movq	-8(%rbp), %rdx
	testq	%rdx, %rdx
	je	.LBB14_39
	movl	$1, %r8d
	movq	-24(%rbp), %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB14_39:
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.Lfunc_end2:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E,unique,14
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E,unique,2
	.p2align	2, 0x0
$cppxdata$_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E:
	.long	429065506
	.long	1
	.long	$stateUnwindMap$_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E@IMGREL
	.long	0
	.long	0
	.long	3
	.long	$ip2state$_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E@IMGREL
	.long	80
	.long	0
	.long	1
$stateUnwindMap$_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E:
	.long	-1
	.long	"?dtor$37@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E@4HA"@IMGREL
$ip2state$_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E:
	.long	.Lfunc_begin2@IMGREL
	.long	-1
	.long	.Ltmp30@IMGREL+1
	.long	0
	.long	.Ltmp31@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E,unique,14

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena10lcp_across17h9bb68f7f3d9e2afaE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena10lcp_across17h9bb68f7f3d9e2afaE,unique,15
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena10lcp_across17h9bb68f7f3d9e2afaE
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena10lcp_across17h9bb68f7f3d9e2afaE:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena10lcp_across17h9bb68f7f3d9e2afaE
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	testl	%edx, 112(%rsp)
	je	.LBB15_6
	movl	%r8d, %eax
	movq	16(%rcx), %rdx
	cmpq	%rax, %rdx
	jbe	.LBB15_7
	movl	120(%rsp), %r11d
	movl	%r11d, %r10d
	movq	16(%r9), %rdx
	cmpq	%r10, %rdx
	jbe	.LBB15_8
	movq	8(%rcx), %rdx
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	xorl	%esi, %esi
	cmpl	$0, (%rdx,%rax)
	leaq	(%rdx,%rax), %rax
	setne	%sil
	movq	16(%rax,%rsi,8), %rax
	movq	8(%r9), %rdx
	leaq	(%r10,%r10,2), %r10
	shlq	$4, %r10
	leaq	(%rdx,%r10), %rsi
	xorl	%edi, %edi
	cmpl	$0, (%rdx,%r10)
	setne	%dil
	movq	16(%rsi,%rdi,8), %rdx
	cmpq	%rax, %rdx
	cmovbq	%rdx, %rax
	cmpq	%r9, %rcx
	sete	%dl
	cmpl	%r11d, %r8d
	sete	%r10b
	testb	%r10b, %dl
	jne	.LBB15_5
	movq	%rax, 48(%rsp)
	movl	%r11d, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	%r9, %rdx
	movl	%r8d, %r9d
	xorl	%r8d, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E
.LBB15_5:
	nop
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB15_6:
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB15_7:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%rax, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB15_8:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%r10, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena11ensure_hash17h30fd789d47a64470E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena11ensure_hash17h30fd789d47a64470E,unique,16
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena11ensure_hash17h30fd789d47a64470E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena11ensure_hash17h30fd789d47a64470E:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena11ensure_hash17h30fd789d47a64470E
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	2112(%rcx), %rax
	cmpq	2072(%rcx), %rax
	jne	.LBB16_2
	movq	2080(%rcx), %rax
	cmpq	%rax, 2120(%rcx)
	jne	.LBB16_2
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	jmp	_ZN26hashrope_diagnostic_slot_a4rope5Arena17ensure_hash_inner17h09315aac70f25a18E
.LBB16_2:
	leaq	anon.3126157283a31055444fc45c79212b1f.37(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena11equal_range17h9e898da6cfece7fbE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena11equal_range17h9e898da6cfece7fbE,unique,17
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena11equal_range17h9e898da6cfece7fbE
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena11equal_range17h9e898da6cfece7fbE:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena11equal_range17h9e898da6cfece7fbE
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$80, %rsp
	.seh_stackalloc 80
	.seh_endprologue
	movl	128(%rsp), %eax
	movl	136(%rsp), %r10d
	movq	144(%rsp), %r11
	movq	152(%rsp), %rsi
	movq	%rsi, 64(%rsp)
	movq	%r11, 56(%rsp)
	movl	%r10d, 48(%rsp)
	movl	%eax, 40(%rsp)
	movq	%rcx, 32(%rsp)
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena16lcp_range_across17h4410a1b2238bfc16E
	cmpq	%rsi, %rax
	sete	%al
	.seh_startepilogue
	addq	$80, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena11make_repeat17h97d110bb9b6bcb49E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena11make_repeat17h97d110bb9b6bcb49E,unique,18
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena11make_repeat17h97d110bb9b6bcb49E:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena11make_repeat17h97d110bb9b6bcb49E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	testq	%r8, %r8
	je	.LBB18_1
	movq	%r8, %rsi
	cmpq	$1, %r8
	jne	.LBB18_3
	movl	$1, %eax
	jmp	.LBB18_14
.LBB18_1:
	xorl	%eax, %eax
	jmp	.LBB18_14
.LBB18_3:
	movl	%edx, %eax
	movq	16(%rcx), %rbx
	cmpq	%rax, %rbx
	jbe	.LBB18_6
	movq	8(%rcx), %r9
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	leaq	(%r9,%rax), %r8
	movl	(%r9,%rax), %r9d
	testl	%r9d, %r9d
	je	.LBB18_7
	cmpl	$1, %r9d
	leaq	24(%r8), %rax
	movq	32(%r8), %r15
	movq	(%rax), %rdi
	movq	$-1, %rax
	cmpb	$0, 2128(%rcx)
	jne	.LBB18_10
.LBB18_9:
	xorl	%eax, %eax
	testl	%r9d, %r9d
	setne	%al
	movq	8(%r8,%rax,8), %r12
	leaq	24(%rcx), %rax
	movq	%rcx, %r14
	movq	%rax, %rcx
	movl	%edx, %ebp
	movq	%rdi, %rdx
	callq	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE
	movq	2072(%r14), %rbx
	movq	%rsi, %rcx
	movq	%rax, %rdx
	movq	%rbx, %r8
	callq	_ZN26hashrope_diagnostic_slot_a15polynomial_hash3phi17h9e9794fc8b05b4a7E
	mulq	%r12
	movq	%rdx, %r9
	movl	%ebp, %edx
	movl	$127, %ecx
	bsrq	%rbx, %rcx
	xorl	$63, %ecx
	movb	$64, %r8b
	subb	%cl, %r8b
	movq	%r9, %r10
	movl	%r8d, %ecx
	shrq	%cl, %r10
	movq	%rax, %r11
	shrdq	%cl, %r9, %r11
	xorl	%r9d, %r9d
	testb	$64, %r8b
	cmovneq	%r10, %r11
	cmovneq	%r9, %r10
	andq	%rbx, %rax
	addq	%r11, %rax
	adcq	$0, %r10
	movq	%rax, %r11
	shrdq	%cl, %r10, %r11
	shrq	%cl, %r10
	movq	%r14, %rcx
	testb	$64, %r8b
	cmoveq	%r11, %r10
	andq	%rbx, %rax
	addq	%r10, %rax
	cmpq	%rax, %rbx
	cmovaq	%r9, %rbx
	subq	%rbx, %rax
	movq	16(%r14), %rbx
.LBB18_10:
	cmpq	(%rcx), %rbx
	je	.LBB18_11
.LBB18_12:
	imulq	%rsi, %rdi
	imulq	%rsi, %r15
	movq	8(%rcx), %r8
	leaq	(%rbx,%rbx,2), %r9
	shlq	$4, %r9
	movl	$2, (%r8,%r9)
	movl	%edx, 4(%r8,%r9)
	movq	%rsi, 8(%r8,%r9)
	movq	%rax, 16(%r8,%r9)
	movq	%rdi, 24(%r8,%r9)
	movq	%r15, 32(%r8,%r9)
	movq	%rbx, %rax
	incq	%rax
	movq	%rax, 16(%rcx)
	movl	$1, %eax
	movl	%ebx, %edx
.LBB18_14:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB18_7:
	leaq	16(%r8), %rax
	movl	$1, %r15d
	movq	(%rax), %rdi
	movq	$-1, %rax
	cmpb	$0, 2128(%rcx)
	je	.LBB18_9
	jmp	.LBB18_10
.LBB18_11:
	movq	%rcx, %r14
	movl	%edx, %ebp
	movq	%rax, %r12
	callq	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hdbf86ebe580ab5daE
	movq	%r12, %rax
	movq	%r14, %rcx
	movl	%ebp, %edx
	jmp	.LBB18_12
.LBB18_6:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%rax, %rcx
	movq	%rbx, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena11node_height17h278e7991234695c3E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena11node_height17h278e7991234695c3E,unique,19
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena11node_height17h278e7991234695c3E:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena11node_height17h278e7991234695c3E
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movl	%edx, %eax
	movq	16(%rcx), %rdx
	movl	%eax, %eax
	cmpq	%rax, %rdx
	jbe	.LBB19_7
	movq	8(%rcx), %r8
	xorl	%esi, %esi
	.p2align	4
.LBB19_2:
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	leaq	(%r8,%rax), %r14
	movl	(%r8,%rax), %eax
	cmpl	$2, %eax
	jne	.LBB19_3
	movl	4(%r14), %eax
	incq	%rsi
	cmpq	%rax, %rdx
	ja	.LBB19_2
.LBB19_7:
	leaq	anon.3126157283a31055444fc45c79212b1f.45(%rip), %r8
	movq	%rax, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB19_3:
	testl	%eax, %eax
	je	.LBB19_5
	movl	4(%r14), %edx
	movq	%rcx, %rdi
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11node_height17h278e7991234695c3E
	movq	%rax, %rbx
	movl	8(%r14), %edx
	movq	%rdi, %rcx
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11node_height17h278e7991234695c3E
	cmpq	%rbx, %rax
	cmovaq	%rax, %rbx
	addq	%rbx, %rsi
	incq	%rsi
.LBB19_5:
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E,unique,20
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E:
.Lfunc_begin3:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$104, %rsp
	.seh_stackalloc 104
	leaq	96(%rsp), %rbp
	.seh_setframe %rbp, 96
	movaps	%xmm6, -16(%rbp)
	.seh_savexmm %xmm6, 80
	.seh_endprologue
	movq	$-2, -24(%rbp)
	movq	%rdx, %rdi
	movq	%rcx, %rsi
	movl	%r8d, %ecx
	movq	16(%rdx), %rdx
	cmpq	%rcx, %rdx
	jbe	.LBB20_11
	movq	%r9, %rbx
	movq	8(%rdi), %r8
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	leaq	(%r8,%rcx), %rax
	movl	(%r8,%rcx), %ecx
	testl	%ecx, %ecx
	je	.LBB20_12
	cmpl	$1, %ecx
	jne	.LBB20_18
	movl	4(%rax), %r14d
	cmpq	%r14, %rdx
	jbe	.LBB20_60
	movl	8(%rax), %r15d
	leaq	(%r14,%r14,2), %rax
	shlq	$4, %rax
	leaq	(%r8,%rax), %rcx
	xorl	%edx, %edx
	cmpl	$0, (%r8,%rax)
	setne	%dl
	movq	%rbx, %r9
	subq	16(%rcx,%rdx,8), %r9
	jne	.LBB20_5
	movl	$1, (%rsi)
	movl	%r14d, 4(%rsi)
	jmp	.LBB20_67
.LBB20_12:
	movq	32(%rax), %r14
	movq	40(%rax), %r15
	testq	%r15, %r15
	je	.LBB20_13
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$1, %edx
	movq	%r15, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB20_69
	movq	%rax, %r12
	jmp	.LBB20_16
.LBB20_18:
	movl	4(%rax), %r14d
	cmpq	%r14, %rdx
	jbe	.LBB20_60
	leaq	(%r14,%r14,2), %rcx
	shlq	$4, %rcx
	xorl	%edx, %edx
	cmpl	$0, (%r8,%rcx)
	leaq	(%r8,%rcx), %rcx
	setne	%dl
	movq	16(%rcx,%rdx,8), %rcx
	testq	%rcx, %rcx
	je	.LBB20_70
	movq	8(%rax), %r15
	movq	%rbx, %rax
	orq	%rcx, %rax
	shrq	$32, %rax
	je	.LBB20_21
	movq	%rbx, %rax
	xorl	%edx, %edx
	divq	%rcx
	movq	%rdx, %r9
	movq	%rax, %r12
	testq	%r9, %r9
	je	.LBB20_24
.LBB20_25:
	leaq	-56(%rbp), %rcx
	movq	%rdi, %rdx
	movl	%r14d, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E
	movl	-56(%rbp), %r13d
	movl	-52(%rbp), %ebx
	movl	-48(%rbp), %eax
	movl	%eax, -64(%rbp)
	movl	-44(%rbp), %eax
	movl	%eax, -32(%rbp)
	movq	%rdi, %rcx
	movl	%r14d, %edx
	movq	%r12, %r8
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11make_repeat17h97d110bb9b6bcb49E
	movq	2112(%rdi), %rcx
	cmpq	2072(%rdi), %rcx
	jne	.LBB20_71
	movq	2080(%rdi), %rcx
	cmpq	%rcx, 2120(%rdi)
	jne	.LBB20_71
	testb	$1, %al
	je	.LBB20_32
	testl	%r13d, %r13d
	je	.LBB20_29
	movq	%rdi, %rcx
	movl	%ebx, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE
	movl	%eax, %ebx
	jmp	.LBB20_31
.LBB20_5:
	leaq	-56(%rbp), %rcx
	movq	%rdi, %rdx
	jae	.LBB20_6
	movl	%r14d, %r8d
	movq	%rbx, %r9
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E
	movq	2112(%rdi), %rax
	cmpq	2072(%rdi), %rax
	jne	.LBB20_71
	movq	2080(%rdi), %rax
	cmpq	%rax, 2120(%rdi)
	jne	.LBB20_71
	movsd	-56(%rbp), %xmm6
	cmpl	$0, -48(%rbp)
	je	.LBB20_66
	movl	-44(%rbp), %edx
	movq	%rdi, %rcx
	movl	%r15d, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE
	movl	%eax, %r15d
.LBB20_66:
	movlps	%xmm6, (%rsi)
.LBB20_67:
	movl	$1, 8(%rsi)
	movl	%r15d, 12(%rsi)
	jmp	.LBB20_68
.LBB20_13:
	movl	$1, %r12d
.LBB20_16:
	movq	%r12, %rcx
	movq	%r14, %rdx
	movq	%r15, %r8
	callq	memcpy
	cmpq	%rbx, %r15
	movq	%r15, -64(%rbp)
	movq	%r12, -32(%rbp)
	jb	.LBB20_17
	testq	%rbx, %rbx
	jns	.LBB20_42
	xorl	%r14d, %r14d
.LBB20_41:
.Ltmp38:
	movq	%r14, %rcx
	movq	%rbx, %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
.Ltmp39:
	jmp	.LBB20_50
.LBB20_42:
	je	.LBB20_43
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$1, %r14d
	movl	$1, %edx
	movq	%rbx, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB20_41
	movq	%rax, %rcx
	jmp	.LBB20_46
.LBB20_21:
	movl	%ebx, %eax
	xorl	%edx, %edx
	divl	%ecx
	movl	%edx, %r9d
	movl	%eax, %r12d
	testq	%r9, %r9
	jne	.LBB20_25
.LBB20_24:
	movq	%rdi, %rcx
	movl	%r14d, %edx
	movq	%r12, %r8
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11make_repeat17h97d110bb9b6bcb49E
	movl	%eax, %ebx
	movl	%edx, %r13d
	subq	%r12, %r15
	movq	%rdi, %rcx
	movl	%r14d, %edx
	movq	%r15, %r8
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11make_repeat17h97d110bb9b6bcb49E
	movl	%ebx, (%rsi)
	movl	%r13d, 4(%rsi)
	movl	%eax, 8(%rsi)
	movl	%edx, 12(%rsi)
	jmp	.LBB20_68
.LBB20_6:
	movl	%r15d, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E
	movq	2112(%rdi), %rax
	cmpq	2072(%rdi), %rax
	jne	.LBB20_71
	movq	2080(%rdi), %rax
	cmpq	%rax, 2120(%rdi)
	jne	.LBB20_71
	movsd	-48(%rbp), %xmm6
	cmpl	$0, -56(%rbp)
	je	.LBB20_10
	movl	-52(%rbp), %r8d
	movq	%rdi, %rcx
	movl	%r14d, %edx
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE
	movl	%eax, %r14d
.LBB20_10:
	movl	$1, (%rsi)
	movl	%r14d, 4(%rsi)
	movlps	%xmm6, 8(%rsi)
	jmp	.LBB20_68
.LBB20_43:
	movl	$1, %ecx
.LBB20_46:
	movq	%rbx, -56(%rbp)
	movq	%rcx, -48(%rbp)
	movq	%r12, %rdx
	movq	%rbx, %r8
	callq	memcpy
	movq	%rbx, -40(%rbp)
.Ltmp32:
	leaq	-56(%rbp), %rdx
	movq	%rdi, %rcx
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E
.Ltmp33:
	movl	%eax, %r14d
	movq	-32(%rbp), %rax
	leaq	(%rax,%rbx), %r12
	movq	-64(%rbp), %r15
	subq	%rbx, %r15
	jns	.LBB20_54
	xorl	%ebx, %ebx
.LBB20_49:
.Ltmp36:
	movq	%rbx, %rcx
	movq	%r15, %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
.Ltmp37:
	jmp	.LBB20_50
.LBB20_54:
	movl	$1, %ecx
	je	.LBB20_57
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$1, %ebx
	movl	$1, %edx
	movq	%r15, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB20_49
	movq	%rax, %rcx
.LBB20_57:
	movq	%r15, -56(%rbp)
	movq	%rcx, -48(%rbp)
	movq	%r12, %rdx
	movq	%r15, %r8
	callq	memcpy
	movq	%r15, -40(%rbp)
.Ltmp34:
	leaq	-56(%rbp), %rdx
	movq	%rdi, %rcx
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E
.Ltmp35:
	movl	$1, (%rsi)
	movl	%r14d, 4(%rsi)
	movl	$1, 8(%rsi)
	movl	%eax, 12(%rsi)
	movq	-64(%rbp), %rdx
	testq	%rdx, %rdx
	je	.LBB20_68
	movl	$1, %r8d
	movq	-32(%rbp), %rcx
	movaps	-16(%rbp), %xmm6
	.seh_startepilogue
	addq	$104, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	jmp	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB20_29:
	movl	%edx, %ebx
.LBB20_31:
	movl	$1, %r13d
.LBB20_32:
	notq	%r12
	addq	%r12, %r15
	movq	%rdi, %rcx
	movl	%r14d, %edx
	movq	%r15, %r8
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11make_repeat17h97d110bb9b6bcb49E
	movq	2112(%rdi), %rcx
	cmpq	2072(%rdi), %rcx
	jne	.LBB20_71
	movq	2080(%rdi), %rcx
	cmpq	%rcx, 2120(%rdi)
	jne	.LBB20_71
	movl	%edx, %r8d
	cmpl	$0, -64(%rbp)
	je	.LBB20_38
	testb	$1, %al
	movl	$1, %eax
	je	.LBB20_36
	movq	%rdi, %rcx
	movl	-32(%rbp), %edx
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE
	movl	%eax, %r8d
	movl	$1, %eax
	jmp	.LBB20_38
.LBB20_36:
	movl	-32(%rbp), %r8d
.LBB20_38:
	movl	%r13d, (%rsi)
	movl	%ebx, 4(%rsi)
	movl	%eax, 8(%rsi)
	movl	%r8d, 12(%rsi)
.LBB20_68:
	movaps	-16(%rbp), %xmm6
	.seh_startepilogue
	addq	$104, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.LBB20_71:
	leaq	anon.3126157283a31055444fc45c79212b1f.37(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB20_17:
.Ltmp40:
	leaq	anon.3126157283a31055444fc45c79212b1f.47(%rip), %r9
	xorl	%ecx, %ecx
	movq	%rbx, %rdx
	movq	%r15, %r8
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.Ltmp41:
.LBB20_50:
	ud2
.LBB20_11:
	leaq	anon.3126157283a31055444fc45c79212b1f.46(%rip), %r8
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB20_60:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%r14, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB20_70:
	leaq	anon.3126157283a31055444fc45c79212b1f.48(%rip), %rcx
	callq	_ZN4core9panicking11panic_const23panic_const_div_by_zero17hdceffd214664eedfE
.LBB20_69:
	movl	$1, %ecx
	movq	%r15, %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
	int3
	.seh_handlerdata
	.long	$cppxdata$_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E@IMGREL
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E,unique,20
	.seh_endproc
	.def	"?dtor$51@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$51@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E@4HA":
.seh_proc "?dtor$51@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E@4HA"
.LBB20_51:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	leaq	96(%rdx), %rbp
	movaps	%xmm6, 32(%rsp)
	.seh_savexmm %xmm6, 32
	.seh_endprologue
	movq	-64(%rbp), %rdx
	testq	%rdx, %rdx
	je	.LBB20_53
	movl	$1, %r8d
	movq	-32(%rbp), %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB20_53:
	movaps	32(%rsp), %xmm6
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.Lfunc_end3:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E,unique,20
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E,unique,3
	.p2align	2, 0x0
$cppxdata$_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E:
	.long	429065506
	.long	1
	.long	$stateUnwindMap$_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E@IMGREL
	.long	0
	.long	0
	.long	9
	.long	$ip2state$_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E@IMGREL
	.long	72
	.long	0
	.long	1
$stateUnwindMap$_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E:
	.long	-1
	.long	"?dtor$51@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E@4HA"@IMGREL
$ip2state$_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E:
	.long	.Lfunc_begin3@IMGREL
	.long	-1
	.long	.Ltmp38@IMGREL+1
	.long	0
	.long	.Ltmp39@IMGREL+1
	.long	-1
	.long	.Ltmp32@IMGREL+1
	.long	0
	.long	.Ltmp37@IMGREL+1
	.long	-1
	.long	.Ltmp34@IMGREL+1
	.long	0
	.long	.Ltmp35@IMGREL+1
	.long	-1
	.long	.Ltmp40@IMGREL+1
	.long	0
	.long	.Ltmp41@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E,unique,20

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena11substr_hash17h3b8f30c8fdf77acfE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena11substr_hash17h3b8f30c8fdf77acfE,unique,21
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena11substr_hash17h3b8f30c8fdf77acfE
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena11substr_hash17h3b8f30c8fdf77acfE:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena11substr_hash17h3b8f30c8fdf77acfE
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	2112(%rcx), %rax
	cmpq	2072(%rcx), %rax
	jne	.LBB21_4
	movq	2080(%rcx), %rax
	cmpq	%rax, 2120(%rcx)
	jne	.LBB21_4
	movq	80(%rsp), %rax
	testq	%rax, %rax
	setne	%r10b
	testb	%dl, %r10b
	je	.LBB21_5
	movl	%r8d, %edx
	movq	%r9, %r8
	movq	%rax, %r9
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	jmp	_ZN26hashrope_diagnostic_slot_a4rope5Arena10hash_range17he5099a48ea978d26E
.LBB21_5:
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB21_4:
	leaq	anon.3126157283a31055444fc45c79212b1f.37(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena12equal_across17h1407222e31fb6a69E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena12equal_across17h1407222e31fb6a69E,unique,22
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena12equal_across17h1407222e31fb6a69E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena12equal_across17h1407222e31fb6a69E:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena12equal_across17h1407222e31fb6a69E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$64, %rsp
	.seh_stackalloc 64
	.seh_endprologue
	movl	%edx, %eax
	movq	8(%rcx), %rdi
	movq	16(%rcx), %rdx
	testb	$1, %al
	je	.LBB22_1
	movl	%r8d, %r10d
	cmpq	%r10, %rdx
	jbe	.LBB22_18
	leaq	(%r10,%r10,2), %r10
	shlq	$4, %r10
	leaq	(%rdi,%r10), %r11
	xorl	%esi, %esi
	cmpl	$0, (%rdi,%r10)
	setne	%sil
	movq	16(%r11,%rsi,8), %rsi
	jmp	.LBB22_4
.LBB22_1:
	xorl	%esi, %esi
.LBB22_4:
	movl	168(%rsp), %ebx
	movl	160(%rsp), %ebp
	movq	8(%r9), %r14
	movq	16(%r9), %r10
	testb	$1, %bpl
	je	.LBB22_5
	movl	%ebx, %r11d
	cmpq	%r11, %r10
	jbe	.LBB22_19
	leaq	(%r11,%r11,2), %r11
	shlq	$4, %r11
	leaq	(%r14,%r11), %r15
	xorl	%r12d, %r12d
	cmpl	$0, (%r14,%r11)
	setne	%r12b
	movq	16(%r15,%r12,8), %r11
	cmpq	%r11, %rsi
	je	.LBB22_10
.LBB22_9:
	xorl	%eax, %eax
	jmp	.LBB22_17
.LBB22_5:
	xorl	%r11d, %r11d
	cmpq	%r11, %rsi
	jne	.LBB22_9
.LBB22_10:
	testl	%eax, %ebp
	je	.LBB22_11
	movl	%r8d, %eax
	cmpq	%rax, %rdx
	jbe	.LBB22_20
	movl	%ebx, %edx
	cmpq	%rdx, %r10
	jbe	.LBB22_21
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	leaq	(%rdi,%rax), %r10
	xorl	%r11d, %r11d
	cmpl	$0, (%rdi,%rax)
	setne	%r11b
	movq	16(%r10,%r11,8), %rax
	leaq	(%rdx,%rdx,2), %rdx
	shlq	$4, %rdx
	leaq	(%r14,%rdx), %r10
	xorl	%r11d, %r11d
	cmpl	$0, (%r14,%rdx)
	setne	%r11b
	movq	16(%r10,%r11,8), %rdx
	cmpq	%rax, %rdx
	cmovbq	%rdx, %rax
	cmpq	%r9, %rcx
	sete	%dl
	cmpl	%ebx, %r8d
	sete	%r10b
	testb	%r10b, %dl
	jne	.LBB22_16
	movq	%rax, 48(%rsp)
	movl	%ebx, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	%r9, %rdx
	movl	%r8d, %r9d
	xorl	%r8d, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E
	jmp	.LBB22_16
.LBB22_11:
	xorl	%eax, %eax
.LBB22_16:
	cmpq	%rsi, %rax
	sete	%al
.LBB22_17:
	.seh_startepilogue
	addq	$64, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB22_18:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%r10, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB22_19:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%r11, %rcx
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB22_20:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%rax, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB22_21:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%rdx, %rcx
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena13collect_bytes17hdc8ef44d8c149711E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena13collect_bytes17hdc8ef44d8c149711E,unique,23
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena13collect_bytes17hdc8ef44d8c149711E:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena13collect_bytes17hdc8ef44d8c149711E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rcx, %rdi
	movq	16(%rcx), %rbx
	movl	%edx, %ecx
	cmpq	%rcx, %rbx
	jbe	.LBB23_8
	movq	%r8, %rsi
	movq	8(%rdi), %r15
	.p2align	4
.LBB23_2:
	leaq	(%rcx,%rcx,2), %rax
	shlq	$4, %rax
	leaq	(%r15,%rax), %r14
	movl	(%r15,%rax), %eax
	cmpl	$1, %eax
	jne	.LBB23_3
	movl	4(%r14), %edx
	movq	%rdi, %rcx
	movq	%rsi, %r8
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena13collect_bytes17hdc8ef44d8c149711E
	movl	8(%r14), %ecx
	cmpq	%rcx, %rbx
	ja	.LBB23_2
.LBB23_8:
	leaq	anon.3126157283a31055444fc45c79212b1f.49(%rip), %r8
	movq	%rbx, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB23_3:
	testl	%eax, %eax
	jne	.LBB23_9
	movq	32(%r14), %rdx
	movq	40(%r14), %rdi
	movq	(%rsi), %rax
	movq	16(%rsi), %rcx
	subq	%rcx, %rax
	cmpq	%rax, %rdi
	ja	.LBB23_5
.LBB23_6:
	addq	8(%rsi), %rcx
	movq	%rdi, %r8
	callq	memcpy
	addq	%rdi, 16(%rsi)
	jmp	.LBB23_11
.LBB23_9:
	movq	8(%r14), %rbx
	testq	%rbx, %rbx
	je	.LBB23_11
	.p2align	4
.LBB23_10:
	movl	4(%r14), %edx
	movq	%rdi, %rcx
	movq	%rsi, %r8
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena13collect_bytes17hdc8ef44d8c149711E
	decq	%rbx
	jne	.LBB23_10
.LBB23_11:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB23_5:
	movq	%rcx, %rax
	movq	%rsi, %rcx
	movq	%rdx, %rbx
	movq	%rax, %rdx
	movq	%rdi, %r8
	callq	_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17h19c8325f6c8f9791E
	movq	%rbx, %rdx
	movq	16(%rsi), %rcx
	jmp	.LBB23_6
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena13make_internal17ha027843002ae76f3E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena13make_internal17ha027843002ae76f3E,unique,24
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena13make_internal17ha027843002ae76f3E:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena13make_internal17ha027843002ae76f3E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rcx, %rsi
	movl	%edx, %ecx
	movq	16(%rsi), %r14
	cmpq	%rcx, %r14
	jbe	.LBB24_11
	movl	%r8d, %edi
	movl	%edx, %ebx
	movq	8(%rsi), %rdx
	leaq	(%rcx,%rcx,2), %r8
	shlq	$4, %r8
	movl	(%rdx,%r8), %r9d
	xorl	%eax, %eax
	testl	%r9d, %r9d
	setne	%r10b
	movl	%edi, %ecx
	cmpq	%rcx, %r14
	jbe	.LBB24_11
	addq	%rdx, %r8
	movb	%r10b, %al
	leaq	(%rcx,%rcx,2), %r11
	shlq	$4, %r11
	movl	(%rdx,%r11), %r10d
	xorl	%ecx, %ecx
	testl	%r10d, %r10d
	setne	%cl
	movl	$1, %r15d
	movl	$1, %r12d
	testl	%r9d, %r9d
	je	.LBB24_4
	movq	32(%r8), %r12
.LBB24_4:
	addq	%r11, %rdx
	testl	%r10d, %r10d
	je	.LBB24_6
	movq	32(%rdx), %r15
.LBB24_6:
	movq	16(%r8,%rax,8), %rbp
	movq	16(%rdx,%rcx,8), %r13
	movq	$-1, %rax
	cmpb	$0, 2128(%rsi)
	jne	.LBB24_8
	leaq	24(%rsi), %rcx
	xorl	%eax, %eax
	testl	%r9d, %r9d
	setne	%al
	movq	8(%r8,%rax,8), %r14
	xorl	%eax, %eax
	testl	%r10d, %r10d
	setne	%al
	movq	%r12, 32(%rsp)
	movl	%ebx, %r12d
	movq	%rbp, %rbx
	movl	%edi, %ebp
	movq	8(%rdx,%rax,8), %rdi
	movq	16(%rdx,%rax,8), %rdx
	callq	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE
	mulq	%r14
	addq	%rdi, %rax
	movl	%ebp, %edi
	movq	%rbx, %rbp
	movl	%r12d, %ebx
	movq	32(%rsp), %r12
	adcq	$0, %rdx
	movq	2072(%rsi), %r8
	movl	$127, %r9d
	bsrq	%r8, %r9
	xorl	$63, %r9d
	movb	$64, %cl
	subb	%r9b, %cl
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	xorl	%r10d, %r10d
	testb	$64, %cl
	cmovneq	%rdx, %r9
	cmovneq	%r10, %rdx
	andq	%r8, %rax
	addq	%r9, %rax
	adcq	$0, %rdx
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	testb	$64, %cl
	cmoveq	%r9, %rdx
	andq	%r8, %rax
	addq	%rdx, %rax
	cmpq	%rax, %r8
	cmovaq	%r10, %r8
	subq	%r8, %rax
	movq	16(%rsi), %r14
.LBB24_8:
	cmpq	(%rsi), %r14
	je	.LBB24_9
.LBB24_10:
	addq	%rbp, %r13
	addq	%r12, %r15
	movq	8(%rsi), %rcx
	leaq	(%r14,%r14,2), %rdx
	shlq	$4, %rdx
	movl	$1, (%rcx,%rdx)
	movl	%ebx, 4(%rcx,%rdx)
	movl	%edi, 8(%rcx,%rdx)
	movq	%rax, 16(%rcx,%rdx)
	movq	%r13, 24(%rcx,%rdx)
	movq	%r15, 32(%rcx,%rdx)
	movq	%r14, %rax
	incq	%rax
	movq	%rax, 16(%rsi)
	movl	%r14d, %eax
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB24_9:
	movq	%rsi, %rcx
	movq	%rax, 32(%rsp)
	callq	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hdbf86ebe580ab5daE
	movq	32(%rsp), %rax
	jmp	.LBB24_10
.LBB24_11:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%r14, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena14validate_inner17h78360aa4f3e08b56E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena14validate_inner17h78360aa4f3e08b56E,unique,25
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena14validate_inner17h78360aa4f3e08b56E:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena14validate_inner17h78360aa4f3e08b56E
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$136, %rsp
	.seh_stackalloc 136
	.seh_endprologue
	movq	%rcx, %rbx
	movq	16(%rcx), %rdi
	movl	%edx, %ecx
	cmpq	%rcx, %rdi
	jbe	.LBB25_24
	movq	8(%rbx), %r14
	jmp	.LBB25_2
	.p2align	4
.LBB25_22:
	movq	%rbx, %rcx
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena14validate_inner17h78360aa4f3e08b56E
	movl	8(%rsi), %ecx
.LBB25_23:
	cmpq	%rcx, %rdi
	jbe	.LBB25_24
.LBB25_2:
	leaq	(%rcx,%rcx,2), %rax
	shlq	$4, %rax
	leaq	(%r14,%rax), %rsi
	movl	(%r14,%rax), %eax
	cmpl	$1, %eax
	je	.LBB25_8
	cmpl	$2, %eax
	jne	.LBB25_4
	leaq	8(%rsi), %rax
	movq	%rax, 48(%rsp)
	movl	4(%rsi), %ecx
	cmpq	%rcx, %rdi
	jbe	.LBB25_38
	leaq	(%rcx,%rcx,2), %rax
	shlq	$4, %rax
	leaq	(%r14,%rax), %rdx
	movl	(%r14,%rax), %r8d
	xorl	%r9d, %r9d
	testl	%r8d, %r8d
	setne	%r9b
	movq	8(%rsi), %rax
	movq	16(%rdx,%r9,8), %r9
	imulq	%rax, %r9
	movq	%r9, 120(%rsp)
	cmpq	%r9, 24(%rsi)
	jne	.LBB25_30
	testl	%r8d, %r8d
	je	.LBB25_32
	movq	32(%rdx), %rdx
	imulq	%rax, %rdx
	movq	%rdx, 128(%rsp)
	cmpq	%rdx, 32(%rsi)
	je	.LBB25_36
	jmp	.LBB25_35
	.p2align	4
.LBB25_8:
	movl	4(%rsi), %edx
	cmpq	%rdx, %rdi
	jbe	.LBB25_40
	movl	8(%rsi), %ecx
	cmpq	%rcx, %rdi
	jbe	.LBB25_38
	leaq	(%rdx,%rdx,2), %r8
	shlq	$4, %r8
	leaq	(%r14,%r8), %rax
	movl	(%r14,%r8), %r8d
	xorl	%r11d, %r11d
	testl	%r8d, %r8d
	setne	%r11b
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	leaq	(%r14,%rcx), %r9
	movl	(%r14,%rcx), %r10d
	xorl	%ecx, %ecx
	testl	%r10d, %r10d
	setne	%cl
	movq	16(%r9,%rcx,8), %rcx
	addq	16(%rax,%r11,8), %rcx
	movq	%rcx, 104(%rsp)
	cmpq	%rcx, 24(%rsi)
	jne	.LBB25_11
	movl	$1, %ecx
	movl	$1, %r11d
	testl	%r8d, %r8d
	je	.LBB25_14
	movq	32(%rax), %r11
.LBB25_14:
	testl	%r10d, %r10d
	je	.LBB25_16
	movq	32(%r9), %rcx
.LBB25_16:
	addq	%r11, %rcx
	movq	%rcx, 112(%rsp)
	cmpq	%rcx, 32(%rsi)
	jne	.LBB25_17
	movq	%rcx, 88(%rsp)
	testl	%r8d, %r8d
	je	.LBB25_19
	movq	32(%rax), %rax
	movq	%rax, 48(%rsp)
	cmpq	$2, %rcx
	jbe	.LBB25_22
	jmp	.LBB25_25
.LBB25_32:
	movl	$1, %edx
	imulq	%rax, %rdx
	movq	%rdx, 128(%rsp)
	cmpq	%rdx, 32(%rsi)
	jne	.LBB25_35
.LBB25_36:
	cmpq	$1, %rax
	ja	.LBB25_23
	jmp	.LBB25_37
.LBB25_19:
	movl	$1, %eax
	movq	%rax, 48(%rsp)
	cmpq	$2, %rcx
	jbe	.LBB25_22
.LBB25_25:
	leaq	(%rcx,%rcx), %r9
	leaq	(,%rax,8), %r8
	subq	%rax, %r8
	cmpq	%r8, %r9
	ja	.LBB25_39
	leaq	(%rcx,%rcx,4), %rax
	cmpq	%rax, %r8
	jbe	.LBB25_22
	leaq	48(%rsp), %rax
	movq	%rax, 56(%rsp)
	leaq	_ZN4core3fmt3num3imp52_$LT$impl$u20$core..fmt..Display$u20$for$u20$u64$GT$3fmt17h9f4f228998531a48E(%rip), %rax
	movq	%rax, 64(%rsp)
	leaq	88(%rsp), %rcx
	movq	%rcx, 72(%rsp)
	movq	%rax, 80(%rsp)
	leaq	anon.3126157283a31055444fc45c79212b1f.59(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.60(%rip), %r8
	leaq	56(%rsp), %rdx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB25_4:
	movq	40(%rsi), %rax
	movq	%rax, 96(%rsp)
	cmpq	%rax, 16(%rsi)
	jne	.LBB25_5
	.seh_startepilogue
	addq	$136, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.LBB25_30:
	addq	$24, %rsi
	leaq	anon.3126157283a31055444fc45c79212b1f.62(%rip), %rax
	movq	%rax, 40(%rsp)
	movq	$47, 32(%rsp)
	leaq	anon.3126157283a31055444fc45c79212b1f.61(%rip), %r9
	leaq	120(%rsp), %r8
	xorl	%ecx, %ecx
	movq	%rsi, %rdx
	callq	_ZN4core9panicking13assert_failed17h05de43114f7e23d0E
.LBB25_11:
	addq	$24, %rsi
	leaq	anon.3126157283a31055444fc45c79212b1f.54(%rip), %rax
	movq	%rax, 40(%rsp)
	movq	$43, 32(%rsp)
	leaq	anon.3126157283a31055444fc45c79212b1f.53(%rip), %r9
	leaq	104(%rsp), %r8
	xorl	%ecx, %ecx
	movq	%rsi, %rdx
	callq	_ZN4core9panicking13assert_failed17h05de43114f7e23d0E
.LBB25_35:
	addq	$32, %rsi
	leaq	anon.3126157283a31055444fc45c79212b1f.64(%rip), %rax
	movq	%rax, 40(%rsp)
	movq	$53, 32(%rsp)
	leaq	anon.3126157283a31055444fc45c79212b1f.63(%rip), %r9
	leaq	128(%rsp), %r8
	xorl	%ecx, %ecx
	movq	%rsi, %rdx
	callq	_ZN4core9panicking13assert_failed17h05de43114f7e23d0E
.LBB25_17:
	addq	$32, %rsi
	leaq	anon.3126157283a31055444fc45c79212b1f.56(%rip), %rax
	movq	%rax, 40(%rsp)
	movq	$49, 32(%rsp)
	leaq	anon.3126157283a31055444fc45c79212b1f.55(%rip), %r9
	leaq	112(%rsp), %r8
	xorl	%ecx, %ecx
	movq	%rsi, %rdx
	callq	_ZN4core9panicking13assert_failed17h05de43114f7e23d0E
.LBB25_37:
	leaq	48(%rsp), %rax
	movq	%rax, 56(%rsp)
	leaq	_ZN44_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$3fmt17hdc7922d22f1eccf3E(%rip), %rax
	movq	%rax, 64(%rsp)
	leaq	anon.3126157283a31055444fc45c79212b1f.65(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.66(%rip), %r8
	leaq	56(%rsp), %rdx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB25_39:
	leaq	48(%rsp), %rax
	movq	%rax, 56(%rsp)
	leaq	_ZN4core3fmt3num3imp52_$LT$impl$u20$core..fmt..Display$u20$for$u20$u64$GT$3fmt17h9f4f228998531a48E(%rip), %rax
	movq	%rax, 64(%rsp)
	leaq	88(%rsp), %rcx
	movq	%rcx, 72(%rsp)
	movq	%rax, 80(%rsp)
	leaq	anon.3126157283a31055444fc45c79212b1f.57(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.58(%rip), %r8
	leaq	56(%rsp), %rdx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB25_5:
	addq	$16, %rsi
	leaq	anon.3126157283a31055444fc45c79212b1f.52(%rip), %rax
	movq	%rax, 40(%rsp)
	movq	$35, 32(%rsp)
	leaq	anon.3126157283a31055444fc45c79212b1f.51(%rip), %r9
	leaq	96(%rsp), %r8
	xorl	%ecx, %ecx
	movq	%rsi, %rdx
	callq	_ZN4core9panicking13assert_failed17h05de43114f7e23d0E
.LBB25_24:
	leaq	anon.3126157283a31055444fc45c79212b1f.50(%rip), %r8
	movq	%rdi, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB25_38:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%rdi, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB25_40:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%rdx, %rcx
	movq	%rdi, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena16lcp_range_across17h4410a1b2238bfc16E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena16lcp_range_across17h4410a1b2238bfc16E,unique,26
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena16lcp_range_across17h4410a1b2238bfc16E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena16lcp_range_across17h4410a1b2238bfc16E:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena16lcp_range_across17h4410a1b2238bfc16E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movl	%r8d, %r10d
	testb	$1, %dl
	je	.LBB26_1
	movq	16(%rcx), %r11
	movl	%r10d, %eax
	cmpq	%rax, %r11
	jbe	.LBB26_24
	movq	8(%rcx), %r8
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	leaq	(%r8,%rax), %r11
	xorl	%esi, %esi
	cmpl	$0, (%r8,%rax)
	setne	%sil
	movq	16(%r11,%rsi,8), %rbx
	jmp	.LBB26_4
.LBB26_1:
	xorl	%ebx, %ebx
.LBB26_4:
	movl	160(%rsp), %esi
	movl	152(%rsp), %edi
	movq	144(%rsp), %r8
	testb	$1, %dil
	je	.LBB26_5
	movq	16(%r8), %r11
	movl	%esi, %eax
	cmpq	%rax, %r11
	jbe	.LBB26_24
	movq	8(%r8), %r11
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	leaq	(%r11,%rax), %r14
	xorl	%r15d, %r15d
	cmpl	$0, (%r11,%rax)
	setne	%r15b
	movq	16(%r14,%r15,8), %r14
	jmp	.LBB26_8
.LBB26_5:
	xorl	%r14d, %r14d
.LBB26_8:
	subq	%r9, %rbx
	jb	.LBB26_25
	movq	176(%rsp), %rax
	cmpq	%rbx, %rax
	ja	.LBB26_25
	movq	168(%rsp), %r11
	subq	%r11, %r14
	jb	.LBB26_26
	cmpq	%r14, %rax
	ja	.LBB26_26
	testq	%rax, %rax
	je	.LBB26_13
	cmpq	%r8, %rcx
	jne	.LBB26_20
	testb	$1, %dl
	je	.LBB26_18
	testb	$1, %dil
	je	.LBB26_27
	cmpl	%esi, %r10d
	sete	%bl
	cmpq	%r11, %r9
	sete	%bpl
	testb	%bl, %bpl
	je	.LBB26_20
	jmp	.LBB26_23
.LBB26_13:
	xorl	%eax, %eax
	jmp	.LBB26_23
.LBB26_18:
	movl	%edi, %ebx
	xorb	$1, %bl
	cmpq	%r11, %r9
	sete	%bpl
	testb	%bl, %bpl
	jne	.LBB26_23
.LBB26_20:
	testb	$1, %dl
	je	.LBB26_28
	testb	$1, %dil
	je	.LBB26_27
	movq	%rax, 48(%rsp)
	movl	%esi, 40(%rsp)
	movq	%r11, 32(%rsp)
	movq	%r8, %rdx
	movq	%r9, %r8
	movl	%r10d, %r9d
	callq	_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E
.LBB26_23:
	nop
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB26_25:
	leaq	anon.3126157283a31055444fc45c79212b1f.67(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.68(%rip), %r8
	movl	$71, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB26_26:
	leaq	anon.3126157283a31055444fc45c79212b1f.69(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.70(%rip), %r8
	movl	$73, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB26_28:
	leaq	anon.3126157283a31055444fc45c79212b1f.71(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.LBB26_24:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%rax, %rcx
	movq	%r11, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB26_27:
	leaq	anon.3126157283a31055444fc45c79212b1f.72(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena17ensure_hash_inner17h09315aac70f25a18E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena17ensure_hash_inner17h09315aac70f25a18E,unique,27
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena17ensure_hash_inner17h09315aac70f25a18E:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena17ensure_hash_inner17h09315aac70f25a18E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movl	%edx, %esi
	movq	16(%rcx), %rdx
	cmpq	%rsi, %rdx
	jbe	.LBB27_22
	movq	%rcx, %rdi
	movq	8(%rcx), %rax
	leaq	(%rsi,%rsi,2), %r12
	shlq	$4, %r12
	movl	(%rax,%r12), %ecx
	addq	%r12, %rax
	xorl	%edx, %edx
	testl	%ecx, %ecx
	setne	%dl
	cmpq	$-1, 8(%rax,%rdx,8)
	jne	.LBB27_15
	testl	%ecx, %ecx
	je	.LBB27_7
	cmpl	$2, %ecx
	jne	.LBB27_4
	movl	4(%rax), %ebx
	movq	8(%rax), %r14
	movq	%rdi, %rcx
	movl	%ebx, %edx
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena17ensure_hash_inner17h09315aac70f25a18E
	movq	16(%rdi), %rdx
	cmpq	%rbx, %rdx
	jbe	.LBB27_20
	movq	8(%rdi), %rax
	leaq	(%rbx,%rbx,2), %rcx
	shlq	$4, %rcx
	leaq	(%rax,%rcx), %rdx
	xorl	%r8d, %r8d
	cmpl	$0, (%rax,%rcx)
	setne	%r8b
	movq	8(%rdx,%r8,8), %r15
	movq	16(%rdx,%r8,8), %rdx
	leaq	24(%rdi), %rcx
	callq	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE
	movq	2072(%rdi), %rbx
	movq	%r14, %rcx
	movq	%rax, %rdx
	movq	%rbx, %r8
	callq	_ZN26hashrope_diagnostic_slot_a15polynomial_hash3phi17h9e9794fc8b05b4a7E
	mulq	%r15
	movl	$127, %r8d
	bsrq	%rbx, %r8
	xorl	$63, %r8d
	movb	$64, %cl
	subb	%r8b, %cl
	movq	%rdx, %r8
	shrq	%cl, %r8
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	xorl	%edx, %edx
	testb	$64, %cl
	cmovneq	%r8, %r9
	cmovneq	%rdx, %r8
	andq	%rbx, %rax
	addq	%r9, %rax
	adcq	$0, %r8
	movq	%rax, %r9
	shrdq	%cl, %r8, %r9
	shrq	%cl, %r8
	testb	$64, %cl
	cmoveq	%r9, %r8
	andq	%rbx, %rax
	addq	%r8, %rax
	cmpq	%rax, %rbx
	cmovaq	%rdx, %rbx
	subq	%rbx, %rax
	movq	16(%rdi), %rdx
	cmpq	%rsi, %rdx
	ja	.LBB27_14
	jmp	.LBB27_21
.LBB27_7:
	movq	40(%rax), %rbx
	testq	%rbx, %rbx
	je	.LBB27_8
	movq	32(%rax), %r15
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$1, %edx
	movq	%rbx, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB27_23
	movq	%rax, %r14
	movq	%rax, %rcx
	movq	%r15, %rdx
	movq	%rbx, %r8
	callq	memcpy
	movq	2072(%rdi), %r8
	movq	2080(%rdi), %r9
	movl	$127, %ecx
	bsrq	%r8, %rcx
	xorl	$-64, %ecx
	addl	$65, %ecx
	xorl	%r10d, %r10d
	xorl	%r11d, %r11d
	xorl	%eax, %eax
	.p2align	4
.LBB27_11:
	movzbl	(%r14,%r11), %r15d
	mulq	%r9
	addq	%r15, %rax
	adcq	$0, %rdx
	addq	$1, %rax
	adcq	$0, %rdx
	movq	%rax, %r15
	shrdq	%cl, %rdx, %r15
	shrq	%cl, %rdx
	testb	$64, %cl
	cmovneq	%rdx, %r15
	cmovneq	%r10, %rdx
	andq	%r8, %rax
	addq	%r15, %rax
	adcq	$0, %rdx
	movq	%rax, %r15
	shrdq	%cl, %rdx, %r15
	shrq	%cl, %rdx
	testb	$64, %cl
	cmoveq	%r15, %rdx
	andq	%r8, %rax
	addq	%rdx, %rax
	cmpq	%rax, %r8
	movq	%r8, %rdx
	cmovaq	%r10, %rdx
	subq	%rdx, %rax
	incq	%r11
	cmpq	%r11, %rbx
	jne	.LBB27_11
	movl	$1, %r8d
	movq	%r14, %rcx
	movq	%rbx, %rdx
	movq	%rax, %rbx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	movq	%rbx, %rax
	movq	16(%rdi), %rdx
	cmpq	%rsi, %rdx
	ja	.LBB27_14
	jmp	.LBB27_21
.LBB27_4:
	movl	4(%rax), %r14d
	movl	8(%rax), %ebx
	movq	%rdi, %rcx
	movl	%r14d, %edx
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena17ensure_hash_inner17h09315aac70f25a18E
	movq	%rdi, %rcx
	movl	%ebx, %edx
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena17ensure_hash_inner17h09315aac70f25a18E
	movq	16(%rdi), %rdx
	cmpq	%r14, %rdx
	jbe	.LBB27_16
	cmpq	%rbx, %rdx
	jbe	.LBB27_17
	leaq	24(%rdi), %rcx
	movq	8(%rdi), %rax
	leaq	(%r14,%r14,2), %rdx
	shlq	$4, %rdx
	xorl	%r8d, %r8d
	cmpl	$0, (%rax,%rdx)
	leaq	(%rax,%rdx), %rdx
	setne	%r8b
	movq	8(%rdx,%r8,8), %r14
	leaq	(%rbx,%rbx,2), %rdx
	shlq	$4, %rdx
	xorl	%r8d, %r8d
	cmpl	$0, (%rax,%rdx)
	leaq	(%rax,%rdx), %rax
	setne	%r8b
	movq	8(%rax,%r8,8), %rbx
	movq	16(%rax,%r8,8), %rdx
	callq	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE
	mulq	%r14
	addq	%rbx, %rax
	adcq	$0, %rdx
	movq	2072(%rdi), %r8
	movl	$127, %r9d
	bsrq	%r8, %r9
	xorl	$63, %r9d
	movb	$64, %cl
	subb	%r9b, %cl
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	xorl	%r10d, %r10d
	testb	$64, %cl
	cmovneq	%rdx, %r9
	cmovneq	%r10, %rdx
	andq	%r8, %rax
	addq	%r9, %rax
	adcq	$0, %rdx
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	testb	$64, %cl
	cmoveq	%r9, %rdx
	andq	%r8, %rax
	addq	%rdx, %rax
	cmpq	%rax, %r8
	cmovaq	%r10, %r8
	subq	%r8, %rax
	movq	16(%rdi), %rdx
	cmpq	%rsi, %rdx
	jbe	.LBB27_21
.LBB27_14:
	movq	8(%rdi), %rcx
	leaq	(%rcx,%r12), %rdx
	xorl	%r8d, %r8d
	cmpl	$0, (%rcx,%r12)
	setne	%r8b
	movq	%rax, 8(%rdx,%r8,8)
.LBB27_15:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB27_8:
	xorl	%eax, %eax
	movq	16(%rdi), %rdx
	cmpq	%rsi, %rdx
	ja	.LBB27_14
.LBB27_21:
	leaq	anon.3126157283a31055444fc45c79212b1f.73(%rip), %r8
	movq	%rsi, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB27_22:
	leaq	anon.3126157283a31055444fc45c79212b1f.40(%rip), %r8
	movq	%rsi, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB27_20:
	leaq	anon.3126157283a31055444fc45c79212b1f.40(%rip), %r8
	movq	%rbx, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB27_16:
	leaq	anon.3126157283a31055444fc45c79212b1f.40(%rip), %r8
	movq	%r14, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB27_17:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%rbx, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB27_23:
	movl	$1, %ecx
	movq	%rbx, %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena18equal_range_across17h7ae9b88637ee9d66E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena18equal_range_across17h7ae9b88637ee9d66E,unique,28
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena18equal_range_across17h7ae9b88637ee9d66E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena18equal_range_across17h7ae9b88637ee9d66E:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena18equal_range_across17h7ae9b88637ee9d66E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	movq	128(%rsp), %rax
	movl	136(%rsp), %r10d
	movl	144(%rsp), %r11d
	movq	152(%rsp), %rsi
	movq	160(%rsp), %rdi
	movq	%rdi, 64(%rsp)
	movq	%rsi, 56(%rsp)
	movl	%r11d, 48(%rsp)
	movl	%r10d, 40(%rsp)
	movq	%rax, 32(%rsp)
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena16lcp_range_across17h4410a1b2238bfc16E
	cmpq	%rdi, %rax
	sete	%al
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena3lcp17h8f1137f97e70fbb5E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena3lcp17h8f1137f97e70fbb5E,unique,29
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena3lcp17h8f1137f97e70fbb5E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena3lcp17h8f1137f97e70fbb5E:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena3lcp17h8f1137f97e70fbb5E
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$64, %rsp
	.seh_stackalloc 64
	.seh_endprologue
	testl	%edx, %r9d
	je	.LBB29_6
	movl	%r8d, %r10d
	movl	%r8d, %eax
	movq	16(%rcx), %rdx
	cmpq	%rax, %rdx
	jbe	.LBB29_7
	movl	112(%rsp), %r8d
	movl	%r8d, %r9d
	cmpq	%r9, %rdx
	jbe	.LBB29_8
	movq	8(%rcx), %rdx
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	leaq	(%rdx,%rax), %r11
	xorl	%esi, %esi
	cmpl	$0, (%rdx,%rax)
	setne	%sil
	movq	16(%r11,%rsi,8), %rax
	leaq	(%r9,%r9,2), %r9
	shlq	$4, %r9
	leaq	(%rdx,%r9), %r11
	xorl	%esi, %esi
	cmpl	$0, (%rdx,%r9)
	setne	%sil
	movq	16(%r11,%rsi,8), %rdx
	cmpq	%rax, %rdx
	cmovbq	%rdx, %rax
	cmpl	%r8d, %r10d
	je	.LBB29_5
	movq	%rax, 48(%rsp)
	movl	%r8d, 40(%rsp)
	movq	$0, 32(%rsp)
	movq	%rcx, %rdx
	xorl	%r8d, %r8d
	movl	%r10d, %r9d
	callq	_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E
.LBB29_5:
	nop
	.seh_startepilogue
	addq	$64, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB29_6:
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$64, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB29_7:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%rax, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB29_8:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%r9, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena3new17h5716ea7726a36750E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena3new17h5716ea7726a36750E,unique,30
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena3new17h5716ea7726a36750E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena3new17h5716ea7726a36750E:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena3new17h5716ea7726a36750E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$2088, %rsp
	.seh_stackalloc 2088
	.seh_endprologue
	movq	%rcx, %rsi
	movabsq	$2305843009213693951, %rdi
	leaq	48(%rsp), %rcx
	movl	$2040, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	$1, 40(%rsp)
	movl	$1, %eax
	movl	$131, %r8d
	movabsq	$-2305843009213693951, %r9
	movl	$1, %r10d
	.p2align	4
.LBB30_1:
	mulq	%r8
	movq	%rax, %rcx
	shrq	$61, %rax
	leaq	(%rax,%rdx,8), %rax
	andq	%rdi, %rcx
	addq	%rax, %rcx
	movq	%rcx, %rax
	shrq	$61, %rax
	andq	%rdi, %rcx
	addq	%rax, %rcx
	leaq	(%rcx,%r9), %rax
	cmpq	%rdi, %rcx
	cmovbq	%rcx, %rax
	movq	%rax, 40(%rsp,%r10,8)
	incq	%r10
	cmpq	$256, %r10
	jne	.LBB30_1
	movq	$0, (%rsi)
	movq	$8, 8(%rsi)
	movq	$0, 16(%rsi)
	leaq	24(%rsi), %rcx
	leaq	40(%rsp), %rdx
	movl	$2048, %r8d
	callq	memcpy
	movq	%rdi, 2072(%rsi)
	movq	$131, 2080(%rsi)
	movq	$0, 2088(%rsi)
	movq	$0, 2104(%rsi)
	movq	%rdi, 2112(%rsi)
	movq	$131, 2120(%rsi)
	movb	$0, 2128(%rsi)
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$2088, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE,unique,31
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE:
.Lfunc_begin4:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$88, %rsp
	.seh_stackalloc 88
	leaq	80(%rsp), %rbp
	.seh_setframe %rbp, 80
	.seh_endprologue
	movq	$-2, (%rbp)
	movq	16(%rcx), %rax
	movl	%edx, %r9d
	cmpq	%r9, %rax
	jbe	.LBB31_7
	movq	8(%rcx), %rdi
	leaq	(%r9,%r9,2), %r9
	shlq	$4, %r9
	leaq	(%rdi,%r9), %r10
	movl	(%rdi,%r9), %r11d
	testl	%r11d, %r11d
	je	.LBB31_2
	movq	32(%r10), %rsi
	movl	%r8d, %r9d
	cmpq	%r9, %rax
	jbe	.LBB31_7
.LBB31_5:
	leaq	(%r9,%r9,2), %r9
	shlq	$4, %r9
	leaq	(%rdi,%r9), %rax
	movl	(%rdi,%r9), %r9d
	testl	%r9d, %r9d
	je	.LBB31_6
	movq	32(%rax), %rdi
	addq	%rsi, %rdi
	cmpq	$3, %rdi
	jae	.LBB31_10
	jmp	.LBB31_59
.LBB31_2:
	movl	$1, %esi
	movl	%r8d, %r9d
	cmpq	%r9, %rax
	ja	.LBB31_5
.LBB31_7:
	leaq	anon.3126157283a31055444fc45c79212b1f.44(%rip), %r8
	movq	%r9, %rcx
	movq	%rax, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB31_6:
	movl	$1, %edi
	addq	%rsi, %rdi
	cmpq	$3, %rdi
	jb	.LBB31_59
.LBB31_10:
	leaq	(%rdi,%rdi), %r14
	leaq	(,%rsi,8), %rbx
	subq	%rsi, %rbx
	cmpq	%rbx, %r14
	ja	.LBB31_12
	leaq	(%rdi,%rdi,4), %rsi
	cmpq	%rsi, %rbx
	ja	.LBB31_12
.LBB31_59:
	.seh_startepilogue
	addq	$88, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	jmp	_ZN26hashrope_diagnostic_slot_a4rope5Arena13make_internal17ha027843002ae76f3E
.LBB31_12:
	movl	$1, %esi
	movl	$1, %edi
	testl	%r11d, %r11d
	je	.LBB31_14
	movq	32(%r10), %rdi
.LBB31_14:
	testl	%r9d, %r9d
	je	.LBB31_16
	movq	32(%rax), %rsi
.LBB31_16:
	cmpq	%rsi, %rdi
	jbe	.LBB31_17
	cmpl	$2, %r11d
	je	.LBB31_52
	cmpl	$1, %r11d
	jne	.LBB31_42
	movl	4(%r10), %esi
	movl	8(%r10), %edx
	movq	24(%r10), %rbx
	movq	32(%r10), %r14
	movb	$1, -2(%rbp)
	movq	%rbx, -32(%rbp)
	movq	%r14, -40(%rbp)
.Ltmp72:
	movq	%rcx, %rdi
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE
.Ltmp73:
	movb	$1, -2(%rbp)
	movq	%rbx, -32(%rbp)
	movq	%r14, -40(%rbp)
.Ltmp74:
	movq	%rdi, %rcx
	movl	%esi, %edx
	movl	%eax, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena7balance17hb683a88a0e15e0adE
.Ltmp75:
	jmp	.LBB31_58
.LBB31_17:
	cmpl	$2, %r9d
	je	.LBB31_31
	cmpl	$1, %r9d
	jne	.LBB31_19
	movl	4(%rax), %r8d
	movq	8(%rax), %rsi
	movq	24(%rax), %rbx
	movq	32(%rax), %r14
	movb	$1, -1(%rbp)
	movq	%rbx, -16(%rbp)
	movq	%r14, -24(%rbp)
.Ltmp54:
	movq	%rcx, %rdi
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE
.Ltmp55:
	movb	$1, -1(%rbp)
	movq	%rbx, -16(%rbp)
	movq	%r14, -24(%rbp)
.Ltmp56:
	movq	%rdi, %rcx
	movl	%eax, %edx
	movl	%esi, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena7balance17hb683a88a0e15e0adE
.Ltmp57:
	jmp	.LBB31_58
.LBB31_52:
	movl	%r8d, -44(%rbp)
	movl	4(%r10), %r14d
	movq	8(%r10), %r15
	movq	24(%r10), %rdi
	movq	32(%r10), %r13
	movq	%r15, %r12
	shrq	%r12
	movb	$1, -2(%rbp)
	movq	%rdi, -32(%rbp)
	movq	%r13, -40(%rbp)
.Ltmp60:
	movq	%rcx, %rsi
	movl	%r14d, %edx
	movq	%r12, %r8
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11make_repeat17h97d110bb9b6bcb49E
.Ltmp61:
	testb	$1, %al
	je	.LBB31_61
	movl	%edx, %ebx
	subq	%r12, %r15
	movb	$1, -2(%rbp)
	movq	%rdi, -32(%rbp)
	movq	%r13, -40(%rbp)
.Ltmp64:
	movq	%rsi, %rcx
	movl	%r14d, %edx
	movq	%r15, %r8
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11make_repeat17h97d110bb9b6bcb49E
.Ltmp65:
	testb	$1, %al
	je	.LBB31_62
	movb	$1, -2(%rbp)
	movq	%rdi, -32(%rbp)
	movq	%r13, -40(%rbp)
.Ltmp68:
	movq	%rsi, %rcx
	movl	-44(%rbp), %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE
.Ltmp69:
	movb	$1, -2(%rbp)
	movq	%rdi, -32(%rbp)
	movq	%r13, -40(%rbp)
.Ltmp70:
	movq	%rsi, %rcx
	movl	%ebx, %edx
	movl	%eax, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE
.Ltmp71:
	jmp	.LBB31_58
.LBB31_31:
	movl	%edx, -44(%rbp)
	movl	4(%rax), %r14d
	movq	8(%rax), %r15
	movq	24(%rax), %rdi
	movq	32(%rax), %r13
	movq	%r15, %r12
	shrq	%r12
	movb	$1, -1(%rbp)
	movq	%rdi, -16(%rbp)
	movq	%r13, -24(%rbp)
.Ltmp42:
	movq	%rcx, %rsi
	movl	%r14d, %edx
	movq	%r12, %r8
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11make_repeat17h97d110bb9b6bcb49E
.Ltmp43:
	testb	$1, %al
	je	.LBB31_37
	movl	%edx, %ebx
	subq	%r12, %r15
	movb	$1, -1(%rbp)
	movq	%rdi, -16(%rbp)
	movq	%r13, -24(%rbp)
.Ltmp46:
	movq	%rsi, %rcx
	movl	%r14d, %edx
	movq	%r15, %r8
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11make_repeat17h97d110bb9b6bcb49E
.Ltmp47:
	testb	$1, %al
	je	.LBB31_39
	movl	%edx, %r14d
	movb	$1, -1(%rbp)
	movq	%rdi, -16(%rbp)
	movq	%r13, -24(%rbp)
.Ltmp50:
	movq	%rsi, %rcx
	movl	-44(%rbp), %edx
	movl	%ebx, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE
.Ltmp51:
	movb	$1, -1(%rbp)
	movq	%rdi, -16(%rbp)
	movq	%r13, -24(%rbp)
.Ltmp52:
	movq	%rsi, %rcx
	movl	%eax, %edx
	movl	%r14d, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE
.Ltmp53:
	jmp	.LBB31_58
.LBB31_42:
	movl	%edx, %r14d
	movl	%r8d, %edi
	movq	%rcx, %r15
	movq	32(%r10), %r12
	movq	40(%r10), %rsi
	testq	%rsi, %rsi
	je	.LBB31_43
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$1, %edx
	movq	%rsi, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB31_60
	movq	%rax, %rbx
	jmp	.LBB31_46
.LBB31_19:
	movl	%edx, %r14d
	movl	%r8d, %edi
	movq	%rcx, %r15
	movq	32(%rax), %r12
	movq	40(%rax), %rsi
	testq	%rsi, %rsi
	je	.LBB31_20
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$1, %edx
	movq	%rsi, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB31_60
	movq	%rax, %rbx
	jmp	.LBB31_23
.LBB31_43:
	movl	$1, %ebx
.LBB31_46:
	movq	%rbx, %rcx
	movq	%r12, %rdx
	movq	%rsi, %r8
	callq	memcpy
	movb	$0, -2(%rbp)
	movq	%rsi, -32(%rbp)
	movq	%rbx, -40(%rbp)
.Ltmp76:
	movq	%r15, %rcx
	movl	%r14d, %edx
	movl	%edi, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena13make_internal17ha027843002ae76f3E
.Ltmp77:
	jmp	.LBB31_24
.LBB31_20:
	movl	$1, %ebx
.LBB31_23:
	movq	%rbx, %rcx
	movq	%r12, %rdx
	movq	%rsi, %r8
	callq	memcpy
	movb	$0, -1(%rbp)
	movq	%rsi, -16(%rbp)
	movq	%rbx, -24(%rbp)
.Ltmp58:
	movq	%r15, %rcx
	movl	%r14d, %edx
	movl	%edi, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena13make_internal17ha027843002ae76f3E
.Ltmp59:
.LBB31_24:
	testq	%rsi, %rsi
	je	.LBB31_58
	movl	$1, %r8d
	movq	%rbx, %rcx
	movq	%rsi, %rdx
	movl	%eax, %esi
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	movl	%esi, %eax
.LBB31_58:
	.seh_startepilogue
	addq	$88, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.LBB31_61:
	movb	$1, -2(%rbp)
	movq	%rdi, -32(%rbp)
	movq	%r13, -40(%rbp)
.Ltmp62:
	leaq	anon.3126157283a31055444fc45c79212b1f.76(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.Ltmp63:
	jmp	.LBB31_38
.LBB31_37:
	movb	$1, -1(%rbp)
	movq	%rdi, -16(%rbp)
	movq	%r13, -24(%rbp)
.Ltmp44:
	leaq	anon.3126157283a31055444fc45c79212b1f.74(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.Ltmp45:
	jmp	.LBB31_38
.LBB31_62:
	movb	$1, -2(%rbp)
	movq	%rdi, -32(%rbp)
	movq	%r13, -40(%rbp)
.Ltmp66:
	leaq	anon.3126157283a31055444fc45c79212b1f.77(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.Ltmp67:
	jmp	.LBB31_38
.LBB31_39:
	movb	$1, -1(%rbp)
	movq	%rdi, -16(%rbp)
	movq	%r13, -24(%rbp)
.Ltmp48:
	leaq	anon.3126157283a31055444fc45c79212b1f.75(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.Ltmp49:
.LBB31_38:
	ud2
.LBB31_60:
	movl	$1, %ecx
	movq	%rsi, %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
	int3
	.seh_handlerdata
	.long	$cppxdata$_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE@IMGREL
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE,unique,31
	.seh_endproc
	.def	"?dtor$26@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$26@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE@4HA":
.seh_proc "?dtor$26@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE@4HA"
.LBB31_26:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	80(%rdx), %rbp
	.seh_endprologue
	movq	-16(%rbp), %rdx
	testq	%rdx, %rdx
	sete	%al
	orb	-1(%rbp), %al
	testb	$1, %al
	jne	.LBB31_28
	movq	-24(%rbp), %rcx
	movl	$1, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB31_28:
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE,unique,31
	.seh_endproc
	.def	"?dtor$47@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$47@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE@4HA":
.seh_proc "?dtor$47@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE@4HA"
.LBB31_47:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	80(%rdx), %rbp
	.seh_endprologue
	movq	-32(%rbp), %rdx
	testq	%rdx, %rdx
	sete	%al
	orb	-2(%rbp), %al
	testb	$1, %al
	jne	.LBB31_49
	movq	-40(%rbp), %rcx
	movl	$1, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB31_49:
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.Lfunc_end4:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE,unique,31
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE,unique,4
	.p2align	2, 0x0
$cppxdata$_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE:
	.long	429065506
	.long	2
	.long	$stateUnwindMap$_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE@IMGREL
	.long	0
	.long	0
	.long	14
	.long	$ip2state$_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE@IMGREL
	.long	80
	.long	0
	.long	1
$stateUnwindMap$_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE:
	.long	-1
	.long	"?dtor$26@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE@4HA"@IMGREL
	.long	-1
	.long	"?dtor$47@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE@4HA"@IMGREL
$ip2state$_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE:
	.long	.Lfunc_begin4@IMGREL
	.long	-1
	.long	.Ltmp72@IMGREL+1
	.long	1
	.long	.Ltmp54@IMGREL+1
	.long	0
	.long	.Ltmp60@IMGREL+1
	.long	1
	.long	.Ltmp42@IMGREL+1
	.long	0
	.long	.Ltmp53@IMGREL+1
	.long	-1
	.long	.Ltmp76@IMGREL+1
	.long	1
	.long	.Ltmp77@IMGREL+1
	.long	-1
	.long	.Ltmp58@IMGREL+1
	.long	0
	.long	.Ltmp62@IMGREL+1
	.long	1
	.long	.Ltmp44@IMGREL+1
	.long	0
	.long	.Ltmp66@IMGREL+1
	.long	1
	.long	.Ltmp48@IMGREL+1
	.long	0
	.long	.Ltmp49@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE,unique,31

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena5equal17h98950bbe8ee0e501E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena5equal17h98950bbe8ee0e501E,unique,32
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena5equal17h98950bbe8ee0e501E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena5equal17h98950bbe8ee0e501E:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena5equal17h98950bbe8ee0e501E
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	movl	96(%rsp), %eax
	movl	%eax, 40(%rsp)
	movl	%r9d, 32(%rsp)
	movq	%rcx, %r9
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena12equal_across17h1407222e31fb6a69E
	nop
	.seh_startepilogue
	addq	$56, %rsp
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena5split17h4eabee455e3a259eE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena5split17h4eabee455e3a259eE,unique,33
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena5split17h4eabee455e3a259eE
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena5split17h4eabee455e3a259eE:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena5split17h4eabee455e3a259eE
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	2112(%rdx), %rax
	cmpq	2072(%rdx), %rax
	jne	.LBB33_13
	movq	2080(%rdx), %rax
	cmpq	%rax, 2120(%rdx)
	jne	.LBB33_13
	testb	$1, %r8b
	je	.LBB33_7
	movq	80(%rsp), %rax
	testq	%rax, %rax
	je	.LBB33_8
	movl	%r9d, %r11d
	movq	16(%rdx), %r10
	cmpq	%r11, %r10
	jbe	.LBB33_14
	movq	8(%rdx), %r8
	leaq	(%r11,%r11,2), %r10
	shlq	$4, %r10
	xorl	%r11d, %r11d
	cmpl	$0, (%r8,%r10)
	leaq	(%r8,%r10), %r8
	setne	%r11b
	cmpq	16(%r8,%r11,8), %rax
	jae	.LBB33_9
	movq	%rcx, %rsi
	movl	%r9d, %r8d
	movq	%rax, %r9
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB33_7:
	movl	$0, (%rcx)
	jmp	.LBB33_10
.LBB33_8:
	movl	$0, (%rcx)
	movl	$1, 8(%rcx)
	movl	%r9d, 12(%rcx)
	movq	%rcx, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB33_9:
	movl	$1, (%rcx)
	movl	%r9d, 4(%rcx)
.LBB33_10:
	movl	$0, 8(%rcx)
	movq	%rcx, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rsi
	.seh_endepilogue
	retq
.LBB33_13:
	leaq	anon.3126157283a31055444fc45c79212b1f.37(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB33_14:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%r11, %rcx
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena6concat17h7712937319125471E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena6concat17h7712937319125471E,unique,34
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena6concat17h7712937319125471E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena6concat17h7712937319125471E:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena6concat17h7712937319125471E
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movl	%edx, %eax
	movq	2112(%rcx), %rdx
	cmpq	2072(%rcx), %rdx
	jne	.LBB34_7
	movq	2080(%rcx), %rdx
	cmpq	%rdx, 2120(%rcx)
	jne	.LBB34_7
	movl	80(%rsp), %edx
	testb	$1, %al
	je	.LBB34_5
	testb	$1, %r9b
	movl	$1, %r9d
	je	.LBB34_6
	movl	%edx, %eax
	movl	%r8d, %edx
	movl	%eax, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE
	movl	$1, %r9d
	movl	%eax, %edx
.LBB34_5:
	movl	%r9d, %eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB34_6:
	movl	%r8d, %edx
	movl	%r9d, %eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB34_7:
	leaq	anon.3126157283a31055444fc45c79212b1f.37(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena6height17hf232cb4de005dd05E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena6height17hf232cb4de005dd05E,unique,35
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena6height17hf232cb4de005dd05E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena6height17hf232cb4de005dd05E:
	testb	$1, %dl
	je	.LBB35_1
	movl	%r8d, %edx
	jmp	_ZN26hashrope_diagnostic_slot_a4rope5Arena11node_height17h278e7991234695c3E
.LBB35_1:
	xorl	%eax, %eax
	retq

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena6repeat17h9128118ae6f5b132E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena6repeat17h9128118ae6f5b132E,unique,36
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena6repeat17h9128118ae6f5b132E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena6repeat17h9128118ae6f5b132E:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena6repeat17h9128118ae6f5b132E
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	2112(%rcx), %rax
	cmpq	2072(%rcx), %rax
	jne	.LBB36_6
	movq	2080(%rcx), %rax
	cmpq	%rax, 2120(%rcx)
	jne	.LBB36_6
	testb	$1, %dl
	je	.LBB36_3
	movl	%r8d, %edx
	movq	%r9, %r8
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11make_repeat17h97d110bb9b6bcb49E
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB36_3:
	xorl	%eax, %eax
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB36_6:
	leaq	anon.3126157283a31055444fc45c79212b1f.37(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena7balance17hb683a88a0e15e0adE;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena7balance17hb683a88a0e15e0adE,unique,37
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena7balance17hb683a88a0e15e0adE:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena7balance17hb683a88a0e15e0adE
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movl	%edx, %ebx
	movq	%rcx, %rsi
	movl	%edx, %ecx
	movq	16(%rsi), %rdx
	cmpq	%rcx, %rdx
	jbe	.LBB37_30
	movl	%r8d, %edi
	jmp	.LBB37_2
	.p2align	4
.LBB37_29:
	movq	%rsi, %rcx
	movl	%eax, %edx
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E
	movl	%edx, %ebp
	movq	%rsi, %rcx
	movl	%ebx, %edx
	movl	%eax, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena7balance17hb683a88a0e15e0adE
	movl	%eax, %ebx
	movq	%rsi, %rcx
	movl	%ebp, %edx
	movl	%edi, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena7balance17hb683a88a0e15e0adE
	movl	%eax, %edi
	movl	%ebx, %ecx
	movq	16(%rsi), %rdx
	cmpq	%rcx, %rdx
	jbe	.LBB37_30
.LBB37_2:
	movq	8(%rsi), %rax
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	cmpl	$0, (%rax,%rcx)
	je	.LBB37_3
	addq	%rax, %rcx
	movq	32(%rcx), %r15
	movl	%edi, %ecx
	cmpq	%rcx, %rdx
	ja	.LBB37_6
	jmp	.LBB37_30
	.p2align	4
.LBB37_3:
	movl	$1, %r15d
	movl	%edi, %ecx
	cmpq	%rcx, %rdx
	jbe	.LBB37_30
.LBB37_6:
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	cmpl	$0, (%rax,%rcx)
	je	.LBB37_7
	addq	%rcx, %rax
	movq	32(%rax), %r14
	leaq	(%r14,%r15), %rax
	cmpq	$2, %rax
	ja	.LBB37_13
	jmp	.LBB37_10
	.p2align	4
.LBB37_7:
	movl	$1, %r14d
	leaq	(%r14,%r15), %rax
	cmpq	$2, %rax
	jbe	.LBB37_10
.LBB37_13:
	leaq	(%rax,%rax), %rcx
	leaq	(,%r15,8), %r12
	subq	%r15, %r12
	cmpq	%r12, %rcx
	ja	.LBB37_15
	leaq	(%rax,%rax,4), %rax
	cmpq	%rax, %r12
	jbe	.LBB37_10
.LBB37_15:
	cmpq	%r12, %rcx
	jbe	.LBB37_16
	movq	%rsi, %rcx
	movl	%edi, %edx
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E
	movl	%edx, %edi
	movl	%eax, %ecx
	movq	16(%rsi), %rdx
	cmpq	%rcx, %rdx
	jbe	.LBB37_30
	movq	8(%rsi), %r9
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	cmpl	$0, (%r9,%rcx)
	je	.LBB37_35
	addq	%r9, %rcx
	movq	32(%rcx), %r8
	movl	%edi, %ecx
	cmpq	%rcx, %rdx
	ja	.LBB37_38
	jmp	.LBB37_30
	.p2align	4
.LBB37_16:
	movq	%rsi, %rcx
	movl	%ebx, %edx
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E
	movl	%eax, %ebx
	movl	%edx, %eax
	movl	%ebx, %ecx
	movq	16(%rsi), %rdx
	cmpq	%rcx, %rdx
	jbe	.LBB37_30
	movq	8(%rsi), %r9
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	cmpl	$0, (%r9,%rcx)
	je	.LBB37_18
	addq	%r9, %rcx
	movq	32(%rcx), %r8
	movl	%eax, %ecx
	cmpq	%rcx, %rdx
	ja	.LBB37_21
	jmp	.LBB37_30
.LBB37_35:
	movl	$1, %r8d
	movl	%edi, %ecx
	cmpq	%rcx, %rdx
	jbe	.LBB37_30
.LBB37_38:
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	cmpl	$0, (%r9,%rcx)
	je	.LBB37_39
	addq	%rcx, %r9
	movq	32(%r9), %rcx
	addq	%r15, %r8
	cmpq	$3, %r8
	jae	.LBB37_42
	jmp	.LBB37_44
.LBB37_18:
	movl	$1, %r8d
	movl	%eax, %ecx
	cmpq	%rcx, %rdx
	jbe	.LBB37_30
.LBB37_21:
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	cmpl	$0, (%r9,%rcx)
	je	.LBB37_22
	addq	%rcx, %r9
	movq	32(%r9), %rcx
	addq	%rcx, %r14
	cmpq	$3, %r14
	jae	.LBB37_25
	jmp	.LBB37_27
.LBB37_39:
	movl	$1, %ecx
	addq	%r15, %r8
	cmpq	$3, %r8
	jb	.LBB37_44
.LBB37_42:
	leaq	(%r8,%r8), %rdx
	cmpq	%r12, %rdx
	ja	.LBB37_29
	leaq	(%r8,%r8,4), %rdx
	cmpq	%rdx, %r12
	ja	.LBB37_29
.LBB37_44:
	addq	%r8, %rcx
	cmpq	$3, %rcx
	jb	.LBB37_47
	leaq	(%rcx,%rcx), %r9
	leaq	(,%r8,8), %rdx
	subq	%r8, %rdx
	cmpq	%rdx, %r9
	ja	.LBB37_29
	leaq	(%rcx,%rcx,4), %rcx
	cmpq	%rcx, %rdx
	ja	.LBB37_29
	jmp	.LBB37_47
.LBB37_22:
	movl	$1, %ecx
	addq	%rcx, %r14
	cmpq	$3, %r14
	jb	.LBB37_27
.LBB37_25:
	leaq	(%r14,%r14), %r9
	leaq	(,%rcx,8), %rdx
	subq	%rcx, %rdx
	cmpq	%rdx, %r9
	ja	.LBB37_29
	leaq	(%r14,%r14,4), %rcx
	cmpq	%rcx, %rdx
	ja	.LBB37_29
.LBB37_27:
	addq	%r8, %r14
	cmpq	$3, %r14
	jb	.LBB37_32
	leaq	(%r14,%r14), %rdx
	leaq	(,%r8,8), %rcx
	subq	%r8, %rcx
	cmpq	%rcx, %rdx
	ja	.LBB37_29
	leaq	(%r14,%r14,4), %rdx
	cmpq	%rdx, %rcx
	ja	.LBB37_29
.LBB37_32:
	movq	%rsi, %rcx
	movl	%eax, %edx
	movl	%edi, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena13make_internal17ha027843002ae76f3E
	movq	%rsi, %rcx
	movl	%ebx, %edx
	movl	%eax, %r8d
	jmp	.LBB37_12
.LBB37_10:
	movq	%rsi, %rcx
	movl	%ebx, %edx
	jmp	.LBB37_11
.LBB37_47:
	movq	%rsi, %rcx
	movl	%ebx, %edx
	movl	%eax, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena13make_internal17ha027843002ae76f3E
	movq	%rsi, %rcx
	movl	%eax, %edx
.LBB37_11:
	movl	%edi, %r8d
.LBB37_12:
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	jmp	_ZN26hashrope_diagnostic_slot_a4rope5Arena13make_internal17ha027843002ae76f3E
.LBB37_30:
	leaq	anon.3126157283a31055444fc45c79212b1f.44(%rip), %r8
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena8new_lazy17h3ef3c6c54e6c5133E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena8new_lazy17h3ef3c6c54e6c5133E,unique,38
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena8new_lazy17h3ef3c6c54e6c5133E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena8new_lazy17h3ef3c6c54e6c5133E:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena8new_lazy17h3ef3c6c54e6c5133E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$2088, %rsp
	.seh_stackalloc 2088
	.seh_endprologue
	movq	%rcx, %rsi
	movabsq	$2305843009213693951, %rdi
	leaq	48(%rsp), %rcx
	movl	$2040, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	$1, 40(%rsp)
	movl	$1, %eax
	movl	$131, %r8d
	movabsq	$-2305843009213693951, %r9
	movl	$1, %r10d
	.p2align	4
.LBB38_1:
	mulq	%r8
	movq	%rax, %rcx
	shrq	$61, %rax
	leaq	(%rax,%rdx,8), %rax
	andq	%rdi, %rcx
	addq	%rax, %rcx
	movq	%rcx, %rax
	shrq	$61, %rax
	andq	%rdi, %rcx
	addq	%rax, %rcx
	leaq	(%rcx,%r9), %rax
	cmpq	%rdi, %rcx
	cmovbq	%rcx, %rax
	movq	%rax, 40(%rsp,%r10,8)
	incq	%r10
	cmpq	$256, %r10
	jne	.LBB38_1
	movq	$0, (%rsi)
	movq	$8, 8(%rsi)
	movq	$0, 16(%rsi)
	leaq	24(%rsi), %rcx
	leaq	40(%rsp), %rdx
	movl	$2048, %r8d
	callq	memcpy
	movq	%rdi, 2072(%rsi)
	movq	$131, 2080(%rsi)
	movq	$0, 2088(%rsi)
	movq	$0, 2104(%rsi)
	movq	%rdi, 2112(%rsi)
	movq	$131, 2120(%rsi)
	movb	$1, 2128(%rsi)
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$2088, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena8to_bytes17h895d40a80850cba9E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena8to_bytes17h895d40a80850cba9E,unique,39
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena8to_bytes17h895d40a80850cba9E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena8to_bytes17h895d40a80850cba9E:
.Lfunc_begin5:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena8to_bytes17h895d40a80850cba9E
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$72, %rsp
	.seh_stackalloc 72
	leaq	64(%rsp), %rbp
	.seh_setframe %rbp, 64
	.seh_endprologue
	movq	$-2, (%rbp)
	movq	%rcx, %rsi
	movq	$0, -24(%rbp)
	movq	$1, -16(%rbp)
	movq	$0, -8(%rbp)
	testb	$1, %r8b
	je	.LBB39_2
.Ltmp78:
	leaq	-24(%rbp), %r8
	movq	%rdx, %rcx
	movl	%r9d, %edx
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena13collect_bytes17hdc8ef44d8c149711E
.Ltmp79:
.LBB39_2:
	movq	-8(%rbp), %rax
	movq	%rax, 16(%rsi)
	movq	-24(%rbp), %rax
	movq	%rax, (%rsi)
	movq	-16(%rbp), %rax
	movq	%rax, 8(%rsi)
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rsi
	popq	%rbp
	.seh_endepilogue
	retq
	.seh_handlerdata
	.long	$cppxdata$_ZN26hashrope_diagnostic_slot_a4rope5Arena8to_bytes17h895d40a80850cba9E@IMGREL
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena8to_bytes17h895d40a80850cba9E,unique,39
	.seh_endproc
	.def	"?dtor$3@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena8to_bytes17h895d40a80850cba9E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$3@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena8to_bytes17h895d40a80850cba9E@4HA":
.seh_proc "?dtor$3@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena8to_bytes17h895d40a80850cba9E@4HA"
.LBB39_3:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rsi
	.seh_pushreg %rsi
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	64(%rdx), %rbp
	.seh_endprologue
	movq	-24(%rbp), %rdx
	testq	%rdx, %rdx
	je	.LBB39_5
	movq	-16(%rbp), %rcx
	movl	$1, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB39_5:
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rsi
	popq	%rbp
	.seh_endepilogue
	retq
.Lfunc_end5:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena8to_bytes17h895d40a80850cba9E,unique,39
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN26hashrope_diagnostic_slot_a4rope5Arena8to_bytes17h895d40a80850cba9E,unique,5
	.p2align	2, 0x0
$cppxdata$_ZN26hashrope_diagnostic_slot_a4rope5Arena8to_bytes17h895d40a80850cba9E:
	.long	429065506
	.long	1
	.long	$stateUnwindMap$_ZN26hashrope_diagnostic_slot_a4rope5Arena8to_bytes17h895d40a80850cba9E@IMGREL
	.long	0
	.long	0
	.long	3
	.long	$ip2state$_ZN26hashrope_diagnostic_slot_a4rope5Arena8to_bytes17h895d40a80850cba9E@IMGREL
	.long	64
	.long	0
	.long	1
$stateUnwindMap$_ZN26hashrope_diagnostic_slot_a4rope5Arena8to_bytes17h895d40a80850cba9E:
	.long	-1
	.long	"?dtor$3@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena8to_bytes17h895d40a80850cba9E@4HA"@IMGREL
$ip2state$_ZN26hashrope_diagnostic_slot_a4rope5Arena8to_bytes17h895d40a80850cba9E:
	.long	.Lfunc_begin5@IMGREL
	.long	-1
	.long	.Ltmp78@IMGREL+1
	.long	0
	.long	.Ltmp79@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena8to_bytes17h895d40a80850cba9E,unique,39

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena8validate17hab660e0f376fd19dE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena8validate17hab660e0f376fd19dE,unique,40
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena8validate17hab660e0f376fd19dE
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena8validate17hab660e0f376fd19dE:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena8validate17hab660e0f376fd19dE
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	2112(%rcx), %rax
	cmpq	2072(%rcx), %rax
	jne	.LBB40_4
	movq	2080(%rcx), %rax
	cmpq	%rax, 2120(%rcx)
	jne	.LBB40_4
	testb	$1, %dl
	je	.LBB40_3
	movl	%r8d, %edx
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	jmp	_ZN26hashrope_diagnostic_slot_a4rope5Arena14validate_inner17h78360aa4f3e08b56E
.LBB40_3:
	nop
	.seh_startepilogue
	addq	$40, %rsp
	.seh_endepilogue
	retq
.LBB40_4:
	leaq	anon.3126157283a31055444fc45c79212b1f.37(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E,unique,41
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E:
.Lfunc_begin6:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$72, %rsp
	.seh_stackalloc 72
	leaq	64(%rsp), %rbp
	.seh_setframe %rbp, 64
	.seh_endprologue
	movq	$-2, (%rbp)
	movl	%edx, %eax
	movq	16(%rcx), %rdx
	cmpq	%rax, %rdx
	jbe	.LBB41_19
	movq	8(%rcx), %rdx
	leaq	(%rax,%rax,2), %r8
	shlq	$4, %r8
	leaq	(%rdx,%r8), %rax
	movl	(%rdx,%r8), %edx
	cmpl	$1, %edx
	je	.LBB41_10
	movl	%edx, -20(%rbp)
	cmpl	$2, %edx
	jne	.LBB41_3
	movl	4(%rax), %edi
	movq	8(%rax), %rbx
	movq	24(%rax), %r13
	movq	32(%rax), %r12
	movq	%rbx, %r14
	shrq	%r14
	movq	%r13, -8(%rbp)
	movq	%r12, -16(%rbp)
.Ltmp80:
	movq	%rcx, %r15
	movl	%edi, %edx
	movq	%r14, %r8
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11make_repeat17h97d110bb9b6bcb49E
.Ltmp81:
	testb	$1, %al
	je	.LBB41_17
	movl	%edx, %esi
	subq	%r14, %rbx
	movq	%r13, -8(%rbp)
	movq	%r12, -16(%rbp)
.Ltmp84:
	movq	%r15, %rcx
	movl	%edi, %edx
	movq	%rbx, %r8
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11make_repeat17h97d110bb9b6bcb49E
.Ltmp85:
	testb	$1, %al
	jne	.LBB41_11
	movq	%r13, -8(%rbp)
	movq	%r12, -16(%rbp)
.Ltmp86:
	leaq	anon.3126157283a31055444fc45c79212b1f.82(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.Ltmp87:
	jmp	.LBB41_18
.LBB41_10:
	movl	4(%rax), %esi
	movl	8(%rax), %edx
.LBB41_11:
	movl	%esi, %eax
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.LBB41_17:
	movq	%r13, -8(%rbp)
	movq	%r12, -16(%rbp)
.Ltmp82:
	leaq	anon.3126157283a31055444fc45c79212b1f.81(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.Ltmp83:
	jmp	.LBB41_18
.LBB41_19:
	leaq	anon.3126157283a31055444fc45c79212b1f.78(%rip), %r8
	movq	%rax, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB41_3:
	movq	32(%rax), %rdi
	movq	40(%rax), %rsi
	movl	$1, %ebx
	testq	%rsi, %rsi
	je	.LBB41_6
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$1, %edx
	movq	%rsi, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	jne	.LBB41_5
	movl	$1, %ecx
	movq	%rsi, %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
.LBB41_5:
	movq	%rax, %rbx
.LBB41_6:
	movq	%rbx, %rcx
	movq	%rdi, %rdx
	movq	%rsi, %r8
	callq	memcpy
	movq	%rsi, -8(%rbp)
	movq	%rbx, -16(%rbp)
.Ltmp88:
	leaq	anon.3126157283a31055444fc45c79212b1f.79(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.80(%rip), %r8
	movl	$149, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.Ltmp89:
.LBB41_18:
	ud2
	.seh_handlerdata
	.long	$cppxdata$_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E@IMGREL
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E,unique,41
	.seh_endproc
	.def	"?dtor$7@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$7@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E@4HA":
.seh_proc "?dtor$7@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E@4HA"
.LBB41_7:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	leaq	64(%rdx), %rbp
	.seh_endprologue
	movq	-8(%rbp), %rdx
	cmpl	$0, -20(%rbp)
	setne	%al
	testq	%rdx, %rdx
	sete	%cl
	orb	%al, %cl
	jne	.LBB41_9
	movq	-16(%rbp), %rcx
	movl	$1, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB41_9:
	nop
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.Lfunc_end6:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E,unique,41
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E,unique,6
	.p2align	2, 0x0
$cppxdata$_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E:
	.long	429065506
	.long	1
	.long	$stateUnwindMap$_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E@IMGREL
	.long	0
	.long	0
	.long	5
	.long	$ip2state$_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E@IMGREL
	.long	64
	.long	0
	.long	1
$stateUnwindMap$_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E:
	.long	-1
	.long	"?dtor$7@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E@4HA"@IMGREL
$ip2state$_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E:
	.long	.Lfunc_begin6@IMGREL
	.long	-1
	.long	.Ltmp80@IMGREL+1
	.long	0
	.long	.Ltmp83@IMGREL+1
	.long	-1
	.long	.Ltmp88@IMGREL+1
	.long	0
	.long	.Ltmp89@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena9decompose17h43cd00eaffdbaf37E,unique,41

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena9lcp_range17hc057da4dc11a19edE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena9lcp_range17hc057da4dc11a19edE,unique,42
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena9lcp_range17hc057da4dc11a19edE
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena9lcp_range17hc057da4dc11a19edE:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena9lcp_range17hc057da4dc11a19edE
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	movl	112(%rsp), %eax
	movl	120(%rsp), %r10d
	movaps	128(%rsp), %xmm0
	movups	%xmm0, 56(%rsp)
	movl	%r10d, 48(%rsp)
	movl	%eax, 40(%rsp)
	movq	%rcx, 32(%rsp)
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena16lcp_range_across17h4410a1b2238bfc16E
	nop
	.seh_startepilogue
	addq	$72, %rsp
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E,unique,43
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E:
.Lfunc_begin7:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$80, %rsp
	.seh_stackalloc 80
	leaq	80(%rsp), %rbp
	.seh_setframe %rbp, 80
	.seh_endprologue
	movq	$-2, -8(%rbp)
	movq	16(%rdx), %r15
	testq	%r15, %r15
	movq	%rdx, -24(%rbp)
	movq	%r15, -40(%rbp)
	je	.LBB43_1
	movq	%rdx, %r14
	movq	%rcx, %rsi
	movq	8(%rdx), %r12
	movq	$-1, %rdi
	cmpb	$0, 2128(%rcx)
	jne	.LBB43_6
	movq	2072(%rsi), %r8
	movq	2080(%rsi), %r9
	movl	$127, %ecx
	bsrq	%r8, %rcx
	xorl	$-64, %ecx
	addl	$65, %ecx
	xorl	%r10d, %r10d
	xorl	%r11d, %r11d
	xorl	%edi, %edi
	.p2align	4
.LBB43_5:
	movzbl	(%r12,%r11), %ebx
	movq	%rdi, %rax
	mulq	%r9
	movq	%rax, %rdi
	addq	%rbx, %rdi
	adcq	$0, %rdx
	addq	$1, %rdi
	adcq	$0, %rdx
	movq	%rdi, %rax
	shrdq	%cl, %rdx, %rax
	shrq	%cl, %rdx
	testb	$64, %cl
	cmovneq	%rdx, %rax
	cmovneq	%r10, %rdx
	andq	%r8, %rdi
	addq	%rax, %rdi
	adcq	$0, %rdx
	movq	%rdi, %rax
	shrdq	%cl, %rdx, %rax
	shrq	%cl, %rdx
	testb	$64, %cl
	cmoveq	%rax, %rdx
	andq	%r8, %rdi
	addq	%rdx, %rdi
	cmpq	%rdi, %r8
	movq	%r8, %rax
	cmovaq	%r10, %rax
	subq	%rax, %rdi
	incq	%r11
	cmpq	%r11, %r15
	jne	.LBB43_5
.LBB43_6:
	movq	%r12, -32(%rbp)
	movq	(%r14), %rax
	movq	%rax, -16(%rbp)
	movq	16(%rsi), %rbx
	cmpq	(%rsi), %rbx
	jne	.LBB43_8
.Ltmp90:
	movq	%rsi, %rcx
	callq	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hdbf86ebe580ab5daE
.Ltmp91:
.LBB43_8:
	movq	8(%rsi), %rax
	leaq	(%rbx,%rbx,2), %rcx
	shlq	$4, %rcx
	movl	$0, (%rax,%rcx)
	movq	%rdi, 8(%rax,%rcx)
	movq	-40(%rbp), %rdx
	movq	%rdx, 16(%rax,%rcx)
	movq	-16(%rbp), %r8
	movq	%r8, 24(%rax,%rcx)
	movq	-32(%rbp), %r8
	movq	%r8, 32(%rax,%rcx)
	movq	%rdx, 40(%rax,%rcx)
	leaq	1(%rbx), %rax
	movq	%rax, 16(%rsi)
	movl	%ebx, %eax
	.seh_startepilogue
	addq	$80, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.LBB43_1:
.Ltmp92:
	leaq	anon.3126157283a31055444fc45c79212b1f.83(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.84(%rip), %r8
	movl	$41, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.Ltmp93:
	ud2
	.seh_handlerdata
	.long	$cppxdata$_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E@IMGREL
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E,unique,43
	.seh_endproc
	.def	"?dtor$9@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$9@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E@4HA":
.seh_proc "?dtor$9@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E@4HA"
.LBB43_9:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	leaq	80(%rdx), %rbp
	.seh_endprologue
	cmpq	$0, -16(%rbp)
	je	.LBB43_11
	movl	$1, %r8d
	movq	-32(%rbp), %rcx
	movq	-16(%rbp), %rdx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB43_11:
	nop
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E,unique,43
	.seh_endproc
	.def	"?dtor$12@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$12@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E@4HA":
.seh_proc "?dtor$12@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E@4HA"
.LBB43_12:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	leaq	80(%rdx), %rbp
	.seh_endprologue
	cmpq	$0, -40(%rbp)
	jne	.LBB43_15
	movq	-24(%rbp), %rax
	movq	(%rax), %rdx
	testq	%rdx, %rdx
	je	.LBB43_15
	movq	-24(%rbp), %rax
	movq	8(%rax), %rcx
	movl	$1, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB43_15:
	nop
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.Lfunc_end7:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E,unique,43
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E,unique,7
	.p2align	2, 0x0
$cppxdata$_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E:
	.long	429065506
	.long	2
	.long	$stateUnwindMap$_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E@IMGREL
	.long	0
	.long	0
	.long	4
	.long	$ip2state$_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E@IMGREL
	.long	72
	.long	0
	.long	1
$stateUnwindMap$_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E:
	.long	-1
	.long	"?dtor$12@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E@4HA"@IMGREL
	.long	0
	.long	"?dtor$9@?0?_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E@4HA"@IMGREL
$ip2state$_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E:
	.long	.Lfunc_begin7@IMGREL
	.long	-1
	.long	.Ltmp90@IMGREL+1
	.long	1
	.long	.Ltmp92@IMGREL+1
	.long	0
	.long	.Ltmp93@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena9make_leaf17h2ff3b16d1a9eedc2E,unique,43

	.def	_ZN26hashrope_diagnostic_slot_a4rope5Arena9with_hash17h1381c7ff6185b36cE;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope5Arena9with_hash17h1381c7ff6185b36cE,unique,44
	.globl	_ZN26hashrope_diagnostic_slot_a4rope5Arena9with_hash17h1381c7ff6185b36cE
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope5Arena9with_hash17h1381c7ff6185b36cE:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope5Arena9with_hash17h1381c7ff6185b36cE
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$2088, %rsp
	.seh_stackalloc 2088
	.seh_endprologue
	cmpq	$2, %r8
	jb	.LBB44_5
	movq	%r8, %rdi
	movq	%rdx, %rbx
	cmpq	%rdx, %r8
	jae	.LBB44_5
	movq	%rcx, %rsi
	leaq	48(%rsp), %rcx
	xorl	%r14d, %r14d
	movl	$2040, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	$1, 40(%rsp)
	bsrq	%rbx, %rcx
	incl	%ecx
	movl	$1, %eax
	movl	$1, %r8d
	.p2align	4
.LBB44_3:
	mulq	%rdi
	movq	%rdx, %r9
	shrq	%cl, %r9
	movq	%rax, %r10
	shrdq	%cl, %rdx, %r10
	testb	$64, %cl
	cmovneq	%r9, %r10
	cmovneq	%r14, %r9
	andq	%rbx, %rax
	addq	%r10, %rax
	adcq	$0, %r9
	movq	%rax, %rdx
	shrdq	%cl, %r9, %rdx
	shrq	%cl, %r9
	testb	$64, %cl
	cmoveq	%rdx, %r9
	andq	%rbx, %rax
	addq	%r9, %rax
	cmpq	%rax, %rbx
	movq	%rbx, %rdx
	cmovaq	%r14, %rdx
	subq	%rdx, %rax
	movq	%rax, 40(%rsp,%r8,8)
	incq	%r8
	cmpq	$256, %r8
	jne	.LBB44_3
	movq	$0, (%rsi)
	movq	$8, 8(%rsi)
	movq	$0, 16(%rsi)
	leaq	24(%rsi), %rcx
	leaq	40(%rsp), %rdx
	movl	$2048, %r8d
	callq	memcpy
	movq	%rbx, 2072(%rsi)
	movq	%rdi, 2080(%rsi)
	movq	$0, 2088(%rsi)
	movq	$0, 2104(%rsi)
	movq	%rbx, 2112(%rsi)
	movq	%rdi, 2120(%rsi)
	movb	$0, 2128(%rsi)
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$2088, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
.LBB44_5:
	leaq	anon.3126157283a31055444fc45c79212b1f.2(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.3(%rip), %r8
	movl	$49, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E,unique,45
	.p2align	4
_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E:
.Lfunc_begin8:
.seh_proc _ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$1816, %rsp
	.seh_stackalloc 1816
	leaq	128(%rsp), %rbp
	.seh_setframe %rbp, 128
	.seh_endprologue
	movq	$-2, 1680(%rbp)
	movq	%rcx, %r15
	movq	16(%rcx), %r10
	movl	%r9d, %ecx
	cmpq	%rcx, %r10
	jbe	.LBB45_94
	movq	16(%rdx), %r11
	leaq	(%r11,%r10), %rdi
	movq	8(%r15), %rsi
	leaq	(%rcx,%rcx,2), %rax
	shlq	$4, %rax
	cmpl	$0, (%rsi,%rax)
	movq	%rsi, 1632(%rbp)
	je	.LBB45_3
	addq	%rsi, %rax
	movq	32(%rax), %rax
	jmp	.LBB45_4
.LBB45_3:
	movl	$1, %eax
.LBB45_4:
	movq	1808(%rbp), %r13
	movl	1800(%rbp), %r12d
	movq	1792(%rbp), %rbx
	cmpq	%rdi, %rax
	ja	.LBB45_8
	movl	%r12d, %ecx
	cmpq	%rcx, %r11
	jbe	.LBB45_95
	movq	8(%rdx), %rsi
	leaq	(%rcx,%rcx,2), %rax
	shlq	$4, %rax
	cmpl	$0, (%rsi,%rax)
	movq	%rsi, 1656(%rbp)
	je	.LBB45_15
	addq	%rsi, %rax
	movq	32(%rax), %rax
	cmpq	%rdi, %rax
	jbe	.LBB45_16
.LBB45_8:
	cmpq	%rdx, %r15
	movq	%r15, 728(%rbp)
	movq	%rdx, 736(%rbp)
	sete	768(%rbp)
	movq	$0, 744(%rbp)
	movq	$0, 760(%rbp)
.Ltmp96:
	movq	%r13, 40(%rsp)
	movl	%r12d, 32(%rsp)
	leaq	728(%rbp), %rcx
	movq	%r8, %rdx
	movl	%r9d, %r8d
	movq	%rbx, %r9
	callq	_ZN26hashrope_diagnostic_slot_a4rope15ExactComparison3lcp17h189789a5c51c350fE
.Ltmp97:
	movq	%rax, %rbx
	movq	744(%rbp), %rcx
	testq	%rcx, %rcx
	je	.LBB45_11
	movq	752(%rbp), %rdx
	movq	760(%rbp), %rax
	movq	$0, -64(%rbp)
	movq	%rcx, -56(%rbp)
	movq	%rdx, -48(%rbp)
	movq	$0, -32(%rbp)
	movq	%rcx, -24(%rbp)
	movq	%rdx, -16(%rbp)
	movl	$1, %ecx
	jmp	.LBB45_12
.LBB45_11:
	xorl	%ecx, %ecx
	xorl	%eax, %eax
.LBB45_12:
	movq	%rcx, -72(%rbp)
	movq	%rcx, -40(%rbp)
	movq	%rax, -8(%rbp)
	leaq	1576(%rbp), %rcx
	leaq	-72(%rbp), %rdx
	callq	_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E
	cmpq	$0, 1576(%rbp)
	je	.LBB45_87
	leaq	1576(%rbp), %rsi
	leaq	-72(%rbp), %rdi
	.p2align	4
.LBB45_14:
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	callq	_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E
	cmpq	$0, 1576(%rbp)
	jne	.LBB45_14
	jmp	.LBB45_87
.LBB45_15:
	movl	$1, %eax
	cmpq	%rdi, %rax
	ja	.LBB45_8
.LBB45_16:
	shlq	$3, %rdi
	cmpq	%rdx, %r15
	sete	1679(%rbp)
	setne	%al
	movq	%r15, 1576(%rbp)
	movq	%rdx, 1584(%rbp)
	sete	1600(%rbp)
	movq	%rdi, 1592(%rbp)
	cmpq	$8192, %r13
	setae	%cl
	testb	%cl, %al
	jne	.LBB45_18
	movq	%r13, 40(%rsp)
	movl	%r12d, 32(%rsp)
	leaq	1576(%rbp), %rcx
	movq	%r8, %rdi
	movq	%rdx, %r14
	movq	%r8, %rdx
	movl	%r9d, %esi
	movl	%r9d, %r8d
	movq	%rbx, %r9
	callq	_ZN26hashrope_diagnostic_slot_a4rope14FastComparison13lcp_recursive17h6af0d9319335c753E
	movq	%rdx, 1664(%rbp)
	testb	$1, %al
	jne	.LBB45_78
	jmp	.LBB45_86
.LBB45_18:
	movq	%r15, 1568(%rbp)
	movq	%rdx, 1560(%rbp)
	movq	%r8, 1552(%rbp)
	movq	%r8, 1496(%rbp)
	movl	%r9d, 1628(%rbp)
	movl	%r9d, 1504(%rbp)
	movq	%r13, 1512(%rbp)
	movq	$0, 728(%rbp)
	movl	$0, 736(%rbp)
	movq	$0, 1488(%rbp)
	movq	$0, 1520(%rbp)
	xorps	%xmm0, %xmm0
	movups	%xmm0, 744(%rbp)
	movl	$0, 760(%rbp)
	movups	%xmm0, 768(%rbp)
	movl	$0, 784(%rbp)
	movups	%xmm0, 792(%rbp)
	movl	$0, 808(%rbp)
	movups	%xmm0, 816(%rbp)
	movl	$0, 832(%rbp)
	movups	%xmm0, 840(%rbp)
	movl	$0, 856(%rbp)
	movups	%xmm0, 864(%rbp)
	movl	$0, 880(%rbp)
	movups	%xmm0, 888(%rbp)
	movl	$0, 904(%rbp)
	movups	%xmm0, 912(%rbp)
	movl	$0, 928(%rbp)
	movups	%xmm0, 936(%rbp)
	movl	$0, 952(%rbp)
	movups	%xmm0, 960(%rbp)
	movl	$0, 976(%rbp)
	movups	%xmm0, 984(%rbp)
	movl	$0, 1000(%rbp)
	movups	%xmm0, 1008(%rbp)
	movl	$0, 1024(%rbp)
	movups	%xmm0, 1032(%rbp)
	movl	$0, 1048(%rbp)
	movups	%xmm0, 1056(%rbp)
	movl	$0, 1072(%rbp)
	movups	%xmm0, 1080(%rbp)
	movl	$0, 1096(%rbp)
	movups	%xmm0, 1104(%rbp)
	movl	$0, 1120(%rbp)
	movups	%xmm0, 1128(%rbp)
	movl	$0, 1144(%rbp)
	movups	%xmm0, 1152(%rbp)
	movl	$0, 1168(%rbp)
	movups	%xmm0, 1176(%rbp)
	movl	$0, 1192(%rbp)
	movups	%xmm0, 1200(%rbp)
	movl	$0, 1216(%rbp)
	movups	%xmm0, 1224(%rbp)
	movl	$0, 1240(%rbp)
	movups	%xmm0, 1248(%rbp)
	movl	$0, 1264(%rbp)
	movups	%xmm0, 1272(%rbp)
	movl	$0, 1288(%rbp)
	movups	%xmm0, 1296(%rbp)
	movl	$0, 1312(%rbp)
	movups	%xmm0, 1320(%rbp)
	movl	$0, 1336(%rbp)
	movups	%xmm0, 1344(%rbp)
	movl	$0, 1360(%rbp)
	movups	%xmm0, 1368(%rbp)
	movl	$0, 1384(%rbp)
	movups	%xmm0, 1392(%rbp)
	movl	$0, 1408(%rbp)
	movups	%xmm0, 1416(%rbp)
	movl	$0, 1432(%rbp)
	movups	%xmm0, 1440(%rbp)
	movl	$0, 1456(%rbp)
	movups	%xmm0, 1464(%rbp)
	movl	$0, 1480(%rbp)
	movq	%rbx, 696(%rbp)
	movl	%r12d, 704(%rbp)
	movq	%r13, 712(%rbp)
	movq	$0, -72(%rbp)
	movl	$0, -64(%rbp)
	movq	$0, 688(%rbp)
	movq	$0, 720(%rbp)
	movups	%xmm0, -56(%rbp)
	movl	$0, -40(%rbp)
	movups	%xmm0, -32(%rbp)
	movl	$0, -16(%rbp)
	movups	%xmm0, -8(%rbp)
	movl	$0, 8(%rbp)
	movups	%xmm0, 16(%rbp)
	movl	$0, 32(%rbp)
	movups	%xmm0, 40(%rbp)
	movl	$0, 56(%rbp)
	movups	%xmm0, 64(%rbp)
	movl	$0, 80(%rbp)
	movups	%xmm0, 88(%rbp)
	movl	$0, 104(%rbp)
	movups	%xmm0, 112(%rbp)
	movl	$0, 128(%rbp)
	movups	%xmm0, 136(%rbp)
	movl	$0, 152(%rbp)
	movups	%xmm0, 160(%rbp)
	movl	$0, 176(%rbp)
	movups	%xmm0, 184(%rbp)
	movl	$0, 200(%rbp)
	movups	%xmm0, 208(%rbp)
	movl	$0, 224(%rbp)
	movups	%xmm0, 232(%rbp)
	movl	$0, 248(%rbp)
	movups	%xmm0, 256(%rbp)
	movl	$0, 272(%rbp)
	movups	%xmm0, 280(%rbp)
	movl	$0, 296(%rbp)
	movups	%xmm0, 304(%rbp)
	movl	$0, 320(%rbp)
	movups	%xmm0, 328(%rbp)
	movl	$0, 344(%rbp)
	movups	%xmm0, 352(%rbp)
	movl	$0, 368(%rbp)
	movups	%xmm0, 376(%rbp)
	movl	$0, 392(%rbp)
	movups	%xmm0, 400(%rbp)
	movl	$0, 416(%rbp)
	movups	%xmm0, 424(%rbp)
	movl	$0, 440(%rbp)
	movups	%xmm0, 448(%rbp)
	movl	$0, 464(%rbp)
	movups	%xmm0, 472(%rbp)
	movl	$0, 488(%rbp)
	movups	%xmm0, 496(%rbp)
	movl	$0, 512(%rbp)
	movups	%xmm0, 520(%rbp)
	movl	$0, 536(%rbp)
	movups	%xmm0, 544(%rbp)
	movl	$0, 560(%rbp)
	movups	%xmm0, 568(%rbp)
	movl	$0, 584(%rbp)
	movups	%xmm0, 592(%rbp)
	movl	$0, 608(%rbp)
	movups	%xmm0, 616(%rbp)
	movl	$0, 632(%rbp)
	movups	%xmm0, 640(%rbp)
	movl	$0, 656(%rbp)
	movups	%xmm0, 664(%rbp)
	movl	$0, 680(%rbp)
	movq	%r13, %r15
	movq	1512(%rbp), %r13
	cmpq	%r13, %r15
	movq	%r13, %r14
	cmovbq	%r15, %r14
	movl	%r12d, %eax
	movq	1496(%rbp), %r12
	negq	%rdi
	movq	%rbx, %rsi
	movq	$0, 1664(%rbp)
	movq	%r10, %rbx
	movq	%r11, 1648(%rbp)
	movq	1656(%rbp), %r9
	movq	%r10, 1616(%rbp)
	jmp	.LBB45_22
	.p2align	4
.LBB45_19:
	leaq	-72(%rbp), %rcx
	movq	%r9, %rdx
	movq	%r11, %r8
.LBB45_20:
	callq	_ZN26hashrope_diagnostic_slot_a4rope13ExactFrontier6expand17h83c92e36a51ff2ebE
	movq	1656(%rbp), %r9
	movq	1648(%rbp), %r11
	testb	%al, %al
	je	.LBB45_77
.LBB45_21:
	movq	1496(%rbp), %r12
	movq	1512(%rbp), %r13
	movl	704(%rbp), %eax
	movq	696(%rbp), %rsi
	movq	712(%rbp), %r15
	cmpq	%r13, %r15
	movq	%r13, %r14
	cmovbq	%r15, %r14
	addq	$2, %rdi
	je	.LBB45_77
.LBB45_22:
	movl	1504(%rbp), %ecx
	cmpq	%rcx, %rbx
	jbe	.LBB45_92
	movl	%eax, %eax
	cmpq	%rax, %r11
	jbe	.LBB45_93
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	addq	1632(%rbp), %rcx
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	addq	%r9, %rax
	movl	(%rcx), %edx
	testl	%edx, %edx
	je	.LBB45_27
	movl	$1, %ecx
	movq	%rcx, 1640(%rbp)
	cmpl	$1, %edx
	jne	.LBB45_77
	movl	(%rax), %r8d
	jmp	.LBB45_28
	.p2align	4
.LBB45_27:
	movl	$1, %r8d
	movq	%r8, 1640(%rbp)
	movl	(%rax), %r8d
	testl	%r8d, %r8d
	je	.LBB45_36
.LBB45_28:
	testl	%r8d, %r8d
	je	.LBB45_34
	cmpl	$1, %r8d
	jne	.LBB45_77
	cmpl	$1, %edx
	jne	.LBB45_19
	cmpq	%r15, %r13
	jb	.LBB45_33
	leaq	728(%rbp), %rcx
	movq	1632(%rbp), %rdx
	movq	%rbx, %r8
	callq	_ZN26hashrope_diagnostic_slot_a4rope13ExactFrontier6expand17h83c92e36a51ff2ebE
	movq	1656(%rbp), %r9
	movq	1648(%rbp), %r11
	testb	%al, %al
	je	.LBB45_77
.LBB45_33:
	cmpq	%r13, %r15
	jae	.LBB45_19
	jmp	.LBB45_21
	.p2align	4
.LBB45_34:
	cmpl	$1, %edx
	jne	.LBB45_19
	leaq	728(%rbp), %rcx
	movq	1632(%rbp), %rdx
	movq	%rbx, %r8
	jmp	.LBB45_20
.LBB45_36:
	movq	40(%rcx), %rdx
	movq	%rdx, %r8
	subq	%r12, %r8
	jb	.LBB45_89
	cmpq	%r8, %r14
	ja	.LBB45_88
	movq	40(%rax), %rdx
	movq	%rdx, %r8
	subq	%rsi, %r8
	jb	.LBB45_90
	cmpq	%r8, %r14
	ja	.LBB45_91
	movq	%rdi, 1608(%rbp)
	movq	32(%rcx), %rbx
	addq	%r12, %rbx
	movq	32(%rax), %rdi
	addq	%rsi, %rdi
	movq	%rbx, %rcx
	movq	%rdi, %rdx
	movq	%r14, %r8
	callq	memcmp
	testl	%eax, %eax
	jne	.LBB45_54
	cmpq	%r15, %r13
	movq	1648(%rbp), %r11
	jbe	.LBB45_43
	addq	%r14, %r12
	movq	%r12, 1496(%rbp)
	movq	%r13, %rax
	subq	%r14, %rax
	movq	%rax, 1512(%rbp)
	movq	1616(%rbp), %rbx
	movq	1656(%rbp), %r9
	movq	1608(%rbp), %rdi
	cmpq	%r13, %r15
	jbe	.LBB45_48
.LBB45_46:
	addq	%r14, %rsi
	movq	%rsi, 696(%rbp)
	subq	%r14, %r15
	movq	%r15, 712(%rbp)
	movq	1808(%rbp), %rdx
	jmp	.LBB45_52
.LBB45_43:
	movq	1520(%rbp), %rax
	testq	%rax, %rax
	movq	1616(%rbp), %rbx
	movq	1656(%rbp), %r9
	movq	1608(%rbp), %rdi
	je	.LBB45_47
	leaq	-1(%rax), %rcx
	movq	%rcx, 1520(%rbp)
	cmpq	$32, %rax
	ja	.LBB45_96
	leaq	(%rcx,%rcx,2), %rax
	movups	728(%rbp,%rax,8), %xmm0
	movq	744(%rbp,%rax,8), %rax
	leaq	1496(%rbp), %rcx
	movq	%rax, 16(%rcx)
	movups	%xmm0, (%rcx)
	cmpq	%r13, %r15
	ja	.LBB45_46
.LBB45_48:
	movq	720(%rbp), %rax
	testq	%rax, %rax
	movq	1808(%rbp), %rdx
	je	.LBB45_51
	leaq	-1(%rax), %rcx
	movq	%rcx, 720(%rbp)
	cmpq	$32, %rax
	movq	1664(%rbp), %r8
	ja	.LBB45_96
	leaq	(%rcx,%rcx,2), %rax
	movups	-72(%rbp,%rax,8), %xmm0
	movq	-56(%rbp,%rax,8), %rax
	leaq	696(%rbp), %rcx
	movq	%rax, 16(%rcx)
	movups	%xmm0, (%rcx)
	addq	%r14, %r8
	movq	%r8, 1664(%rbp)
	cmpq	%rdx, %r8
	jb	.LBB45_21
	jmp	.LBB45_53
.LBB45_47:
	movq	$0, 1512(%rbp)
	cmpq	%r13, %r15
	ja	.LBB45_46
	jmp	.LBB45_48
.LBB45_51:
	movq	$0, 712(%rbp)
.LBB45_52:
	movq	1664(%rbp), %r8
	addq	%r14, %r8
	movq	%r8, 1664(%rbp)
	cmpq	%rdx, %r8
	jb	.LBB45_21
.LBB45_53:
	movq	1808(%rbp), %rax
	movq	%rax, 1664(%rbp)
	jmp	.LBB45_76
.LBB45_54:
	movabsq	$9223372036854775800, %rax
	andq	%r14, %rax
	movq	$-8, %rdx
	movq	%r14, %rcx
	movq	1664(%rbp), %r10
.LBB45_55:
	cmpq	$7, %rcx
	jbe	.LBB45_58
	movq	8(%rbx,%rdx), %r8
	movq	8(%rdi,%rdx), %r9
	addq	$8, %rdx
	addq	$-8, %rcx
	cmpq	%r9, %r8
	je	.LBB45_55
	xorq	%r8, %r9
	rep		bsfq	%r9, %rcx
	shrl	$3, %ecx
	addq	%rdx, %rcx
	jmp	.LBB45_75
.LBB45_58:
	andq	$7, %r14
	je	.LBB45_97
	movzbl	(%rbx,%rax), %ecx
	cmpb	(%rdi,%rax), %cl
	jne	.LBB45_73
	cmpl	$1, %r14d
	je	.LBB45_97
	movzbl	1(%rbx,%rax), %edx
	movl	$1, %ecx
	cmpb	1(%rdi,%rax), %dl
	jne	.LBB45_74
	cmpl	$2, %r14d
	je	.LBB45_97
	movzbl	2(%rbx,%rax), %edx
	movl	$2, %ecx
	cmpb	2(%rdi,%rax), %dl
	jne	.LBB45_74
	cmpl	$3, %r14d
	je	.LBB45_97
	movzbl	3(%rbx,%rax), %edx
	movl	$3, %ecx
	cmpb	3(%rdi,%rax), %dl
	jne	.LBB45_74
	cmpl	$4, %r14d
	je	.LBB45_97
	movzbl	4(%rbx,%rax), %edx
	movl	$4, %ecx
	cmpb	4(%rdi,%rax), %dl
	jne	.LBB45_74
	cmpl	$5, %r14d
	je	.LBB45_97
	movzbl	5(%rbx,%rax), %edx
	movl	$5, %ecx
	cmpb	5(%rdi,%rax), %dl
	jne	.LBB45_74
	cmpl	$6, %r14d
	je	.LBB45_97
	movzbl	6(%rbx,%rax), %edx
	movl	$6, %ecx
	cmpb	6(%rdi,%rax), %dl
	jne	.LBB45_74
.LBB45_97:
	leaq	anon.3126157283a31055444fc45c79212b1f.36(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.LBB45_73:
	xorl	%ecx, %ecx
.LBB45_74:
	orq	%rax, %rcx
.LBB45_75:
	addq	%rcx, %r10
	movq	%r10, 1664(%rbp)
.LBB45_76:
	movq	$0, 1640(%rbp)
.LBB45_77:
	movl	1628(%rbp), %esi
	movq	1552(%rbp), %rdi
	movq	1792(%rbp), %rbx
	movq	1560(%rbp), %r14
	movq	1568(%rbp), %r15
	movl	1800(%rbp), %r12d
	movq	1808(%rbp), %r13
	movq	1640(%rbp), %rax
	testb	$1, %al
	je	.LBB45_86
.LBB45_78:
	movq	%r15, 728(%rbp)
	movq	%r14, 736(%rbp)
	movzbl	1679(%rbp), %eax
	movb	%al, 768(%rbp)
	movq	$0, 744(%rbp)
	movq	$0, 760(%rbp)
	movq	%rdi, %rdx
	movq	1664(%rbp), %r14
	addq	%r14, %rdx
	addq	%r14, %rbx
	subq	%r14, %r13
.Ltmp94:
	movq	%r13, 40(%rsp)
	movl	%r12d, 32(%rsp)
	leaq	728(%rbp), %rcx
	movl	%esi, %r8d
	movq	%rbx, %r9
	callq	_ZN26hashrope_diagnostic_slot_a4rope15ExactComparison3lcp17h189789a5c51c350fE
.Ltmp95:
	movq	%rax, %rsi
	movq	744(%rbp), %rcx
	testq	%rcx, %rcx
	je	.LBB45_81
	movq	752(%rbp), %rdx
	movq	760(%rbp), %rax
	movq	$0, -64(%rbp)
	movq	%rcx, -56(%rbp)
	movq	%rdx, -48(%rbp)
	movq	$0, -32(%rbp)
	movq	%rcx, -24(%rbp)
	movq	%rdx, -16(%rbp)
	movl	$1, %ecx
	jmp	.LBB45_82
.LBB45_81:
	xorl	%ecx, %ecx
	xorl	%eax, %eax
.LBB45_82:
	movq	%rcx, -72(%rbp)
	movq	%rcx, -40(%rbp)
	movq	%rax, -8(%rbp)
	leaq	1528(%rbp), %rcx
	leaq	-72(%rbp), %rdx
	callq	_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E
	cmpq	$0, 1528(%rbp)
	je	.LBB45_85
	leaq	1528(%rbp), %rdi
	leaq	-72(%rbp), %rbx
	.p2align	4
.LBB45_84:
	movq	%rdi, %rcx
	movq	%rbx, %rdx
	callq	_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E
	cmpq	$0, 1528(%rbp)
	jne	.LBB45_84
.LBB45_85:
	addq	%rsi, %r14
	movq	%r14, 1664(%rbp)
.LBB45_86:
	movq	1664(%rbp), %rbx
.LBB45_87:
	movq	%rbx, %rax
	.seh_startepilogue
	addq	$1816, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.LBB45_88:
	leaq	anon.3126157283a31055444fc45c79212b1f.15(%rip), %r9
	xorl	%ecx, %ecx
	movq	%r14, %rdx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB45_89:
	leaq	anon.3126157283a31055444fc45c79212b1f.16(%rip), %r9
	movq	%r12, %rcx
	movq	%rdx, %r8
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB45_90:
	leaq	anon.3126157283a31055444fc45c79212b1f.14(%rip), %r9
	movq	%rsi, %rcx
	movq	%rdx, %r8
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB45_91:
	leaq	anon.3126157283a31055444fc45c79212b1f.12(%rip), %r9
	xorl	%ecx, %ecx
	movq	%r14, %rdx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.LBB45_92:
	leaq	anon.3126157283a31055444fc45c79212b1f.10(%rip), %r8
	movq	%rbx, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB45_93:
	leaq	anon.3126157283a31055444fc45c79212b1f.11(%rip), %r8
	movq	%rax, %rcx
	movq	%r11, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB45_94:
	leaq	anon.3126157283a31055444fc45c79212b1f.44(%rip), %r8
	movq	%r10, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB45_95:
	leaq	anon.3126157283a31055444fc45c79212b1f.44(%rip), %r8
	movq	%r11, %rdx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB45_96:
	leaq	anon.3126157283a31055444fc45c79212b1f.13(%rip), %r8
	movl	$32, %edx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_handlerdata
	.long	$cppxdata$_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E@IMGREL
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E,unique,45
	.seh_endproc
	.def	"?dtor$98@?0?_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$98@?0?_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E@4HA":
.seh_proc "?dtor$98@?0?_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E@4HA"
.LBB45_98:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	leaq	128(%rdx), %rbp
	.seh_endprologue
	leaq	728(%rbp), %rcx
	callq	_ZN4core3ptr70drop_in_place$LT$hashrope_diagnostic_slot_a..rope..ExactComparison$GT$17hb52820c24582e630E
	nop
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E,unique,45
	.seh_endproc
	.def	"?dtor$99@?0?_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$99@?0?_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E@4HA":
.seh_proc "?dtor$99@?0?_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E@4HA"
.LBB45_99:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	leaq	128(%rdx), %rbp
	.seh_endprologue
	leaq	728(%rbp), %rcx
	callq	_ZN4core3ptr70drop_in_place$LT$hashrope_diagnostic_slot_a..rope..ExactComparison$GT$17hb52820c24582e630E
	nop
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.Lfunc_end8:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E,unique,45
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E,unique,8
	.p2align	2, 0x0
$cppxdata$_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E:
	.long	429065506
	.long	2
	.long	$stateUnwindMap$_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E@IMGREL
	.long	0
	.long	0
	.long	5
	.long	$ip2state$_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E@IMGREL
	.long	1808
	.long	0
	.long	1
$stateUnwindMap$_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E:
	.long	-1
	.long	"?dtor$99@?0?_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E@4HA"@IMGREL
	.long	-1
	.long	"?dtor$98@?0?_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E@4HA"@IMGREL
$ip2state$_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E:
	.long	.Lfunc_begin8@IMGREL
	.long	-1
	.long	.Ltmp96@IMGREL+1
	.long	0
	.long	.Ltmp97@IMGREL+1
	.long	-1
	.long	.Ltmp94@IMGREL+1
	.long	1
	.long	.Ltmp95@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a4rope9exact_lcp17he31637b4cada78f0E,unique,45

	.def	_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow10final_hash17h055ca5ea7d424632E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow10final_hash17h055ca5ea7d424632E,unique,46
	.globl	_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow10final_hash17h055ca5ea7d424632E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow10final_hash17h055ca5ea7d424632E:
	jmp	_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow12current_hash17h8d4dff4544a7e411E

	.def	_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow11append_copy17hb6dfa3ba51c53177E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow11append_copy17hb6dfa3ba51c53177E,unique,47
	.globl	_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow11append_copy17hb6dfa3ba51c53177E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow11append_copy17hb6dfa3ba51c53177E:
.seh_proc _ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow11append_copy17hb6dfa3ba51c53177E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$112, %rsp
	.seh_stackalloc 112
	.seh_endprologue
	movq	%r8, %rdi
	movq	%rdx, %r10
	movq	%rcx, %rsi
	movq	%rdx, 32(%rsp)
	movl	2136(%rcx), %r11d
	movl	2140(%rcx), %ebx
	movq	8(%rcx), %rcx
	movq	16(%rsi), %rdx
	cmpl	$1, %r11d
	jne	.LBB47_1
	cmpq	%rbx, %rdx
	jbe	.LBB47_84
	leaq	(%rbx,%rbx,2), %rax
	shlq	$4, %rax
	leaq	(%rcx,%rax), %r8
	xorl	%r9d, %r9d
	cmpl	$0, (%rcx,%rax)
	setne	%r9b
	movq	16(%r8,%r9,8), %r14
	jmp	.LBB47_4
.LBB47_1:
	xorl	%r14d, %r14d
.LBB47_4:
	movq	%r14, 104(%rsp)
	cmpq	2184(%rsi), %r10
	ja	.LBB47_85
	movq	%r14, %r9
	subq	%r10, %r9
	jb	.LBB47_86
	cmpq	%rdi, %r10
	jae	.LBB47_25
	movq	2072(%rsi), %rax
	cmpq	%rax, 2112(%rsi)
	jne	.LBB47_87
	movq	2080(%rsi), %r8
	cmpq	%r8, 2120(%rsi)
	jne	.LBB47_87
	testb	%r11b, %r11b
	je	.LBB47_10
	cmpq	%r10, %r14
	je	.LBB47_19
	cmpq	%rbx, %rdx
	jbe	.LBB47_84
	leaq	(%rbx,%rbx,2), %rdx
	shlq	$4, %rdx
	xorl	%r11d, %r11d
	cmpl	$0, (%rcx,%rdx)
	leaq	(%rcx,%rdx), %rcx
	setne	%r11b
	cmpq	16(%rcx,%r11,8), %r9
	jae	.LBB47_10
	leaq	40(%rsp), %rcx
	movq	%rsi, %rdx
	movl	%ebx, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E
	movzbl	48(%rsp), %ecx
	movl	52(%rsp), %ebx
	movq	32(%rsp), %r10
	movq	2072(%rsi), %r9
	movq	2080(%rsi), %rdx
	movq	2112(%rsi), %rax
	movq	2120(%rsi), %r8
	jmp	.LBB47_15
.LBB47_25:
	movq	2072(%rsi), %rax
	cmpq	%rax, 2112(%rsi)
	jne	.LBB47_87
	movq	2080(%rsi), %r8
	cmpq	%r8, 2120(%rsi)
	jne	.LBB47_87
	testb	%r11b, %r11b
	je	.LBB47_28
	cmpq	%r10, %r14
	je	.LBB47_37
	cmpq	%rbx, %rdx
	jbe	.LBB47_84
	leaq	(%rbx,%rbx,2), %rdx
	shlq	$4, %rdx
	xorl	%r10d, %r10d
	cmpl	$0, (%rcx,%rdx)
	leaq	(%rcx,%rdx), %rcx
	setne	%r10b
	cmpq	16(%rcx,%r10,8), %r9
	jae	.LBB47_28
	leaq	40(%rsp), %rcx
	movq	%rsi, %rdx
	movl	%ebx, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E
	movzbl	48(%rsp), %ecx
	movl	52(%rsp), %ebx
	movq	2072(%rsi), %r9
	movq	2080(%rsi), %rdx
	movq	2112(%rsi), %rax
	movq	2120(%rsi), %r8
	jmp	.LBB47_33
.LBB47_10:
	xorl	%ecx, %ecx
	movq	%r8, %rdx
	movq	%rax, %r9
.LBB47_15:
	cmpq	%r9, %rax
	jne	.LBB47_87
	cmpq	%rdx, %r8
	jne	.LBB47_87
	testb	%cl, %cl
	je	.LBB47_18
.LBB47_19:
	testq	%r10, %r10
	je	.LBB47_24
	movl	%ebx, %ecx
	movq	16(%rsi), %rdx
	cmpq	%rcx, %rdx
	jbe	.LBB47_75
	movq	8(%rsi), %rax
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	xorl	%edx, %edx
	cmpl	$0, (%rax,%rcx)
	leaq	(%rax,%rcx), %rax
	setne	%dl
	cmpq	16(%rax,%rdx,8), %r10
	jae	.LBB47_51
	leaq	40(%rsp), %rcx
	movq	%rsi, %rdx
	movl	%ebx, %r8d
	movq	%r10, %r9
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E
	movzbl	40(%rsp), %r12d
	movl	44(%rsp), %ebx
	movq	32(%rsp), %r10
	jmp	.LBB47_23
.LBB47_28:
	xorl	%ecx, %ecx
	movq	%r8, %rdx
	movq	%rax, %r9
.LBB47_33:
	cmpq	%r9, %rax
	jne	.LBB47_87
	cmpq	%rdx, %r8
	jne	.LBB47_87
	testb	%cl, %cl
	je	.LBB47_36
.LBB47_37:
	testq	%rdi, %rdi
	je	.LBB47_36
	movl	%ebx, %ecx
	movq	16(%rsi), %rdx
	cmpq	%rcx, %rdx
	jbe	.LBB47_75
	movq	8(%rsi), %rdx
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	leaq	(%rdx,%rcx), %r9
	xorl	%r10d, %r10d
	cmpl	$0, (%rdx,%rcx)
	setne	%r10b
	movl	$1, %ecx
	cmpq	16(%r9,%r10,8), %rdi
	jae	.LBB47_40
	leaq	40(%rsp), %rcx
	movq	%rsi, %rdx
	movl	%ebx, %r8d
	movq	%rdi, %r9
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E
	movl	40(%rsp), %ecx
	movl	44(%rsp), %ebx
	movq	2072(%rsi), %r9
	movq	2080(%rsi), %rdx
	movq	2112(%rsi), %rax
	movq	2120(%rsi), %r8
	cmpq	%r9, %rax
	je	.LBB47_43
	jmp	.LBB47_87
.LBB47_36:
	xorl	%ecx, %ecx
	movq	%r8, %rdx
	movq	%rax, %r9
	cmpq	%r9, %rax
	je	.LBB47_43
	jmp	.LBB47_87
.LBB47_18:
	xorl	%r12d, %r12d
.LBB47_23:
	testq	%r10, %r10
	je	.LBB47_24
	movq	%rdi, %rax
	orq	%r10, %rax
	shrq	$32, %rax
	je	.LBB47_53
.LBB47_54:
	movq	%rdi, %rax
	xorl	%edx, %edx
	divq	%r10
	movq	%rdx, %r15
	jmp	.LBB47_55
.LBB47_51:
	movb	$1, %r12b
	movq	%rdi, %rax
	orq	%r10, %rax
	shrq	$32, %rax
	jne	.LBB47_54
.LBB47_53:
	movl	%edi, %eax
	xorl	%edx, %edx
	divl	%r10d
	movl	%edx, %r15d
.LBB47_55:
	xorl	%ebp, %ebp
	movq	2072(%rsi), %rdx
	movq	2080(%rsi), %rcx
	movq	2112(%rsi), %r9
	movq	2120(%rsi), %r8
	cmpq	%rdi, %r10
	jbe	.LBB47_57
	jmp	.LBB47_61
.LBB47_57:
	cmpq	%rdx, %r9
	jne	.LBB47_87
	cmpq	%rcx, %r8
	jne	.LBB47_87
	movq	%rcx, %r8
	movq	%rdx, %r9
	testb	%r12b, %r12b
	je	.LBB47_61
	movq	%rsi, %rcx
	movl	%ebx, %edx
	movq	%rax, %r8
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11make_repeat17h97d110bb9b6bcb49E
	movl	%eax, %ebp
	movl	%edx, %r14d
	movq	2072(%rsi), %rdx
	movq	2080(%rsi), %rcx
	movq	2112(%rsi), %r9
	movq	2120(%rsi), %r8
.LBB47_61:
	testq	%r15, %r15
	je	.LBB47_62
	cmpq	%rdx, %r9
	jne	.LBB47_87
	cmpq	%rcx, %r8
	jne	.LBB47_87
	testb	%r12b, %r12b
	je	.LBB47_71
	movl	%ebx, %ecx
	movq	16(%rsi), %rdx
	cmpq	%rcx, %rdx
	jbe	.LBB47_75
	movq	8(%rsi), %rax
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	leaq	(%rax,%rcx), %rdx
	xorl	%r10d, %r10d
	cmpl	$0, (%rax,%rcx)
	setne	%r10b
	movl	$1, %eax
	cmpq	16(%rdx,%r10,8), %r15
	jae	.LBB47_74
	leaq	40(%rsp), %rcx
	movq	%rsi, %rdx
	movl	%ebx, %r8d
	movq	%r15, %r9
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E
	movl	40(%rsp), %eax
	movl	44(%rsp), %ebx
	movq	2072(%rsi), %rdx
	movq	2080(%rsi), %rcx
	movq	2112(%rsi), %r9
	movq	2120(%rsi), %r8
	cmpq	%rdx, %r9
	je	.LBB47_78
	jmp	.LBB47_87
.LBB47_71:
	xorl	%eax, %eax
	movq	%r8, %rcx
	movq	%r9, %rdx
	cmpq	%rdx, %r9
	je	.LBB47_78
	jmp	.LBB47_87
.LBB47_40:
	movq	%r8, %rdx
	movq	%rax, %r9
	cmpq	%r9, %rax
	jne	.LBB47_87
.LBB47_43:
	cmpq	%rdx, %r8
	jne	.LBB47_87
	cmpl	$0, 2136(%rsi)
	je	.LBB47_45
	movl	2140(%rsi), %edx
	movl	$1, %ebp
	testl	%ecx, %ecx
	je	.LBB47_48
	movq	%rsi, %rcx
	movl	%ebx, %r8d
	jmp	.LBB47_50
.LBB47_45:
	movl	%ecx, %ebp
	jmp	.LBB47_46
.LBB47_48:
	movl	%edx, %ebx
	jmp	.LBB47_46
.LBB47_74:
	movq	%r8, %rcx
	movq	%r9, %rdx
	cmpq	%rdx, %r9
	jne	.LBB47_87
.LBB47_78:
	cmpq	%rcx, %r8
	jne	.LBB47_87
	testb	$1, %bpl
	je	.LBB47_80
	movl	$1, %ebp
	testl	%eax, %eax
	je	.LBB47_82
	movq	%rsi, %rcx
	movl	%r14d, %edx
	movl	%ebx, %r8d
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE
	movl	%eax, %r14d
	movq	2072(%rsi), %rdx
	movq	2080(%rsi), %rcx
	movq	2112(%rsi), %r9
	movq	2120(%rsi), %r8
	cmpq	%rdx, %r9
	je	.LBB47_63
	jmp	.LBB47_87
.LBB47_80:
	movq	%r8, %rcx
	movq	%r9, %rdx
	movl	%ebx, %r14d
	movl	%eax, %ebp
.LBB47_62:
	cmpq	%rdx, %r9
	jne	.LBB47_87
.LBB47_63:
	cmpq	%rcx, %r8
	jne	.LBB47_87
	cmpl	$0, 2136(%rsi)
	je	.LBB47_65
	movl	2140(%rsi), %ebx
	testb	$1, %bpl
	movl	$1, %ebp
	je	.LBB47_46
	movq	%rsi, %rcx
	movl	%ebx, %edx
	movl	%r14d, %r8d
.LBB47_50:
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE
	movl	%eax, %ebx
	jmp	.LBB47_46
.LBB47_65:
	movl	%r14d, %ebx
.LBB47_46:
	movl	%ebp, 2136(%rsi)
	movl	%ebx, 2140(%rsi)
	addq	%rdi, 2184(%rsi)
	movq	%rsi, %rcx
	.seh_startepilogue
	addq	$112, %rsp
	popq	%rbx
	popq	%rbp
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	jmp	_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow5evict17h8ca36cd88b36e0d7E
.LBB47_82:
	movq	%r8, %rcx
	movq	%r9, %rdx
	cmpq	%rdx, %r9
	je	.LBB47_63
.LBB47_87:
	leaq	anon.3126157283a31055444fc45c79212b1f.37(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB47_85:
	addq	$2184, %rsi
	leaq	32(%rsp), %rax
	movq	%rax, 40(%rsp)
	leaq	_ZN4core3fmt3num3imp52_$LT$impl$u20$core..fmt..Display$u20$for$u20$u64$GT$3fmt17h9f4f228998531a48E(%rip), %rax
	movq	%rax, 48(%rsp)
	movq	%rsi, 56(%rsp)
	movq	%rax, 64(%rsp)
	leaq	anon.3126157283a31055444fc45c79212b1f.85(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.87(%rip), %r8
	leaq	40(%rsp), %rdx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB47_86:
	addq	$2144, %rsi
	leaq	32(%rsp), %rax
	movq	%rax, 40(%rsp)
	leaq	_ZN4core3fmt3num3imp52_$LT$impl$u20$core..fmt..Display$u20$for$u20$u64$GT$3fmt17h9f4f228998531a48E(%rip), %rcx
	movq	%rcx, 48(%rsp)
	leaq	104(%rsp), %rdx
	movq	%rdx, 56(%rsp)
	movq	%rcx, 64(%rsp)
	movq	%rsi, 72(%rsp)
	movq	%rcx, 80(%rsp)
	movq	%rax, 88(%rsp)
	movq	%rcx, 96(%rsp)
	leaq	anon.3126157283a31055444fc45c79212b1f.88(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.89(%rip), %r8
	leaq	40(%rsp), %rdx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB47_84:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%rbx, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB47_75:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB47_24:
	leaq	anon.3126157283a31055444fc45c79212b1f.90(%rip), %rcx
	callq	_ZN4core9panicking11panic_const23panic_const_div_by_zero17hdceffd214664eedfE
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow12append_bytes17h2a54fd8afaf25721E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow12append_bytes17h2a54fd8afaf25721E,unique,48
	.globl	_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow12append_bytes17h2a54fd8afaf25721E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow12append_bytes17h2a54fd8afaf25721E:
.seh_proc _ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow12append_bytes17h2a54fd8afaf25721E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	testq	%r8, %r8
	je	.LBB48_8
	movq	%r8, %rsi
	movq	%rcx, %rdi
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena10from_bytes17h2b33bd045a584022E
	movq	2112(%rdi), %rcx
	cmpq	2072(%rdi), %rcx
	jne	.LBB48_9
	movq	2080(%rdi), %rcx
	cmpq	%rcx, 2120(%rdi)
	jne	.LBB48_9
	movl	%edx, %r8d
	cmpl	$0, 2136(%rdi)
	je	.LBB48_7
	movl	2140(%rdi), %edx
	testb	$1, %al
	movl	$1, %eax
	je	.LBB48_5
	movq	%rdi, %rcx
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena4join17hb9228ad0a015f96dE
	movl	%eax, %r8d
	movl	$1, %eax
	jmp	.LBB48_7
.LBB48_8:
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB48_5:
	movl	%edx, %r8d
.LBB48_7:
	movl	%eax, 2136(%rdi)
	movl	%r8d, 2140(%rdi)
	addq	%rsi, 2184(%rdi)
	movq	%rdi, %rcx
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	jmp	_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow5evict17h8ca36cd88b36e0d7E
.LBB48_9:
	leaq	anon.3126157283a31055444fc45c79212b1f.37(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow12current_hash17h8d4dff4544a7e411E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow12current_hash17h8d4dff4544a7e411E,unique,49
	.globl	_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow12current_hash17h8d4dff4544a7e411E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow12current_hash17h8d4dff4544a7e411E:
.seh_proc _ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow12current_hash17h8d4dff4544a7e411E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	.seh_endprologue
	movq	%rcx, %rsi
	movl	2136(%rcx), %r9d
	movl	2140(%rcx), %ecx
	movq	8(%rsi), %r8
	movq	16(%rsi), %rdx
	cmpl	$1, %r9d
	jne	.LBB49_1
	cmpq	%rcx, %rdx
	jbe	.LBB49_11
	leaq	(%rcx,%rcx,2), %rax
	shlq	$4, %rax
	leaq	(%r8,%rax), %r10
	xorl	%r11d, %r11d
	cmpl	$0, (%r8,%rax)
	setne	%r11b
	movq	16(%r10,%r11,8), %rax
	jmp	.LBB49_4
.LBB49_1:
	xorl	%eax, %eax
.LBB49_4:
	movq	2112(%rsi), %r10
	cmpq	2072(%rsi), %r10
	jne	.LBB49_12
	movq	2080(%rsi), %r10
	cmpq	%r10, 2120(%rsi)
	jne	.LBB49_12
	testb	%r9b, %r9b
	je	.LBB49_7
	movl	%ecx, %ecx
	cmpq	%rcx, %rdx
	jbe	.LBB49_13
	leaq	(%rcx,%rcx,2), %rcx
	shlq	$4, %rcx
	leaq	(%r8,%rcx), %rdx
	xorl	%r9d, %r9d
	cmpl	$0, (%r8,%rcx)
	setne	%r9b
	movq	8(%rdx,%r9,8), %rdi
	jmp	.LBB49_10
.LBB49_7:
	xorl	%edi, %edi
.LBB49_10:
	leaq	24(%rsi), %rcx
	movq	2168(%rsi), %rbx
	movq	%rax, %rdx
	callq	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE
	mulq	%rbx
	addq	%rdi, %rax
	adcq	$0, %rdx
	movq	2072(%rsi), %r8
	movl	$127, %r9d
	bsrq	%r8, %r9
	xorl	$63, %r9d
	movb	$64, %cl
	subb	%r9b, %cl
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	xorl	%r10d, %r10d
	testb	$64, %cl
	cmovneq	%rdx, %r9
	cmovneq	%r10, %rdx
	andq	%r8, %rax
	addq	%r9, %rax
	adcq	$0, %rdx
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	testb	$64, %cl
	cmovneq	%rdx, %r9
	andq	%r8, %rax
	addq	%r9, %rax
	cmpq	%rax, %r8
	cmovaq	%r10, %r8
	subq	%r8, %rax
	.seh_startepilogue
	addq	$32, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB49_12:
	leaq	anon.3126157283a31055444fc45c79212b1f.37(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB49_11:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB49_13:
	leaq	anon.3126157283a31055444fc45c79212b1f.40(%rip), %r8
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow14default_window17h8dd5b82a0138b040E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow14default_window17h8dd5b82a0138b040E,unique,50
	.globl	_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow14default_window17h8dd5b82a0138b040E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow14default_window17h8dd5b82a0138b040E:
.seh_proc _ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow14default_window17h8dd5b82a0138b040E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$2088, %rsp
	.seh_stackalloc 2088
	.seh_endprologue
	movq	%rcx, %rsi
	movabsq	$2305843009213693951, %rdi
	leaq	48(%rsp), %rcx
	movl	$2040, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	$1, 40(%rsp)
	movl	$1, %eax
	movl	$131, %r8d
	movabsq	$-2305843009213693951, %r9
	movl	$1, %r10d
	.p2align	4
.LBB50_1:
	mulq	%r8
	movq	%rax, %rcx
	shrq	$61, %rax
	leaq	(%rax,%rdx,8), %rax
	andq	%rdi, %rcx
	addq	%rax, %rcx
	movq	%rcx, %rax
	shrq	$61, %rax
	andq	%rdi, %rcx
	addq	%rax, %rcx
	leaq	(%rcx,%r9), %rax
	cmpq	%rdi, %rcx
	cmovbq	%rcx, %rax
	movq	%rax, 40(%rsp,%r10,8)
	incq	%r10
	cmpq	$256, %r10
	jne	.LBB50_1
	movq	$0, (%rsi)
	movq	$8, 8(%rsi)
	movq	$0, 16(%rsi)
	leaq	24(%rsi), %rcx
	leaq	40(%rsp), %rdx
	movl	$2048, %r8d
	callq	memcpy
	movq	%rdi, 2072(%rsi)
	movq	$131, 2080(%rsi)
	movq	$0, 2088(%rsi)
	movq	$0, 2104(%rsi)
	movq	%rdi, 2112(%rsi)
	movq	$131, 2120(%rsi)
	movb	$0, 2128(%rsi)
	movq	$32768, 2144(%rsi)
	movq	$258, 2152(%rsi)
	movq	$33026, 2160(%rsi)
	movl	$0, 2136(%rsi)
	xorps	%xmm0, %xmm0
	movups	%xmm0, 2168(%rsi)
	movq	$0, 2184(%rsi)
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$2088, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow3new17hcc0ce7c911b245c8E;
	.scl	2;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow3new17hcc0ce7c911b245c8E,unique,51
	.globl	_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow3new17hcc0ce7c911b245c8E
	.p2align	4
_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow3new17hcc0ce7c911b245c8E:
.seh_proc _ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow3new17hcc0ce7c911b245c8E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$2120, %rsp
	.seh_stackalloc 2120
	.seh_endprologue
	movq	%rdx, 56(%rsp)
	movq	%r8, 64(%rsp)
	testq	%rdx, %rdx
	je	.LBB51_7
	movq	%r8, %rdi
	testq	%r8, %r8
	je	.LBB51_8
	movq	2208(%rsp), %r15
	cmpq	$2, %r15
	jb	.LBB51_9
	movq	%r9, %r14
	cmpq	%r9, %r15
	jae	.LBB51_9
	movq	%rdx, %rbx
	movq	%rcx, %rsi
	leaq	80(%rsp), %rcx
	xorl	%r12d, %r12d
	movl	$2040, %r8d
	xorl	%edx, %edx
	callq	memset
	movq	$1, 72(%rsp)
	bsrq	%r14, %rcx
	incl	%ecx
	movl	$1, %eax
	movl	$1, %r8d
	.p2align	4
.LBB51_5:
	mulq	%r15
	movq	%rdx, %r9
	shrq	%cl, %r9
	movq	%rax, %r10
	shrdq	%cl, %rdx, %r10
	testb	$64, %cl
	cmovneq	%r9, %r10
	cmovneq	%r12, %r9
	andq	%r14, %rax
	addq	%r10, %rax
	adcq	$0, %r9
	movq	%rax, %rdx
	shrdq	%cl, %r9, %rdx
	shrq	%cl, %r9
	testb	$64, %cl
	cmoveq	%rdx, %r9
	andq	%r14, %rax
	addq	%r9, %rax
	cmpq	%rax, %r14
	movq	%r14, %rdx
	cmovaq	%r12, %rdx
	subq	%rdx, %rax
	movq	%rax, 72(%rsp,%r8,8)
	incq	%r8
	cmpq	$256, %r8
	jne	.LBB51_5
	leaq	(%rdi,%rbx), %r12
	movq	$0, (%rsi)
	movq	$8, 8(%rsi)
	movq	$0, 16(%rsi)
	leaq	24(%rsi), %rcx
	leaq	72(%rsp), %rdx
	movl	$2048, %r8d
	callq	memcpy
	movq	%r14, 2072(%rsi)
	movq	%r15, 2080(%rsi)
	movq	$0, 2088(%rsi)
	movq	$0, 2104(%rsi)
	movq	%r14, 2112(%rsi)
	movq	%r15, 2120(%rsi)
	movb	$0, 2128(%rsi)
	movq	%rbx, 2144(%rsi)
	movq	%rdi, 2152(%rsi)
	movq	%r12, 2160(%rsi)
	movl	$0, 2136(%rsi)
	xorps	%xmm0, %xmm0
	movups	%xmm0, 2168(%rsi)
	movq	$0, 2184(%rsi)
	movq	%rsi, %rax
	.seh_startepilogue
	addq	$2120, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB51_9:
	leaq	anon.3126157283a31055444fc45c79212b1f.2(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.3(%rip), %r8
	movl	$49, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB51_7:
	leaq	56(%rsp), %rax
	movq	%rax, 40(%rsp)
	leaq	_ZN4core3fmt3num3imp52_$LT$impl$u20$core..fmt..Display$u20$for$u20$u64$GT$3fmt17h9f4f228998531a48E(%rip), %rax
	movq	%rax, 48(%rsp)
	leaq	anon.3126157283a31055444fc45c79212b1f.91(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.92(%rip), %r8
	leaq	40(%rsp), %rdx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB51_8:
	leaq	64(%rsp), %rax
	movq	%rax, 40(%rsp)
	leaq	_ZN4core3fmt3num3imp52_$LT$impl$u20$core..fmt..Display$u20$for$u20$u64$GT$3fmt17h9f4f228998531a48E(%rip), %rax
	movq	%rax, 48(%rsp)
	leaq	anon.3126157283a31055444fc45c79212b1f.93(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.94(%rip), %r8
	leaq	40(%rsp), %rdx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
	int3
	.seh_endproc

	.def	_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow5evict17h8ca36cd88b36e0d7E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow5evict17h8ca36cd88b36e0d7E,unique,52
	.p2align	4
_ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow5evict17h8ca36cd88b36e0d7E:
.seh_proc _ZN26hashrope_diagnostic_slot_a7sliding13SlidingWindow5evict17h8ca36cd88b36e0d7E
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	.seh_endprologue
	cmpl	$1, 2136(%rcx)
	jne	.LBB52_20
	movl	2140(%rcx), %esi
	movq	16(%rcx), %rdx
	cmpq	%rsi, %rdx
	jbe	.LBB52_21
	movq	8(%rcx), %r8
	leaq	(%rsi,%rsi,2), %rax
	shlq	$4, %rax
	leaq	(%r8,%rax), %r9
	xorl	%r10d, %r10d
	cmpl	$0, (%r8,%rax)
	setne	%r10b
	movq	16(%r9,%r10,8), %rax
	cmpq	2160(%rcx), %rax
	jbe	.LBB52_20
	movq	2112(%rcx), %r9
	cmpq	2072(%rcx), %r9
	jne	.LBB52_22
	movq	2080(%rcx), %r9
	cmpq	%r9, 2120(%rcx)
	jne	.LBB52_22
	movq	2144(%rcx), %r9
	movq	%rax, %rdi
	subq	%r9, %rdi
	jne	.LBB52_7
	movl	$1, %ebx
	xorl	%r11d, %r11d
	xorl	%eax, %eax
	movq	2112(%rcx), %r10
	cmpq	2072(%rcx), %r10
	je	.LBB52_14
	jmp	.LBB52_22
.LBB52_7:
	cmpq	%rax, %rdi
	jae	.LBB52_8
	leaq	40(%rsp), %rax
	movq	%rcx, %rbx
	movq	%rax, %rcx
	movq	%rbx, %rdx
	movl	%esi, %r8d
	movq	%rdi, %r9
	callq	_ZN26hashrope_diagnostic_slot_a4rope5Arena11split_inner17hd5a502f802adccd9E
	movq	%rbx, %rcx
	movl	44(%rsp), %r9d
	movl	48(%rsp), %ebx
	movl	52(%rsp), %r10d
	movq	8(%rcx), %r8
	movq	16(%rcx), %rdx
	cmpl	$1, 40(%rsp)
	jne	.LBB52_23
	movl	%r9d, %esi
	jmp	.LBB52_11
.LBB52_8:
	xorl	%ebx, %ebx
.LBB52_11:
	movl	%esi, %eax
	cmpq	%rax, %rdx
	jbe	.LBB52_24
	leaq	(%rax,%rax,2), %rax
	shlq	$4, %rax
	leaq	(%r8,%rax), %r9
	xorl	%r11d, %r11d
	cmpl	$0, (%r8,%rax)
	setne	%r11b
	movq	16(%r9,%r11,8), %rax
	movb	$1, %r11b
	movl	%esi, %r9d
	movl	%r10d, %esi
	movq	2112(%rcx), %r10
	cmpq	2072(%rcx), %r10
	je	.LBB52_14
	jmp	.LBB52_22
.LBB52_23:
	xorl	%r11d, %r11d
	movl	%r10d, %esi
	xorl	%eax, %eax
	movq	2112(%rcx), %r10
	cmpq	2072(%rcx), %r10
	jne	.LBB52_22
.LBB52_14:
	movq	2080(%rcx), %r10
	cmpq	%r10, 2120(%rcx)
	jne	.LBB52_22
	testb	%r11b, %r11b
	je	.LBB52_16
	movl	%r9d, %r9d
	cmpq	%r9, %rdx
	jbe	.LBB52_25
	leaq	(%r9,%r9,2), %rdx
	shlq	$4, %rdx
	leaq	(%r8,%rdx), %r9
	xorl	%r10d, %r10d
	cmpl	$0, (%r8,%rdx)
	setne	%r10b
	movq	8(%r9,%r10,8), %r15
	jmp	.LBB52_19
.LBB52_16:
	xorl	%r15d, %r15d
.LBB52_19:
	leaq	24(%rcx), %rdx
	movq	2168(%rcx), %r12
	movq	%rcx, %r14
	movq	%rdx, %rcx
	movq	%rax, %rdx
	callq	_ZN26hashrope_diagnostic_slot_a15polynomial_hash14PolynomialHash5power17hc3e934a515d4627bE
	mulq	%r12
	addq	%r15, %rax
	adcq	$0, %rdx
	movq	2072(%r14), %r8
	movl	$127, %r9d
	bsrq	%r8, %r9
	xorl	$63, %r9d
	movb	$64, %cl
	subb	%r9b, %cl
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	xorl	%r10d, %r10d
	testb	$64, %cl
	cmovneq	%rdx, %r9
	cmovneq	%r10, %rdx
	andq	%r8, %rax
	addq	%r9, %rax
	adcq	$0, %rdx
	movq	%rax, %r9
	shrdq	%cl, %rdx, %r9
	shrq	%cl, %rdx
	testb	$64, %cl
	cmoveq	%r9, %rdx
	andq	%r8, %rax
	addq	%rdx, %rax
	cmpq	%rax, %r8
	cmovaq	%r10, %r8
	subq	%r8, %rax
	movq	%rax, 2168(%r14)
	addq	%rdi, 2176(%r14)
	movl	%ebx, 2136(%r14)
	movl	%esi, 2140(%r14)
.LBB52_20:
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	.seh_endepilogue
	retq
.LBB52_22:
	leaq	anon.3126157283a31055444fc45c79212b1f.37(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.38(%rip), %r8
	movl	$153, %edx
	callq	_ZN4core9panicking9panic_fmt17h3f41ae44232b60f5E
.LBB52_21:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%rsi, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB52_25:
	leaq	anon.3126157283a31055444fc45c79212b1f.40(%rip), %r8
	movq	%r9, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
.LBB52_24:
	leaq	anon.3126157283a31055444fc45c79212b1f.6(%rip), %r8
	movq	%rax, %rcx
	callq	_ZN4core9panicking18panic_bounds_check17hb49dc5b15511a536E
	int3
	.seh_endproc

	.def	_ZN44_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$3fmt17hdc7922d22f1eccf3E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN44_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$3fmt17hdc7922d22f1eccf3E,unique,53
	.p2align	4
_ZN44_$LT$$RF$T$u20$as$u20$core..fmt..Display$GT$3fmt17hdc7922d22f1eccf3E:
	movq	(%rcx), %rcx
	jmp	_ZN4core3fmt3num3imp52_$LT$impl$u20$core..fmt..Display$u20$for$u20$u64$GT$3fmt17h9f4f228998531a48E

	.def	_ZN4core3ptr70drop_in_place$LT$hashrope_diagnostic_slot_a..rope..ExactComparison$GT$17hb52820c24582e630E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN4core3ptr70drop_in_place$LT$hashrope_diagnostic_slot_a..rope..ExactComparison$GT$17hb52820c24582e630E,unique,54
	.p2align	4
_ZN4core3ptr70drop_in_place$LT$hashrope_diagnostic_slot_a..rope..ExactComparison$GT$17hb52820c24582e630E:
.seh_proc _ZN4core3ptr70drop_in_place$LT$hashrope_diagnostic_slot_a..rope..ExactComparison$GT$17hb52820c24582e630E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$136, %rsp
	.seh_stackalloc 136
	.seh_endprologue
	movq	16(%rcx), %rdx
	testq	%rdx, %rdx
	je	.LBB54_1
	movq	24(%rcx), %r8
	movq	32(%rcx), %rax
	movq	$0, 72(%rsp)
	movq	%rdx, 80(%rsp)
	movq	%r8, 88(%rsp)
	movq	$0, 104(%rsp)
	movq	%rdx, 112(%rsp)
	movq	%r8, 120(%rsp)
	movl	$1, %ecx
	jmp	.LBB54_3
.LBB54_1:
	xorl	%ecx, %ecx
	xorl	%eax, %eax
.LBB54_3:
	movq	%rcx, 64(%rsp)
	movq	%rcx, 96(%rsp)
	movq	%rax, 128(%rsp)
	leaq	40(%rsp), %rcx
	leaq	64(%rsp), %rdx
	callq	_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E
	cmpq	$0, 40(%rsp)
	je	.LBB54_6
	leaq	40(%rsp), %rsi
	leaq	64(%rsp), %rdi
	.p2align	4
.LBB54_5:
	movq	%rsi, %rcx
	movq	%rdi, %rdx
	callq	_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E
	cmpq	$0, 40(%rsp)
	jne	.LBB54_5
.LBB54_6:
	.seh_startepilogue
	addq	$136, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E,unique,55
	.p2align	4
_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E:
.Lfunc_begin9:
.seh_proc _ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$232, %rsp
	.seh_stackalloc 232
	leaq	128(%rsp), %rbp
	.seh_setframe %rbp, 128
	movaps	%xmm6, 80(%rbp)
	.seh_savexmm %xmm6, 208
	.seh_endprologue
	movq	$-2, 72(%rbp)
	movq	(%rcx), %r15
	testq	%r15, %r15
	je	.LBB55_83
	movq	%rcx, 32(%rbp)
	movq	8(%rcx), %r8
	movl	16(%rdx), %eax
	movq	(%rdx), %r14
	movq	8(%rdx), %rbx
	movl	20(%rdx), %ecx
	movq	24(%rdx), %rdi
	movq	%r8, -48(%rbp)
	movq	%r15, -56(%rbp)
.LBB55_2:
	movzwl	362(%r15), %r12d
	movl	%r12d, %r9d
	shll	$5, %r9d
	movq	$-1, %r13
	xorl	%r10d, %r10d
	jmp	.LBB55_3
	.p2align	4
.LBB55_10:
	incq	%r13
	addq	$32, %r10
	cmpb	$1, %r11b
	jne	.LBB55_11
.LBB55_3:
	cmpq	%r10, %r9
	je	.LBB55_4
	movl	16(%r15,%r10), %esi
	cmpl	%esi, %eax
	seta	%r11b
	sbbb	$0, %r11b
	cmpl	%esi, %eax
	jne	.LBB55_10
	movq	(%r15,%r10), %rsi
	cmpq	%rsi, %r14
	seta	%r11b
	sbbb	$0, %r11b
	cmpq	%rsi, %r14
	jne	.LBB55_10
	movl	20(%r15,%r10), %esi
	cmpl	%esi, %ecx
	seta	%r11b
	sbbb	$0, %r11b
	cmpl	%esi, %ecx
	jne	.LBB55_10
	movq	8(%r15,%r10), %rsi
	cmpq	%rsi, %rbx
	seta	%r11b
	sbbb	$0, %r11b
	cmpq	%rsi, %rbx
	jne	.LBB55_10
	cmpq	24(%r15,%r10), %rdi
	seta	%r11b
	sbbb	$0, %r11b
	jmp	.LBB55_10
	.p2align	4
.LBB55_11:
	movzbl	%r11b, %r9d
	testl	%r9d, %r9d
	je	.LBB55_86
	jmp	.LBB55_12
	.p2align	4
.LBB55_4:
	movq	%r12, %r13
.LBB55_12:
	subq	$1, %r8
	jb	.LBB55_14
	movq	368(%r15,%r13,8), %r15
	jmp	.LBB55_2
.LBB55_83:
	movq	%rcx, %rbx
	movq	(%rdx), %rsi
	movups	8(%rdx), %xmm6
	movq	24(%rdx), %rdi
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$368, %ecx
	movl	$8, %edx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB55_87
	movq	$0, 352(%rax)
	movq	%rbx, %rcx
	movq	%rax, (%rbx)
	movq	$0, 8(%rbx)
	movw	$1, 362(%rax)
	movq	%rsi, (%rax)
	movups	%xmm6, 8(%rax)
	movq	%rdi, 24(%rax)
.LBB55_85:
	incq	16(%rcx)
.LBB55_86:
	movaps	80(%rbp), %xmm6
	.seh_startepilogue
	addq	$232, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.LBB55_14:
	movq	16(%rdx), %rsi
	cmpw	$11, %r12w
	jae	.LBB55_15
	cmpq	%r13, %r12
	jbe	.LBB55_19
	movq	%r13, %rax
	shlq	$5, %rax
	leaq	(%r15,%rax), %rdx
	leaq	(%r15,%rax), %rcx
	addq	$32, %rcx
	movl	%r12d, %r8d
	subl	%r13d, %r8d
	shll	$5, %r8d
	callq	memmove
.LBB55_19:
	incl	%r12d
	shlq	$5, %r13
	movq	%r14, (%r15,%r13)
	movq	%rbx, 8(%r15,%r13)
	movq	%rsi, 16(%r15,%r13)
	movq	%rdi, 24(%r15,%r13)
	movw	%r12w, 362(%r15)
	movq	32(%rbp), %rcx
	jmp	.LBB55_85
.LBB55_15:
	cmpq	$5, %r13
	movq	%rsi, 48(%rbp)
	jae	.LBB55_20
	movl	$4, %eax
	movq	%rax, 64(%rbp)
	xorl	%r12d, %r12d
	jmp	.LBB55_25
.LBB55_20:
	je	.LBB55_21
	cmpq	$6, %r13
	jne	.LBB55_23
	movl	$5, %eax
	movq	%rax, 64(%rbp)
	movb	$1, %r12b
	xorl	%r13d, %r13d
	jmp	.LBB55_25
.LBB55_21:
	xorl	%r12d, %r12d
	movq	%r13, 64(%rbp)
	jmp	.LBB55_25
.LBB55_23:
	addq	$-7, %r13
	movl	$6, %eax
	movq	%rax, 64(%rbp)
	movb	$1, %r12b
.LBB55_25:
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$368, %ecx
	movl	$8, %edx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB55_87
	movq	%rax, %rsi
	movl	%r12d, 40(%rbp)
	movq	$0, 352(%rax)
	movzwl	362(%r15), %eax
	movq	64(%rbp), %r12
	movq	%r12, %r8
	notq	%r8
	addq	%rax, %r8
	movw	%r8w, 362(%rsi)
	cmpq	$12, %r8
	movq	%rsi, 56(%rbp)
	jae	.LBB55_27
	movq	%r12, 64(%rbp)
	shlq	$5, %r12
	leaq	(%r15,%r12), %rdx
	addq	$32, %rdx
	shlq	$5, %r8
	movq	%rsi, %rcx
	callq	memcpy
	movq	64(%rbp), %rax
	movw	%ax, 362(%r15)
	movups	(%r15,%r12), %xmm0
	movups	16(%r15,%r12), %xmm1
	movaps	%xmm1, -16(%rbp)
	cmpb	$0, 40(%rbp)
	cmoveq	%r15, %rsi
	movaps	%xmm0, -32(%rbp)
	movzwl	362(%rsi), %r12d
	movzwl	%r12w, %r8d
	cmpq	%r13, %r8
	jbe	.LBB55_32
	movq	%r13, %rax
	shlq	$5, %rax
	leaq	(%rsi,%rax), %rdx
	leaq	(%rsi,%rax), %rcx
	addq	$32, %rcx
	subl	%r13d, %r8d
	shll	$5, %r8d
	callq	memmove
.LBB55_32:
	incl	%r12d
	shlq	$5, %r13
	movq	%r14, (%rsi,%r13)
	movq	%rbx, 8(%rsi,%r13)
	movq	48(%rbp), %rax
	movq	%rax, 16(%rsi,%r13)
	movq	%rdi, 24(%rsi,%r13)
	movw	%r12w, 362(%rsi)
	movaps	-32(%rbp), %xmm0
	movaps	-16(%rbp), %xmm1
	movaps	%xmm1, 16(%rbp)
	movaps	%xmm0, (%rbp)
	movq	352(%r15), %rax
	testq	%rax, %rax
	je	.LBB55_33
	movq	$0, 40(%rbp)
	movq	56(%rbp), %r14
	jmp	.LBB55_43
.LBB55_82:
	movaps	-96(%rbp), %xmm0
	movaps	-80(%rbp), %xmm1
	movaps	%xmm1, 16(%rbp)
	movaps	%xmm0, (%rbp)
	movq	352(%r15), %rax
	testq	%rax, %rax
	je	.LBB55_34
.LBB55_43:
	movq	%r14, %rdx
	movzwl	360(%r15), %ecx
	movq	%rax, %r15
	movzwl	%cx, %r13d
	movzwl	362(%rax), %r14d
	cmpq	$11, %r14
	movq	%rdx, 64(%rbp)
	jb	.LBB55_46
	cmpw	$5, %cx
	jae	.LBB55_57
	movq	%r13, 48(%rbp)
	movl	$4, %esi
	xorl	%r13d, %r13d
	jmp	.LBB55_62
.LBB55_57:
	je	.LBB55_58
	cmpl	$6, %r13d
	jne	.LBB55_60
	movb	$1, %r13b
	movl	$5, %esi
	movq	$0, 48(%rbp)
	jmp	.LBB55_62
.LBB55_58:
	movq	%r13, %rsi
	xorl	%r13d, %r13d
	movq	%rsi, 48(%rbp)
	jmp	.LBB55_62
.LBB55_60:
	addq	$-7, %r13
	movq	%r13, 48(%rbp)
	movb	$1, %r13b
	movl	$6, %esi
.LBB55_62:
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$464, %ecx
	movl	$8, %edx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB55_89
	movq	%rax, %rdi
	movq	$0, 352(%rdi)
	movzwl	362(%r15), %eax
	movq	%rsi, %r8
	notq	%r8
	addq	%rax, %r8
	movw	%r8w, 362(%rdi)
	cmpq	$12, %r8
	movq	%rdi, 56(%rbp)
	jae	.LBB55_64
	movl	%esi, %r12d
	shll	$5, %r12d
	leaq	(%r15,%r12), %rdx
	addq	$32, %rdx
	shlq	$5, %r8
	movq	%rdi, %rcx
	callq	memcpy
	movw	%si, 362(%r15)
	movups	(%r15,%r12), %xmm0
	movups	16(%r15,%r12), %xmm1
	movaps	%xmm1, -16(%rbp)
	movaps	%xmm0, -32(%rbp)
	movzwl	362(%rdi), %r12d
	leaq	1(%r12), %r8
	cmpq	$12, %r12
	jae	.LBB55_66
	movzwl	%r14w, %eax
	subl	%esi, %eax
	cmpl	%r8d, %eax
	jne	.LBB55_68
	incq	40(%rbp)
	leaq	368(%rdi), %rcx
	leaq	(%r15,%rsi,8), %rdx
	addq	$376, %rdx
	shll	$3, %r8d
	callq	memcpy
	xorl	%eax, %eax
	movq	56(%rbp), %r14
	.p2align	4
.LBB55_70:
	movq	%rax, %rcx
	cmpq	%r12, %rax
	adcq	$0, %rax
	movq	368(%r14,%rcx,8), %rdx
	movq	%r14, 352(%rdx)
	movw	%cx, 360(%rdx)
	cmpq	%r12, %rcx
	jae	.LBB55_72
	cmpq	%r12, %rax
	jbe	.LBB55_70
.LBB55_72:
	movaps	-32(%rbp), %xmm0
	movaps	-16(%rbp), %xmm1
	movaps	%xmm1, -80(%rbp)
	testb	%r13b, %r13b
	cmoveq	%r15, %rdi
	movaps	%xmm0, -96(%rbp)
	movzwl	362(%rdi), %esi
	movq	48(%rbp), %r13
	leaq	1(%r13), %r12
	movq	%r13, %rbx
	shlq	$5, %rbx
	addq	%rdi, %rbx
	movq	%rsi, %r10
	subq	%r13, %r10
	jbe	.LBB55_73
	movq	%r12, %rcx
	shlq	$5, %rcx
	addq	%rdi, %rcx
	movl	%esi, %r14d
	subl	%r13d, %r14d
	movl	%r14d, %r8d
	shll	$5, %r8d
	movq	%rbx, %rdx
	movq	%r10, -40(%rbp)
	callq	memmove
	movaps	(%rbp), %xmm0
	movaps	16(%rbp), %xmm1
	movups	%xmm0, (%rbx)
	movups	%xmm1, 16(%rbx)
	leaq	(%rdi,%r12,8), %rdx
	addq	$368, %rdx
	leaq	(%rdi,%r13,8), %rcx
	addq	$384, %rcx
	shll	$3, %r14d
	movq	%r14, %r8
	movq	56(%rbp), %r14
	callq	memmove
	movq	-40(%rbp), %r10
	jmp	.LBB55_75
.LBB55_73:
	movaps	(%rbp), %xmm0
	movaps	16(%rbp), %xmm1
	movups	%xmm1, 16(%rbx)
	movups	%xmm0, (%rbx)
.LBB55_75:
	movq	64(%rbp), %rdx
	leal	1(%rsi), %ecx
	leaq	2(%rsi), %rax
	movq	%rdx, 376(%rdi,%r13,8)
	movw	%cx, 362(%rdi)
	cmpq	%rax, %r12
	jae	.LBB55_82
	subl	%r13d, %esi
	incl	%esi
	andl	$3, %esi
	je	.LBB55_80
	leaq	(%rdi,%r13,8), %rdx
	addq	$376, %rdx
	xorl	%ecx, %ecx
	.p2align	4
.LBB55_78:
	movq	(%rdx,%rcx,8), %r8
	movq	%rdi, 352(%r8)
	leal	(%r12,%rcx), %r9d
	movw	%r9w, 360(%r8)
	incq	%rcx
	cmpq	%rcx, %rsi
	jne	.LBB55_78
	addq	%rcx, %r12
.LBB55_80:
	cmpq	$3, %r10
	jb	.LBB55_82
	.p2align	4
.LBB55_81:
	movq	368(%rdi,%r12,8), %rcx
	movq	%rdi, 352(%rcx)
	movw	%r12w, 360(%rcx)
	movq	376(%rdi,%r12,8), %rcx
	movq	%rdi, 352(%rcx)
	leal	1(%r12), %edx
	movw	%dx, 360(%rcx)
	movq	384(%rdi,%r12,8), %rcx
	movq	%rdi, 352(%rcx)
	leal	2(%r12), %edx
	movw	%dx, 360(%rcx)
	movq	392(%rdi,%r12,8), %rcx
	movq	%rdi, 352(%rcx)
	leal	3(%r12), %edx
	movw	%dx, 360(%rcx)
	addq	$4, %r12
	cmpq	%rax, %r12
	jne	.LBB55_81
	jmp	.LBB55_82
.LBB55_33:
	movq	$0, 40(%rbp)
	movq	56(%rbp), %r14
.LBB55_34:
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movl	$464, %ecx
	movl	$8, %edx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	je	.LBB55_35
	movq	$0, 352(%rax)
	movw	$0, 362(%rax)
	movq	-56(%rbp), %rdx
	movq	%rdx, 368(%rax)
	movq	-48(%rbp), %r8
	movq	%r8, %r9
	incq	%r9
	movq	32(%rbp), %rcx
	je	.LBB55_37
	movq	%rax, 352(%rdx)
	movw	$0, 360(%rdx)
	movq	%rax, (%rcx)
	movq	%r9, 8(%rcx)
	cmpq	%r8, 40(%rbp)
	jne	.LBB55_88
	movw	$1, 362(%rax)
	movaps	(%rbp), %xmm0
	movaps	16(%rbp), %xmm1
	movups	%xmm0, (%rax)
	movups	%xmm1, 16(%rax)
	movq	%r14, 376(%rax)
	movq	%rax, 352(%r14)
	movw	$1, 360(%r14)
	jmp	.LBB55_85
.LBB55_46:
	leal	1(%r14), %esi
	leaq	1(%r13), %r12
	movl	%r13d, %edi
	shll	$5, %edi
	addq	%r15, %rdi
	cmpw	%r14w, %cx
	jae	.LBB55_47
	movl	%r12d, %ecx
	shll	$5, %ecx
	addq	%r15, %rcx
	movq	%r14, %rbx
	subq	%r13, %rbx
	movq	%rbx, %r8
	shlq	$5, %r8
	movq	%rdi, %rdx
	callq	memmove
	movaps	(%rbp), %xmm0
	movaps	16(%rbp), %xmm1
	movups	%xmm0, (%rdi)
	movups	%xmm1, 16(%rdi)
	leaq	(%r15,%r12,8), %rdx
	addq	$368, %rdx
	leaq	(%r15,%r13,8), %rcx
	addq	$384, %rcx
	shlq	$3, %rbx
	movq	%rbx, %r8
	callq	memmove
	movq	64(%rbp), %rdx
	jmp	.LBB55_49
.LBB55_47:
	movaps	(%rbp), %xmm0
	movaps	16(%rbp), %xmm1
	movups	%xmm1, 16(%rdi)
	movups	%xmm0, (%rdi)
.LBB55_49:
	leaq	2(%r14), %rax
	movq	%rdx, 376(%r15,%r13,8)
	movw	%si, 362(%r15)
	cmpl	%eax, %r12d
	jae	.LBB55_56
	movl	%r14d, %ecx
	subl	%r13d, %ecx
	incl	%ecx
	subq	%r13, %r14
	andl	$3, %ecx
	je	.LBB55_54
	leaq	(%r15,%r13,8), %r8
	addq	$376, %r8
	xorl	%edx, %edx
.LBB55_52:
	movq	(%r8,%rdx,8), %r9
	movq	%r15, 352(%r9)
	leal	(%r12,%rdx), %r10d
	movw	%r10w, 360(%r9)
	incq	%rdx
	cmpq	%rdx, %rcx
	jne	.LBB55_52
	addq	%rdx, %r12
.LBB55_54:
	cmpq	$3, %r14
	jb	.LBB55_56
.LBB55_55:
	movq	368(%r15,%r12,8), %rcx
	movq	%r15, 352(%rcx)
	movw	%r12w, 360(%rcx)
	movq	376(%r15,%r12,8), %rcx
	movq	%r15, 352(%rcx)
	leal	1(%r12), %edx
	movw	%dx, 360(%rcx)
	movq	384(%r15,%r12,8), %rcx
	movq	%r15, 352(%rcx)
	leal	2(%r12), %edx
	movw	%dx, 360(%rcx)
	movq	392(%r15,%r12,8), %rcx
	movq	%r15, 352(%rcx)
	leal	3(%r12), %edx
	movw	%dx, 360(%rcx)
	addq	$4, %r12
	cmpq	%rax, %r12
	jne	.LBB55_55
.LBB55_56:
	movq	32(%rbp), %rcx
	jmp	.LBB55_85
.LBB55_87:
	movl	$8, %ecx
	movl	$368, %edx
	callq	_ZN5alloc5alloc18handle_alloc_error17h6942ce664312655aE
.LBB55_64:
.Ltmp100:
	leaq	anon.3126157283a31055444fc45c79212b1f.101(%rip), %r9
	movq	%r8, %rdx
	movl	$11, %r8d
	xorl	%ecx, %ecx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.Ltmp101:
	jmp	.LBB55_28
.LBB55_66:
.Ltmp102:
	leaq	anon.3126157283a31055444fc45c79212b1f.102(%rip), %r9
	movq	%r8, %rdx
	movl	$12, %r8d
	xorl	%ecx, %ecx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.Ltmp103:
	jmp	.LBB55_28
.LBB55_89:
	movl	$8, %ecx
	movl	$464, %edx
	callq	_ZN5alloc5alloc18handle_alloc_error17h6942ce664312655aE
.LBB55_68:
.Ltmp104:
	leaq	anon.3126157283a31055444fc45c79212b1f.99(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.100(%rip), %r8
	movl	$40, %edx
	callq	_ZN4core9panicking5panic17hc5fbe615138639caE
.Ltmp105:
	jmp	.LBB55_28
.LBB55_27:
.Ltmp98:
	leaq	anon.3126157283a31055444fc45c79212b1f.101(%rip), %r9
	movq	%r8, %rdx
	movl	$11, %r8d
	xorl	%ecx, %ecx
	callq	_ZN4core5slice5index16slice_index_fail17h12779f3ee151cbd8E
.Ltmp99:
	jmp	.LBB55_28
.LBB55_35:
.Ltmp108:
	movl	$8, %ecx
	movl	$464, %edx
	callq	_ZN5alloc5alloc18handle_alloc_error17h6942ce664312655aE
.Ltmp109:
	jmp	.LBB55_28
.LBB55_37:
.Ltmp106:
	movq	%rax, 32(%rbp)
	leaq	anon.3126157283a31055444fc45c79212b1f.98(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.Ltmp107:
.LBB55_28:
	ud2
.LBB55_88:
	leaq	anon.3126157283a31055444fc45c79212b1f.96(%rip), %rcx
	leaq	anon.3126157283a31055444fc45c79212b1f.97(%rip), %r8
	movl	$48, %edx
	callq	_ZN4core9panicking5panic17hc5fbe615138639caE
	int3
	.seh_handlerdata
	.long	$cppxdata$_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E@IMGREL
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E,unique,55
	.seh_endproc
	.def	"?dtor$29@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$29@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E@4HA":
.seh_proc "?dtor$29@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E@4HA"
.LBB55_29:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	leaq	128(%rdx), %rbp
	movaps	%xmm6, 32(%rsp)
	.seh_savexmm %xmm6, 32
	.seh_endprologue
	movl	$368, %edx
	movl	$8, %r8d
	movq	56(%rbp), %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	movaps	32(%rsp), %xmm6
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E,unique,55
	.seh_endproc
	.def	"?dtor$38@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$38@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E@4HA":
.seh_proc "?dtor$38@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E@4HA"
.LBB55_38:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	leaq	128(%rdx), %rbp
	movaps	%xmm6, 32(%rsp)
	.seh_savexmm %xmm6, 32
	.seh_endprologue
	movl	$464, %edx
	movl	$8, %r8d
	movq	32(%rbp), %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	movaps	32(%rsp), %xmm6
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E,unique,55
	.seh_endproc
	.def	"?dtor$39@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$39@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E@4HA":
.seh_proc "?dtor$39@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E@4HA"
.LBB55_39:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	leaq	128(%rdx), %rbp
	movaps	%xmm6, 32(%rsp)
	.seh_savexmm %xmm6, 32
	.seh_endprologue
	ud2
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E,unique,55
	.seh_endproc
	.def	"?dtor$90@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$90@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E@4HA":
.seh_proc "?dtor$90@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E@4HA"
.LBB55_90:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r13
	.seh_pushreg %r13
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$56, %rsp
	.seh_stackalloc 56
	leaq	128(%rdx), %rbp
	movaps	%xmm6, 32(%rsp)
	.seh_savexmm %xmm6, 32
	.seh_endprologue
	movl	$464, %edx
	movl	$8, %r8d
	movq	56(%rbp), %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	movaps	32(%rsp), %xmm6
	.seh_startepilogue
	addq	$56, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r13
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.Lfunc_end9:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E,unique,55
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E,unique,9
	.p2align	2, 0x0
$cppxdata$_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E:
	.long	429065506
	.long	4
	.long	$stateUnwindMap$_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E@IMGREL
	.long	0
	.long	0
	.long	8
	.long	$ip2state$_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E@IMGREL
	.long	200
	.long	0
	.long	1
$stateUnwindMap$_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E:
	.long	-1
	.long	"?dtor$29@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E@4HA"@IMGREL
	.long	-1
	.long	"?dtor$39@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E@4HA"@IMGREL
	.long	1
	.long	"?dtor$38@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E@4HA"@IMGREL
	.long	-1
	.long	"?dtor$90@?0?_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E@4HA"@IMGREL
$ip2state$_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E:
	.long	.Lfunc_begin9@IMGREL
	.long	-1
	.long	.Ltmp100@IMGREL+1
	.long	3
	.long	.Ltmp103@IMGREL+1
	.long	-1
	.long	.Ltmp104@IMGREL+1
	.long	3
	.long	.Ltmp98@IMGREL+1
	.long	0
	.long	.Ltmp108@IMGREL+1
	.long	1
	.long	.Ltmp106@IMGREL+1
	.long	2
	.long	.Ltmp107@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25BTreeMap$LT$K$C$V$C$A$GT$6insert17hae055a6c82c326c4E,unique,55

	.def	_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E;
	.scl	3;
	.type	32;
	.endef
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E,unique,56
	.p2align	4
_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E:
.Lfunc_begin10:
.seh_proc _ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E
	.seh_handler __CxxFrameHandler3, @unwind, @except
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$48, %rsp
	.seh_stackalloc 48
	leaq	48(%rsp), %rbp
	.seh_setframe %rbp, 48
	.seh_endprologue
	movq	$-2, -8(%rbp)
	movq	%rcx, %rsi
	movq	64(%rdx), %rax
	testq	%rax, %rax
	je	.LBB56_1
	decq	%rax
	movq	%rax, 64(%rdx)
	cmpl	$1, (%rdx)
	jne	.LBB56_49
	movq	8(%rdx), %rcx
	testq	%rcx, %rcx
	je	.LBB56_21
	movq	16(%rdx), %rax
	movq	24(%rdx), %rdi
	movzwl	362(%rcx), %r8d
	cmpq	%r8, %rdi
	jae	.LBB56_31
.LBB56_30:
	movq	%rax, %r14
	movq	%rcx, %rbx
	testq	%r14, %r14
	je	.LBB56_36
.LBB56_39:
	leaq	(%rbx,%rdi,8), %rax
	addq	$376, %rax
	movq	%r14, %r8
	andq	$7, %r8
	je	.LBB56_40
	xorl	%r10d, %r10d
	.p2align	4
.LBB56_42:
	movq	(%rax), %rcx
	leaq	368(%rcx), %rax
	incq	%r10
	cmpq	%r10, %r8
	jne	.LBB56_42
	movq	%r14, %r9
	subq	%r10, %r9
	xorl	%r8d, %r8d
	cmpq	$8, %r14
	jae	.LBB56_45
	jmp	.LBB56_37
.LBB56_1:
	movq	8(%rdx), %rcx
	movq	16(%rdx), %rdi
	movq	24(%rdx), %rax
	testb	$1, (%rdx)
	movq	$0, (%rdx)
	je	.LBB56_17
	testq	%rcx, %rcx
	je	.LBB56_4
	movq	%rdi, %rbx
	movq	%rcx, %rdi
.LBB56_13:
	movq	352(%rdi), %rax
	testq	%rax, %rax
	je	.LBB56_16
	movl	$368, %r14d
	movq	%rdi, %rcx
	movq	%rbx, %rdx
	.p2align	4
.LBB56_15:
	movq	%rax, %rdi
	leaq	1(%rdx), %rbx
	testq	%rdx, %rdx
	movl	$464, %edx
	cmoveq	%r14, %rdx
	movl	$8, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	movq	352(%rdi), %rax
	movq	%rdi, %rcx
	movq	%rbx, %rdx
	testq	%rax, %rax
	jne	.LBB56_15
.LBB56_16:
	testq	%rbx, %rbx
	movl	$368, %eax
	movl	$464, %edx
	cmoveq	%rax, %rdx
	movl	$8, %r8d
	movq	%rdi, %rcx
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.LBB56_17:
	movq	$0, (%rsi)
	jmp	.LBB56_38
.LBB56_21:
	movq	16(%rdx), %rcx
	movq	24(%rdx), %rax
	testq	%rax, %rax
	je	.LBB56_28
	movq	%rax, %r8
	andq	$7, %r8
	je	.LBB56_23
	xorl	%r9d, %r9d
	.p2align	4
.LBB56_25:
	movq	368(%rcx), %rcx
	incq	%r9
	cmpq	%r9, %r8
	jne	.LBB56_25
	movq	%rax, %r8
	subq	%r9, %r8
	cmpq	$8, %rax
	jb	.LBB56_28
	.p2align	4
.LBB56_50:
	movq	368(%rcx), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rcx
	addq	$-8, %r8
	jne	.LBB56_50
.LBB56_28:
	movq	$1, (%rdx)
	xorl	%edi, %edi
	xorl	%eax, %eax
	movzwl	362(%rcx), %r8d
	cmpq	%r8, %rdi
	jb	.LBB56_30
.LBB56_31:
	movq	%rdx, %r15
	movl	$368, %r12d
	.p2align	4
.LBB56_32:
	movq	352(%rcx), %rbx
	testq	%rbx, %rbx
	je	.LBB56_46
	leaq	1(%rax), %r14
	movzwl	360(%rcx), %edi
	testq	%rax, %rax
	movl	$464, %edx
	cmoveq	%r12, %rdx
	movl	$8, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
	movq	%rbx, %rcx
	movq	%r14, %rax
	cmpw	362(%rbx), %di
	jae	.LBB56_32
	movq	%r15, %rdx
	testq	%r14, %r14
	jne	.LBB56_39
.LBB56_36:
	leaq	1(%rdi), %r8
	movq	%rbx, %rcx
	jmp	.LBB56_37
.LBB56_40:
	movq	%r14, %r9
	xorl	%r8d, %r8d
	cmpq	$8, %r14
	jb	.LBB56_37
	.p2align	4
.LBB56_45:
	movq	(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rcx
	leaq	368(%rcx), %rax
	addq	$-8, %r9
	jne	.LBB56_45
.LBB56_37:
	movq	%rcx, 8(%rdx)
	movq	$0, 16(%rdx)
	movq	%r8, 24(%rdx)
	movq	%rbx, (%rsi)
	movq	%r14, 8(%rsi)
	movq	%rdi, 16(%rsi)
.LBB56_38:
	.seh_startepilogue
	addq	$48, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r12
	popq	%r14
	popq	%r15
	popq	%rbp
	.seh_endepilogue
	retq
.LBB56_4:
	testq	%rax, %rax
	je	.LBB56_5
	movq	%rax, %rcx
	andq	$7, %rcx
	je	.LBB56_7
	xorl	%edx, %edx
	.p2align	4
.LBB56_9:
	movq	368(%rdi), %rdi
	incq	%rdx
	cmpq	%rdx, %rcx
	jne	.LBB56_9
	movq	%rax, %rcx
	subq	%rdx, %rcx
	jmp	.LBB56_11
.LBB56_23:
	movq	%rax, %r8
	cmpq	$8, %rax
	jae	.LBB56_50
	jmp	.LBB56_28
.LBB56_5:
	xorl	%ebx, %ebx
	jmp	.LBB56_13
.LBB56_7:
	movq	%rax, %rcx
.LBB56_11:
	xorl	%ebx, %ebx
	cmpq	$8, %rax
	jb	.LBB56_13
	.p2align	4
.LBB56_12:
	movq	368(%rdi), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rax
	movq	368(%rax), %rdi
	addq	$-8, %rcx
	jne	.LBB56_12
	jmp	.LBB56_13
.LBB56_46:
	testq	%rax, %rax
	movl	$368, %eax
	movl	$464, %edx
	cmoveq	%rax, %rdx
	movl	$8, %r8d
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_dealloc
.Ltmp110:
	leaq	anon.3126157283a31055444fc45c79212b1f.104(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
.Ltmp111:
	ud2
.LBB56_49:
	leaq	anon.3126157283a31055444fc45c79212b1f.105(%rip), %rcx
	callq	_ZN4core6option13unwrap_failed17h4eed510f59d8d3dcE
	int3
	.seh_handlerdata
	.long	$cppxdata$_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E@IMGREL
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E,unique,56
	.seh_endproc
	.def	"?dtor$48@?0?_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E@4HA";
	.scl	3;
	.type	32;
	.endef
	.p2align	4
"?dtor$48@?0?_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E@4HA":
.seh_proc "?dtor$48@?0?_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E@4HA"
.LBB56_48:
	movq	%rdx, 16(%rsp)
	pushq	%rbp
	.seh_pushreg %rbp
	pushq	%r15
	.seh_pushreg %r15
	pushq	%r14
	.seh_pushreg %r14
	pushq	%r12
	.seh_pushreg %r12
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$32, %rsp
	.seh_stackalloc 32
	leaq	48(%rdx), %rbp
	.seh_endprologue
	ud2
.Lfunc_end10:
	.seh_handlerdata
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E,unique,56
	.seh_endproc
	.section	.xdata,"dr",associative,_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E,unique,10
	.p2align	2, 0x0
$cppxdata$_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E:
	.long	429065506
	.long	1
	.long	$stateUnwindMap$_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E@IMGREL
	.long	0
	.long	0
	.long	3
	.long	$ip2state$_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E@IMGREL
	.long	40
	.long	0
	.long	1
$stateUnwindMap$_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E:
	.long	-1
	.long	"?dtor$48@?0?_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E@4HA"@IMGREL
$ip2state$_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E:
	.long	.Lfunc_begin10@IMGREL
	.long	-1
	.long	.Ltmp110@IMGREL+1
	.long	0
	.long	.Ltmp111@IMGREL+1
	.long	-1
	.section	.text,"xr",one_only,_ZN5alloc11collections5btree3map25IntoIter$LT$K$C$V$C$A$GT$10dying_next17h56f687270f4e68c4E,unique,56

	.def	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h4f12d29f835ee7cfE;
	.scl	2;
	.type	32;
	.endef
	.section	.text$unlikely,"xr",one_only,_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h4f12d29f835ee7cfE,unique,57
	.globl	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h4f12d29f835ee7cfE
	.p2align	4
_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h4f12d29f835ee7cfE:
.seh_proc _ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17h4f12d29f835ee7cfE
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	movq	%rcx, %rsi
	movq	(%rcx), %rdx
	leaq	(%rdx,%rdx), %rax
	cmpq	$5, %rax
	movl	$4, %edi
	cmovaeq	%rax, %rdi
	movq	8(%rcx), %r8
	movq	$4, 40(%rsp)
	movq	$4, 32(%rsp)
	leaq	48(%rsp), %rcx
	movq	%rdi, %r9
	callq	_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h5c8a01ed803ae400E
	cmpl	$1, 48(%rsp)
	je	.LBB57_2
	movq	56(%rsp), %rax
	movq	%rax, 8(%rsi)
	movq	%rdi, (%rsi)
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB57_2:
	movq	56(%rsp), %rcx
	movq	64(%rsp), %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
	int3
	.seh_endproc

	.def	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hdbf86ebe580ab5daE;
	.scl	2;
	.type	32;
	.endef
	.section	.text$unlikely,"xr",one_only,_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hdbf86ebe580ab5daE,unique,58
	.globl	_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hdbf86ebe580ab5daE
	.p2align	4
_ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hdbf86ebe580ab5daE:
.seh_proc _ZN5alloc7raw_vec19RawVec$LT$T$C$A$GT$8grow_one17hdbf86ebe580ab5daE
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	movq	%rcx, %rsi
	movq	(%rcx), %rdx
	leaq	(%rdx,%rdx), %rax
	cmpq	$5, %rax
	movl	$4, %edi
	cmovaeq	%rax, %rdi
	movq	8(%rcx), %r8
	movq	$48, 40(%rsp)
	movq	$8, 32(%rsp)
	leaq	48(%rsp), %rcx
	movq	%rdi, %r9
	callq	_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h5c8a01ed803ae400E
	cmpl	$1, 48(%rsp)
	je	.LBB58_2
	movq	56(%rsp), %rax
	movq	%rax, 8(%rsi)
	movq	%rdi, (%rsi)
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB58_2:
	movq	56(%rsp), %rcx
	movq	64(%rsp), %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
	int3
	.seh_endproc

	.def	_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h5c8a01ed803ae400E;
	.scl	3;
	.type	32;
	.endef
	.section	.text$unlikely,"xr",one_only,_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h5c8a01ed803ae400E,unique,59
	.p2align	4
_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h5c8a01ed803ae400E:
.seh_proc _ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h5c8a01ed803ae400E
	pushq	%r14
	.seh_pushreg %r14
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	pushq	%rbx
	.seh_pushreg %rbx
	subq	$40, %rsp
	.seh_stackalloc 40
	.seh_endprologue
	movq	%rdx, %r11
	movq	%rcx, %rsi
	movq	112(%rsp), %rbx
	movq	120(%rsp), %r10
	leaq	(%rbx,%r10), %rcx
	decq	%rcx
	movq	%rbx, %rax
	negq	%rax
	andq	%rcx, %rax
	mulq	%r9
	movq	%rax, %rdi
	seto	%al
	movabsq	$-9223372036854775808, %rcx
	subq	%rbx, %rcx
	cmpq	%rcx, %rdi
	seta	%cl
	orb	%al, %cl
	movl	$1, %r14d
	je	.LBB59_2
	movl	$8, %eax
	xorl	%edi, %edi
	jmp	.LBB59_10
.LBB59_2:
	testq	%r11, %r11
	je	.LBB59_4
	imulq	%r11, %r10
	movq	%r8, %rcx
	movq	%r10, %rdx
	movq	%rbx, %r8
	movq	%rdi, %r9
	callq	_RNvCs5QKde7ScR4H_7___rustc14___rust_realloc
	testq	%rax, %rax
	jne	.LBB59_6
	jmp	.LBB59_9
.LBB59_4:
	testq	%rdi, %rdi
	je	.LBB59_5
	callq	_RNvCs5QKde7ScR4H_7___rustc35___rust_no_alloc_shim_is_unstable_v2
	movq	%rdi, %rcx
	movq	%rbx, %rdx
	callq	_RNvCs5QKde7ScR4H_7___rustc12___rust_alloc
	testq	%rax, %rax
	jne	.LBB59_6
.LBB59_9:
	movq	%rbx, 8(%rsi)
	movl	$16, %eax
	jmp	.LBB59_10
.LBB59_5:
	movq	%rbx, %rax
.LBB59_6:
	movq	%rax, 8(%rsi)
	movl	$16, %eax
	xorl	%r14d, %r14d
.LBB59_10:
	movq	%rdi, (%rsi,%rax)
	movq	%r14, (%rsi)
	.seh_startepilogue
	addq	$40, %rsp
	popq	%rbx
	popq	%rdi
	popq	%rsi
	popq	%r14
	.seh_endepilogue
	retq
	.seh_endproc

	.def	_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17h19c8325f6c8f9791E;
	.scl	3;
	.type	32;
	.endef
	.section	.text$unlikely,"xr",one_only,_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17h19c8325f6c8f9791E,unique,60
	.p2align	4
_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17h19c8325f6c8f9791E:
.seh_proc _ZN5alloc7raw_vec20RawVecInner$LT$A$GT$7reserve21do_reserve_and_handle17h19c8325f6c8f9791E
	pushq	%rsi
	.seh_pushreg %rsi
	pushq	%rdi
	.seh_pushreg %rdi
	subq	$72, %rsp
	.seh_stackalloc 72
	.seh_endprologue
	addq	%r8, %rdx
	jb	.LBB60_1
	movq	%rcx, %rsi
	movq	(%rcx), %rax
	leaq	(%rax,%rax), %rcx
	cmpq	%rcx, %rdx
	cmovaq	%rdx, %rcx
	cmpq	$9, %rcx
	movl	$8, %edi
	cmovaeq	%rcx, %rdi
	movq	8(%rsi), %r8
	movq	$1, 40(%rsp)
	movq	$1, 32(%rsp)
	leaq	48(%rsp), %rcx
	movq	%rax, %rdx
	movq	%rdi, %r9
	callq	_ZN5alloc7raw_vec20RawVecInner$LT$A$GT$11finish_grow17h5c8a01ed803ae400E
	cmpl	$1, 48(%rsp)
	je	.LBB60_3
	movq	56(%rsp), %rax
	movq	%rax, 8(%rsi)
	movq	%rdi, (%rsi)
	.seh_startepilogue
	addq	$72, %rsp
	popq	%rdi
	popq	%rsi
	.seh_endepilogue
	retq
.LBB60_1:
	xorl	%ecx, %ecx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
.LBB60_3:
	movq	56(%rsp), %rcx
	movq	64(%rsp), %rdx
	callq	_ZN5alloc7raw_vec12handle_error17h83891c7b13f7a15bE
	int3
	.seh_endproc

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.0,unique,61
anon.3126157283a31055444fc45c79212b1f.0:
	.asciz	"slot_a\\src\\polynomial_hash.rs"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.1,unique,62
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.1:
	.quad	anon.3126157283a31055444fc45c79212b1f.0
	.asciz	"\035\000\000\000\000\000\000\000\340\000\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.2,unique,63
anon.3126157283a31055444fc45c79212b1f.2:
	.ascii	"Base must be in [2, p-1]"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.3,unique,64
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.3:
	.quad	anon.3126157283a31055444fc45c79212b1f.0
	.asciz	"\035\000\000\000\000\000\000\000\202\000\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.4,unique,65
anon.3126157283a31055444fc45c79212b1f.4:
	.asciz	"slot_a\\src\\rope.rs"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.5,unique,66
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.5:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000%\004\000\000.\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.6,unique,67
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.6:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\265\000\000\000\032\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.7,unique,68
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.7:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\0001\004\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.8,unique,69
anon.3126157283a31055444fc45c79212b1f.8:
	.ascii	"internal error: entered unreachable code"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.9,unique,70
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.9:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000'\004\000\000\022\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.10,unique,71
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.10:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000Z\004\000\000$\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.11,unique,72
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.11:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000Z\004\000\000H\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.12,unique,73
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.12:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000]\004\000\0004\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.13,unique,74
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.13:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000=\004\000\000\035\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.14,unique,75
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.14:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000]\004\000\000\037\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.15,unique,76
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.15:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\\\004\000\0004\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.16,unique,77
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.16:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\\\004\000\000\037\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.17,unique,78
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.17:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\350\003\000\0000\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.18,unique,79
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.18:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\350\003\000\000\033\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.19,unique,80
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.19:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\347\003\000\0000\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.20,unique,81
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.20:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\347\003\000\000\033\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.21,unique,82
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.21:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\006\004\000\000'\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.22,unique,83
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.22:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\n\004\000\000(\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.23,unique,84
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.23:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\270\003\000\000\037\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.24,unique,85
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.24:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\235\004\000\000\037\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.25,unique,86
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.25:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\335\004\000\000@\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.26,unique,87
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.26:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\336\004\000\000A\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.27,unique,88
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.27:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\326\004\000\000\031\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.28,unique,89
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.28:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\001\005\000\000!\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.29,unique,90
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.29:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\002\005\000\000\"\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.30,unique,91
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.30:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\007\005\000\0004\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.31,unique,92
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.31:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\007\005\000\000\037\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.32,unique,93
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.32:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\006\005\000\0004\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.33,unique,94
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.33:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\006\005\000\000\037\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.34,unique,95
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.34:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\253\004\000\000\037\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.35,unique,96
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.35:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\272\004\000\000\025\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.36,unique,97
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.36:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\201\004\000\000T\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.37,unique,98
anon.3126157283a31055444fc45c79212b1f.37:
	.ascii	"Arena hash parameters changed; create a new arena to use a different profile"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.38,unique,99
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.38:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\216\000\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.39,unique,100
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.39:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\0002\003\000\000\023\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.40,unique,101
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.40:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\254\000\000\000\032\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.41,unique,102
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.41:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\316\002\000\000\031\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.42,unique,103
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.42:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\322\002\000\000\"\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.43,unique,104
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.43:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\347\002\000\000\"\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.44,unique,105
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.44:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\276\000\000\000\032\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.45,unique,106
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.45:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\270\001\000\000\032\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.46,unique,107
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.46:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000v\002\000\000\031\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.47,unique,108
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.47:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000y\002\000\000/\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.48,unique,109
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.48:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\224\002\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.49,unique,110
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.49:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000?\003\000\000\032\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.50,unique,111
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.50:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000[\003\000\000\032\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.51,unique,112
anon.3126157283a31055444fc45c79212b1f.51:
	.ascii	"Leaf len mismatch"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.52,unique,113
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.52:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000]\003\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.53,unique,114
anon.3126157283a31055444fc45c79212b1f.53:
	.ascii	"Internal len mismatch"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.54,unique,115
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.54:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000`\003\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.55,unique,116
anon.3126157283a31055444fc45c79212b1f.55:
	.ascii	"Internal weight mismatch"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.56,unique,117
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.56:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000a\003\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.57,unique,118
anon.3126157283a31055444fc45c79212b1f.57:
	.asciz	"\026Left child too light: \300\001/\300"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.58,unique,119
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.58:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000e\003\000\000\025\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.59,unique,120
anon.3126157283a31055444fc45c79212b1f.59:
	.asciz	"\026Left child too heavy: \300\001/\300"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.60,unique,121
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.60:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000i\003\000\000\025\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.61,unique,122
anon.3126157283a31055444fc45c79212b1f.61:
	.ascii	"RepeatNode len mismatch"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.62,unique,123
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.62:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000r\003\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.63,unique,124
anon.3126157283a31055444fc45c79212b1f.63:
	.ascii	"RepeatNode weight mismatch"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.64,unique,125
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.64:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000s\003\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.65,unique,126
anon.3126157283a31055444fc45c79212b1f.65:
	.asciz	"\"RepeatNode reps must be >= 2, got \300"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.66,unique,127
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.66:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000t\003\000\000\021\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.67,unique,128
anon.3126157283a31055444fc45c79212b1f.67:
	.ascii	"Left comparison range out of bounds"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.68,unique,129
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.68:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\240\001\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.69,unique,130
anon.3126157283a31055444fc45c79212b1f.69:
	.ascii	"Right comparison range out of bounds"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.70,unique,131
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.70:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\241\001\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.71,unique,132
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.71:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\246\001\000\000\"\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.72,unique,133
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.72:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\247\001\000\000\"\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.73,unique,134
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.73:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\313\000\000\000\036\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.74,unique,135
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.74:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000F\002\000\000<\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.75,unique,136
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.75:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000G\002\000\000C\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.76,unique,137
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.76:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\0006\002\000\000<\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.77,unique,138
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.77:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\0007\002\000\000C\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.78,unique,139
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.78:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\327\001\000\000\031\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.79,unique,140
anon.3126157283a31055444fc45c79212b1f.79:
	.ascii	"internal error: entered unreachable code: Cannot decompose Leaf in balance"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.80,unique,141
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.80:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\337\001\000\000'\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.81,unique,142
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.81:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\333\001\000\000:\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.82,unique,143
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.82:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\334\001\000\000B\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.83,unique,144
anon.3126157283a31055444fc45c79212b1f.83:
	.ascii	"Leaf cannot be empty"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.84,unique,145
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.84:
	.quad	anon.3126157283a31055444fc45c79212b1f.4
	.asciz	"\022\000\000\000\000\000\000\000\033\001\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.85,unique,146
anon.3126157283a31055444fc45c79212b1f.85:
	.asciz	"\025Invalid copy: offset \300\030 exceeds decoded length \300"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.86,unique,147
anon.3126157283a31055444fc45c79212b1f.86:
	.asciz	"slot_a\\src\\sliding.rs"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.87,unique,148
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.87:
	.quad	anon.3126157283a31055444fc45c79212b1f.86
	.asciz	"\025\000\000\000\000\000\000\000g\000\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.88,unique,149
anon.3126157283a31055444fc45c79212b1f.88:
	.asciz	"\fCopy offset \300\025 exceeds window size \300\034. Increase d_max (currently \300\016) to at least \300\001."

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.89,unique,150
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.89:
	.quad	anon.3126157283a31055444fc45c79212b1f.86
	.asciz	"\025\000\000\000\000\000\000\000l\000\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.90,unique,151
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.90:
	.quad	anon.3126157283a31055444fc45c79212b1f.86
	.asciz	"\025\000\000\000\000\000\000\000~\000\000\000\025\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.91,unique,152
anon.3126157283a31055444fc45c79212b1f.91:
	.asciz	"\030d_max must be >= 1, got \300"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.92,unique,153
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.92:
	.quad	anon.3126157283a31055444fc45c79212b1f.86
	.asciz	"\025\000\000\000\000\000\000\000\035\000\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.93,unique,154
anon.3126157283a31055444fc45c79212b1f.93:
	.asciz	"\030m_max must be >= 1, got \300"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.94,unique,155
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.94:
	.quad	anon.3126157283a31055444fc45c79212b1f.86
	.asciz	"\025\000\000\000\000\000\000\000\036\000\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.95,unique,156
anon.3126157283a31055444fc45c79212b1f.95:
	.asciz	"/rustc/4a4ef493e3a1488c6e321570238084b38948f6db/library\\alloc\\src\\collections\\btree\\node.rs"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.96,unique,157
anon.3126157283a31055444fc45c79212b1f.96:
	.ascii	"assertion failed: edge.height == self.height - 1"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.97,unique,158
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.97:
	.quad	anon.3126157283a31055444fc45c79212b1f.95
	.asciz	"[\000\000\000\000\000\000\000\266\002\000\000\t\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.98,unique,159
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.98:
	.quad	anon.3126157283a31055444fc45c79212b1f.95
	.asciz	"[\000\000\000\000\000\000\000\360\000\000\000M\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.99,unique,160
anon.3126157283a31055444fc45c79212b1f.99:
	.ascii	"assertion failed: src.len() == dst.len()"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.100,unique,161
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.100:
	.quad	anon.3126157283a31055444fc45c79212b1f.95
	.asciz	"[\000\000\000\000\000\000\000T\007\000\000\005\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.101,unique,162
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.101:
	.quad	anon.3126157283a31055444fc45c79212b1f.95
	.asciz	"[\000\000\000\000\000\000\000\320\004\000\000#\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.102,unique,163
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.102:
	.quad	anon.3126157283a31055444fc45c79212b1f.95
	.asciz	"[\000\000\000\000\000\000\000\023\005\000\000$\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.103,unique,164
anon.3126157283a31055444fc45c79212b1f.103:
	.asciz	"/rustc/4a4ef493e3a1488c6e321570238084b38948f6db/library\\alloc\\src\\collections\\btree\\navigate.rs"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.104,unique,165
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.104:
	.quad	anon.3126157283a31055444fc45c79212b1f.103
	.asciz	"_\000\000\000\000\000\000\000X\002\000\0000\000\000"

	.section	.rdata,"dr",one_only,anon.3126157283a31055444fc45c79212b1f.105,unique,166
	.p2align	3, 0x0
anon.3126157283a31055444fc45c79212b1f.105:
	.quad	anon.3126157283a31055444fc45c79212b1f.103
	.asciz	"_\000\000\000\000\000\000\000\306\000\000\000'\000\000"

