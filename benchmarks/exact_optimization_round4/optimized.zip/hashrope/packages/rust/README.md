# hashrope

A BB[2/7] weight-balanced binary tree augmented with polynomial hash metadata at every node.

**Zero dependencies. `no_std + alloc` compatible. Rust 2021 edition.**

## What it does

hashrope is a rope data structure where every node carries a polynomial hash over a Mersenne prime field. This enables:

- **O(log w) concat and split** with strict BB[2/7] weight-balance via recursive join
- **O(log q) repetition encoding** via `RepeatNode` — represent `s^q` without materializing
- **O(log w) substring hashing** without allocating new nodes
- **O(1) whole-sequence hash** at any node
- **Exact equality and longest common prefix** with shared-subtree and periodicity shortcuts
- **Bounded-memory sliding window** with eviction

The logarithmic tree traversal bounds do not include all arithmetic costs: uncached powers and repeat accumulators add work, and joins that repeatedly decompose repeats can require more than logarithmic arithmetic work. `from_bytes` bounds leaves to 512 bytes, limiting partial-leaf copying and hashing. Substring hashing allocates no rope nodes, but may grow the exponent cache. Whole-sequence hash access returns cached metadata; lazy arenas require materialization first.

Hash arithmetic uses Mersenne prime (2⁶¹ − 1) modular reduction via bit shifts. Nodes are stored in a contiguous arena (`Vec<NodeInner>`) for cache-friendly access. No reference counting, no atomic operations.

## Install

The exact comparison and profile-checking APIs in this checkout are unreleased.
To use them, point the consuming crate's `hashrope` path dependency at this
checkout's `packages/rust` directory. The registry dependency below describes
the published API and does not yet supply these new methods.

```toml
[dependencies]
hashrope = "0.2"
```

## Quick start

```rust
use hashrope::Arena;

let mut a = Arena::new();

// Build ropes from byte slices
let hello = a.from_bytes(b"hello ");
let world = a.from_bytes(b"world");

// Concat: O(log w)
let hw = a.concat(hello, world);
assert_eq!(a.hash(hw), a.hash_bytes(b"hello world"));
assert_eq!(a.len(hw), 11);

// Split at any byte position: O(log w)
let (left, right) = a.split(hw, 6);
assert_eq!(a.to_bytes(left), b"hello ");
assert_eq!(a.to_bytes(right), b"world");

// Rejoin preserves hash
let rejoined = a.concat(left, right);
assert_eq!(a.hash(rejoined), a.hash(hw));

// Repeat: O(log q) — no materialization
let pattern = a.from_bytes(b"ab");
let repeated = a.repeat(pattern, 1_000_000); // "ab" × 10⁶
assert_eq!(a.len(repeated), 2_000_000);

// Substring hash without allocation: O(log w)
let h = a.substr_hash(hw, 0, 5); // hash of "hello"
assert_eq!(h, a.hash_bytes(b"hello"));

// Validate BB[2/7] invariants (for debugging)
a.validate(hw);
```

## Node types

| Type | Description | Weight |
|------|-------------|--------|
| `Leaf(data)` | Raw byte slice | 1 |
| `Internal(left, right)` | Binary node with BB[2/7] balance | w(left) + w(right) |
| `Repeat(child, q)` | Virtual repetition, q ≥ 2 | w(child) × q |

## Arena allocation

All nodes live in a single `Arena`. Node references are `u32` indices. They identify nodes only within their owning arena: passing another arena's numeric ID is invalid even if that ID happens to exist locally. The arena is dropped as a unit — no per-node deallocation. This gives cache-friendly traversal and zero-cost structural sharing.

```rust
let mut a = Arena::new();
let node = a.from_bytes(b"data");
println!("Nodes allocated: {}", a.node_count());
```

## Sliding window

For streaming applications, `SlidingWindow` maintains a bounded-size rope with O(log w) append and eviction:

```rust
use hashrope::{SlidingWindow, MERSENNE_61};

let mut sw = SlidingWindow::new(512, 512, MERSENNE_61, 257);
sw.append_bytes(b"incoming data...");
// Oldest bytes are evicted when the window exceeds d_max + m_max
```

## Polynomial hash properties

The hash function is a polynomial rolling hash over GF(2⁶¹ − 1):

- **Homomorphic under concatenation**: `H(A‖B) = H(A)·x^|B| + H(B)`
- **Homomorphic under repetition**: `H(s^q) = H(s)·Φ(q, x^|s|)` where Φ is computed in O(log q)
- **Noncryptographic fingerprints**: useful for candidate matching, never proof of content identity

The default base remains **131** for compatibility. `[0,131]` and `[1,0]` both hash to **263**, before modular reduction. A larger modulus or an additional modulus with the same base does not separate this pair. Existing fingerprint values and default parameters are unchanged.

For the default profile, leaf hashing evaluates eight bytes per modular
reduction using `H(prefix) * 131^8 + H(block)`. This is the same polynomial:
the block fits in `u64`, and the combined accumulator is below `2^118`.
The tail uses the original byte recurrence. Other accepted profiles retain
their legacy per-byte arithmetic, including their existing custom-modulus
behavior. Splitting copies only the two output slices; lazy materialization
and partial substring hashing borrow the original leaf bytes.

A polynomial collision bound requires a probability model. For two distinct equal-length byte strings of length `n`, fixed before a base is chosen uniformly from `{2,...,p-1}`, the usual root bound is at most `(n-1)/(p-2)` for `p > 256`. The fixed public default base has no such random-base guarantee, particularly for inputs chosen after the parameters are known.

## Exact comparison

```rust
use hashrope::Arena;

let mut arena = Arena::new();
let a = arena.from_bytes(&[0, 131, 42]);
let b = arena.from_bytes(&[1, 0, 42]);
assert_eq!(arena.hash(a), arena.hash(b)); // A candidate match only.
assert!(!arena.equal(a, b));
assert_eq!(arena.lcp(a, b), 0);
```

`Arena::equal(a,b)` compares represented bytes regardless of tree shape. `Arena::lcp(a,b)` returns the exact longest common prefix length **in bytes**. Free functions `rope_equal(&arena,a,b)` and `rope_lcp(&arena,a,b)` provide the same operations. Across arenas, use `left_arena.equal_across(a,&right_arena,b)` or `lcp_across`; each handle belongs to the corresponding arena. Different prime/base profiles and eager/lazy modes are supported.

For windows, `equal_range(a,a_start,b,b_start,length)` and `lcp_range` compare equal-length ranges without splitting or hashing. Their `_across` variants accept the other arena before `b`. Free wrappers are `rope_range_equal` and `rope_range_lcp`. Bounds are checked without overflowing: invalid ranges panic, and empty ranges at a rope's end are valid.

These operations read bytes and immutable structure, without using fingerprints, materializing lazy hashes, splitting ropes, or allocating flattened content. Identical shared ranges are skipped. Ordinary trees use borrowed leaf slices without heap allocations. Long cross-arena ranges (at least 8 KiB) use two iterative traversal stacks to avoid revisiting branches when the tree boundaries differ. Their 32-frame capacity uses 1,600 bytes of frontier storage on 64-bit targets, excluding other local variables. Smaller and same-arena ranges retain a recursive traversal that enters known children directly. An unequal leaf is localized using safe 8-byte comparisons.

Normalization and frontier node examinations consume a visit budget of eight times the combined number of stored arena nodes. Exhausting that budget, encountering a repeat, or filling a frontier stack transfers the unverified suffix to the cached engine; the verified prefix is not rescanned. Clearly compressed roots go directly to that engine. This bounds uncached traversal before fallback without adding metadata to nodes. Node layout and the 512-byte leaf construction policy are unchanged.

In the cached engine, repeated ranges with periods `p` and `q` are proved equal by checking at most `p+q-gcd(p,q)` bytes before skipping further copies (the Fine-Wilf periodicity bound); that checking can itself skip shared or repeated structure. At query entry, chains of `Repeat` nodes and concatenations of the identical child establish smaller periods structurally. The witness checks the original ranges, including their phase offsets. Reducing these chains once per query avoids repeatedly walking them on late mismatches. A per-call cache records ranges already proved equal, avoiding repeated traversal of other shared DAGs.

Exact comparison is **not a logarithmic worst-case operation**. Independently stored equal content can require reading the entire common prefix plus tree traversal. If fallback is needed, cache storage grows with the number of ranges proved equal, and its ordered lookups add logarithmic overhead. Recursive stack depth follows the compared structure. Sharing and repetition often make comparisons much cheaper, but do not provide a universal bound in compressed size.

## Hash profile consistency

An arena's prime/base profile is fixed at construction. `hasher_mut()` remains available for operations such as warming the exponent cache. Replacing the hasher with the same parameters is supported. Replacing it with different parameters causes subsequent arena hashing, construction, edits and validation to panic before using inconsistent metadata; create a new arena to change profiles. Byte access, length access and exact comparisons remain available because they do not depend on fingerprint parameters.

`validate` checks tree structure and unchanged arena parameters; it does not recompute every cached fingerprint. Lazy `hash` still returns `LAZY_SENTINEL` before materialization. Exact comparison handles lazy ropes directly.

## Benchmarks

```sh
cargo bench
```

Uses [Criterion.rs](https://github.com/bheisler/criterion.rs) with HTML reports.

The [edit and metadata report](../../benchmarks/exact_optimization_round3/README.md)
reruns the same workload against Ropey 1.6.1 after grouping default-profile
hash evaluation and removing redundant leaf copies. Each batch performs
50 edits followed by comparison with prebuilt targets, half equal and half
different at the final byte. Values are **µs per cycle**, mean ± sample SD
across nine fresh-process medians. Setup is excluded; every boolean is checked.

| Bytes / target history | Previous core | Optimized | Ropey, optimized cohort |
|---|---:|---:|---:|
| 10,000 / independent | 7.80 ± 0.34 | 4.71 ± 0.21 | 1.20 ± 0.15 |
| 10,000 / shared | 7.11 ± 0.18 | 3.79 ± 0.18 | 0.99 ± 0.10 |
| 100,000 / independent | 24.64 ± 2.18 | 19.36 ± 0.61 | 10.90 ± 0.45 |
| 100,000 / shared | 12.38 ± 0.82 | 7.76 ± 0.52 | 5.09 ± 0.20 |
| 1,000,000 / independent | 149.09 ± 2.67 | 143.74 ± 4.20 | 106.87 ± 4.83 |
| 1,000,000 / shared | 14.39 ± 0.91 | 9.50 ± 0.39 | 36.66 ± 4.69 |

Both 10 KB cases improve in 9/9 paired runs, by 1.66× and 1.87× respectively.
Ropey still wins both regimes at 10 KB and 100 KB, and every independent-target
size. The 1 MB independent gain is modest (3.6%, 8/9 paired improvements),
with a remaining 1.35× Hashrope/Ropey time ratio. Shared history gives Hashrope
a 3.86× advantage at 1 MB in this cohort. These scoped ratios do not establish
universal superiority or statistical significance.

The separate [decomposition diagnostic](../../benchmarks/exact_optimization_round3/edit_profile.md)
measures 10 KB independent edit-only time at 5.065 ± 0.236 → 1.983 ± 0.068 µs,
versus Ropey's 0.437 ± 0.009 µs (three process medians per core). Each edit
still hashes about 709 leaf bytes and creates 40.41 arena nodes on average;
fresh allocation requests fall from 9.88 to 6.92. The original warmup leaves
zero power-cache misses. Persistent path rebuilding and cached metadata remain
costs, while long independent comparisons still scan content. Separate phase
times are not additive; lazy-mode differences do not isolate a precise hashing
percentage. An extra 1 KB diagnostic still favors Ropey.

The 512-byte hash primitive improves 12.84×, but the one-byte probe is about
0.423 ns slower. Both fingerprint-candidate arms use Hashrope's hash kernel,
including the Ropey rehash control; their gains are distinct from exact equality.

The same structural microbenchmarks use three alternating rounds of seven
samples, reported as median [minimum, maximum] of round medians. Building
64 KiB changes from 311.04 [295.44, 312.30] to 45.93 [28.38, 46.48] µs;
splitting from 2.334 [2.326, 2.534] to 0.466 [0.458, 0.470] µs; and warm
substring hashing from 4.504 [4.494, 4.519] to 0.512 [0.480, 0.517] µs.
The 2 TiB self-concatenation DAG LCP is 0.281 [0.252, 0.287] →
0.251 [0.251, 0.280] µs; Repeat LCP remains about 0.081 µs.
These compressed comparison engines are unchanged in this round.

Comparison-only timings are mixed: independent 1 MiB equality increases
from 58.656 [58.386, 59.864] to 68.446 [58.779, 68.978] µs, and
late-mismatch LCP from 60.029 [59.097, 66.136] to 67.337 [61.213, 68.763] µs.
The unchanged source does not establish unchanged runtime, and these three
rounds do not isolate the cause of those increases. All cells and raw samples
are retained in the report. These independent microbench roots share one
arena and use the recursive comparator; the independent-target churn arm
uses a separate target arena and long comparisons use the frontier path.
The data and sizes also differ, so these microbench timings cannot explain the churn timings by
subtraction. The construction probe includes arena setup and destruction.
Rust layout measurements remain 48 bytes per
`NodeInner`, 2,136 inline bytes per `Arena`, and 255 nodes for the 64 KiB
fixture; these are layout measurements, not total memory usage.

The [previous traversal study](../../benchmarks/exact_optimization_round2/README.md)
and [first optimization study](../../benchmarks/exact_optimization/README.md)
remain preserved separately. Fingerprints, default parameters, node layout,
the leaf-size policy and exact-comparison code are unchanged in this round.

## Changelog

See [CHANGELOG.md](CHANGELOG.md).

## License

MIT
