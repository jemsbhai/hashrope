"""Prevent archived hash-only runs from being relabelled as exact evidence."""
import copy
import json

import pytest

from scripts import exp015_analysis as analysis
from scripts import exp015_bench as bench
from scripts import exp015_negctl_R1 as controls_r1
from scripts import exp015_negctl_R2 as controls_r2


def test_new_exp015_outputs_default_to_separate_directory():
    expected = bench.REPO_ROOT / "experiments" / "exp_015_energy" / "results" / "exact_comparison"
    assert bench.build_parser().parse_args(["--regime", "R1"]).results_dir == expected
    assert controls_r1.build_parser().parse_args([]).results_dir == expected
    assert controls_r2.build_parser().parse_args([]).results_dir == expected


@pytest.mark.parametrize("mode", [None, "historical_hash_only"])
def test_resume_and_output_refuse_historical_results(tmp_path, mode):
    path = tmp_path / "previous.json"
    record = {"cell_id": "old-cell"}
    if mode is not None:
        record["comparison_mode"] = mode
    original = json.dumps(record).encode("utf-8")
    path.write_bytes(original)
    with pytest.raises(ValueError, match="historical or unlabelled"):
        bench._collect(path, {})
    with pytest.raises(ValueError, match="historical or unlabelled"):
        bench.check_output_mode(path)
    assert path.read_bytes() == original


def test_exact_checkpoints_can_resume(tmp_path):
    path = tmp_path / "exact.json"
    record = {"comparison_mode": "exact_structural", "cell_id": "exact-cell"}
    path.write_text(json.dumps(record), encoding="utf-8")
    assert bench._collect(path, {}) == record
    bench.check_output_mode(path)


def test_old_analysis_is_labelled_historical():
    docs = analysis.build_synthetic()
    result = analysis.run_analysis(*docs, quiet=True)
    assert result["comparison_mode"] == "historical_hash_only"
    assert result["verdict"].startswith("HISTORICAL HASH-ONLY:")
    assert result["provenance"]["r2"]["comparison_mode"] == "historical_hash_only"


def test_exact_grid_cannot_reuse_old_corruption_controls():
    docs = list(copy.deepcopy(analysis.build_synthetic()))
    for doc in docs[:2]:
        doc["comparison_mode"] = "exact_structural"
    result = analysis.run_analysis(*docs, quiet=True)
    assert result["comparison_mode"] == "mixed_comparison_modes"
    assert result["verdict"].startswith("S3 UNESTABLISHED")
    assert result["negative_controls"]["r1"]["comparison_mode"] == "historical_hash_only"
    for doc in docs[2:]:
        doc["comparison_mode"] = "exact_structural"
    result = analysis.run_analysis(*docs, quiet=True)
    assert result["comparison_mode"] == "exact_structural"
    assert result["provenance"]["r2"]["comparison_mode"] == "exact_structural"
    assert result["negative_controls"]["r1"]["comparison_mode"] == "exact_structural"
