"""Collision regressions for the paper's actual byte/token/reuse consumers."""

import pytest

from hashrope import MERSENNE_61, MERSENNE_127, PolynomialHash, rope_hash

from src.competitive import (
    build_token_rope,
    hashrope_lcp_tokens,
    hashrope_lcp_tokens_counted,
    oracle_lcp,
)
from src.exp015_identify import correctness_gate, identify, prepare, time_identify
from src.flatten import build_fat_leaf_rope
from src.lcp import lcp_brute, lcp_hash, lcp_hash_counted


@pytest.mark.parametrize("prime", [MERSENNE_61, MERSENNE_127])
@pytest.mark.parametrize("prefix", [b"", b"shared", b"x" * 4097])
def test_byte_helper_rejects_equal_fingerprint_with_different_content(prime, prefix):
    h = PolynomialHash(prime=prime)
    left_bytes = prefix + b"\x00\x83*"
    right_bytes = prefix + b"\x01\x00*"
    left = build_fat_leaf_rope(left_bytes, h, leaf_bytes=17)
    right = build_fat_leaf_rope(right_bytes, h, leaf_bytes=31)
    assert rope_hash(left) == rope_hash(right)
    assert lcp_hash(left, right, h) == lcp_brute(left_bytes, right_bytes) == len(prefix)
    assert lcp_hash_counted(left, right, h) == (len(prefix), 0)


@pytest.mark.parametrize("prefix", [[], [7], list(range(1025))])
def test_token_wrapper_handles_colliding_token_ids(prefix):
    left_tokens = prefix + [33536, 9]
    right_tokens = prefix + [1, 9]
    left, h = build_token_rope(left_tokens)
    right, _ = build_token_rope(right_tokens, h)
    assert rope_hash(left) == rope_hash(right)
    expected = oracle_lcp(left_tokens, right_tokens)
    assert expected == len(prefix)
    assert hashrope_lcp_tokens(left, right, h) == expected
    assert hashrope_lcp_tokens_counted(left, right, h) == (expected, 0)


def test_compatibility_hasher_does_not_restrict_exact_comparison_profiles():
    left_h = PolynomialHash()
    right_h = PolynomialHash(prime=MERSENNE_127, base=257)
    data = b"same bytes across independent profiles" * 40
    left = build_fat_leaf_rope(data, left_h, leaf_bytes=13)
    right = build_fat_leaf_rope(data + b"!", right_h, leaf_bytes=29)
    assert lcp_hash(left, right, left_h) == len(data)
    assert lcp_hash_counted(left, right, right_h) == (len(data), 0)


@pytest.mark.parametrize("with_radix", [False, True])
def test_serving_identification_and_gate_reject_colliding_reuse(with_radix):
    cached = [7, 33536, 9]
    queries = [[7, 1, 9], [7, 33536], [7, 33536, 9, 10], []]
    handles = prepare(cached, with_radix=with_radix)
    for query in queries:
        expected = oracle_lcp(cached, query)
        results = identify(handles, query)
        assert results["oracle"] == results["hashrope"] == results["flat"] == expected
        if handles.radix_on:
            assert results["radix"] == expected

    result = correctness_gate(cached, queries, with_radix=with_radix, keep_detail=True)
    assert result.ok
    assert result.n_checks == len(queries)
    assert result.mismatches == 0
    assert result.detail == []


def test_identification_timing_uses_the_exact_consumer(monkeypatch):
    import src.exp015_identify as serving

    handles = prepare([33536], with_radix=False)
    observed_matches = []
    exact_wrapper = serving.hashrope_lcp_tokens

    def record_exact_match(left, right, h):
        result = exact_wrapper(left, right, h)
        observed_matches.append(result)
        return result

    monkeypatch.setattr(serving, "hashrope_lcp_tokens", record_exact_match)
    result = time_identify(handles, [1], reps=2)
    assert observed_matches == [0, 0, 0]  # warm-up plus two measured queries
    assert result["hashrope_ms"] >= 0
    assert result["hashrope_query_build_ms"] >= 0
