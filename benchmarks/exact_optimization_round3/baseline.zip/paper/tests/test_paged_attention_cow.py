"""
EXP-019 (claim B3) -- PagedAttention block-table COW baseline: correctness GATE
+ structural guards, in token space (the baseline's native unit).

Reference mechanism: Kwon et al., SOSP 2023 (arXiv:2309.06180), sec 4.2 (block
table over ref-counted physical blocks) + sec 4.4 (copy-on-write on a write into
a shared partial last block; copies exactly one block).

Red-first contract: every test below is RED at the stub (NotImplementedError)
and GREEN once src/paged_attention_cow.py is implemented. The oracle is a plain
Python list of token ids; the paged structure must agree with it token-for-token
across build / fork / append / divergence / prune.

Deterministic, offline, hashrope-independent -- this is the baseline arm only;
cross-arm byte-identity vs hashrope lives in tests/test_branch.py.
"""
import math
import random

import pytest

from src.paged_attention_cow import (
    PhysicalBlockPool,
    PagedSequence,
    build_sequence,
    append_token,
    fork,
    materialize,
    free_sequence,
)

SEED = 42
VOCAB = 50257                      # gpt2 vocab size (plausible token-id range)
BLOCK_SIZES = [8, 16, 32, 64]      # the EXP-019 block-size sweep (sec 7.2 study)


def _tokens(n: int, seed: int = SEED) -> list[int]:
    """Deterministic varied token ids. random.Random is a fixed stream, so
    _tokens(m)[:k] == _tokens(k) for m >= k -- prefixes stay consistent."""
    rng = random.Random(seed)
    return [rng.randrange(0, VOCAB) for _ in range(n)]


# ---------------------------------------------------------------------------
# Build + materialize round-trip (the untimed setup path)
# ---------------------------------------------------------------------------

class TestBuildMaterialize:
    @pytest.mark.parametrize("B", BLOCK_SIZES)
    @pytest.mark.parametrize("n", [0, 1, 7, 8, 9, 100, 257])
    def test_roundtrip(self, B, n):
        pool = PhysicalBlockPool(B)
        toks = _tokens(n)
        seq = build_sequence(pool, toks)
        assert materialize(seq) == toks
        assert seq.length == n

    @pytest.mark.parametrize("B", BLOCK_SIZES)
    def test_block_layout(self, B):
        pool = PhysicalBlockPool(B)
        n = 3 * B + 1                      # 4 logical blocks, last holds 1 token
        seq = build_sequence(pool, _tokens(n))
        assert seq.num_blocks == math.ceil(n / B)
        assert seq.filled_in_last == 1

    @pytest.mark.parametrize("B", BLOCK_SIZES)
    def test_exact_multiple_full_last(self, B):
        pool = PhysicalBlockPool(B)
        n = 2 * B                          # last block exactly full
        seq = build_sequence(pool, _tokens(n))
        assert seq.num_blocks == 2
        assert seq.filled_in_last == B


# ---------------------------------------------------------------------------
# Append semantics: in-place / new-block / COW
# ---------------------------------------------------------------------------

class TestAppend:
    def test_in_place_when_exclusive_partial(self):
        B = 8
        pool = PhysicalBlockPool(B)
        seq = build_sequence(pool, _tokens(3))        # one partial block, refcount 1
        allocs_before = pool.num_allocations
        stats = append_token(seq, 999)
        assert stats["cow"] is False
        assert stats["new_block"] is False
        assert pool.num_allocations == allocs_before  # no allocation
        assert materialize(seq) == _tokens(3) + [999]

    def test_new_block_when_full(self):
        B = 8
        pool = PhysicalBlockPool(B)
        seq = build_sequence(pool, _tokens(B))        # last block full
        allocs_before = pool.num_allocations
        stats = append_token(seq, 999)
        assert stats["new_block"] is True
        assert stats["cow"] is False
        assert pool.num_allocations == allocs_before + 1
        assert seq.num_blocks == 2
        assert materialize(seq) == _tokens(B) + [999]


# ---------------------------------------------------------------------------
# Fork: structural sharing + the O(ceil(N/B)) guard
# ---------------------------------------------------------------------------

class TestFork:
    @pytest.mark.parametrize("B", BLOCK_SIZES)
    def test_fork_byte_identity(self, B):
        pool = PhysicalBlockPool(B)
        toks = _tokens(100)
        parent = build_sequence(pool, toks)
        child = fork(parent)
        assert materialize(child) == toks
        assert materialize(parent) == toks

    @pytest.mark.parametrize("B", BLOCK_SIZES)
    def test_fork_shares_and_increfs_all_blocks(self, B):
        """Guard (ii): fork copies a block table of ceil(N/B) entries and increfs
        each shared physical block -- the O(N/B) fork cost."""
        pool = PhysicalBlockPool(B)
        n = 100
        parent = build_sequence(pool, _tokens(n))
        nb = parent.num_blocks
        assert nb == math.ceil(n / B)
        for bid in parent.block_table:                # every base block starts exclusive
            assert pool.ref_count(bid) == 1
        child = fork(parent)
        assert child.block_table == parent.block_table  # same physical blocks, in order
        assert child.num_blocks == nb
        for bid in parent.block_table:                # all shared -> refcount 2
            assert pool.ref_count(bid) == 2

    def test_fork_no_new_allocation(self):
        B = 16
        pool = PhysicalBlockPool(B)
        parent = build_sequence(pool, _tokens(100))
        allocs_before = pool.num_allocations
        fork(parent)
        assert pool.num_allocations == allocs_before  # fork allocates nothing


# ---------------------------------------------------------------------------
# Copy-on-write (sec 4.4, Fig 8)
# ---------------------------------------------------------------------------

class TestCopyOnWrite:
    def test_cow_on_shared_partial_block(self):
        """Append into a shared partial last block triggers COW of exactly one
        block; parent unchanged, child diverges, old block refcount drops."""
        B = 8
        pool = PhysicalBlockPool(B)
        base = _tokens(3)                              # one partial block (3/8 filled)
        parent = build_sequence(pool, base)
        shared_bid = parent.block_table[-1]
        child = fork(parent)
        assert pool.ref_count(shared_bid) == 2
        allocs_before = pool.num_allocations

        stats = append_token(child, 777)
        assert stats["cow"] is True
        assert stats["blocks_copied"] == 1
        assert pool.num_allocations == allocs_before + 1   # exactly one new block
        assert pool.ref_count(shared_bid) == 1             # old block now exclusive to parent
        assert child.block_table[-1] != shared_bid         # child points at a NEW last block
        assert materialize(child) == base + [777]
        assert materialize(parent) == base                 # parent untouched

    def test_parallel_sampling_two_children_diverge(self):
        """Fig 8: two samples share the prompt, write different tokens, both
        correct via COW on the final block."""
        B = 8
        pool = PhysicalBlockPool(B)
        prompt = _tokens(5)
        a = build_sequence(pool, prompt)
        b = fork(a)
        append_token(a, 100)
        append_token(b, 200)
        assert materialize(a) == prompt + [100]
        assert materialize(b) == prompt + [200]

    def test_cow_only_last_block_earlier_shared(self):
        """COW touches only the last block; earlier blocks stay shared."""
        B = 8
        pool = PhysicalBlockPool(B)
        base = _tokens(B + 3)                          # 2 blocks: full + partial(3)
        parent = build_sequence(pool, base)
        first_bid = parent.block_table[0]
        child = fork(parent)
        append_token(child, 555)
        assert pool.ref_count(first_bid) == 2          # first (full) block still shared
        assert child.block_table[0] == first_bid
        assert materialize(child) == base + [555]

    def test_full_last_block_fork_append_allocates_new_not_cow(self):
        """If the shared last block is full, the next append allocates a fresh
        (exclusive) block rather than copying -- not a COW."""
        B = 8
        pool = PhysicalBlockPool(B)
        base = _tokens(B)                              # last block exactly full
        parent = build_sequence(pool, base)
        child = fork(parent)
        stats = append_token(child, 321)
        assert stats["new_block"] is True
        assert stats["cow"] is False
        assert materialize(child) == base + [321]
        assert materialize(parent) == base


# ---------------------------------------------------------------------------
# Prune / free (beam search: reclaim pruned candidates' blocks)
# ---------------------------------------------------------------------------

class TestFreeSequence:
    def test_free_reclaims_exclusive_blocks(self):
        B = 8
        pool = PhysicalBlockPool(B)
        seq = build_sequence(pool, _tokens(20))
        assert pool.num_live_blocks == seq.num_blocks
        free_sequence(seq)
        assert pool.num_live_blocks == 0

    def test_free_keeps_blocks_shared_with_survivor(self):
        B = 8
        pool = PhysicalBlockPool(B)
        parent = build_sequence(pool, _tokens(20))
        child = fork(parent)                           # all blocks shared (refcount 2)
        nb = parent.num_blocks
        free_sequence(child)                           # prune the child
        assert pool.num_live_blocks == nb              # parent's blocks survive
        for bid in parent.block_table:
            assert pool.ref_count(bid) == 1
        assert materialize(parent) == _tokens(20)


# ---------------------------------------------------------------------------
# Randomized oracle agreement (strong correctness, EXP-017 style)
# ---------------------------------------------------------------------------

class TestOracleAgreement:
    @pytest.mark.parametrize("B", [8, 16])
    def test_random_fork_append_tree(self, B):
        """A random tree of fork/append ops; every paged sequence must materialize
        equal to its independently-maintained oracle token list."""
        rng = random.Random(SEED + B)
        pool = PhysicalBlockPool(B)

        base = _tokens(rng.randrange(1, 50))
        root = build_sequence(pool, base)
        seqs = [root]
        oracles = [list(base)]

        for _ in range(200):
            i = rng.randrange(len(seqs))
            if rng.random() < 0.4:                     # fork sequence i
                seqs.append(fork(seqs[i]))
                oracles.append(list(oracles[i]))
            else:                                       # append a token to sequence i
                tok = rng.randrange(0, VOCAB)
                append_token(seqs[i], tok)
                oracles[i].append(tok)

        for s, o in zip(seqs, oracles):
            assert materialize(s) == o
