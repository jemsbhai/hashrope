"""
EXP-005 -- exact LCP correctness and zero-hash-query guard (no timing).

The historical lcp_hash name now wraps exact structural comparison. Its
counted compatibility form reports zero hash queries, which makes no claim
about byte comparisons or total complexity. Correctness is checked against
the independent byte oracle, including deliberate fingerprint collisions in
test_exact_identification.py.

Unit-test sizes are small (10 KB – 50 KB). Paper-grade timing uses the
downloaded corpus and the full size sweep (scripts/exp005_bench.py).
"""
import random

import pytest
import hashrope
import hashrope.rope as _rope
from hashrope import PolynomialHash

from src.flatten import build_fat_leaf_rope, make_hash
from src.lcp import lcp_brute, lcp_hash, lcp_hash_counted

SIZES = [10_000, 50_000]
SEEDS = [42, 43]
FRACTIONS = [0.0, 0.5, 0.99]


def _corpus(nbytes: int, seed: int) -> bytes:
    """Deterministic varied bytes."""
    return random.Random(seed).randbytes(nbytes)


def _make_pair(data: bytes, f: float, h: PolynomialHash):
    """Build rope pair (A, B) with known LCP = int(f * len(data)).

    B is a copy of data with byte at position L flipped (XOR 0xFF).
    For f=0.0, L=0 → first byte differs → LCP = 0.
    For f=1.0, no flip → LCP = len(data).
    """
    n = len(data)
    lcp_expected = int(f * n)
    a_bytes = data
    b_bytes = bytearray(data)
    if lcp_expected < n:
        b_bytes[lcp_expected] ^= 0xFF  # guarantees difference
    b_bytes = bytes(b_bytes)
    rope_a = build_fat_leaf_rope(a_bytes, h)
    rope_b = build_fat_leaf_rope(b_bytes, h)
    return rope_a, rope_b, a_bytes, b_bytes, lcp_expected


# ── Correctness gate (real corpus) ──────────────────────────────────────


@pytest.mark.parametrize("nbytes", SIZES)
@pytest.mark.parametrize("seed", SEEDS)
@pytest.mark.parametrize("f", FRACTIONS)
def test_lcp_correctness_real_corpus(nbytes, seed, f):
    """lcp_hash must return the exact same position as lcp_brute."""
    h = make_hash()
    data = _corpus(nbytes, seed)
    rope_a, rope_b, a_bytes, b_bytes, lcp_expected = _make_pair(data, f, h)

    brute = lcp_brute(a_bytes, b_bytes)
    hashed = lcp_hash(rope_a, rope_b, h)

    assert brute == lcp_expected, (
        f"lcp_brute={brute} != expected={lcp_expected} (f={f}, N={nbytes})"
    )
    assert hashed == lcp_expected, (
        f"lcp_hash={hashed} != expected={lcp_expected} (f={f}, N={nbytes})"
    )
    assert hashed == brute, (
        f"lcp_hash={hashed} != lcp_brute={brute}"
    )


# ── Correctness gate (synthetic control) ────────────────────────────────


@pytest.mark.parametrize("lcp_len", [0, 1, 100, 4095, 4096, 4097, 10_000])
def test_lcp_correctness_synthetic(lcp_len):
    """Algebraically known LCP on uniform-byte data with single flip."""
    h = make_hash()
    n = max(lcp_len + 1, 1024)  # ensure rope is at least 1 KB
    a_bytes = bytes([0xAB] * n)
    b_bytes = bytearray(a_bytes)
    if lcp_len < n:
        b_bytes[lcp_len] ^= 0xFF
    b_bytes = bytes(b_bytes)

    rope_a = build_fat_leaf_rope(a_bytes, h)
    rope_b = build_fat_leaf_rope(b_bytes, h)

    assert lcp_brute(a_bytes, b_bytes) == lcp_len
    assert lcp_hash(rope_a, rope_b, h) == lcp_len


# ── No-hash-query guard ─────────────────────────────────────────────────


@pytest.mark.parametrize("nbytes", SIZES)
@pytest.mark.parametrize("seed", SEEDS)
def test_lcp_uses_no_hash_queries(nbytes, seed, monkeypatch):
    """Exact comparisons perform no fingerprint queries after construction."""
    h = make_hash()
    data = _corpus(nbytes, seed)
    rope_a, rope_b, _, _, _ = _make_pair(data, 0.5, h)

    def forbid_hash(*args, **kwargs):
        raise AssertionError("Exact LCP must not query fingerprints")

    monkeypatch.setattr(_rope, "rope_substr_hash", forbid_hash)
    monkeypatch.setattr(hashrope, "rope_substr_hash", forbid_hash)
    monkeypatch.setattr(PolynomialHash, "hash", forbid_hash)

    lcp_val, num_calls = lcp_hash_counted(rope_a, rope_b, h)
    assert lcp_val == nbytes // 2
    assert num_calls == 0


# ── Edge cases ──────────────────────────────────────────────────────────


@pytest.mark.parametrize("nbytes", SIZES)
@pytest.mark.parametrize("seed", SEEDS)
def test_lcp_zero_prefix(nbytes, seed):
    """f=0.0: first byte differs → LCP = 0."""
    h = make_hash()
    data = _corpus(nbytes, seed)
    rope_a, rope_b, a_bytes, b_bytes, _ = _make_pair(data, 0.0, h)
    assert lcp_brute(a_bytes, b_bytes) == 0
    assert lcp_hash(rope_a, rope_b, h) == 0


@pytest.mark.parametrize("nbytes", SIZES)
@pytest.mark.parametrize("seed", SEEDS)
def test_lcp_full_match(nbytes, seed):
    """Identical ropes → LCP = len(data)."""
    h = make_hash()
    data = _corpus(nbytes, seed)
    rope_a = build_fat_leaf_rope(data, h)
    rope_b = build_fat_leaf_rope(data, h)
    assert lcp_brute(data, data) == nbytes
    assert lcp_hash(rope_a, rope_b, h) == nbytes


def test_lcp_empty_ropes():
    """Empty / None ropes → LCP = 0."""
    h = make_hash()
    assert lcp_brute(b"", b"") == 0
    assert lcp_brute(b"abc", b"") == 0
    assert lcp_brute(b"", b"abc") == 0
    assert lcp_hash(None, None, h) == 0
    rope = build_fat_leaf_rope(b"hello", h)
    assert lcp_hash(rope, None, h) == 0
    assert lcp_hash(None, rope, h) == 0
