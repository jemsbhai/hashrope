#!/usr/bin/env python3
"""
Extract compact working subsets from downloaded canonical datasets.

Produces:
  data/canonical/sharegpt_sample.jsonl    — 5K conversations (stratified by turn count)
  data/canonical/lmsys_sample.jsonl       — 10K conversations (random, seeded)
  data/canonical/game_of_24.jsonl         — all 1,362 puzzles
  data/canonical/dataset_stats.json       — summary statistics

After running, delete the multi-GB originals in data/raw/{sharegpt_vicuna,lmsys_chat_1m,game_of_24}.
"""
import json
import os
import random
import sys
from collections import Counter
from pathlib import Path

REPO = Path(__file__).resolve().parent.parent
RAW = REPO / "data" / "raw"
OUT = REPO / "data" / "canonical"
SEED = 42


def process_sharegpt(n_sample=5000):
    """ShareGPT V3: multi-turn conversations with human/gpt roles."""
    path = RAW / "sharegpt_vicuna" / "ShareGPT_V3_unfiltered_cleaned_split.json"
    print(f"Loading ShareGPT from {path} ...")
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    print(f"  Total conversations: {len(data)}")

    # Parse into uniform format: list of {id, turns: [{role, content}]}
    convos = []
    for item in data:
        turns = []
        for msg in item.get("conversations", []):
            role = msg.get("from", "unknown")
            content = msg.get("value", "")
            turns.append({"role": role, "content": content})
        if turns:
            convos.append({
                "id": item.get("id", ""),
                "turns": turns,
                "n_turns": len(turns),
                "total_bytes": sum(len(t["content"].encode("utf-8")) for t in turns),
            })

    # Stratified sample by turn count buckets: [2, 4-6, 8-14, 16+]
    rng = random.Random(SEED)
    buckets = {
        "2-3": [c for c in convos if 2 <= c["n_turns"] <= 3],
        "4-6": [c for c in convos if 4 <= c["n_turns"] <= 6],
        "8-14": [c for c in convos if 8 <= c["n_turns"] <= 14],
        "16+": [c for c in convos if c["n_turns"] >= 16],
    }
    per_bucket = n_sample // len(buckets)
    sampled = []
    for name, bucket in buckets.items():
        rng.shuffle(bucket)
        take = min(per_bucket, len(bucket))
        sampled.extend(bucket[:take])
        print(f"  Bucket {name}: {len(bucket)} total, sampled {take}")

    # Fill remainder from largest bucket if needed
    if len(sampled) < n_sample:
        remaining = n_sample - len(sampled)
        sampled_ids = {c["id"] for c in sampled}
        extras = [c for c in convos if c["id"] not in sampled_ids]
        rng.shuffle(extras)
        sampled.extend(extras[:remaining])

    rng.shuffle(sampled)
    print(f"  Final sample: {len(sampled)} conversations")

    # Write
    out_path = OUT / "sharegpt_sample.jsonl"
    with open(out_path, "w", encoding="utf-8") as f:
        for c in sampled:
            f.write(json.dumps(c, ensure_ascii=False) + "\n")
    print(f"  -> {out_path} ({out_path.stat().st_size / 1e6:.1f} MB)")

    return {
        "source": "ShareGPT_V3_unfiltered_cleaned_split",
        "total_conversations": len(data),
        "sampled": len(sampled),
        "turn_distribution": {k: len(v) for k, v in buckets.items()},
        "median_turns": sorted(c["n_turns"] for c in sampled)[len(sampled) // 2],
        "median_bytes": sorted(c["total_bytes"] for c in sampled)[len(sampled) // 2],
    }


def process_lmsys(n_sample=10000):
    """LMSYS-Chat-1M: real-world LLM conversations."""
    from datasets import load_from_disk
    path = RAW / "lmsys_chat_1m"
    print(f"Loading LMSYS from {path} ...")
    ds = load_from_disk(str(path))
    print(f"  Total conversations: {len(ds)}")

    # Seeded random sample
    rng = random.Random(SEED)
    indices = list(range(len(ds)))
    rng.shuffle(indices)
    indices = indices[:n_sample]

    sampled = []
    for idx in indices:
        item = ds[idx]
        conversation = item.get("conversation", [])
        turns = []
        for msg in conversation:
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
            turns.append({"role": role, "content": content})
        if turns:
            sampled.append({
                "id": item.get("conversation_id", str(idx)),
                "model": item.get("model", "unknown"),
                "language": item.get("language", "unknown"),
                "turns": turns,
                "n_turns": len(turns),
                "total_bytes": sum(len(t["content"].encode("utf-8")) for t in turns),
            })

    print(f"  Sampled: {len(sampled)} conversations")

    out_path = OUT / "lmsys_sample.jsonl"
    with open(out_path, "w", encoding="utf-8") as f:
        for c in sampled:
            f.write(json.dumps(c, ensure_ascii=False) + "\n")
    print(f"  -> {out_path} ({out_path.stat().st_size / 1e6:.1f} MB)")

    # Language distribution in sample
    langs = Counter(c["language"] for c in sampled)
    models = Counter(c["model"] for c in sampled)

    return {
        "source": "lmsys/lmsys-chat-1m",
        "total_conversations": len(ds),
        "sampled": len(sampled),
        "median_turns": sorted(c["n_turns"] for c in sampled)[len(sampled) // 2],
        "median_bytes": sorted(c["total_bytes"] for c in sampled)[len(sampled) // 2],
        "top_languages": dict(langs.most_common(5)),
        "top_models": dict(models.most_common(5)),
    }


def process_game24():
    """Game of 24: all puzzles (tiny dataset, keep everything)."""
    from datasets import load_from_disk
    path = RAW / "game_of_24"
    print(f"Loading Game of 24 from {path} ...")
    ds = load_from_disk(str(path))
    split = list(ds.keys())[0]  # usually 'train'
    data = ds[split]
    print(f"  Total puzzles: {len(data)}")

    puzzles = []
    for i in range(len(data)):
        item = data[i]
        puzzles.append({
            "rank": item.get("Rank", i),
            "puzzles": item.get("Puzzles", ""),
            "solved_rate": item.get("Solved rate", 0),
            "amt_seconds": item.get("AMT (s)", 0),
        })

    out_path = OUT / "game_of_24.jsonl"
    with open(out_path, "w", encoding="utf-8") as f:
        for p in puzzles:
            f.write(json.dumps(p) + "\n")
    print(f"  -> {out_path} ({out_path.stat().st_size / 1e3:.1f} KB)")

    return {
        "source": "test-time-compute/game-of-24",
        "total_puzzles": len(puzzles),
        "standard_test_range": "901-1000 (per Yao et al. 2023)",
    }


def main():
    OUT.mkdir(parents=True, exist_ok=True)

    stats = {}
    stats["sharegpt"] = process_sharegpt()
    print()
    stats["lmsys"] = process_lmsys()
    print()
    stats["game_of_24"] = process_game24()

    # Write stats
    stats_path = OUT / "dataset_stats.json"
    stats_path.write_text(json.dumps(stats, indent=2))
    print(f"\n-> {stats_path}")

    # Compute total extracted size
    total = sum(f.stat().st_size for f in OUT.iterdir() if f.is_file())
    print(f"\nTotal extracted: {total / 1e6:.1f} MB")
    print("\nYou can now delete the large originals:")
    print(f"  Remove-Item -Recurse -Force '{RAW / 'sharegpt_vicuna'}'")
    print(f"  Remove-Item -Recurse -Force '{RAW / 'lmsys_chat_1m'}'")
    print(f"  Remove-Item -Recurse -Force '{RAW / 'game_of_24'}'")


if __name__ == "__main__":
    main()
