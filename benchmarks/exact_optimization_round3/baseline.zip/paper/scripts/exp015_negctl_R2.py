#!/usr/bin/env python3
"""EXP-015 R2 corruption controls for the corrected exact identifier.

Corrupt one cached token before the true LCP and check the shortened match.
These workload checks do not prove correctness for every possible input.
Results record corpus provenance and exact_structural metadata in a separate
exact_comparison directory. Requires the updated local Hashrope checkout.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import time
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from scripts.exp015_bench import COMPARISON_MODE, DEFAULT_RESULTS_DIR, check_output_mode


def build_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", default="Qwen/Qwen2.5-7B-Instruct-1M")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--corpus", type=Path, default=REPO_ROOT / "data" / "raw" / "corpus_s42.txt")
    parser.add_argument("--lengths", default="131072,262144,393216,524288,1000000")
    parser.add_argument("--results-dir", type=Path, default=DEFAULT_RESULTS_DIR)
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    lengths = [int(value) for value in args.lengths.split(",")]
    if not lengths or any(length < 1 for length in lengths):
        raise ValueError("Control prefix lengths must be positive")
    output = args.results_dir / "exp015_negative_control_R2.json"
    check_output_mode(output)
    from src.exp015_identify import (build_r2_stream, negative_control,
                                     correctness_gate, radix_available)
    from transformers import AutoTokenizer

    print("radix_available:", radix_available(), flush=True)
    tokenizer = AutoTokenizer.from_pretrained(args.model)
    corpus = args.corpus.read_bytes()
    sha = hashlib.sha256(corpus).hexdigest()[:16]
    start = time.time()
    tokens = tokenizer(corpus.decode("utf-8"), add_special_tokens=False)["input_ids"]
    print(f"corpus sha16={sha} tokens={len(tokens):,} "
          f"(tokenized in {time.time() - start:.0f}s)", flush=True)

    rows = []
    for length in lengths:
        stream = build_r2_stream(tokens, L=length, n_queries=8, seed=args.seed)
        cached, queries = stream["cached_tokens"], stream["queries"]
        gate = correctness_gate(cached, queries, with_radix=True)
        row = {"L": length, "seed": args.seed, "gate_ok": gate.ok,
               "gate_checks": gate.n_checks, "gate_mismatches": gate.mismatches,
               "arms_present": gate.arms_present, "controls": []}
        for label, pos in (("first", 0), ("mid", length // 2), ("last", length - 1)):
            control = negative_control(cached, queries[0], corrupt_pos=pos, with_radix=True)
            row["controls"].append({"where": label, "pos": control["pos"],
                                    "true_lcp": control["true_lcp"],
                                    "arms_checked": control["arms_checked"],
                                    "results": control["results"], "detected": control["detected"]})
            print(f"L={length} corrupt@{label} pos={control['pos']} "
                  f"detected={control['detected']}", flush=True)
        rows.append(row)

    result = {"experiment": "EXP-015", "claim": "S3", "regime": "R2",
              "comparison_mode": COMPARISON_MODE,
              "purpose": "Empirical corrupted-cached-entry checks",
              "model": args.model, "corpus_sha16": {str(args.seed): sha},
              "corpus_path": str(args.corpus), "seed": args.seed, "L_sweep": lengths,
              "rows": rows,
              "all_detected": all(c["detected"] for r in rows for c in r["controls"]),
              "all_gates_ok": all(r["gate_ok"] for r in rows)}
    args.results_dir.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("ALL CONTROLS DETECTED:", result["all_detected"])
    print("ALL UNCORRUPTED GATES OK:", result["all_gates_ok"])
    print("wrote", output)
    return 0 if result["all_detected"] and result["all_gates_ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
