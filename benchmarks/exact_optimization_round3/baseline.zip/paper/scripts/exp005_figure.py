#!/usr/bin/env python3
"""
EXP-005 figure -- LCP timing (log-log) + fingerprint-query count.

Reads from experiments/exp_005_lcp/results/exp005_lcp_latest.json.
Missing comparison metadata identifies the archived hash-only algorithm.
Pass --result to plot a new exact run. Outputs include the comparison mode
in their filenames, preserving the archived figures.

Panel (a): measured latency vs N at f=0.5; no exact-LCP complexity is inferred.
Panel (b): fingerprint queries, not total work. Exact traversal uses zero.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

REPO_ROOT = Path(__file__).resolve().parent.parent
RESULT = REPO_ROOT / "experiments" / "exp_005_lcp" / "results" / "exp005_lcp_latest.json"
FIG_DIR = REPO_ROOT / "figures"
PRIMARY_F = 0.5


def comparison_mode(result):
    mode = result.get("comparison_mode")
    if mode is None:
        semantics = result.get("comparison_semantics", "")
        mode = "exact_structural" if semantics.startswith("exact;") else "historical_hash_only"
    if mode not in ("exact_structural", "historical_hash_only"):
        raise ValueError(f"Unsupported comparison_mode: {mode!r}")
    return mode


def comparison_label(result):
    return ("exact structural LCP" if comparison_mode(result) == "exact_structural"
            else "historical hash-only LCP")


def load_result(path=RESULT):
    path = Path(path)
    if not path.exists():
        print(f"Result file not found: {path}", file=sys.stderr)
        sys.exit(1)
    return json.loads(path.read_text(encoding="utf-8"))


def make_latency_figure(result: dict, out_dir=FIG_DIR) -> None:
    """Measured latency vs N at f=0.5, labelled with comparison semantics."""
    sizes = result["params"]["sizes"]
    p = result["per_size_fraction"]

    hash_mean = [p[f"{n}_{PRIMARY_F}"]["hash_ms"]["mean"] for n in sizes]
    hash_std = [p[f"{n}_{PRIMARY_F}"]["hash_ms"]["std"] for n in sizes]
    brute_mean = [p[f"{n}_{PRIMARY_F}"]["brute_ms"]["mean"] for n in sizes]
    brute_std = [p[f"{n}_{PRIMARY_F}"]["brute_ms"]["std"] for n in sizes]

    slopes = result["scaling_slopes_loglog_f05"]
    hash_slope = slopes["hash_ms"]
    brute_slope = slopes["brute_ms"]

    fig, ax = plt.subplots(figsize=(7, 4.5))
    ax.errorbar(sizes, hash_mean, yerr=hash_std, fmt="o-",
                color="#2563eb", linewidth=2, markersize=6, capsize=4,
                label=f"{comparison_label(result)} (slope {hash_slope:.3f})")
    ax.errorbar(sizes, brute_mean, yerr=brute_std, fmt="s--",
                color="#dc2626", linewidth=2, markersize=6, capsize=4,
                label=f"brute-force (slope {brute_slope:.3f})")

    ax.set_xscale("log")
    ax.set_yscale("log")
    ax.set_xlabel("Rope size N (bytes)", fontsize=12)
    ax.set_ylabel("Latency (ms)", fontsize=12)
    ax.set_title("LCP latency vs rope size (f = 0.5)",
                 fontsize=13, fontweight="bold")
    ax.legend(fontsize=10, loc="upper left")
    ax.grid(True, alpha=0.3, which="both")

    # annotate crossover
    for i, n in enumerate(sizes):
        if hash_mean[i] < brute_mean[i] and (i == 0 or hash_mean[i-1] >= brute_mean[i-1]):
            ax.annotate(f"crossover ~{n/1e6:.0f} MB",
                        xy=(n, hash_mean[i]), fontsize=9, color="#666",
                        xytext=(n * 2, hash_mean[i] * 2.5),
                        arrowprops=dict(arrowstyle="->", color="#666"))
            break

    fig.tight_layout()
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = out_dir / f"exp005_lcp_latency_{comparison_mode(result)}"
    fig.savefig(stem.with_suffix(".png"), dpi=300)
    fig.savefig(stem.with_suffix(".pdf"))
    plt.close(fig)
    print(f"[figure] wrote: {stem}.png / .pdf")


def make_steps_figure(result: dict, out_dir=FIG_DIR) -> None:
    """Fingerprint-query count; this does not measure exact traversal work."""
    sizes = result["params"]["sizes"]
    p = result["per_size_fraction"]

    observed = [p[f"{n}_{PRIMARY_F}"]["step_count_max_seen"] for n in sizes]

    fig, ax = plt.subplots(figsize=(7, 4))
    ax.plot(sizes, observed, "o-", color="#2563eb", linewidth=2,
            markersize=7, label="observed (max across runs)")
    if comparison_mode(result) == "historical_hash_only":
        theoretical = [2 * math.ceil(math.log2(n + 1)) for n in sizes]
        ax.plot(sizes, theoretical, "^:", color="#dc2626", linewidth=1.5,
                markersize=6,
                label=r"$2 \cdot \lceil \log_2(N+1) \rceil$ (upper bound)")
    else:
        if any(observed):
            raise ValueError("Exact traversal result reports nonzero fingerprint queries")
        ax.text(0.5, 0.8, "Zero hash queries is not a bound on total comparison work",
                transform=ax.transAxes, ha="center", fontsize=9)

    ax.set_xscale("log")
    ax.set_xlabel("Rope size N (bytes)", fontsize=12)
    ax.set_ylabel("rope_substr_hash calls", fontsize=12)
    ax.set_title(f"Fingerprint queries: {comparison_label(result)} (f = 0.5)",
                 fontsize=13, fontweight="bold")
    ax.legend(fontsize=10, loc="upper left")
    ax.grid(True, alpha=0.3, which="both")

    fig.tight_layout()
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = out_dir / f"exp005_lcp_steps_{comparison_mode(result)}"
    fig.savefig(stem.with_suffix(".png"), dpi=300)
    fig.savefig(stem.with_suffix(".pdf"))
    plt.close(fig)
    print(f"[figure] wrote: {stem}.png / .pdf")


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--result", type=Path, default=RESULT)
    parser.add_argument("--out-dir", type=Path, default=FIG_DIR)
    args = parser.parse_args(argv)
    result = load_result(args.result)
    make_latency_figure(result, args.out_dir)
    make_steps_figure(result, args.out_dir)


if __name__ == "__main__":
    main()
