#!/usr/bin/env python3
"""EXP-015 R1 corruption controls for the corrected exact identifier.

These workload checks are not a proof against all hash collisions. Results
use exact_structural metadata and a separate exact_comparison directory.
Requires the updated local Hashrope checkout and the model tokenizer.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from scripts.exp015_bench import COMPARISON_MODE, DEFAULT_RESULTS_DIR, check_output_mode


def build_parser():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--model", default="Qwen/Qwen2.5-7B-Instruct-1M")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--data-dir", type=Path, default=REPO_ROOT / "data" / "canonical")
    parser.add_argument("--results-dir", type=Path, default=DEFAULT_RESULTS_DIR)
    return parser


def main(argv=None):
    args = build_parser().parse_args(argv)
    output = args.results_dir / "exp015_negative_control_R1.json"
    check_output_mode(output)
    from src.exp015_identify import build_r1_stream, negative_control

    rows = []
    for dataset in ("sharegpt_sample.jsonl", "lmsys_sample.jsonl"):
        path = args.data_dir / dataset
        sha = hashlib.sha256(path.read_bytes()).hexdigest()[:16]
        stream = build_r1_stream(str(path), n_pairs=80, seed=args.seed,
                                 tokenizer_name=args.model)
        tested, controls = 0, []
        for item in stream["items"]:
            cached, query = item["cached_tokens"], item["query_tokens"]
            true_lcp = item["oracle_lcp"]
            if true_lcp < 2:
                continue
            for label, pos in (("first", 0), ("mid", true_lcp // 2),
                               ("last", true_lcp - 1)):
                result = negative_control(cached, query, corrupt_pos=pos, with_radix=True)
                controls.append({"where": label, "pos": result["pos"],
                                 "true_lcp": result["true_lcp"], "results": result["results"],
                                 "detected": result["detected"], "arms": result["arms_checked"]})
            tested += 1
            if tested >= 15:
                break
        all_detected = bool(controls) and all(c["detected"] for c in controls)
        rows.append({"dataset": dataset, "sha16": sha, "pairs_tested": tested,
                     "controls": len(controls), "all_detected": all_detected,
                     "sample": controls[:3]})
        print(f"{dataset}: sha16={sha} pairs_tested={tested} "
              f"controls={len(controls)} all_detected={all_detected}", flush=True)

    result = {"experiment": "EXP-015", "claim": "S3", "regime": "R1",
              "comparison_mode": COMPARISON_MODE, "seed": args.seed, "model": args.model,
              "purpose": "Empirical corrupted-cached-entry checks on real ShareGPT/LMSYS streams",
              "rows": rows, "all_detected": all(r["all_detected"] for r in rows)}
    args.results_dir.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print("R1 ALL CONTROLS DETECTED:", result["all_detected"])
    print("wrote", output)
    return 0 if result["all_detected"] else 1


if __name__ == "__main__":
    sys.exit(main())
