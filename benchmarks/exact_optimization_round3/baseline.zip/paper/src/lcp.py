"""
EXP-005: Exact longest-common-prefix comparison on persistent ropes.

lcp_brute
    Byte-by-byte comparison oracle. O(LCP_length). Used as correctness
    ground truth, not for performance claims.

lcp_hash
    Historical name retained for experiment compatibility. Delegates to
    hashrope.rope_lcp, which compares content exactly and skips shared or
    verified periodic ranges. Independent inputs may require a linear scan;
    the former hash-only binary search's O(log² N) claim does not apply.

lcp_hash_counted
    Compatibility wrapper returning (lcp_length, num_hash_calls). Exact LCP
    issues zero substring-hash queries. This count is not a measure of its
    byte comparisons, visited ranges, or total work.

Requires the updated hashrope package exposing rope_lcp. Archived experiments
using hashrope 0.2.2 with the former hash-only paper helper are not measurements
of this exact-comparison implementation.
"""
from __future__ import annotations

from hashrope import PolynomialHash, rope_lcp
from hashrope.rope import Node


def lcp_brute(a: bytes, b: bytes) -> int:
    """Byte-by-byte LCP oracle. O(min(len(a), len(b))) worst case."""
    n = min(len(a), len(b))
    for i in range(n):
        if a[i] != b[i]:
            return i
    return n


def lcp_hash(rope_a: Node, rope_b: Node, h: PolynomialHash) -> int:
    """Exact byte LCP; ``h`` is retained for compatibility and is unused.

    Comparing ropes built under different hash profiles is supported because
    the result depends on their bytes, not their stored fingerprints.
    """
    return rope_lcp(rope_a, rope_b)


def lcp_hash_counted(
    rope_a: Node, rope_b: Node, h: PolynomialHash
) -> tuple[int, int]:
    """Return exact LCP and zero hash calls; this is not a step-count bound."""
    return lcp_hash(rope_a, rope_b, h), 0
