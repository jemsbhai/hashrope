"""
src/paged_attention_cow.py

Faithful CPU reimplementation of PagedAttention's block-table copy-on-write,
the EXP-019 (claim B3) competitive baseline for hashrope branch/snapshot.

Reference: Woosuk Kwon et al., "Efficient Memory Management for Large Language
Model Serving with PagedAttention," SOSP 2023, pp. 611-626 (arXiv:2309.06180).
  * Structure  = sec 4.2 (KV Cache Manager): a per-sequence *block table* over a
    pool of fixed-size *physical blocks*; each physical block carries a
    *reference count*.
  * Copy-on-write = sec 4.4 (Application to Other Decoding Scenarios -- parallel
    sampling / beam search): forking maps a child's logical blocks to the same
    physical blocks (incrementing refcounts); a write into a shared (refcount>1)
    partial last block allocates a new physical block, copies that one block's
    contents, decrements the old refcount, and writes into the copy. COW copies
    *exactly one block*, and only when the new token lands in a shared block.

This models the block-table *bookkeeping* (allocation, ref-counting, COW) whose
asymptotics we benchmark -- it is NOT a CUDA attention kernel. Each token slot
stores a token id (standing in for that token's KV vectors), which is what we
checksum for token-identity. Fork cost is O(ceil(N/B)) (copy the block table +
incref each shared block); append is O(1) amortized (write in place; occasionally
one COW block-copy or a new-block allocation).
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class PhysicalBlock:
    """A fixed-capacity physical KV block holding up to `capacity` token ids."""
    block_id: int
    capacity: int
    slots: list[int] = field(default_factory=list)


class PhysicalBlockPool:
    """Block engine (sec 4.2): allocates / frees fixed-size physical blocks and
    tracks per-block reference counts. `block_size` (B) = token slots per block.
    """

    def __init__(self, block_size: int) -> None:
        if block_size <= 0:
            raise ValueError("block_size must be positive")
        self._block_size = block_size
        self._blocks: dict[int, PhysicalBlock] = {}
        self._refcount: dict[int, int] = {}
        self._next_id = 0
        self._num_allocations = 0

    @property
    def block_size(self) -> int:
        return self._block_size

    def allocate(self) -> int:
        """Allocate a fresh physical block (refcount 1); return its block id."""
        bid = self._next_id
        self._next_id += 1
        self._blocks[bid] = PhysicalBlock(block_id=bid, capacity=self._block_size)
        self._refcount[bid] = 1
        self._num_allocations += 1
        return bid

    def incref(self, block_id: int) -> None:
        self._refcount[block_id] += 1

    def decref(self, block_id: int) -> None:
        """Decrement refcount; reclaim the block when it reaches 0."""
        rc = self._refcount[block_id] - 1
        if rc <= 0:
            del self._refcount[block_id]
            del self._blocks[block_id]
        else:
            self._refcount[block_id] = rc

    def ref_count(self, block_id: int) -> int:
        return self._refcount.get(block_id, 0)

    def block(self, block_id: int) -> PhysicalBlock:
        return self._blocks[block_id]

    @property
    def num_live_blocks(self) -> int:
        """Number of physical blocks currently allocated (refcount > 0)."""
        return len(self._blocks)

    @property
    def num_allocations(self) -> int:
        """Cumulative count of allocate() calls (monotone; for op-count guards)."""
        return self._num_allocations


class PagedSequence:
    """A sequence's logical view (sec 4.2): a block table (list of physical block
    ids, in logical order) over a shared pool, plus the total token length.
    """

    def __init__(self, pool: PhysicalBlockPool) -> None:
        self.pool = pool
        self.block_table: list[int] = []
        self.length: int = 0

    @property
    def num_blocks(self) -> int:
        return len(self.block_table)

    @property
    def filled_in_last(self) -> int:
        """Number of filled slots in the last logical block (0 if empty).

        Left-to-right fill invariant: a new block is allocated only when the last
        block is full, so num_blocks == ceil(length / B) and
        filled_in_last == length - (num_blocks - 1) * B.
        """
        if not self.block_table:
            return 0
        return self.length - (len(self.block_table) - 1) * self.pool.block_size


def append_token(seq: PagedSequence, token: int) -> dict:
    """Append one token to `seq` (one decode step). See module docstring for the
    three cases. Returns {"cow": bool, "new_block": bool, "blocks_copied": int}.
    """
    pool = seq.pool
    B = pool.block_size
    stats = {"cow": False, "new_block": False, "blocks_copied": 0}

    # Case 1: empty sequence, or last block full -> allocate a fresh block.
    if seq.length == 0 or seq.filled_in_last == B:
        bid = pool.allocate()
        seq.block_table.append(bid)
        pool.block(bid).slots.append(token)
        seq.length += 1
        stats["new_block"] = True
        return stats

    last = seq.block_table[-1]

    # Case 2: partial last block shared by >1 sequence -> copy-on-write one block.
    if pool.ref_count(last) > 1:
        new_bid = pool.allocate()
        new_blk = pool.block(new_bid)
        new_blk.slots = list(pool.block(last).slots)   # copy the one shared block
        pool.decref(last)
        seq.block_table[-1] = new_bid
        new_blk.slots.append(token)
        seq.length += 1
        stats["cow"] = True
        stats["blocks_copied"] = 1
        return stats

    # Case 3: exclusive partial last block -> write in place.
    pool.block(last).slots.append(token)
    seq.length += 1
    return stats


def fork(seq: PagedSequence) -> PagedSequence:
    """Fork `seq` (sec 4.4): the child's block table is a copy of the parent's
    (same physical block ids, in logical order); incref each shared physical
    block. O(ceil(N/B)) work -- copy the table + one incref per block."""
    child = PagedSequence(seq.pool)
    child.block_table = list(seq.block_table)
    child.length = seq.length
    for bid in child.block_table:
        seq.pool.incref(bid)
    return child


def build_sequence(pool: PhysicalBlockPool, tokens: list[int]) -> PagedSequence:
    """Build a fresh sequence holding `tokens`, filling physical blocks
    left-to-right (the untimed setup path) via repeated append_token."""
    seq = PagedSequence(pool)
    for tok in tokens:
        append_token(seq, tok)
    return seq


def materialize(seq: PagedSequence) -> list[int]:
    """Walk the block table and return the token-id list of length seq.length."""
    out: list[int] = []
    for bid in seq.block_table:
        out.extend(seq.pool.block(bid).slots)
    return out


def free_sequence(seq: PagedSequence) -> None:
    """Release a sequence (e.g., a pruned beam candidate): decref each block in
    its table; the pool reclaims blocks whose refcount reaches 0."""
    for bid in seq.block_table:
        seq.pool.decref(bid)
    seq.block_table = []
    seq.length = 0
