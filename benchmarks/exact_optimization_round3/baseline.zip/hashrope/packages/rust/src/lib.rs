//! # hashrope
//!
//! A BB[2/7] weight-balanced binary tree augmented with polynomial hash
//! metadata at every node.
//!
//! Zero dependencies. `no_std + alloc` compatible.
//! All arithmetic uses Mersenne prime modular reduction.
//! Nodes are stored in a contiguous arena for cache-friendly access.

#![no_std]
extern crate alloc;

pub mod polynomial_hash;
pub mod rope;
pub mod sliding;

pub use polynomial_hash::{mersenne_mod, mersenne_mul, phi, PolynomialHash, MERSENNE_61};
pub use rope::{
    Arena, Node, NodeId, NodeInner, LAZY_SENTINEL,
    rope_concat, rope_equal, rope_from_bytes, rope_hash, rope_height, rope_lcp, rope_len,
    rope_range_equal, rope_range_lcp, rope_repeat, rope_split, rope_substr_hash, rope_to_bytes, validate_rope,
};
pub use sliding::SlidingWindow;
