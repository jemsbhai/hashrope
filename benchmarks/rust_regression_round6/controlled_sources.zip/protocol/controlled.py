"""Frozen dual-slot diagnostic; separate from the original full-sequence workloads."""
import argparse
import ctypes
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import shutil
import statistics
import subprocess
import sys
import time
import zipfile

HERE = Path(__file__).resolve().parent
CACHE = HERE / ".cache/controlled"
CORES = {"released": HERE / ".cache/released_033_reference/hashrope/packages/rust",
         "current": HERE / ".cache/baseline/hashrope/packages/rust"}
BUILDS = {"released_current": {"a": "released", "b": "current"},
          "current_released": {"a": "current", "b": "released"},
          "current_current": {"a": "current", "b": "current"}}
CASES = ["concat_growing", "concat_prewarmed", "churn_combined_1M",
         "churn_edit_only_1M", "churn_compare_only_1M"]
FILES = ["controlled.py", "controlled.rs", "PLAN.md", "baseline_manifest.json",
         "concat_capacity_probe.json", "concat_capacity_probe_manifest.json"]
EXPECTED_MASK = sum(1 << i for i in range(0, 50, 2))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    with Path(path).open("x", encoding="utf-8", newline="\n") as output:
        json.dump(value, output, indent=2)
        output.write("\n")


def source_map(core):
    return {path.relative_to(core).as_posix(): sha(path)
            for path in sorted((core / "src").rglob("*.rs"))}


def schedule():
    result = []
    for seed in range(1, 7):
        builds = list(BUILDS)
        rotation = (seed - 1) % 3
        builds = builds[rotation:] + builds[:rotation]
        if seed > 3:
            builds.reverse()
        modes = ["unpinned", "pinned"] if seed % 2 else ["pinned", "unpinned"]
        for mode in modes:
            for build in builds:
                result.append({"seed": seed, "churn_seed": (seed - 1) % 3 + 1,
                               "affinity_mode": mode, "build": build})
    assert len(result) == 36
    return result


def validate_capacity():
    probe = json.loads((HERE / "concat_capacity_probe.json").read_text())
    manifest = json.loads((HERE / "concat_capacity_probe_manifest.json").read_text())
    parent = json.loads((HERE / "baseline_manifest.json").read_text())
    assert probe["manifest_sha256"] == sha(HERE / "concat_capacity_probe_manifest.json")
    for label, parent_name in [("released", "released_033_reference"), ("round5", "baseline")]:
        item = manifest["arms"][label]
        assert item["original_sources"] == parent["source_sha256"][parent_name]
        assert item["archive_sha256"] == parent["archives"][item["archive"]]
    assert set(probe["arms"]) == {"released", "round5"}
    for rows in probe["arms"].values():
        assert len(rows) == 16
        for setup, start, end, capacity in [
                ("original_growth", 513, 14513, 16384),
                ("prewarmed_no_growth", 50513, 64513, 65536)]:
            group = [row for row in rows if row["setup"] == setup]
            assert [row["sample"] for row in group] == list(range(-1, 7))
            assert group[0]["nodes_after"] == start
            assert group[-1]["nodes_after"] == end
            assert group[-1]["capacity_after"] == capacity
            if setup == "prewarmed_no_growth":
                for row in group[1:]:
                    assert row["capacity_before"] == row["capacity_after"] == 65536
                    assert all(row["allocator"][key] == 0
                               for key in ["allocations", "reallocations", "deallocations"])
            else:
                assert [row["allocator"]["reallocations"] for row in group[1:]] == [2, 1, 0, 1, 0, 0, 0]
            for row in group:
                assert (row["root_length"], row["root_weight"], row["fingerprint"]) == (
                    131072, 256, 2138634010386205116)


def freeze():
    if CACHE.exists() or (HERE / "controlled_freeze.json").exists():
        raise SystemExit("Frozen controlled build already exists; preserve it.")
    validate_capacity()
    parent = json.loads((HERE / "baseline_manifest.json").read_text())
    for name, expected in parent["archives"].items():
        assert sha(HERE / name) == expected
    for label, core in CORES.items():
        parent_name = "baseline" if label == "current" else "released_033_reference"
        expected = parent["source_sha256"][parent_name]
        assert {"packages/rust/" + name: value for name, value in source_map(core).items()} == {
            name: value for name, value in expected.items() if name.endswith(".rs")}
        assert sha(core / "Cargo.toml") == expected["packages/rust/Cargo.toml"]
    CACHE.mkdir(parents=True)
    metadata = {"frozen_utc": datetime.now(timezone.utc).isoformat(),
                "protocol": "Separate five-case controlled diagnostic, no production instrumentation.",
                "files": {name: sha(HERE / name) for name in FILES},
                "parent_archives": parent["archives"],
                "source_sha256": {label: source_map(core) for label, core in CORES.items()},
                "schedule": schedule(), "builds": {}}
    for label, mapping in BUILDS.items():
        project = CACHE / label
        (project / "src").mkdir(parents=True)
        shutil.copyfile(HERE / "controlled.rs", project / "src/main.rs")
        for slot, core in mapping.items():
            destination = project / f"slot_{slot}"
            shutil.copytree(CORES[core] / "src", destination / "src")
            # Default u64 engine has zero dependencies. Only diagnostic manifests
            # and crate identities differ; copied runtime bytes stay unchanged.
            (destination / "Cargo.toml").write_text(
                f'[package]\nname="hashrope-diagnostic-slot-{slot}"\nversion="0.0.0"\nedition="2021"\n'
                '[features]\ndefault=[]\nbigint=[]\n', encoding="utf-8", newline="\n")
            assert source_map(destination) == metadata["source_sha256"][core]
        (project / "Cargo.toml").write_text(
            '[package]\nname="hashrope-controlled-regression"\nversion="0.0.0"\nedition="2021"\n'
            '[dependencies]\nslot_a={package="hashrope-diagnostic-slot-a",path="slot_a"}\n'
            'slot_b={package="hashrope-diagnostic-slot-b",path="slot_b"}\n[workspace]\n',
            encoding="utf-8", newline="\n")
        lock = ('# This file is automatically @generated by Cargo.\n'
                '# It is not intended for manual editing.\nversion = 4\n\n'
                '[[package]]\nname = "hashrope-controlled-regression"\nversion = "0.0.0"\n'
                'dependencies = [\n "hashrope-diagnostic-slot-a",\n "hashrope-diagnostic-slot-b",\n]\n\n'
                '[[package]]\nname = "hashrope-diagnostic-slot-a"\nversion = "0.0.0"\n\n'
                '[[package]]\nname = "hashrope-diagnostic-slot-b"\nversion = "0.0.0"\n')
        (project / "Cargo.lock").write_text(lock, encoding="utf-8", newline="\n")
        metadata["builds"][label] = {"mapping": mapping,
            "input_sha256": {path.relative_to(project).as_posix(): sha(path)
                             for path in sorted(project.rglob("*")) if path.is_file()}}
    with zipfile.ZipFile(HERE / "controlled_sources.zip", "x", zipfile.ZIP_DEFLATED) as archive:
        for name in FILES:
            archive.write(HERE / name, f"protocol/{name}")
        for path in sorted(CACHE.rglob("*")):
            if path.is_file():
                archive.write(path, f"builds/{path.relative_to(CACHE).as_posix()}")
    metadata["source_archive_sha256"] = sha(HERE / "controlled_sources.zip")
    save(HERE / "controlled_freeze.json", metadata)
    print("Frozen three dual-slot sources and 36-process schedule; no build or timing yet.")


def verify_freeze():
    frozen = json.loads((HERE / "controlled_freeze.json").read_text())
    assert frozen["schedule"] == schedule()
    assert all(sha(HERE / name) == value for name, value in frozen["files"].items())
    assert sha(HERE / "controlled_sources.zip") == frozen["source_archive_sha256"]
    for label, item in frozen["builds"].items():
        assert all(sha(CACHE / label / name) == value for name, value in item["input_sha256"].items())
    for label, core in CORES.items():
        assert source_map(core) == frozen["source_sha256"][label]
    for name, value in frozen["parent_archives"].items():
        assert sha(HERE / name) == value
    return frozen


def build():
    frozen = verify_freeze()
    output = HERE / "controlled_build"
    output.mkdir(exist_ok=False)
    metadata = {"freeze_sha256": sha(HERE / "controlled_freeze.json"),
                "rustc": subprocess.check_output(["rustc", "-Vv"], text=True),
                "cargo": subprocess.check_output(["cargo", "-V"], text=True),
                "environment": {key: os.environ.get(key) for key in ["RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "RUSTC_WRAPPER"]},
                "builds": {}}
    for label, item in frozen["builds"].items():
        command = ["cargo", "build", "--release", "--offline", "--locked", "--manifest-path",
                   str(CACHE / label / "Cargo.toml")]
        result = subprocess.run(command, capture_output=True)
        (output / f"{label}.stdout").write_bytes(result.stdout)
        (output / f"{label}.stderr").write_bytes(result.stderr)
        if result.returncode:
            raise SystemExit(f"Build failed: {label}; retained logs in {output}")
        path = CACHE / label / "target/release/hashrope-controlled-regression.exe"
        metadata["builds"][label] = {"command": command, "binary": str(path), "binary_sha256": sha(path),
            "lock_sha256": sha(CACHE / label / "Cargo.lock"),
            "stdout_sha256": sha(output / f"{label}.stdout"), "stderr_sha256": sha(output / f"{label}.stderr")}
    verify_freeze()
    with zipfile.ZipFile(HERE / "controlled_binaries.zip", "x", zipfile.ZIP_DEFLATED) as archive:
        for label, item in metadata["builds"].items():
            archive.write(item["binary"], f"{label}/hashrope-controlled-regression.exe")
    metadata["binary_archive_sha256"] = sha(HERE / "controlled_binaries.zip")
    save(HERE / "controlled_build.json", metadata)
    print("Three diagnostic builds ready; no measurements run.")


def parse(raw, run, mask):
    lines = iter(raw.splitlines())
    meta = next(lines).split("\t")
    assert meta[0] == "meta" and len(meta) == 6
    values = list(map(int, meta[1:]))
    seed, churn_seed, requested, initial, actual = values
    assert seed == run["seed"] and churn_seed == run["churn_seed"] and requested == mask
    assert initial > 0 and actual == (requested or initial)
    assert requested & initial == requested
    result = {"metadata": dict(seed=seed, churn_seed=churn_seed, requested_affinity=requested,
                              initial_affinity=initial, actual_affinity=actual), "cases": []}
    used = set()
    for order in range(5):
        parts = next(lines).split("\t")
        assert len(parts) == 5 and parts[0] == "calibration" and int(parts[2]) == order
        case, count, pattern = parts[1], int(parts[3]), parts[4]
        assert case in CASES and case not in used and 1 <= count <= 4096
        used.add(case)
        expected_pattern = "ABBA" if (seed + CASES.index(case)) % 2 == 0 else "BAAB"
        assert pattern == expected_pattern
        case_result = {"case": case, "order": order, "sessions_per_block": count,
                       "pattern": pattern, "blocks": []}
        concat = case.startswith("concat")
        sample_count, operations = (7, 2000) if concat else (1, 50)
        expected_answer = 131072 if concat else (1000000 if case == "churn_edit_only_1M" else EXPECTED_MASK)
        for position, slot in enumerate(pattern.lower()):
            sessions = []
            for session in range(count):
                durations = []
                telemetry = None
                for sample in range(sample_count):
                    row = next(lines).split("\t")
                    assert len(row) == 14 and row[:5] == ["sample", case, str(order), str(position), slot]
                    assert list(map(int, row[5:8])) == [session, sample, operations]
                    duration, answer, start, end, root, leaf = map(int, row[8:])
                    assert duration > 0 and answer == expected_answer and root > 0 and leaf > 0
                    if concat:
                        assert start == (513 if case == "concat_growing" else 50513)
                        assert end == start + 14000
                    elif case == "churn_compare_only_1M":
                        assert end == start and start > 0
                    else:
                        assert end > start > 0
                    current = dict(answer=answer, nodes_start=start, nodes_end=end,
                                   root_address=root, leaf_address=leaf)
                    assert telemetry is None or current == telemetry
                    telemetry = current
                    durations.append(duration)
                sessions.append({**telemetry, "durations_ns": durations,
                                 "operations_per_sample": operations,
                                 "statistic_ns": statistics.median(durations) / operations})
            row = next(lines).split("\t")
            assert len(row) == 12 and row[:5] == ["block", case, str(order), str(position), slot]
            n, ops = map(int, row[5:7])
            statistic = float(row[7])
            timed_ns, wall_ns, cpu0, cpu1 = map(int, row[8:])
            assert n == count and ops == count * operations * sample_count
            assert timed_ns == sum(sum(s["durations_ns"]) for s in sessions)
            assert math.isclose(statistic, statistics.median(s["statistic_ns"] for s in sessions), rel_tol=1e-12)
            assert wall_ns >= timed_ns
            if requested:
                cpu = requested.bit_length() - 1
                assert cpu0 == cpu1 == cpu
            case_result["blocks"].append(dict(position=position, slot=slot, sessions=sessions,
                statistic_ns=statistic, timed_ns=timed_ns, wall_ns=wall_ns, operations=ops,
                timed_mean_ns=timed_ns / ops, wall_per_operation_ns=wall_ns / ops,
                processor_before=cpu0, processor_after=cpu1))
        result["cases"].append(case_result)
    assert next(lines, None) is None and used == set(CASES)
    return result


def available_affinity():
    assert os.name == "nt", "Pinned diagnostic implemented for Windows only"
    kernel = ctypes.WinDLL("kernel32", use_last_error=True)
    kernel.GetCurrentProcess.restype = ctypes.c_void_p
    kernel.GetProcessAffinityMask.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_size_t)]
    process, system = ctypes.c_size_t(), ctypes.c_size_t()
    if not kernel.GetProcessAffinityMask(kernel.GetCurrentProcess(), ctypes.byref(process), ctypes.byref(system)):
        raise ctypes.WinError(ctypes.get_last_error())
    assert process.value > 0
    return process.value, system.value


def verify_build():
    verify_freeze()
    built = json.loads((HERE / "controlled_build.json").read_text())
    assert built["freeze_sha256"] == sha(HERE / "controlled_freeze.json")
    assert built["binary_archive_sha256"] == sha(HERE / "controlled_binaries.zip")
    assert set(built["builds"]) == set(BUILDS)
    with zipfile.ZipFile(HERE / "controlled_binaries.zip") as archive:
        assert set(archive.namelist()) == {f"{label}/hashrope-controlled-regression.exe" for label in BUILDS}
        for label, item in built["builds"].items():
            assert sha(item["binary"]) == item["binary_sha256"]
            assert hashlib.sha256(archive.read(f"{label}/hashrope-controlled-regression.exe")).hexdigest() == item["binary_sha256"]
            assert sha(CACHE / label / "Cargo.lock") == item["lock_sha256"]
            for suffix in ["stdout", "stderr"]:
                assert sha(HERE / "controlled_build" / f"{label}.{suffix}") == item[f"{suffix}_sha256"]
    return built


def run():
    frozen = verify_freeze()
    built = verify_build()
    output = HERE / "controlled_results"
    output.mkdir(exist_ok=False)
    available, system = available_affinity()
    pin_mask = available & -available
    results = {"freeze_sha256": sha(HERE / "controlled_freeze.json"),
        "build_sha256": sha(HERE / "controlled_build.json"),
        "python": sys.version, "platform": platform.platform(),
        "initial_affinity_mask": available, "system_affinity_mask": system, "pinned_mask": pin_mask,
        "schedule": frozen["schedule"], "runs": []}
    save(output / "context.json", {key: value for key, value in results.items() if key != "runs"})
    results["context_sha256"] = sha(output / "context.json")
    for index, item in enumerate(frozen["schedule"]):
        label = f'{index:02d}_{item["build"]}_{item["affinity_mode"]}_s{item["seed"]}'
        print(f"Controlled {index + 1}/36: {label}", flush=True)
        mask = pin_mask if item["affinity_mode"] == "pinned" else 0
        binary = built["builds"][item["build"]]["binary"]
        assert sha(binary) == built["builds"][item["build"]]["binary_sha256"]
        command = [binary, str(item["seed"]), str(mask)]
        start = time.monotonic()
        try:
            process = subprocess.run(command, capture_output=True, timeout=600)
            stdout, stderr, status = process.stdout, process.stderr, process.returncode
        except subprocess.TimeoutExpired as error:
            stdout, stderr, status = error.stdout or b"", error.stderr or b"", "timeout"
        (output / f"{label}.tsv").write_bytes(stdout)
        (output / f"{label}.stderr").write_bytes(stderr)
        record = {**item, "index": index, "command": command, "exit_status": status,
                  "wall_seconds": time.monotonic() - start,
                  "raw_file": f"{label}.tsv", "raw_sha256": sha(output / f"{label}.tsv"),
                  "stderr_file": f"{label}.stderr", "stderr_sha256": sha(output / f"{label}.stderr")}
        save(output / f"{label}.json", record)
        assert status == 0, f"Stopped fixed cohort at {label}; no failed-process replacement"
        assert not stderr, f"Unexpected stderr in {label}"
        parsed = parse(stdout.decode(), item, mask)
        results["runs"].append({**record, **parsed})
    verify_build()
    save(output / "results.json", results)
    print("All 36 processes completed; source and executable identities unchanged.")


def ratio_summary(values):
    logs = [math.log(row["ratio"]) for row in values]
    assert len(logs) == 6
    mean = statistics.mean(logs)
    margin = 2.570581835636305 * statistics.stdev(logs) / math.sqrt(6)
    return {"process_pairs": values, "geomean_ratio": math.exp(mean),
            "ratio_min": min(row["ratio"] for row in values),
            "ratio_max": max(row["ratio"] for row in values),
            "numerator_slower_count": sum(row["ratio"] > 1 for row in values),
            "exploratory_95pct_log_t_interval": [math.exp(mean - margin), math.exp(mean + margin)],
            "denominator_median_ns": statistics.median(row["denominator_ns"] for row in values),
            "numerator_median_ns": statistics.median(row["numerator_ns"] for row in values)}


def summarize():
    built = verify_build()
    output = HERE / "controlled_results"
    results = json.loads((output / "results.json").read_text())
    assert results["freeze_sha256"] == sha(HERE / "controlled_freeze.json")
    assert results["build_sha256"] == sha(HERE / "controlled_build.json")
    assert results["context_sha256"] == sha(output / "context.json")
    assert json.loads((output / "context.json").read_text()) == {
        key: value for key, value in results.items() if key not in ["runs", "context_sha256"]}
    assert [{key: row[key] for key in ["seed", "churn_seed", "affinity_mode", "build"]}
            for row in results["runs"]] == schedule()
    total_samples = 0
    for index, run in enumerate(results["runs"]):
        label = f'{index:02d}_{run["build"]}_{run["affinity_mode"]}_s{run["seed"]}'
        assert run["index"] == index and run["exit_status"] == 0
        assert run["raw_file"] == f"{label}.tsv" and run["stderr_file"] == f"{label}.stderr"
        sidecar = json.loads((output / f"{label}.json").read_text())
        assert sidecar == {key: run[key] for key in sidecar}
        assert sha(output / run["raw_file"]) == run["raw_sha256"]
        assert sha(output / run["stderr_file"]) == run["stderr_sha256"]
        assert (output / run["stderr_file"]).stat().st_size == 0
        mask = results["pinned_mask"] if run["affinity_mode"] == "pinned" else 0
        assert run["command"] == [built["builds"][run["build"]]["binary"], str(run["seed"]), str(mask)]
        parsed = parse((output / run["raw_file"]).read_text(), run, mask)
        assert parsed["cases"] == run["cases"] and parsed["metadata"] == run["metadata"]
        total_samples += sum(len(s["durations_ns"]) for c in run["cases"] for b in c["blocks"] for s in b["sessions"])
    summaries = []
    for mode in ["unpinned", "pinned"]:
        for build in BUILDS:
            matching = [run for run in results["runs"] if run["build"] == build and run["affinity_mode"] == mode]
            assert [run["seed"] for run in matching] == list(range(1, 7))
            denominator, numerator = ("b", "a") if build == "current_released" else ("a", "b")
            for case in CASES:
                estimates = {}
                for metric in ["statistic_ns", "timed_mean_ns", "wall_per_operation_ns"]:
                    pairs = []
                    for run in matching:
                        group = next(c for c in run["cases"] if c["case"] == case)
                        medians = {slot: statistics.median(b[metric] for b in group["blocks"] if b["slot"] == slot)
                                   for slot in ["a", "b"]}
                        pairs.append(dict(seed=run["seed"], churn_seed=run["churn_seed"], pattern=group["pattern"],
                            sessions_per_block=group["sessions_per_block"], denominator_ns=medians[denominator],
                            numerator_ns=medians[numerator], ratio=medians[numerator] / medians[denominator]))
                    estimates[metric] = ratio_summary(pairs)
                summaries.append(dict(affinity_mode=mode, build=build, case=case,
                    ratio_definition="slot_b / slot_a (identical current code)" if build == "current_current" else "current / released",
                    estimates=estimates))
    save(output / "summary.json", {"results_sha256": sha(output / "results.json"),
        "processes": 36, "blocks": 720, "samples": total_samples,
        "statistical_scope": "Six fresh process ratios per cell; inner samples are not independent replicates. Exploratory 95% log-t intervals, no multiplicity adjustment or equivalence assertion.",
        "summary": summaries})
    print(f"Verified and summarized 36 processes, 720 blocks, {total_samples} raw samples.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=["freeze", "build", "run", "summarize"])
    action = parser.parse_args().action
    {"freeze": freeze, "build": build, "run": run, "summarize": summarize}[action]()
