# hashrope

A BB[2/7] weight-balanced binary tree augmented with polynomial hash metadata at every node.

**Zero dependencies. `no_std + alloc` compatible. Rust 2021 edition.**

## What it does

hashrope is a rope data structure where every node carries a polynomial hash over a Mersenne prime field. This enables:

- **O(log w) concat and split** with strict BB[2/7] weight-balance via recursive join
- **O(log q) repetition encoding** via `RepeatNode` — represent `s^q` without materializing
- **O(log w) substring hashing** without allocating new nodes
- **O(1) whole-sequence hash** at any node
- **Exact equality and longest common prefix** with shared-subtree and periodicity shortcuts
- **Bounded-memory sliding window** with eviction

The logarithmic tree traversal bounds do not include all arithmetic costs: uncached powers and repeat accumulators add work, and joins that repeatedly decompose repeats can require more than logarithmic arithmetic work. `from_bytes` bounds leaves to 512 bytes, limiting partial-leaf copying and hashing. Substring hashing allocates no rope nodes, but may grow the exponent cache. Whole-sequence hash access returns cached metadata; lazy arenas require materialization first.

Hash arithmetic uses Mersenne prime (2⁶¹ − 1) modular reduction via bit shifts. Nodes are stored in a contiguous arena (`Vec<NodeInner>`) for cache-friendly access. No reference counting, no atomic operations.

## Install

The exact comparison and profile-checking APIs in this checkout are unreleased.
To use them, point the consuming crate's `hashrope` path dependency at this
checkout's `packages/rust` directory. The registry dependency below describes
the published API and does not yet supply these new methods.

```toml
[dependencies]
hashrope = "0.2"
```

## Quick start

```rust
use hashrope::Arena;

let mut a = Arena::new();

// Build ropes from byte slices
let hello = a.from_bytes(b"hello ");
let world = a.from_bytes(b"world");

// Concat: O(log w)
let hw = a.concat(hello, world);
assert_eq!(a.hash(hw), a.hash_bytes(b"hello world"));
assert_eq!(a.len(hw), 11);

// Split at any byte position: O(log w)
let (left, right) = a.split(hw, 6);
assert_eq!(a.to_bytes(left), b"hello ");
assert_eq!(a.to_bytes(right), b"world");

// Rejoin preserves hash
let rejoined = a.concat(left, right);
assert_eq!(a.hash(rejoined), a.hash(hw));

// Repeat: O(log q) — no materialization
let pattern = a.from_bytes(b"ab");
let repeated = a.repeat(pattern, 1_000_000); // "ab" × 10⁶
assert_eq!(a.len(repeated), 2_000_000);

// Substring hash without allocation: O(log w)
let h = a.substr_hash(hw, 0, 5); // hash of "hello"
assert_eq!(h, a.hash_bytes(b"hello"));

// Validate BB[2/7] invariants (for debugging)
a.validate(hw);
```

## Node types

| Type | Description | Weight |
|------|-------------|--------|
| `Leaf(data)` | Raw byte slice | 1 |
| `Internal(left, right)` | Binary node with BB[2/7] balance | w(left) + w(right) |
| `Repeat(child, q)` | Virtual repetition, q ≥ 2 | w(child) × q |

## Arena allocation

All nodes live in a single `Arena`. Node references are `u32` indices. They identify nodes only within their owning arena: passing another arena's numeric ID is invalid even if that ID happens to exist locally. The arena is dropped as a unit — no per-node deallocation. This gives cache-friendly traversal and zero-cost structural sharing.

```rust
let mut a = Arena::new();
let node = a.from_bytes(b"data");
println!("Nodes allocated: {}", a.node_count());
```

## Sliding window

For streaming applications, `SlidingWindow` maintains a bounded-size rope with O(log w) append and eviction:

```rust
use hashrope::{SlidingWindow, MERSENNE_61};

let mut sw = SlidingWindow::new(512, 512, MERSENNE_61, 257);
sw.append_bytes(b"incoming data...");
// Oldest bytes are evicted when the window exceeds d_max + m_max
```

## Polynomial hash properties

The hash function is a polynomial rolling hash over GF(2⁶¹ − 1):

- **Homomorphic under concatenation**: `H(A‖B) = H(A)·x^|B| + H(B)`
- **Homomorphic under repetition**: `H(s^q) = H(s)·Φ(q, x^|s|)` where Φ is computed in O(log q)
- **Noncryptographic fingerprints**: useful for candidate matching, never proof of content identity

The default base remains **131** for compatibility. `[0,131]` and `[1,0]` both hash to **263**, before modular reduction. A larger modulus or an additional modulus with the same base does not separate this pair. Existing fingerprint values and default parameters are unchanged.

A polynomial collision bound requires a probability model. For two distinct equal-length byte strings of length `n`, fixed before a base is chosen uniformly from `{2,...,p-1}`, the usual root bound is at most `(n-1)/(p-2)` for `p > 256`. The fixed public default base has no such random-base guarantee, particularly for inputs chosen after the parameters are known.

## Exact comparison

```rust
use hashrope::Arena;

let mut arena = Arena::new();
let a = arena.from_bytes(&[0, 131, 42]);
let b = arena.from_bytes(&[1, 0, 42]);
assert_eq!(arena.hash(a), arena.hash(b)); // A candidate match only.
assert!(!arena.equal(a, b));
assert_eq!(arena.lcp(a, b), 0);
```

`Arena::equal(a,b)` compares represented bytes regardless of tree shape. `Arena::lcp(a,b)` returns the exact longest common prefix length **in bytes**. Free functions `rope_equal(&arena,a,b)` and `rope_lcp(&arena,a,b)` provide the same operations. Across arenas, use `left_arena.equal_across(a,&right_arena,b)` or `lcp_across`; each handle belongs to the corresponding arena. Different prime/base profiles and eager/lazy modes are supported.

For windows, `equal_range(a,a_start,b,b_start,length)` and `lcp_range` compare equal-length ranges without splitting or hashing. Their `_across` variants accept the other arena before `b`. Free wrappers are `rope_range_equal` and `rope_range_lcp`. Bounds are checked without overflowing: invalid ranges panic, and empty ranges at a rope's end are valid.

These operations read bytes and immutable structure, without using fingerprints, materializing lazy hashes, splitting ropes, or allocating flattened content. Identical shared ranges are skipped. Ordinary trees use a traversal over borrowed leaf slices with no heap allocations. Each node inspected spends a visit budget bounded by eight times the combined number of stored arena nodes. Reaching that budget or a repeat transfers the unverified suffix to the cached engine; the verified prefix is not rescanned. Clearly compressed roots go directly to that engine. This protects compact shared DAGs from unbounded expansion without adding metadata to nodes or slowing constructors.

In the cached engine, repeated ranges with periods `p` and `q` are proved equal by checking at most `p+q-gcd(p,q)` bytes before skipping further copies (the Fine-Wilf periodicity bound); that checking can itself skip shared or repeated structure. A per-call cache records ranges already proved equal, avoiding repeated traversal of shared DAGs.

Exact comparison is **not a logarithmic worst-case operation**. Independently stored equal content can require reading the entire common prefix plus tree traversal. If fallback is needed, cache storage grows with the number of ranges proved equal, and its ordered lookups add logarithmic overhead. Recursive stack depth follows the compared structure. Sharing and repetition often make comparisons much cheaper, but do not provide a universal bound in compressed size.

## Hash profile consistency

An arena's prime/base profile is fixed at construction. `hasher_mut()` remains available for operations such as warming the exponent cache. Replacing the hasher with the same parameters is supported. Replacing it with different parameters causes subsequent arena hashing, construction, edits and validation to panic before using inconsistent metadata; create a new arena to change profiles. Byte access, length access and exact comparisons remain available because they do not depend on fingerprint parameters.

`validate` checks tree structure and unchanged arena parameters; it does not recompute every cached fingerprint. Lazy `hash` still returns `LAZY_SENTINEL` before materialization. Exact comparison handles lazy ropes directly.

## Benchmarks

```sh
cargo bench
```

Uses [Criterion.rs](https://github.com/bheisler/criterion.rs) with HTML reports.

The [exact-comparison optimization report](../../benchmarks/exact_optimization/README.md)
also reruns the same edit-plus-target workload against Ropey 1.6.1. At 1 MB,
the independent-target mean falls from 0.894 to 0.189 ms/cycle (4.73× faster),
versus Ropey's 0.111 ms. With shared ancestry it falls from 0.0589 to 0.0169 ms
(3.49× faster), versus Ropey's 0.0374 ms. Each mean uses nine fresh processes;
the report includes dispersion, smaller sizes, setup exclusions, and raw data.
Ropey remains faster in both regimes at 10 KB and 100 KB, and for independent
targets throughout this grid; structural sharing
allows the optimized Hashrope path to win the 1 MB shared-ancestry case.

## Changelog

See [CHANGELOG.md](CHANGELOG.md).

## License

MIT
